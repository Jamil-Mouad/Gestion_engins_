--
-- PostgreSQL database dump
--

\restrict FsGuBOHkuJnfxNOSelghfkBcLywPABCuoUCxyHPShBqwjrwW4A82hcgpSMKMhEZ

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg12+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: check_camion_type(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_camion_type() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    vtype TEXT;
BEGIN
    SELECT type INTO vtype FROM vehicules WHERE id = NEW.vehicule_id;
    IF vtype <> 'camion' THEN
        RAISE EXCEPTION
            'vehicule % has type %, not camion — cannot insert into camions',
            NEW.vehicule_id, vtype;
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: process_releve(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.process_releve() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prev_km     INT;
    prev_heures INT;
    delta_km    INT;
    delta_h     INT;
BEGIN
    SELECT compteur_km, compteur_heures
      INTO prev_km, prev_heures
      FROM vehicules
     WHERE id = NEW.vehicule_id;

    delta_km := GREATEST(0, COALESCE(NEW.compteur_km,     prev_km)     - COALESCE(prev_km,     0));
    delta_h  := GREATEST(0, COALESCE(NEW.compteur_heures, prev_heures) - COALESCE(prev_heures, 0));

    UPDATE vehicules
       SET compteur_km     = CASE WHEN NEW.compteur_km     IS NOT NULL THEN NEW.compteur_km     ELSE compteur_km     END,
           compteur_heures = CASE WHEN NEW.compteur_heures IS NOT NULL THEN NEW.compteur_heures ELSE compteur_heures END
     WHERE id = NEW.vehicule_id;

    IF delta_km > 0 THEN
        UPDATE pneus
           SET km_parcourus = km_parcourus + delta_km
         WHERE vehicule_id = NEW.vehicule_id
           AND actif = true;
    END IF;

    IF delta_h > 0 THEN
        UPDATE suivi_vidanges
           SET compteur_nbh_actuel = compteur_nbh_actuel + delta_h
         WHERE vehicule_id = NEW.vehicule_id;
    END IF;

    RETURN NEW;
END;
$$;


--
-- Name: refresh_kpis(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.refresh_kpis() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_kpis_dispo;
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_kpis_couts_mois;
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_kpis_km_mois;

    INSERT INTO kpi_matview_refresh (matview_name, last_refresh)
    VALUES
        ('mv_kpis_dispo',      NOW()),
        ('mv_kpis_couts_mois', NOW()),
        ('mv_kpis_km_mois',    NOW())
    ON CONFLICT (matview_name) DO UPDATE
        SET last_refresh = EXCLUDED.last_refresh;
END;
$$;


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


--
-- Name: update_pneu_status(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_pneu_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_km_restant INTEGER;
BEGIN
    v_km_restant := NEW.expected_life_km - NEW.km_parcourus;
    IF v_km_restant <= 0 THEN
        NEW.status := 'empty';
    ELSIF v_km_restant <= 5000 THEN
        NEW.status := 'warn';
    ELSE
        NEW.status := 'ok';
    END IF;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_conversations (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    titre character varying(100) DEFAULT 'Nouvelle conversation'::character varying NOT NULL,
    favori boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_conversations_id_seq OWNED BY public.ai_conversations.id;


--
-- Name: ai_embeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_embeddings (
    id bigint NOT NULL,
    source_table character varying(40) NOT NULL,
    source_id bigint NOT NULL,
    contenu text NOT NULL,
    embedding public.vector(384) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_embeddings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_embeddings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_embeddings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_embeddings_id_seq OWNED BY public.ai_embeddings.id;


--
-- Name: ai_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_messages (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    role character varying(10) NOT NULL,
    content text NOT NULL,
    sources jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ai_messages_role_check CHECK (((role)::text = ANY (ARRAY[('user'::character varying)::text, ('assistant'::character varying)::text])))
);


--
-- Name: ai_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_messages_id_seq OWNED BY public.ai_messages.id;


--
-- Name: arrivage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.arrivage (
    id bigint NOT NULL,
    citerne_id bigint NOT NULL,
    date_arrivage date NOT NULL,
    numero_bl character varying(40),
    quantite_litres numeric(12,2) NOT NULL,
    prix_unitaire_ht numeric(10,4),
    valeur_ht numeric(14,2),
    fournisseur character varying(120),
    source character varying(20) DEFAULT 'SAISIE'::character varying NOT NULL,
    created_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT arrivage_prix_unitaire_ht_check CHECK (((prix_unitaire_ht IS NULL) OR (prix_unitaire_ht > (0)::numeric))),
    CONSTRAINT arrivage_quantite_litres_check CHECK ((quantite_litres > (0)::numeric)),
    CONSTRAINT arrivage_source_check CHECK (((source)::text = ANY (ARRAY[('SAISIE'::character varying)::text, ('IMPORT'::character varying)::text])))
);


--
-- Name: arrivage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.arrivage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: arrivage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.arrivage_id_seq OWNED BY public.arrivage.id;


--
-- Name: bareme_jaugeage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bareme_jaugeage (
    id bigint NOT NULL,
    citerne_id bigint NOT NULL,
    hauteur_cm numeric(7,2) NOT NULL,
    litres numeric(12,2) NOT NULL,
    CONSTRAINT bareme_jaugeage_hauteur_cm_check CHECK ((hauteur_cm >= (0)::numeric)),
    CONSTRAINT bareme_jaugeage_litres_check CHECK ((litres >= (0)::numeric))
);


--
-- Name: bareme_jaugeage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bareme_jaugeage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bareme_jaugeage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bareme_jaugeage_id_seq OWNED BY public.bareme_jaugeage.id;


--
-- Name: citerne; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.citerne (
    id bigint NOT NULL,
    nom character varying(60) DEFAULT 'Citerne principale'::character varying NOT NULL,
    capacite_litres numeric(10,2) NOT NULL,
    densite_kg_par_litre numeric(6,4) DEFAULT 0.845 NOT NULL,
    hauteur_max_cm numeric(7,2),
    stock_initial_litres numeric(12,2) DEFAULT 0 NOT NULL,
    stock_initial_date date NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT citerne_capacite_litres_check CHECK ((capacite_litres > (0)::numeric)),
    CONSTRAINT citerne_densite_kg_par_litre_check CHECK ((densite_kg_par_litre > (0)::numeric)),
    CONSTRAINT citerne_hauteur_max_cm_check CHECK ((hauteur_max_cm > (0)::numeric))
);


--
-- Name: citerne_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.citerne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: citerne_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.citerne_id_seq OWNED BY public.citerne.id;


--
-- Name: composants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.composants (
    id bigint NOT NULL,
    parent_id bigint,
    niveau smallint NOT NULL,
    reference character varying(40),
    designation character varying(120) NOT NULL,
    categorie character varying(40),
    unite character varying(20),
    marque character varying(60),
    prix_unitaire numeric(10,2),
    stock integer DEFAULT 0 NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    cree_par bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    image_url character varying(500),
    vehicule_type character varying(30),
    vehicule_id bigint,
    CONSTRAINT composants_categorie_check CHECK (((categorie)::text = ANY (ARRAY[('moteur'::character varying)::text, ('pneumatique'::character varying)::text, ('freinage'::character varying)::text, ('hydraulique'::character varying)::text, ('electrique'::character varying)::text, ('transmission'::character varying)::text, ('autre'::character varying)::text, ('chassis'::character varying)::text, ('carrosserie'::character varying)::text, ('suspension'::character varying)::text]))),
    CONSTRAINT composants_niveau_check CHECK ((niveau >= 1))
);


--
-- Name: composants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.composants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: composants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.composants_id_seq OWNED BY public.composants.id;


--
-- Name: demandes_achat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demandes_achat (
    id bigint NOT NULL,
    code character varying(20) NOT NULL,
    date_demande timestamp with time zone DEFAULT now() NOT NULL,
    demandeur_id bigint NOT NULL,
    composant_id bigint,
    piece_libre character varying(120),
    reference character varying(40),
    quantite integer DEFAULT 1 NOT NULL,
    motif text,
    urgence character varying(10),
    statut character varying(15) DEFAULT 'Nouvelle'::character varying NOT NULL,
    approbateur_id bigint,
    date_approbation timestamp with time zone,
    raison_rejet text,
    bon_commande_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    demandeur_nom character varying(150),
    photo_url character varying(500),
    CONSTRAINT demandes_achat_statut_check CHECK (((statut)::text = ANY (ARRAY[('Nouvelle'::character varying)::text, ('Approuvée'::character varying)::text, ('Rejetée'::character varying)::text, ('Clôturée'::character varying)::text]))),
    CONSTRAINT demandes_achat_urgence_check CHECK (((urgence)::text = ANY (ARRAY[('Haute'::character varying)::text, ('Moyenne'::character varying)::text, ('Basse'::character varying)::text])))
);


--
-- Name: demandes_achat_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.demandes_achat_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: demandes_achat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.demandes_achat_id_seq OWNED BY public.demandes_achat.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: flyway_schema_history_fleet_core; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history_fleet_core (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: flyway_schema_history_magasin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history_magasin (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: imports_historique; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imports_historique (
    id bigint NOT NULL,
    user_id bigint,
    fichier character varying(255),
    type character varying(30),
    lignes_total integer,
    lignes_ok integer,
    lignes_erreur integer,
    rapport_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT imports_historique_type_check CHECK (((type)::text = ANY (ARRAY[('excel_general'::character varying)::text, ('releves_compteurs'::character varying)::text, ('migration'::character varying)::text])))
);


--
-- Name: imports_historique_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.imports_historique_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: imports_historique_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.imports_historique_id_seq OWNED BY public.imports_historique.id;


--
-- Name: interventions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interventions (
    id bigint NOT NULL,
    vehicule_id bigint NOT NULL,
    type_id smallint NOT NULL,
    composant_id bigint,
    categorie character varying(15) NOT NULL,
    partie character varying(60),
    n_bs character varying(30),
    date_debut timestamp with time zone NOT NULL,
    date_fin timestamp with time zone,
    temps_heures numeric(6,2),
    cout_pieces numeric(10,2) DEFAULT 0 NOT NULL,
    cout_main_oeuvre numeric(10,2) DEFAULT 0 NOT NULL,
    cout_sous_traitance numeric(10,2) DEFAULT 0 NOT NULL,
    cout_total numeric(10,2) GENERATED ALWAYS AS (((cout_pieces + cout_main_oeuvre) + cout_sous_traitance)) STORED,
    observations text,
    demande_achat_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    photo_url character varying(500),
    CONSTRAINT interventions_categorie_check CHECK (((categorie)::text = ANY (ARRAY[('preventive'::character varying)::text, ('corrective'::character varying)::text, ('depannage'::character varying)::text, ('controle'::character varying)::text])))
);


--
-- Name: interventions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.interventions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: interventions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.interventions_id_seq OWNED BY public.interventions.id;


--
-- Name: jaugeage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jaugeage (
    id bigint NOT NULL,
    citerne_id bigint NOT NULL,
    date_jaugeage date NOT NULL,
    hauteur_cm numeric(7,2) NOT NULL,
    litres_mesures numeric(12,2) NOT NULL,
    litres_theoriques numeric(12,2),
    ecart_litres numeric(12,2),
    created_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT jaugeage_hauteur_cm_check CHECK ((hauteur_cm >= (0)::numeric))
);


--
-- Name: jaugeage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jaugeage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jaugeage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jaugeage_id_seq OWNED BY public.jaugeage.id;


--
-- Name: kpi_matview_refresh; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_matview_refresh (
    matview_name character varying(100) NOT NULL,
    last_refresh timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mv_kpis_couts_mois; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_kpis_couts_mois AS
 SELECT (date_trunc('month'::text, date_debut))::date AS mois,
    sum(cout_total) AS cout_total_mad
   FROM public.interventions
  GROUP BY (date_trunc('month'::text, date_debut))
  ORDER BY ((date_trunc('month'::text, date_debut))::date)
  WITH NO DATA;


--
-- Name: vehicules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicules (
    id bigint NOT NULL,
    code character varying(20) NOT NULL,
    type character varying(30) NOT NULL,
    marque character varying(60) NOT NULL,
    modele character varying(60) DEFAULT ''::character varying NOT NULL,
    matricule character varying(20),
    n_chassis character varying(40),
    annee smallint,
    carburant character varying(20),
    statut character varying(20) DEFAULT 'in-service'::character varying NOT NULL,
    date_mise_service date,
    photo_url text,
    actif boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    capacite_tonnes numeric(6,2),
    config_axle character varying(20),
    visite_tech_tracteur_expiration date,
    visite_tech_semi_expiration date,
    carnet_circulation_expiration date,
    metrologie_expiration date,
    extincteur_expiration date,
    batterie_modele character varying(60),
    batterie_date_achat date,
    batterie_date_controle date,
    conso_gasoil_litres_mois numeric(8,2),
    compteur_km integer DEFAULT 0 NOT NULL,
    compteur_heures integer DEFAULT 0 NOT NULL,
    chauffeur_prenom character varying(50),
    chauffeur_nom character varying(50),
    config_axle_semi character varying(20),
    voyages_mois integer,
    km_parcourus integer,
    metrologie_date_controle date,
    CONSTRAINT vehicules_annee_check CHECK (((annee >= 1990) AND (annee <= 2100))),
    CONSTRAINT vehicules_carburant_check CHECK (((carburant)::text = ANY (ARRAY[('gasoil'::character varying)::text, ('essence'::character varying)::text, ('electrique'::character varying)::text, ('hybride'::character varying)::text]))),
    CONSTRAINT vehicules_config_axle_check CHECK (((config_axle)::text = ANY (ARRAY[('4x2'::character varying)::text, ('6x4'::character varying)::text, ('plateau-2x2'::character varying)::text]))),
    CONSTRAINT vehicules_statut_check CHECK (((statut)::text = ANY (ARRAY[('in-service'::character varying)::text, ('workshop'::character varying)::text, ('maintenance'::character varying)::text, ('out-of-service'::character varying)::text]))),
    CONSTRAINT vehicules_type_check CHECK (((type)::text = ANY (ARRAY[('camion'::character varying)::text, ('camion_tracteur'::character varying)::text, ('chariot'::character varying)::text, ('chargeur'::character varying)::text, ('semi_remorque'::character varying)::text, ('voiture'::character varying)::text, ('bus'::character varying)::text, ('balayeuse'::character varying)::text, ('pick_up'::character varying)::text])))
);


--
-- Name: COLUMN vehicules.voyages_mois; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicules.voyages_mois IS 'Number of trips per month (editable, camion types only)';


--
-- Name: COLUMN vehicules.km_parcourus; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicules.km_parcourus IS 'Monthly km driven (editable, camion types only)';


--
-- Name: mv_kpis_dispo; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_kpis_dispo AS
 SELECT (d.day)::date AS jour,
    round((1.0 - ((count(DISTINCT s.vehicule_id))::numeric / (NULLIF(( SELECT count(*) AS count
           FROM public.vehicules
          WHERE (vehicules.actif = true)), 0))::numeric)), 4) AS taux_dispo
   FROM (generate_series((( SELECT (min(interventions.date_debut))::date AS min
           FROM public.interventions))::timestamp with time zone, (CURRENT_DATE)::timestamp with time zone, '1 day'::interval) d(day)
     LEFT JOIN public.interventions s ON ((((s.date_debut)::date <= d.day) AND ((s.date_fin IS NULL) OR ((s.date_fin)::date >= d.day)) AND ((s.categorie)::text = ANY (ARRAY[('corrective'::character varying)::text, ('depannage'::character varying)::text])))))
  GROUP BY d.day
  ORDER BY d.day
  WITH NO DATA;


--
-- Name: releves_compteur; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.releves_compteur (
    id bigint NOT NULL,
    vehicule_id bigint NOT NULL,
    date_releve timestamp with time zone DEFAULT now() NOT NULL,
    compteur_km integer,
    compteur_heures integer,
    source character varying(20),
    import_id bigint,
    created_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT releves_compteur_source_check CHECK (((source)::text = ANY (ARRAY[('manual'::character varying)::text, ('excel_import'::character varying)::text, ('intervention'::character varying)::text])))
);


--
-- Name: mv_kpis_km_mois; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_kpis_km_mois AS
 WITH monthly AS (
         SELECT releves_compteur.vehicule_id,
            (date_trunc('month'::text, releves_compteur.date_releve))::date AS mois,
            max(releves_compteur.compteur_km) AS km_fin,
            lag(max(releves_compteur.compteur_km)) OVER (PARTITION BY releves_compteur.vehicule_id ORDER BY (date_trunc('month'::text, releves_compteur.date_releve))) AS km_debut
           FROM public.releves_compteur
          WHERE (releves_compteur.compteur_km IS NOT NULL)
          GROUP BY releves_compteur.vehicule_id, (date_trunc('month'::text, releves_compteur.date_releve))
        )
 SELECT mois,
    sum(GREATEST(0, (km_fin - COALESCE(km_debut, km_fin)))) AS km_parcourus_mois
   FROM monthly
  GROUP BY mois
  ORDER BY mois
  WITH NO DATA;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    user_id bigint,
    vehicule_id bigint,
    severite character varying(15),
    categorie character varying(20),
    titre character varying(120) NOT NULL,
    detail text,
    target_screen character varying(30),
    target_id bigint,
    lu boolean DEFAULT false NOT NULL,
    email_envoye boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    email_sent_at timestamp with time zone,
    CONSTRAINT notifications_categorie_check CHECK (((categorie)::text = ANY (ARRAY[('seuil_pneu'::character varying)::text, ('seuil_nbh'::character varying)::text, ('seuil_expiration'::character varying)::text, ('demande_achat'::character varying)::text, ('systeme'::character varying)::text, ('ai_chat'::character varying)::text, ('vidange_depasse'::character varying)::text]))),
    CONSTRAINT notifications_severite_check CHECK (((severite)::text = ANY (ARRAY[('critical'::character varying)::text, ('warning'::character varying)::text, ('info'::character varying)::text, ('success'::character varying)::text])))
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: pneu_inspections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pneu_inspections (
    id bigint NOT NULL,
    pneu_id bigint NOT NULL,
    date_inspection timestamp with time zone DEFAULT now() NOT NULL,
    tire_meter integer,
    activity character varying(30) NOT NULL,
    user_id bigint,
    pression_psi numeric(4,1),
    profondeur_32e smallint,
    methode character varying(20),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT pneu_inspections_activity_check CHECK (((activity)::text = ANY (ARRAY[('Installed'::character varying)::text, ('Tread Depth Reading'::character varying)::text, ('Inspection'::character varying)::text, ('Rotation'::character varying)::text, ('Replaced'::character varying)::text])))
);


--
-- Name: pneu_inspections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pneu_inspections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pneu_inspections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pneu_inspections_id_seq OWNED BY public.pneu_inspections.id;


--
-- Name: pneus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pneus (
    id bigint NOT NULL,
    vehicule_id bigint NOT NULL,
    "position" smallint NOT NULL,
    composant_id bigint,
    n_serie character varying(60),
    marque character varying(40),
    date_montage date,
    km_montage integer,
    km_parcourus integer DEFAULT 0 NOT NULL,
    expected_life_km integer DEFAULT 60000 NOT NULL,
    km_restant integer GENERATED ALWAYS AS ((expected_life_km - km_parcourus)) STORED,
    pression_psi numeric(4,1),
    profondeur_32e smallint,
    status character varying(10) DEFAULT 'ok'::character varying NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    photo_url character varying(500),
    reference character varying(40),
    CONSTRAINT pneus_status_check CHECK (((status)::text = ANY (ARRAY[('ok'::character varying)::text, ('warn'::character varying)::text, ('empty'::character varying)::text])))
);


--
-- Name: pneus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pneus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pneus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pneus_id_seq OWNED BY public.pneus.id;


--
-- Name: releves_compteur_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.releves_compteur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: releves_compteur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.releves_compteur_id_seq OWNED BY public.releves_compteur.id;


--
-- Name: sortie_carburant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sortie_carburant (
    id bigint NOT NULL,
    citerne_id bigint NOT NULL,
    date_sortie date NOT NULL,
    totaliseur numeric(14,2),
    quantite_litres numeric(10,2) NOT NULL,
    type_mouvement character varying(20) DEFAULT 'SORTIE'::character varying NOT NULL,
    destination character varying(120) NOT NULL,
    vehicule_id bigint,
    vehicule_code character varying(20),
    tiers boolean DEFAULT false NOT NULL,
    compteur numeric(12,2),
    demandeur character varying(120),
    numero_bs character varying(40),
    source character varying(20) DEFAULT 'SAISIE'::character varying NOT NULL,
    created_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sortie_carburant_quantite_litres_check CHECK ((quantite_litres > (0)::numeric)),
    CONSTRAINT sortie_carburant_source_check CHECK (((source)::text = ANY (ARRAY[('SAISIE'::character varying)::text, ('IMPORT'::character varying)::text]))),
    CONSTRAINT sortie_carburant_type_mouvement_check CHECK (((type_mouvement)::text = ANY (ARRAY[('SORTIE'::character varying)::text, ('RETOUR'::character varying)::text])))
);


--
-- Name: sortie_carburant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sortie_carburant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sortie_carburant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sortie_carburant_id_seq OWNED BY public.sortie_carburant.id;


--
-- Name: suivi_vidanges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suivi_vidanges (
    id bigint NOT NULL,
    vehicule_id bigint NOT NULL,
    composant_id bigint,
    intervalle_nbh integer NOT NULL,
    compteur_nbh_actuel integer DEFAULT 0 NOT NULL,
    nbh_restant integer GENERATED ALWAYS AS ((intervalle_nbh - (compteur_nbh_actuel % intervalle_nbh))) STORED,
    date_dernier_entretien date,
    prochain_entretien_estime date,
    statut character varying(15) DEFAULT 'a_faire'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT suivi_vidanges_statut_check CHECK (((statut)::text = ANY (ARRAY[('a_faire'::character varying)::text, ('en_cours'::character varying)::text, ('fait'::character varying)::text, ('depasse'::character varying)::text])))
);


--
-- Name: suivi_vidanges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suivi_vidanges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suivi_vidanges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suivi_vidanges_id_seq OWNED BY public.suivi_vidanges.id;


--
-- Name: tracteur_semi_assignment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tracteur_semi_assignment (
    id bigint NOT NULL,
    tracteur_id bigint NOT NULL,
    semi_id bigint NOT NULL,
    date_debut date NOT NULL,
    date_fin date,
    actif boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tracteur_semi_assignment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tracteur_semi_assignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tracteur_semi_assignment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tracteur_semi_assignment_id_seq OWNED BY public.tracteur_semi_assignment.id;


--
-- Name: types_intervention; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.types_intervention (
    id smallint NOT NULL,
    libelle character varying(60) NOT NULL
);


--
-- Name: types_intervention_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.types_intervention_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: types_intervention_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.types_intervention_id_seq OWNED BY public.types_intervention.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(255) NOT NULL,
    prenom character varying(60) NOT NULL,
    nom character varying(60) NOT NULL,
    fonction character varying(60),
    matricule_emp character varying(30),
    site character varying(60),
    telephone character varying(20),
    dashboard_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    preferences_notifications jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    refresh_token character varying(512),
    refresh_token_expires_at timestamp with time zone,
    password_reset_otp character varying(6),
    password_reset_otp_expires_at timestamp with time zone,
    password_reset_otp_used_at timestamp with time zone,
    password_reset_token character varying(64),
    password_reset_token_expires_at timestamp with time zone,
    actif boolean DEFAULT true NOT NULL,
    role character varying(32) DEFAULT 'USER'::character varying NOT NULL,
    CONSTRAINT users_role_chk CHECK (((role)::text = ANY (ARRAY[('USER'::character varying)::text, ('ADMIN'::character varying)::text, ('FLEET_MANAGER'::character varying)::text, ('LOGISTIQUE'::character varying)::text, ('MAGASIN'::character varying)::text])))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vehicules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicules_id_seq OWNED BY public.vehicules.id;


--
-- Name: ai_conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_conversations ALTER COLUMN id SET DEFAULT nextval('public.ai_conversations_id_seq'::regclass);


--
-- Name: ai_embeddings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_embeddings ALTER COLUMN id SET DEFAULT nextval('public.ai_embeddings_id_seq'::regclass);


--
-- Name: ai_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_messages ALTER COLUMN id SET DEFAULT nextval('public.ai_messages_id_seq'::regclass);


--
-- Name: arrivage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.arrivage ALTER COLUMN id SET DEFAULT nextval('public.arrivage_id_seq'::regclass);


--
-- Name: bareme_jaugeage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bareme_jaugeage ALTER COLUMN id SET DEFAULT nextval('public.bareme_jaugeage_id_seq'::regclass);


--
-- Name: citerne id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.citerne ALTER COLUMN id SET DEFAULT nextval('public.citerne_id_seq'::regclass);


--
-- Name: composants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composants ALTER COLUMN id SET DEFAULT nextval('public.composants_id_seq'::regclass);


--
-- Name: demandes_achat id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demandes_achat ALTER COLUMN id SET DEFAULT nextval('public.demandes_achat_id_seq'::regclass);


--
-- Name: imports_historique id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imports_historique ALTER COLUMN id SET DEFAULT nextval('public.imports_historique_id_seq'::regclass);


--
-- Name: interventions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interventions ALTER COLUMN id SET DEFAULT nextval('public.interventions_id_seq'::regclass);


--
-- Name: jaugeage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jaugeage ALTER COLUMN id SET DEFAULT nextval('public.jaugeage_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: pneu_inspections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pneu_inspections ALTER COLUMN id SET DEFAULT nextval('public.pneu_inspections_id_seq'::regclass);


--
-- Name: pneus id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pneus ALTER COLUMN id SET DEFAULT nextval('public.pneus_id_seq'::regclass);


--
-- Name: releves_compteur id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.releves_compteur ALTER COLUMN id SET DEFAULT nextval('public.releves_compteur_id_seq'::regclass);


--
-- Name: sortie_carburant id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sortie_carburant ALTER COLUMN id SET DEFAULT nextval('public.sortie_carburant_id_seq'::regclass);


--
-- Name: suivi_vidanges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suivi_vidanges ALTER COLUMN id SET DEFAULT nextval('public.suivi_vidanges_id_seq'::regclass);


--
-- Name: tracteur_semi_assignment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracteur_semi_assignment ALTER COLUMN id SET DEFAULT nextval('public.tracteur_semi_assignment_id_seq'::regclass);


--
-- Name: types_intervention id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types_intervention ALTER COLUMN id SET DEFAULT nextval('public.types_intervention_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vehicules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicules ALTER COLUMN id SET DEFAULT nextval('public.vehicules_id_seq'::regclass);


--
-- Data for Name: ai_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_conversations (id, user_id, titre, favori, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_embeddings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_embeddings (id, source_table, source_id, contenu, embedding, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_messages (id, conversation_id, role, content, sources, created_at) FROM stdin;
\.


--
-- Data for Name: arrivage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.arrivage (id, citerne_id, date_arrivage, numero_bl, quantite_litres, prix_unitaire_ht, valeur_ht, fournisseur, source, created_by, created_at, updated_at) FROM stdin;
47	1	2025-01-01	\N	15200.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
48	1	2025-01-09	ARMA BET	10000.00	9.8800	98800.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
49	1	2025-01-17	\N	17000.00	8.6800	147560.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
50	1	2025-01-29	\N	16000.00	8.8700	141920.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
51	1	2025-02-10	\N	17000.00	9.0600	154020.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
52	1	2025-02-18	\N	16000.00	9.0600	144960.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
53	1	2025-02-24	ARMA BET	10000.00	10.4500	104500.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
54	1	2025-03-05	\N	16000.00	9.0600	144960.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
55	1	2025-03-13	ARMATURE	17000.00	8.3500	141950.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
56	1	2025-03-25	\N	16000.00	8.6900	139040.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
57	1	2025-04-11	\N	16000.00	8.6900	139040.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
58	1	2025-04-19	\N	16000.00	8.2100	131360.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
59	1	2025-04-30	ARMATURE	17000.00	8.2800	140760.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
60	1	2025-05-10	ARMA BET	10000.00	8.1800	81800.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
61	1	2025-05-21	\N	16000.00	7.8000	124800.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
62	1	2025-05-29	\N	16000.00	7.8000	124800.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
63	1	2025-06-17	\N	16000.00	7.9000	126400.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
64	1	2025-07-01	\N	17000.00	8.0000	136000.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
65	1	2025-07-11	\N	17000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
66	1	2025-07-23	\N	10000.00	7.9500	79500.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
67	1	2025-07-29	\N	16000.00	8.4500	135200.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
68	1	2025-08-08	\N	17000.00	8.5300	145010.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
69	1	2025-08-19	\N	16000.00	8.5300	136480.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
70	1	2025-08-29	\N	16000.00	8.5200	136320.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
71	1	2025-09-12	ARMA BET	10000.00	7.6200	76200.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
72	1	2025-09-19	\N	16000.00	8.2000	131200.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
73	1	2025-10-01	\N	16000.00	8.2000	131200.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
74	1	2025-10-10	\N	16000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
75	1	2025-10-22	\N	16000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
76	1	2025-10-29	ARMA BET	10000.00	7.8300	78300.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
77	1	2025-11-05	\N	16000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
78	1	2025-11-14	\N	16000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
79	1	2025-11-25	\N	17000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
80	1	2025-12-05	\N	16000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
81	1	2025-12-17	\N	15000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
82	1	2025-12-26	\N	10000.00	9.1500	91500.00	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
83	1	2026-01-12	\N	16000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
84	1	2026-01-21	ARMABE	10000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
85	1	2026-02-03	\N	10000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
86	1	2026-02-12	\N	16000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
87	1	2026-02-19	\N	15000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
88	1	2026-03-03	\N	10000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
89	1	2026-03-11	\N	14000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
90	1	2026-03-28	\N	16000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
91	1	2026-04-08	\N	17000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
92	1	2026-04-22	\N	17000.00	\N	\N	\N	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
\.


--
-- Data for Name: bareme_jaugeage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bareme_jaugeage (id, citerne_id, hauteur_cm, litres) FROM stdin;
1	1	0.00	0.00
2	1	130.00	10000.00
3	1	260.00	20000.00
\.


--
-- Data for Name: citerne; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.citerne (id, nom, capacite_litres, densite_kg_par_litre, hauteur_max_cm, stock_initial_litres, stock_initial_date, actif, created_at, updated_at) FROM stdin;
1	Citerne principale	20000.00	0.8450	\N	0.00	2025-01-01	t	2026-06-11 20:23:49.506692+00	2026-06-11 20:23:49.506692+00
\.


--
-- Data for Name: composants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.composants (id, parent_id, niveau, reference, designation, categorie, unite, marque, prix_unitaire, stock, actif, cree_par, created_at, updated_at, image_url, vehicule_type, vehicule_id) FROM stdin;
1	\N	1	\N	Moteur	moteur	\N	\N	\N	0	t	\N	2026-04-28 07:30:11.081014+00	2026-04-28 07:30:11.081014+00	\N	\N	\N
2	\N	1	\N	Pneumatique	pneumatique	\N	\N	\N	0	t	\N	2026-04-28 07:30:11.081014+00	2026-04-28 07:30:11.081014+00	\N	\N	\N
3	\N	1	\N	Freinage	freinage	\N	\N	\N	0	t	\N	2026-04-28 07:30:11.081014+00	2026-04-28 07:30:11.081014+00	\N	\N	\N
4	\N	1	\N	Hydraulique	hydraulique	\N	\N	\N	0	t	\N	2026-04-28 07:30:11.081014+00	2026-04-28 07:30:11.081014+00	\N	\N	\N
5	\N	1	\N	Électrique	electrique	\N	\N	\N	0	t	\N	2026-04-28 07:30:11.081014+00	2026-04-28 07:30:11.081014+00	\N	\N	\N
6	\N	1	\N	Transmission	transmission	\N	\N	\N	0	t	\N	2026-04-28 07:30:11.081014+00	2026-04-28 07:30:11.081014+00	\N	\N	\N
7	\N	1	\N	Autre	autre	\N	\N	\N	0	t	\N	2026-04-28 07:30:11.081014+00	2026-04-28 07:30:11.081014+00	\N	\N	\N
8	\N	1	CHA	Châssis	chassis	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
9	\N	1	CAR	Carrosserie	carrosserie	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
10	\N	1	SUS	Suspension	suspension	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
11	1	2	MOT-BLC	Bloc moteur	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
12	1	2	MOT-PST	Pistons	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
13	1	2	MOT-BIE	Bielles	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
14	1	2	MOT-VIL	Vilebrequin	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
15	1	2	MOT-CUL	Culasse	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
16	11	3	MOT-BLC-CYL	Cylindres	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
17	11	3	MOT-BLC-CHM	Chemises	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
18	11	3	MOT-BLC-BCH	Bouchons	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
19	12	3	MOT-PST-SEG	Segments	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
20	12	3	MOT-PST-AXE	Axe piston	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
21	12	3	MOT-PST-CIR	Circlips	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
22	13	3	MOT-BIE-COU	Coussinets	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
23	13	3	MOT-BIE-VIS	Vis de bielle	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
24	14	3	MOT-VIL-PAL	Paliers	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
25	14	3	MOT-VIL-ROU	Roulements	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
26	15	3	MOT-CUL-SOU	Soupapes	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
27	15	3	MOT-CUL-RES	Ressorts	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
28	15	3	MOT-CUL-GUI	Guides	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
29	15	3	MOT-CUL-JOI	Joints	moteur	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
30	3	2	FRE-DIS	Disques	freinage	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
31	3	2	FRE-PLA	Plaquettes	freinage	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
32	3	2	FRE-ETR	Étriers	freinage	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
33	3	2	FRE-PST	Pistons	freinage	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
34	3	2	FRE-DUR	Durites	freinage	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
35	3	2	FRE-VIS	Vis de purge	freinage	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
36	6	2	TRA-EMB	Embrayage	transmission	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
37	6	2	TRA-BOI	Boîte de vitesses	transmission	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
38	6	2	TRA-ARB	Arbres	transmission	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
39	6	2	TRA-ROU	Roulements	transmission	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
40	6	2	TRA-SPI	Joints SPI	transmission	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
41	6	2	TRA-DIF	Différentiel	transmission	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
43	5	2	ELE-FAI	Faisceau électrique	electrique	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
45	5	2	ELE-ECU	ECU	electrique	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
46	5	2	ELE-CAP	Capteurs	electrique	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
47	5	2	ELE-FUS	Fusibles	electrique	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
48	8	2	CHA-LON	Longerons	chassis	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
50	8	2	CHA-SUP	Supports moteur	chassis	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
51	8	2	CHA-BOU	Boulons	chassis	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
52	8	2	CHA-ECR	Écrous	chassis	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
53	8	2	CHA-RON	Rondelles	chassis	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
54	9	2	CAR-CAP	Capot	carrosserie	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
57	54	3	CAR-CAP-CHA	Charnières	carrosserie	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
58	54	3	CAR-CAP-VER	Vérins	carrosserie	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
59	54	3	CAR-CAP-VIS	Vis de fixation	carrosserie	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
66	10	2	SUS-RES	Ressorts	suspension	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
67	10	2	SUS-AMO	Amortisseurs	suspension	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
68	10	2	SUS-BRA	Bras de suspension	suspension	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
69	10	2	SUS-SIL	Silentblocs	suspension	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
70	10	2	SUS-ROT	Rotules	suspension	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 15:42:45.435468+00	\N	\N	\N
49	8	2	CHA-TRA	Traverses	chassis	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 19:25:41.812962+00	/api/v1/files/composant-photos/93b07094-9b89-4343-b7e1-04b958f0d5d0.png	\N	\N
56	9	2	CAR-PCH	Pare-chocs	carrosserie	piece	volvo	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-05 20:56:35.73318+00	/api/v1/files/composant-photos/9b809818-540f-4ab2-bbe0-dcc9d39a28f0.png	\N	\N
79	56	3	exg	filter	pneumatique	piece	volvo	\N	10	t	\N	2026-06-07 07:08:48.627811+00	2026-06-07 07:08:48.627811+00	/api/v1/files/composant-photos/90c8d7fd-82a2-4f25-b342-3722a93bad7c.png	\N	\N
42	5	2	ELE-BAT	Batterie	electrique	\N	\N	\N	0	t	\N	2026-06-05 15:42:45.435468+00	2026-06-10 20:03:04.547075+00	\N	camion_tracteur	\N
3067	45	3	dfghjk	dfghjk	moteur	\N	\N	\N	1	t	\N	2026-06-11 10:16:29.849244+00	2026-06-11 10:16:29.849244+00	\N	\N	\N
\.


--
-- Data for Name: demandes_achat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demandes_achat (id, code, date_demande, demandeur_id, composant_id, piece_libre, reference, quantite, motif, urgence, statut, approbateur_id, date_approbation, raison_rejet, bon_commande_url, created_at, updated_at, demandeur_nom, photo_url) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	init extensions	SQL	V1__init_extensions.sql	1416605933	intersig	2026-04-28 08:30:11.000637	11	t
2	2	init schema	SQL	V2__init_schema.sql	1820735938	intersig	2026-04-28 08:30:11.029656	29	t
4	4	triggers	SQL	V4__triggers.sql	1624168899	intersig	2026-04-28 08:30:11.08628	4	t
5	5	indexes	SQL	V5__indexes.sql	-768491741	intersig	2026-04-28 08:30:11.097445	15	t
6	6	materialized views	SQL	V6__materialized_views.sql	1724407856	intersig	2026-04-28 08:30:11.118314	9	t
7	7	auth refresh tokens	SQL	V7__auth_refresh_tokens.sql	1189730940	intersig	2026-04-28 08:30:11.134557	1	t
3	3	seed lookups	SQL	V3__seed_lookups.sql	-1864542245	intersig	2026-04-28 08:30:11.078494	2	t
8	8	password reset otp	SQL	V8__password_reset_otp.sql	720410648	intersig	2026-04-29 16:54:51.523369	6	t
9	9	password reset token	SQL	V9__password_reset_token.sql	-2084108129	intersig	2026-04-30 07:05:51.908372	5	t
10	10	counters driver to camions	SQL	V10__counters_driver_to_camions.sql	1185507187	intersig	2026-05-21 05:31:41.812397	19	t
11	11	users actif role	SQL	V11__users_actif_role.sql	-2017531275	intersig	2026-05-21 05:31:41.861916	4	t
12	118	ai conversations messages	SQL	V118__ai_conversations_messages.sql	-515888847	intersig	2026-06-08 10:26:04.554775	50	t
\.


--
-- Data for Name: flyway_schema_history_fleet_core; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history_fleet_core (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	11	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	intersig	2026-05-23 16:47:21.163887	0	t
2	101	kpi refresh tracking	SQL	V101__kpi_refresh_tracking.sql	802594057	intersig	2026-05-23 16:47:21.212506	6	t
3	102	users notifications fix	SQL	V102__users_notifications_fix.sql	-1366201509	intersig	2026-05-23 16:47:21.230148	5	t
4	103	pneu warn threshold inclusive	SQL	V103__pneu_warn_threshold_inclusive.sql	599067381	intersig	2026-05-23 16:47:21.239448	1	t
5	104	notifications email sent at	SQL	V104__notifications_email_sent_at.sql	-1950461013	intersig	2026-05-23 16:47:21.244667	7	t
6	105	vehicules search indexes	SQL	V105__vehicules_search_indexes.sql	1308307487	intersig	2026-05-23 16:47:21.256955	10	t
7	106	vehicule single table	SQL	V106__vehicule_single_table.sql	-2116927792	intersig	2026-05-23 17:52:02.458605	12	t
8	107	tracteur semi assignment	SQL	V107__tracteur_semi_assignment.sql	1730094002	intersig	2026-05-25 09:57:31.322496	17	t
9	108	vehicules add camion tracteur	SQL	V108__vehicules_add_camion_tracteur.sql	1496832024	intersig	2026-05-26 14:42:54.900403	12	t
10	109	vehicules matricule nchassis trgm	SQL	V109__vehicules_matricule_nchassis_trgm.sql	167860903	intersig	2026-05-26 14:42:54.928626	6	t
11	110	semi axle config	SQL	V110__semi_axle_config.sql	645937868	intersig	2026-06-04 16:45:07.287771	6	t
12	111	pneu photo url	SQL	V111__pneu_photo_url.sql	344155790	intersig	2026-06-05 07:32:56.318704	11	t
13	112	vehicule kpi fields	SQL	V112__vehicule_kpi_fields.sql	1670845345	intersig	2026-06-05 15:44:54.690554	11	t
14	113	composant hierarchy and image	SQL	V113__composant_hierarchy_and_image.sql	-1134040488	intersig	2026-06-05 16:42:45.419701	21	t
15	114	composant vehicule type	SQL	V114__composant_vehicule_type.sql	-793081455	intersig	2026-06-06 10:33:48.82809	9	t
16	115	drop fournisseur	SQL	V115__drop_fournisseur.sql	-134964559	intersig	2026-06-06 10:33:48.853741	5	t
17	116	intervention photo url	SQL	V116__intervention_photo_url.sql	-501959407	intersig	2026-06-06 18:00:38.068385	9	t
18	117	demande achat demandeur nom and photo	SQL	V117__demande_achat_demandeur_nom_and_photo.sql	521878411	intersig	2026-06-06 18:00:38.098128	2	t
19	118	ai conversations messages	SQL	V118__ai_conversations_messages.sql	1223832715	intersig	2026-06-08 11:47:56.776214	8	t
20	119	ai embeddings pgvector	SQL	V119__ai_embeddings_pgvector.sql	-891479819	intersig	2026-06-08 11:47:56.800496	14	t
21	120	pneus reference and nserie unique	SQL	V120__pneus_reference_and_nserie_unique.sql	1968210780	intersig	2026-06-10 14:30:34.910467	21	t
22	121	vehicules code unique per type	SQL	V121__vehicules_code_unique_per_type.sql	-54756784	intersig	2026-06-10 15:52:04.788647	7	t
23	122	vehicules metrologie date controle	SQL	V122__vehicules_metrologie_date_controle.sql	1235389931	intersig	2026-06-10 15:52:04.809663	1	t
24	123	composants per vehicule	SQL	V123__composants_per_vehicule.sql	118040080	intersig	2026-06-10 15:52:04.818225	417	t
\.


--
-- Data for Name: flyway_schema_history_magasin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history_magasin (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	11	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	intersig	2026-06-11 21:23:49.41276	0	t
2	201	magasin init	SQL	V201__magasin_init.sql	-1107257388	intersig	2026-06-11 21:23:49.468399	16	t
3	202	magasin seed	SQL	V202__magasin_seed.sql	-1746862540	intersig	2026-06-11 21:23:49.504144	1	t
\.


--
-- Data for Name: imports_historique; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.imports_historique (id, user_id, fichier, type, lignes_total, lignes_ok, lignes_erreur, rapport_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: interventions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interventions (id, vehicule_id, type_id, composant_id, categorie, partie, n_bs, date_debut, date_fin, temps_heures, cout_pieces, cout_main_oeuvre, cout_sous_traitance, observations, demande_achat_id, created_at, updated_at, photo_url) FROM stdin;
\.


--
-- Data for Name: jaugeage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jaugeage (id, citerne_id, date_jaugeage, hauteur_cm, litres_mesures, litres_theoriques, ecart_litres, created_by, created_at) FROM stdin;
1	1	2026-06-12	118.60	9123.08	9123.00	0.08	12	2026-06-12 00:35:06.994156+00
\.


--
-- Data for Name: kpi_matview_refresh; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kpi_matview_refresh (matview_name, last_refresh) FROM stdin;
mv_kpis_dispo	2026-05-23 15:47:21.220232+00
mv_kpis_couts_mois	2026-05-23 15:47:21.220232+00
mv_kpis_km_mois	2026-05-23 15:47:21.220232+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, vehicule_id, severite, categorie, titre, detail, target_screen, target_id, lu, email_envoye, created_at, updated_at, email_sent_at) FROM stdin;
\.


--
-- Data for Name: pneu_inspections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pneu_inspections (id, pneu_id, date_inspection, tire_meter, activity, user_id, pression_psi, profondeur_32e, methode, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pneus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pneus (id, vehicule_id, "position", composant_id, n_serie, marque, date_montage, km_montage, km_parcourus, expected_life_km, pression_psi, profondeur_32e, status, actif, created_at, updated_at, photo_url, reference) FROM stdin;
\.


--
-- Data for Name: releves_compteur; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.releves_compteur (id, vehicule_id, date_releve, compteur_km, compteur_heures, source, import_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sortie_carburant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sortie_carburant (id, citerne_id, date_sortie, totaliseur, quantite_litres, type_mouvement, destination, vehicule_id, vehicule_code, tiers, compteur, demandeur, numero_bs, source, created_by, created_at, updated_at) FROM stdin;
4969	1	2025-01-02	2876818.00	577.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	268451.00	ABDELALI	201585	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4973	1	2025-01-03	2877123.00	127.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7217.60	YOUSSEF	201589	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4975	1	2025-01-03	2877765.00	560.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1057083.00	SAID	201591	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4986	1	2025-01-04	2879210.00	41.00	SORTIE	BERLINGO 41521A73	\N	487	f	10246.00	MEJJAD	201602	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4998	1	2025-01-06	2880876.00	51.00	SORTIE	HYUNDAI 15991W6	\N	470	f	169322.00	HOUSSIN	201614	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4955	1	2025-01-01	2875141.00	25.00	SORTIE	LINDE	\N	428	f	3934.20	HASSAN	201571	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5008	1	2025-01-07	2882147.00	129.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7227.30	YOUSSEF	201624	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5021	1	2025-01-08	2884437.00	452.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1058242.00	SAID	201637	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5022	1	2025-01-08	2884794.00	357.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	58.00	ABDENNASER	201638	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5025	1	2025-01-08	2885147.00	118.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7136.60	YOUSSEF	201641	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5038	1	2025-01-09	2886465.00	43.00	SORTIE	MANITOU	\N	485	f	2423.80	ABDELKHALEK	201654	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5040	1	2025-01-09	2886982.00	352.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	61.00	MOHAMED	201656	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5041	1	2025-01-09	2887026.00	44.00	SORTIE	MANITOU	\N	486	f	2248.30	JAWAD	201657	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5045	1	2025-01-09	2887621.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	169647.00	HOUSSIN	201661	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5048	1	2025-01-10	2888642.00	835.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	270897.00	ABDELALI	201664	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5049	1	2025-01-10	2888670.00	28.00	SORTIE	BERLINGO 41521A73	\N	487	f	10713.00	MEJJAD	201665	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5053	1	2025-01-10	2888978.00	18.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201669	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5058	1	2025-01-10	2889397.00	131.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7247.10	YOUSSEF	201674	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5067	1	2025-01-11	2890408.00	39.00	SORTIE	BERLINGO 50313A6	\N	8	f	445387.00	RACHID	201683	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5069	1	2025-01-11	2890586.00	58.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	102661.00	MOBARAK	201685	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5079	1	2025-01-13	2892119.00	348.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	61.00	ABDELHAFID	201695	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5082	1	2025-01-13	2892341.00	120.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7256.90	YOUSSEF	201698	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5086	1	2025-01-13	2892451.00	8.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201702	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5100	1	2025-01-15	2894957.00	305.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	484.00	ABDENNASER	201716	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5102	1	2025-01-15	2895028.00	43.00	SORTIE	MANITOU	\N	485	f	2444.50	ABDELMALEK	201718	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5104	1	2025-01-15	2895240.00	135.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7267.30	YOUSSEF	201720	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5111	1	2025-01-15	2895562.00	48.00	SORTIE	HYUNDAI 15991W6	\N	470	f	169948.00	HOUSSIN	201727	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5116	1	2025-01-16	2896627.00	545.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1059708.00	SAID	201732	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5117	1	2025-01-16	2896985.00	358.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	58.00	SULAYMAN	201733	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5119	1	2025-01-16	2897876.00	709.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	273057.00	ABDELALI	201735	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5129	1	2025-01-17	2899363.00	31.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201745	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5133	1	2025-01-17	2899738.00	41.00	SORTIE	BERLINGO 41521A73	\N	487	f	11439.00	MEJJAD	201749	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5135	1	2025-01-17	2899816.00	28.00	SORTIE	HYUNDAI 18516A73	\N	470	f	294865.00	HAMZA	201751	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5141	1	2025-01-18	2900821.00	156.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7279.50	YOUSSEF	201757	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5142	1	2025-01-18	2901139.00	318.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	513.00	AHMAD	201758	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5157	1	2025-01-20	2902755.00	114.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7288.90	YOUSSEF	201773	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5161	1	2025-01-20	2903134.00	40.00	SORTIE	MANITOU	\N	486	f	2273.50	JAWAD	201777	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5164	1	2025-01-20	2903392.00	49.00	SORTIE	HYUNDAI 15991W6	\N	470	f	170256.00	HOUSSIN	201780	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5173	1	2025-01-21	2904883.00	303.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	476.00	ABDELHAFID	201789	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5174	1	2025-01-21	2904929.00	46.00	SORTIE	MANITOU	\N	485	f	2468.50	ABDELMALEK	201790	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5175	1	2025-01-21	2905054.00	125.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7298.90	YOUSSEF	201791	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5183	1	2025-01-22	2905675.00	54.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	103308.00	MOBARAK	201799	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5185	1	2025-01-22	2905758.00	33.00	SORTIE	BOBCAT 414	\N	414	f	4410.00	IBRAHIM	201801	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5186	1	2025-01-22	2906384.00	626.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1061377.00	SAID	201802	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5197	1	2025-01-23	2907995.00	123.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7308.80	YOUSSEF	201813	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5198	1	2025-01-23	2908339.00	344.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	569.00	SULAYMAN	201814	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5199	1	2025-01-23	2908652.00	313.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	949.00	ABDENNASER	201815	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5206	1	2025-01-23	2909540.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	170568.00	HOUSSIN	201822	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5214	1	2025-01-24	2910442.00	34.00	SORTIE	BERLINGO 41521A73	\N	487	f	12059.00	MEJJAD	201830	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5216	1	2025-01-24	2911207.00	700.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	275075.00	ABDELALI	201833	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5231	1	2025-01-25	2912488.00	119.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	9318.40	YOUSSEF	201848	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5237	1	2025-01-25	2912921.00	16.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201854	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5248	1	2025-01-27	2915122.00	680.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1063178.00	SAID	201865	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5250	1	2025-01-27	2915443.00	300.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	979.00	MOHAMED	201867	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5251	1	2025-01-27	2915576.00	133.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7330.00	YOUSSEF	201868	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5252	1	2025-01-27	2915617.00	41.00	SORTIE	MANITOU	\N	485	f	2488.70	ABDELMALEK	201869	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5266	1	2025-01-29	2916956.00	152.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7342.50	YOUSSEF	201894	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5269	1	2025-01-29	2917599.00	36.00	SORTIE	MANITOU	\N	486	f	2295.00	JAWAD	201897	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5277	1	2025-01-30	2918590.00	342.00	SORTIE	VOLVO 87667E6	\N	KF	t	309961.00	MOHAMED	201906	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5279	1	2025-01-30	2919412.00	755.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	277312.00	ABDELALI	201908	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5285	1	2025-01-30	2919799.00	13.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201914	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5289	1	2025-01-31	2920363.00	36.00	SORTIE	BERLINGO 41521A73	\N	487	f	12689.00	MEJJAD	201918	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5290	1	2025-01-31	2920417.00	54.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	103938.00	MOBARAK	201919	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5300	1	2025-01-31	2921368.00	3.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201929	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5301	1	2025-01-31	2921958.00	590.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1064657.00	SAID	201930	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5303	1	2025-01-31	2922097.00	51.00	SORTIE	HYUNDAI 15991W6	\N	470	f	171211.00	HOUSSIN	201932	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5309	1	2025-02-01	2923015.00	116.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7351.60	YOUSSEF	201938	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5310	1	2025-02-01	2923322.00	307.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	997.00	SULAYMAN	201939	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5311	1	2025-02-01	2923355.00	33.00	SORTIE	BERLINGO 50313A6	\N	8	f	445791.00	RACHID	201940	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5327	1	2025-02-03	2925031.00	303.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	1350.00	ABDENNASER	201956	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5330	1	2025-02-03	2925822.00	576.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	279083.00	ABDELALI	201959	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5331	1	2025-02-03	2926301.00	479.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1065885.00	SAID	201960	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5332	1	2025-02-03	2926406.00	105.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7359.70	YOUSSEF	201961	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5334	1	2025-02-03	2926593.00	30.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201963	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5344	1	2025-02-04	2928046.00	51.00	SORTIE	MANITOU	\N	485	f	2515.50	HASSAN	201973	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5359	1	2025-02-05	2929950.00	111.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7368.30	YOUSSEF	201988	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5360	1	2025-02-05	2930003.00	53.00	SORTIE	HYUNDAI 15991W6	\N	470	f	171519.00	HOUSSIN	201989	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5362	1	2025-02-05	2930720.00	560.00	SORTIE	VOLVO 21393W6	\N	KF	t	353984.00	HICHAM	201991	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5376	1	2025-02-10	2932526.00	299.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	1390.00	SULAYMAN	201036	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5377	1	2025-02-10	2932856.00	330.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	1504.00	ABDELHAFID	201037	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5378	1	2025-02-10	2933165.00	310.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	1541.00	MOHAMED	201038	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5380	1	2025-02-10	2933418.00	62.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	104869.00	MOBARAK	201040	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5385	1	2025-02-10	2934040.00	47.00	SORTIE	HYUNDAI 15991W6	\N	470	f	171819.00	HOUSSIN	201045	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5386	1	2025-02-10	2934367.00	327.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	1835.00	ABDENNASER	201046	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5395	1	2025-02-11	2935484.00	138.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7394.00	YOUSSEF	201055	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5400	1	2025-02-11	2938143.00	2000.00	SORTIE	SINASTONE	\N	SINASTONE	t	\N	REDOUANE	201060	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5402	1	2025-02-11	2938215.00	38.00	SORTIE	MANITOU	\N	485	f	2565.20	HASSAN	201062	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5420	1	2025-02-13	2940931.00	152.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7406.60	YOUSSEF	201080	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5424	1	2025-02-13	2941253.00	34.00	SORTIE	MANITOU	\N	485	f	2585.60	HASSAN	201084	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5431	1	2025-02-14	2942425.00	583.00	SORTIE	VOLVO 805B6	\N	KF	t	1184954.00	ALI	201091	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5434	1	2025-02-14	2942549.00	42.00	SORTIE	MANITOU	\N	486	f	2347.00	JAWAD	201094	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5437	1	2025-02-14	2943300.00	500.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	282217.00	ABDELALI	201097	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5438	1	2025-02-14	2943329.00	29.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201098	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5439	1	2025-02-14	2943386.00	57.00	SORTIE	HYUNDAI 15991W6	\N	470	f	172201.00	HOUSSIN	201099	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5443	1	2025-02-15	2944086.00	397.00	SORTIE	VOLVO 74802B6	\N	KF	t	1194592.00	IDRISS	201103	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5445	1	2025-02-15	2944183.00	47.00	SORTIE	BERLINGO 41521A73	\N	487	f	14237.00	MEJJAD	201105	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5447	1	2025-02-15	2944388.00	33.00	SORTIE	BERLINGO 50313A6	\N	8	f	446176.00	RACHID	201107	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5451	1	2025-02-15	2945275.00	136.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7418.30	YOUSSEF	201111	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5456	1	2025-02-15	2945778.00	29.00	SORTIE	MANITOU	\N	485	f	2603.00	HASSAN	201116	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5458	1	2025-02-15	2946123.00	322.00	SORTIE	VOLVO 87667E6	\N	KF	t	314219.00	TEWIJER	201118	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5463	1	2025-02-17	2947151.00	665.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1068835.00	SAID	201123	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5474	1	2025-02-18	2948597.00	103.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7426.80	YOUSSEF	201134	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5479	1	2025-02-18	2949162.00	36.00	SORTIE	MANITOU	\N	485	f	2623.80	JAWAD	201139	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5487	1	2025-02-19	2950130.00	320.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	2000.00	ABDELHAFID	201147	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5489	1	2025-02-19	2950802.00	307.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	2002.00	AHMAD	201149	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5491	1	2025-02-19	2951441.00	320.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	1850.00	SULAYMAN	201151	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5493	1	2025-02-19	2951520.00	52.00	SORTIE	HYUNDAI 15991W6	\N	470	f	172524.00	HOSSAM	201153	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5502	1	2025-02-20	2952886.00	319.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	2280.00	ABDENNASER	201162	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5503	1	2025-02-20	2952929.00	43.00	SORTIE	BERLINGO 41521A73	\N	487	f	15040.00	MEJJAD	201163	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5510	1	2025-02-20	2953610.00	267.00	SORTIE	MIT 61383H6	\N	KF	t	565006.00	MOHAMED	201170	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5511	1	2025-02-20	2953814.00	204.00	SORTIE	VOLVO 87667E6	\N	KF	t	325995.00	ABDERRAHIM	201171	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5512	1	2025-02-20	2954417.00	603.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1070385.00	SAID	201172	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5513	1	2025-02-20	2954718.00	301.00	SORTIE	VOLVO 74802B6	\N	KF	t	1195553.00	IDRISS	201173	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5514	1	2025-02-20	2954818.00	100.00	SORTIE	MAN 10362B6	\N	KF	t	993153.00	MUSTAPHA	201174	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5522	1	2025-02-21	2955913.00	129.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7439.90	YOUSSEF	201182	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5524	1	2025-02-21	2955998.00	58.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	105525.00	MBAREK	201184	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5525	1	2025-02-21	2956269.00	271.00	SORTIE	950H	\N	KF	t	\N	MOUNIR	201185	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5527	1	2025-02-21	2956637.00	41.00	SORTIE	MANITOU	\N	485	f	2648.00	ABDELMALEK	201187	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5531	1	2025-02-21	2957528.00	659.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	284216.00	ABDELALI	201191	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5532	1	2025-02-21	2957980.00	452.00	SORTIE	VOLVO 21393W6	\N	KF	t	401545.00	AZEHARI	201192	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5533	1	2025-02-21	2958085.00	105.00	SORTIE	VOLVO 60818W6	\N	KF	t	394275.00	ABDELAZIZ	201193	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5537	1	2025-02-22	2959013.00	408.00	SORTIE	VOLVO 25370A7	\N	KF	t	1102083.00	MOHAMED	201197	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5543	1	2025-02-22	2960225.00	752.00	SORTIE	VOLVO 74805B6	\N	KF	t	118768.00	ALI	201203	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5548	1	2025-02-22	2960380.00	10.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201208	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5549	1	2025-02-22	2960425.00	45.00	SORTIE	MANITOU	\N	486	f	\N	JAWAD	201209	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5562	1	2025-02-24	2962182.00	160.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7448.30	KARS	201222	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5566	1	2025-02-24	2962330.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	172836.00	HOUSSIN	201226	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5567	1	2025-02-24	2962649.00	319.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	9145.00	CHOUAIB	201227	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5586	1	2025-02-26	2964940.00	50.00	SORTIE	LINDE ARM	\N	ARMATURE	t	\N	MOAD	201246	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5587	1	2025-02-26	2965615.00	675.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1072093.00	SAID	201247	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5588	1	2025-02-26	2965629.00	14.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201248	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5596	1	2025-02-27	2966430.00	44.00	SORTIE	BERLINGO 41521A73	\N	487	f	15881.00	MEJJAD	201256	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5598	1	2025-02-27	2966836.00	155.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7460.00	KARS	201258	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5603	1	2025-02-27	2967011.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	\N	HOUSSIN	201263	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5613	1	2025-02-28	2968829.00	294.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	2404.00	ABDELHAFID	201273	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5614	1	2025-02-28	2969123.00	294.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	2455.00	MOHAMED	201274	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5615	1	2025-02-28	2969413.00	290.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	2207.00	SULAYMAN	201275	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5617	1	2025-02-28	2969858.00	301.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	2687.00	ABDENNASER	201277	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5620	1	2025-02-28	2970333.00	7.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201280	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5630	1	2025-03-01	2972299.00	848.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	286662.00	ABDELALI	201290	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5636	1	2025-03-01	2973078.00	439.00	SORTIE	MAN  28661D1	\N	ARMATURE	t	1073201.00	SAID	201296	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5589	1	2025-02-26	2965716.00	87.00	SORTIE	MAN 4790B8	\N	403	f	306488.00	KARDODI	201249	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5640	1	2025-03-03	2973506.00	126.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7469.90	LKARS	201300	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5641	1	2025-03-03	2973543.00	37.00	SORTIE	HYUNDAI 15991W6	\N	470	f	1733160.00	HOUCINE	201301	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5648	1	2025-03-03	2974373.00	38.00	SORTIE	MANITOU	\N	485	f	2666.90	ABDELMALEK	201308	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5650	1	2025-03-03	2974548.00	39.00	SORTIE	BERLINGO 41521A73	\N	487	f	16603.00	MEJJAD	201310	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5655	1	2025-03-04	2975037.00	34.00	SORTIE	BERLINGO 50313A6	\N	8	f	446580.00	RACHID	201315	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5658	1	2025-03-05	2975272.00	142.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7480.60	MOHAMED	201326	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5664	1	2025-03-05	2975845.00	41.00	SORTIE	MANITOU	\N	486	f	2401.00	JAWAD	201332	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5674	1	2025-03-06	2976939.00	57.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	106184.00	MBAREK	201342	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5675	1	2025-03-06	2976994.00	55.00	SORTIE	HYUNDAI 15991W6	\N	470	f	173687.00	HOUCINE	201343	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5683	1	2025-03-07	2978021.00	276.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1073907.00	SAID	201351	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5685	1	2025-03-07	2978215.00	144.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7491.30	LKARS	201353	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5686	1	2025-03-07	2978254.00	39.00	SORTIE	BOBCAT 414	\N	414	f	4420.00	BRAHIM	201354	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5694	1	2025-03-08	2979245.00	321.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	2943.00	ABDELHAFID	201362	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5695	1	2025-03-08	2979261.00	16.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201363	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5696	1	2025-03-08	2979296.00	35.00	SORTIE	BERLINGO 41521A73	\N	487	f	17270.00	MEJJAD	201364	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5704	1	2025-03-10	2980417.00	320.00	SORTIE	VOLVO 74802B6	\N	KF	t	1198087.00	KKF	201372	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5707	1	2025-03-10	2980945.00	300.00	SORTIE	VOLVO 60517W6	\N	KF	t	393646.00	KKF RETOUR	201375	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5708	1	2025-03-10	2981003.00	58.00	SORTIE	BUS 46250D6	\N	KF	t	553571.00	KKF RETOUR	201376	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5709	1	2025-03-10	2981042.00	39.00	SORTIE	BUS 26207W6	\N	KF	t	249235.00	KKF RETOUR	201377	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5710	1	2025-03-10	2981351.00	309.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	2661.00	SULAYMAN	201378	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5712	1	2025-03-10	2981796.00	282.00	SORTIE	VOLVO 67668W6	\N	KF	t	3305725.00	KF	201380	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5714	1	2025-03-10	2982244.00	304.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	2981.00	ABDELHAFID	201382	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5719	1	2025-03-10	2982620.00	130.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7502.70	LKARS	201387	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5721	1	2025-03-10	2983348.00	674.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	288606.00	ABDELILAH	201389	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5727	1	2025-03-11	2984416.00	360.00	SORTIE	VOLVO 87667W6	\N	KF	t	320794.00	KF	201395	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5729	1	2025-03-11	2984603.00	55.00	SORTIE	HYUNDAI 15991W6	\N	470	f	174009.00	HOUCINE	201397	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5730	1	2025-03-11	2984646.00	43.00	SORTIE	MANITOU	\N	485	f	2686.50	ABDELMALEK	201398	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5741	1	2025-03-12	2986438.00	50.00	SORTIE	LINDE	\N	472	f	\N	AZIZ	201409	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5753	1	2025-03-13	2988106.00	303.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	3175.00	ABDENNASER	201421	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5755	1	2025-03-13	2988266.00	142.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7515.70	LKARS	201423	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5758	1	2025-03-13	2988491.00	58.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	350328.00	ABDESLAM	201426	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5765	1	2025-03-14	2989842.00	505.00	SORTIE	VOLVO 87668W6	\N	KF	t	332095.00	ABDERRAHIM	201433	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5768	1	2025-03-14	2990372.00	274.00	SORTIE	VOLVO 74802B2	\N	KF	t	1199109.00	IDRISS	201436	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5770	1	2025-03-14	2990456.00	39.00	SORTIE	BERLINGO 41521A73	\N	487	f	17957.00	MEJJAD	201438	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5772	1	2025-03-14	2990734.00	53.00	SORTIE	HYUNDAI 15991W6	\N	470	f	174323.00	HOUSSIN	201440	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5774	1	2025-03-14	2990962.00	23.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	201442	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5778	1	2025-03-14	2991152.00	23.00	SORTIE	MANTOU	\N	485	f	2698.80	JAWAD	201446	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5779	1	2025-03-14	2991978.00	826.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	291080.00	ABDELALI	201447	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5785	1	2025-03-15	2993011.00	54.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	106774.00	MOBARAK	201453	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5795	1	2025-03-17	2994142.00	153.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7527.50	YOUSSEF	201463	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5798	1	2025-03-17	2995109.00	706.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1075590.00	SAID	201466	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5813	1	2025-03-18	2997761.00	313.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	3058.00	SOULAYMAN	201481	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5820	1	2025-03-19	2998630.00	302.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	3346.00	ABDELHAFID	201488	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5821	1	2025-03-19	2998760.00	130.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7538.30	YOUSSEF	201489	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5822	1	2025-03-19	2998821.00	61.00	SORTIE	HYUNDAI 15991W6	\N	470	f	174691.00	HOUCINE	201490	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5832	1	2025-03-20	2999579.00	33.00	SORTIE	BERLINGO 41521A73	\N	487	f	18505.00	SAID	201500	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5836	1	2025-03-20	2999772.00	39.00	SORTIE	MANITOU	\N	485	f	2717.90	ABDELMALEK	203004	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5837	1	2025-03-20	2999818.00	46.00	SORTIE	MANITOU	\N	486	f	2429.10	JAWAD	203005	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5850	1	2025-03-21	3001215.00	335.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	3465.00	AHMED	203018	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5851	1	2025-03-21	3001356.00	141.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7550.70	YOUSSEF	203019	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5859	1	2025-03-22	3002267.00	312.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	3621.00	ABDENNASER	203027	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5860	1	2025-03-22	3002292.00	25.00	SORTIE	BERLINGO 50313A6	\N	8	f	446888.00	RACHID	203028	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5862	1	2025-03-22	3003103.00	607.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1077040.00	SAID	203030	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5864	1	2025-03-22	3003774.00	590.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	292756.00	ABDELALI	203032	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5875	1	2025-03-24	3005561.00	35.00	SORTIE	BERLINGO 41521A73	\N	487	f	19144.00	SAID	203043	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5878	1	2025-03-24	3005728.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	107427.00	MBAREK	203046	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5879	1	2025-03-24	3005783.00	55.00	SORTIE	HYUNDAI 15991W6	\N	470	f	175008.00	HOUSSIN	203047	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5880	1	2025-03-24	3005937.00	154.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7563.10	YOUSSEF	203048	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5885	1	2025-03-24	3006096.00	30.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203053	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5890	1	2025-03-25	3006640.00	150.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	3520.00	SOULAYMAN	203058	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5899	1	2025-03-26	3007738.00	143.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7574.60	YOUSSEF	203067	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5907	1	2025-03-27	3008563.00	307.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	3830.00	ABDELHAFID	203075	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5909	1	2025-03-27	3008677.00	52.00	SORTIE	HYUNDAI 15991W6	\N	470	f	175329.00	HOUSSIN	203077	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5917	1	2025-03-28	3009589.00	31.00	SORTIE	BERLINGO 41521A73	\N	487	f	19657.00	MEJJAD	203085	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5918	1	2025-03-28	3009895.00	307.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	3719.00	SOULAYMAN	203086	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5919	1	2025-03-28	3010172.00	276.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	3925.00	AHMED	203087	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5920	1	2025-03-28	3010179.00	7.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203088	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5926	1	2025-03-28	3010407.00	40.00	SORTIE	MANITOU	\N	489	f	2737.30	ABDELMALEK	203094	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5931	1	2025-03-29	3010840.00	25.00	SORTIE	BERLINGO 41521A73	\N	487	f	20143.00	SAID	203099	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5933	1	2025-03-29	3011036.00	27.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	107734.00	MBAREK	203101	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5934	1	2025-03-29	3011186.00	150.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7587.20	YOUSSEF	203102	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5938	1	2025-03-29	3013391.00	2002.00	SORTIE	SINASTONE	\N	SINASTONE	t	\N	REDOUAN	203106	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5947	1	2025-04-04	3014485.00	628.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1078378.00	SAID	203115	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5949	1	2025-04-04	3015253.00	727.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	295332.00	ABDELALI	203117	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5951	1	2025-04-05	3015340.00	37.00	SORTIE	BERLINGO 41521A73	\N	487	f	20852.00	SAID	203119	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5957	1	2025-04-07	3015679.00	65.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	108865.00	MBAREK	203125	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5959	1	2025-04-07	3016050.00	278.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	4041.00	ABDENNASER	203127	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5963	1	2025-04-07	3016284.00	34.00	SORTIE	BOBCAT 414	\N	414	f	4429.00	IBRAHIM	203131	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5966	1	2025-04-07	3016417.00	52.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203134	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5970	1	2025-04-08	3017596.00	60.00	SORTIE	HYUNDAI 15991W6	\N	470	f	176105.00	HOUCINE	203138	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5973	1	2025-04-08	3017907.00	37.00	SORTIE	MANITOU	\N	485	f	2452.00	JAWAD	203141	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5986	1	2025-04-09	3019448.00	133.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7598.30	YOUSSEF	203154	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5993	1	2025-04-10	3020032.00	44.00	SORTIE	BERLINGO 41521A73	\N	487	f	21644.00	SAID	203161	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5997	1	2025-04-10	3021292.00	763.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	297392.00	ABDELALI	203165	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6002	1	2025-04-10	3022367.00	397.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1099634.00	SAID	203170	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6011	1	2025-04-11	3023219.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	176398.00	HOUSSIN	203179	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6013	1	2025-04-11	3023274.00	26.00	SORTIE	BERLINGO 50313A6	\N	8	f	447197.00	RACHID	203181	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6037	1	2025-04-14	3026306.00	34.00	SORTIE	BERLINGO 981A73	\N	4	f	295986.00	MAGHNIA	203205	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6050	1	2025-04-15	3027354.00	50.00	SORTIE	VOLVO 28403A26	\N	\N	f	\N	MEJJAD	203218	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6053	1	2025-04-15	3028084.00	151.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7611.30	YOUSSEF	203221	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6060	1	2025-04-16	3028762.00	45.00	SORTIE	HYUNDAI 15991W6	\N	470	f	176704.00	HOUSSINE	203228	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6062	1	2025-04-16	3028944.00	49.00	SORTIE	MANITOU	\N	485	f	2760.70	ABDELMALEK	203230	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6067	1	2025-04-16	3029624.00	308.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	4255.00	AHMED	203235	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6069	1	2025-04-16	3030187.00	510.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	298957.00	ABDELALI	203237	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6076	1	2025-04-17	3031603.00	499.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1080815.00	SAID	203244	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6087	1	2025-04-18	3033150.00	38.00	SORTIE	BERLINGO 41521A73	\N	487	f	22286.00	SAID	203255	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6091	1	2025-04-18	3033769.00	60.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	109511.00	MBAREK	203259	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6093	1	2025-04-18	3033914.00	36.00	SORTIE	MANITOU	\N	486	f	2475.10	JAWAD	203261	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6095	1	2025-04-18	3033997.00	25.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203263	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6103	1	2025-04-19	3035382.00	313.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	4414.00	AHMED	203271	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6104	1	2025-04-19	3035525.00	143.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7622.50	IBRAHIM	203272	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6105	1	2025-04-19	3035824.00	299.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	4093.00	SOULAYMAN	203273	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6119	1	2025-04-21	3037613.00	652.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1082584.00	SAID	203287	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6123	1	2025-04-21	3037955.00	40.00	SORTIE	HYUNDAI 15991W6	\N	470	f	176924.00	HOUCINE	203291	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6133	1	2025-04-22	3039432.00	286.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	4436.00	ABDENNASER	203301	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6134	1	2025-04-22	3039472.00	40.00	SORTIE	MANITOU	\N	485	f	2777.30	ABDELMALEK	203302	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6136	1	2025-04-22	3039778.00	141.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7635.40	YOUSSEF	203304	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6145	1	2025-04-23	3041415.00	750.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	301294.00	ABDELALI	203313	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6146	1	2025-04-23	3041455.00	40.00	SORTIE	BOBCAT 414	\N	414	f	4441.00	IBRAHIM	203314	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6152	1	2025-04-24	3042268.00	38.00	SORTIE	BERLINGO 41521A73	\N	487	f	22949.00	SAID	203320	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6158	1	2025-04-24	3042956.00	142.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	\N	YOUSSEF	203326	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6171	1	2025-04-25	3044483.00	327.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	4825.00	AHMED	203339	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6174	1	2025-04-25	3044776.00	65.00	SORTIE	HYUNDAI 15991W6	\N	470	f	177338.00	HOUSSINE	203342	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6177	1	2025-04-25	3045021.00	13.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203345	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6178	1	2025-04-25	3045053.00	32.00	SORTIE	MANITOU	\N	485	f	2792.40	JAWAD	203346	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6183	1	2025-04-26	3045996.00	300.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	3540.00	SOULAYMAN	203351	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6185	1	2025-04-26	3046203.00	60.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	11213.00	MBAREK	203353	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6186	1	2025-04-26	3046228.00	25.00	SORTIE	BERLINGO 50313A6	\N	8	f	447515.00	RACHID	203354	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6189	1	2025-04-26	3046450.00	143.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7658.50	YOUSSEF	203357	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6191	1	2025-04-26	3046642.00	36.00	SORTIE	MANITOU	\N	486	f	2497.10	JAWAD	203359	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6193	1	2025-04-26	3047003.00	308.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	4923.00	AHMED	203361	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6201	1	2025-04-28	3047841.00	38.00	SORTIE	MANITOU	\N	485	f	2814.70	HASSAN	203369	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6217	1	2025-04-29	3050264.00	667.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	303331.00	ABDELALI	203385	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6220	1	2025-04-30	3051235.00	141.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7670.50	YOUSSEF	203388	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6222	1	2025-04-30	3051584.00	287.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	4825.00	ABDENNASER	203390	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6231	1	2025-04-30	3052256.00	45.00	SORTIE	BERLINGO 41521A73	\N	487	f	23750.00	SAID	203399	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6232	1	2025-04-30	3052287.00	31.00	SORTIE	MANITOU	\N	485	f	2833.00	HASSAN	203400	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6233	1	2025-04-30	3052337.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	177644.00	HOUSSINE	203401	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6247	1	2025-05-02	3053877.00	17.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203415	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6254	1	2025-05-03	3054659.00	156.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7681.60	YOUSSEF	203422	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6263	1	2025-05-03	3055437.00	45.00	SORTIE	MANITOU	\N	485	f	2858.00	HASSAN	203431	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6273	1	2025-05-05	3056360.00	54.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	110852.00	MBAREK	203441	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6277	1	2025-05-05	3056804.00	38.00	SORTIE	MANITOU	\N	486	f	2521.80	JAWAD	203445	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6280	1	2025-05-05	3057202.00	308.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	5294.00	AHMED	203448	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6285	1	2025-05-06	3057737.00	36.00	SORTIE	BERLINGO 41521A73	\N	487	f	24357.00	SAID	203453	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6286	1	2025-05-06	3058007.00	270.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	5351.00	AHMED	203454	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6287	1	2025-05-06	3058317.00	310.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	4925.00	SOULAYMAN	203455	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6293	1	2025-05-06	3059809.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	177954.00	HOUSSINE	203461	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6300	1	2025-05-07	3060889.00	157.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7694.50	YOUSSEF	203468	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6304	1	2025-05-07	3061129.00	42.00	SORTIE	MANITOU	\N	485	f	2881.80	ABDELKHALEK	203472	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6321	1	2025-05-08	3062680.00	35.00	SORTIE	BOBCAT 414	\N	414	f	4452.00	IBRAHIM	203489	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6322	1	2025-05-08	3063424.00	744.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	305546.00	ABDELALI	203490	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6337	1	2025-05-09	3065674.00	129.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	77065.00	IBRAHIM	203505	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6338	1	2025-05-09	3065697.00	23.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203506	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6340	1	2025-05-09	3065776.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	178257.00	HOUSSINE	203508	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6343	1	2025-05-10	3066013.00	29.00	SORTIE	BERLINGO 41521A73	\N	487	f	24893.00	SAID	203511	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6351	1	2025-05-10	3066484.00	51.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	411466.00	MBAREK	203519	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6366	1	2025-05-13	3068237.00	154.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7720.00	YOUSSEF	203534	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6368	1	2025-05-13	3068716.00	305.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	5244.00	ABDENNASER	203536	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6372	1	2025-05-13	3069109.00	43.00	SORTIE	MANITOU	\N	485	f	2902.30	ABDELMALEK	203540	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6380	1	2025-05-14	3071695.00	2000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	203548	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6384	1	2025-05-14	3072093.00	46.00	SORTIE	MANITOU	\N	486	f	2550.90	JAWAD	203552	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6387	1	2025-05-14	3072251.00	53.00	SORTIE	HYUNDAI 15991W6	\N	470	f	178597.00	HOUSSINE	203555	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6393	1	2025-05-15	3073573.00	108.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7729.20	YOUSSEF	203561	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6397	1	2025-05-15	3074497.00	655.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	307506.00	ABDELALI	203565	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6398	1	2025-05-15	3074828.00	331.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	5781.00	AHMED	203566	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6411	1	2025-05-16	3076682.00	304.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	5806.00	AHMED	203579	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6413	1	2025-05-16	3076761.00	16.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203581	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6414	1	2025-05-16	3077057.00	297.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	5285.00	SOULAYMAN	203582	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6421	1	2025-05-17	3077666.00	28.00	SORTIE	BERLINGO 50313A6	\N	8	f	447934.00	RACHID	203589	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6422	1	2025-05-17	3077700.00	34.00	SORTIE	BERLINGO 41521A73	\N	487	f	25459.00	SAID	203590	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6441	1	2025-05-19	3079991.00	137.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7740.00	YOUSSEF	203609	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6449	1	2025-05-19	3080807.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	178915.00	HOUSSINE	203617	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6453	1	2025-05-20	3081324.00	58.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	112154.00	MBAREK	203621	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6463	1	2025-05-21	3082566.00	157.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7753.00	YOUSSEF	203631	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6464	1	2025-05-21	3082608.00	43.00	SORTIE	BERLINGO 41521A73	\N	487	f	26205.00	SAID	203632	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6465	1	2025-05-21	3082912.00	304.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	5690.00	ABDENNASER	203633	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6467	1	2025-05-21	3083232.00	48.00	SORTIE	MANITOU	\N	485	f	2924.50	ABDELMALEK	203635	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6485	1	2025-05-22	3084934.00	52.00	SORTIE	HYUNDAI 15991W6	\N	470	f	179223.00	HOUSSINE	203653	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6491	1	2025-05-23	3085869.00	127.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	77630.00	IBRAHIM	203659	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6492	1	2025-05-23	3086178.00	309.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	6343.00	AHMED	203660	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6495	1	2025-05-23	3086411.00	38.00	SORTIE	LINDE	\N	485	f	2576.80	JAWAD	203663	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6499	1	2025-05-23	3086898.00	322.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	6244.00	MOHAMED	203667	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6501	1	2025-05-23	3087095.00	17.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203669	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6508	1	2025-05-24	3087733.00	50.00	SORTIE	VOLVO 28403A26	\N	\N	f	\N	MJID	203676	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6511	1	2025-05-24	3088225.00	314.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	5684.00	SOULAYMAN	203679	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6513	1	2025-05-24	3088905.00	643.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1083991.00	SAID	203681	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6521	1	2025-05-26	3090113.00	727.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	309617.00	ABDELLAH	203689	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6524	1	2025-05-26	3090408.00	129.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7774.20	YOUSSEF	203692	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6531	1	2025-05-26	3091732.00	38.00	SORTIE	MANITOU	\N	485	f	2944.10	JAWAD	203699	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6546	1	2025-05-27	3093390.00	48.00	SORTIE	HYUNDAI 15991W6	\N	470	f	179521.00	HOUSINE	203714	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6548	1	2025-05-27	3093477.00	40.00	SORTIE	BOBCAT 414	\N	414	f	4463.00	IBRAHIM	203716	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6550	1	2025-05-28	3093690.00	41.00	SORTIE	BERLINGO 41521A73	\N	487	f	26941.00	SAID	203718	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6555	1	2025-05-28	3094337.00	160.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7788.00	YOUSSEF	203723	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6556	1	2025-05-28	3094637.00	300.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	6098.00	ABDENNASER	203724	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6569	1	2025-05-29	3095950.00	51.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	112758.00	MBAREK	203737	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6570	1	2025-05-29	3096255.00	305.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	6753.00	MOHAMED	203738	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6572	1	2025-05-29	3096696.00	278.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	6788.00	MOHAMED	203740	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6573	1	2025-05-29	3097001.00	305.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	6101.00	SOULAYMAN	203741	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6577	1	2025-05-29	3097595.00	34.00	SORTIE	MANITOU	\N	486	f	2600.10	JAWAD	203745	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6578	1	2025-05-29	3098130.00	535.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1085860.00	SAID	203746	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6582	1	2025-05-29	3098291.00	34.00	SORTIE	HYUNDAI 15991W6	\N	470	f	179723.00	HOUCINE	203750	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6587	1	2025-05-30	3098904.00	150.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7800.80	IBRAHIM	203755	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6593	1	2025-05-30	3099619.00	13.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203761	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6596	1	2025-05-30	3099795.00	48.00	SORTIE	MANITOU	\N	485	f	2969.60	HASSAN	203764	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6611	1	2025-05-31	3101210.00	39.00	SORTIE	BERLINGO 41521A73	\N	487	f	27620.00	SAID	203779	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6614	1	2025-06-02	3101512.00	165.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7814.40	YOUSSEF	203782	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6616	1	2025-06-02	3101923.00	317.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	6587.00	ABDENNASER	203784	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6622	1	2025-06-02	3102869.00	32.00	SORTIE	MANITOU	\N	485	f	2987.00	HASSAN	203790	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6623	1	2025-06-02	3103119.00	250.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1086906.00	SAID	203791	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6636	1	2025-06-03	3104700.00	54.00	SORTIE	HYUNDAI 15991W6	\N	470	f	180040.00	HOUSSINE	203804	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6644	1	2025-06-04	3105786.00	167.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7830.00	YOUSSEF	203812	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6646	1	2025-06-04	3106150.00	306.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	6538.00	SOULAYMAN	203814	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6647	1	2025-06-04	3106465.00	315.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	7239.00	AHMED	203815	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6649	1	2025-06-04	3107152.00	318.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	7314.00	AHMED	203817	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6652	1	2025-06-04	3107270.00	53.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	113388.00	MBAREK	203820	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6653	1	2025-06-04	3107299.00	30.00	SORTIE	MANITOU	\N	485	f	3004.40	HASSAN	203821	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6654	1	2025-06-04	3107316.00	16.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203822	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6659	1	2025-06-05	3107834.00	85.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7837.70	YOUSSEF	203827	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6663	1	2025-06-05	3107994.00	26.00	SORTIE	BERLINGO 41521A73	\N	487	f	28026.00	SAID	203831	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6664	1	2025-06-11	3108044.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	180330.00	HOUCINE	203832	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6666	1	2025-06-12	3108113.00	39.00	SORTIE	BERLINGO 41521A73	\N	487	f	28689.00	SAID	203834	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6667	1	2025-06-12	3108867.00	754.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	311971.00	ABDELALI	203835	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6675	1	2025-06-14	3109297.00	25.00	SORTIE	BERLINGO 50313A6	\N	\N	f	448231.00	RACHID	203843	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6679	1	2025-06-16	3109604.00	61.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	114608.00	MBAREK	203847	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6687	1	2025-06-16	3110104.00	28.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203855	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6688	1	2025-06-16	3110152.00	48.00	SORTIE	HYUNDAI 15991W6	\N	470	f	180623.00	HOUSSINE	203856	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6694	1	2025-06-17	3110660.00	48.00	SORTIE	MANITOU	\N	485	f	30335.00	JAWAD	203862	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6702	1	2025-06-18	3112292.00	546.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1087371.00	SAID	203870	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6703	1	2025-06-18	3112388.00	96.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7845.30	YOUSSEF	203871	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6713	1	2025-06-19	3113840.00	36.00	SORTIE	MANITOU	\N	485	f	30559.00	JAWAD	203881	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6715	1	2025-06-19	3114067.00	51.00	SORTIE	HYUNDAI 15991W6	\N	470	f	180919.00	HOUSSINE	203883	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6716	1	2025-06-19	3114104.00	37.00	SORTIE	BERLINGO 41521A73	\N	487	f	29318.00	SAID	203884	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6724	1	2025-06-20	3115104.00	254.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	6940.00	ABDENNASER	203892	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6733	1	2025-06-21	3116317.00	40.00	SORTIE	MANITOU	\N	486	f	2626.00	JAWAD	203901	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6734	1	2025-06-21	3116348.00	31.00	SORTIE	MANITOU	\N	485	f	30721.00	JAWAD	203902	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6735	1	2025-06-21	3116474.00	126.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7855.20	YOUSSEF	203903	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6746	1	2025-06-23	3117594.00	21.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203914	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6754	1	2025-06-24	3119571.00	810.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	314424.00	ABDELALI	203922	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6757	1	2025-06-24	3120072.00	55.00	SORTIE	HYUNDAI 15991W6	\N	470	f	181219.00	HOUSSINE	203925	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6761	1	2025-06-24	3120624.00	160.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7867.00	YOUSSEF	203929	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6764	1	2025-06-25	3121073.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	115253.00	MBAREK	203932	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6766	1	2025-06-25	3121424.00	310.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	6950.00	SOULAYMAN	203934	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6768	1	2025-06-25	3121829.00	310.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	7725.00	AHMED	203936	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6769	1	2025-06-25	3121875.00	46.00	SORTIE	MANITOU	\N	485	f	3098.90	ABDELMALEK	203937	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6777	1	2025-06-26	3122417.00	34.00	SORTIE	BERLINGO 41521A73	\N	487	f	29905.00	SAID	203945	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6781	1	2025-06-26	3123759.00	1000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDWAN	203949	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6784	1	2025-06-26	3124211.00	259.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	7734.00	AHMED	203952	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6790	1	2025-06-27	3125158.00	500.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1089255.00	SAID	203958	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6804	1	2025-06-28	3126865.00	130.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7877.00	YOUSSEF	203972	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6809	1	2025-06-30	3127756.00	200.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1090281.00	SAID	203977	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6816	1	2025-06-30	3128219.00	17.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	203984	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6819	1	2025-06-30	3128317.00	54.00	SORTIE	HYUNDAI 15991W6	\N	470	f	181528.00	HOUSSINE	203987	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6827	1	2025-07-01	3129414.00	30.00	SORTIE	BERLINGO 41521A73	\N	487	f	30354.00	SAID	203995	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6833	1	2025-07-02	3129686.00	41.00	SORTIE	MANITOU	\N	486	f	2652.50	JAWAD	204001	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6839	1	2025-07-02	3130680.00	702.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1090935.00	SAID	204007	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6842	1	2025-07-03	3131910.00	717.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	316603.00	ABDELLALI	204010	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6846	1	2025-07-03	3132304.00	167.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7892.60	YOUSSEF	204014	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6847	1	2025-07-03	3132608.00	304.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	7326.00	ABDENNASER	204015	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6850	1	2025-07-03	3132971.00	46.00	SORTIE	MANITOU	\N	485	f	3122.50	ABDELKHALEK	204018	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6855	1	2025-07-03	3133558.00	60.00	SORTIE	HYUNDAI 15991W6	\N	470	f	181867.00	HOUSSINE	204023	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6864	1	2025-07-04	3134883.00	260.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	8142.00	AHMED	204032	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6865	1	2025-07-04	3135185.00	302.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	7347.00	SOULAYMAN	204033	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6868	1	2025-07-05	3135318.00	33.00	SORTIE	BERLINGO 41521A73	\N	487	f	30932.00	SAID	204036	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6872	1	2025-07-05	3135886.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	115893.00	MBAREK	204040	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6873	1	2025-07-05	3135986.00	100.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7902.40	YOUSSEF	204041	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6874	1	2025-07-05	3136295.00	309.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	8143.00	AHMED	204042	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6883	1	2025-07-07	3137231.00	487.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1092156.00	SAID	204051	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6895	1	2025-07-07	3138883.00	18.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	204063	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6896	1	2025-07-07	3139298.00	415.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	317911.00	ABDELLALI	204064	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6903	1	2025-07-08	3140226.00	162.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7915.80	IBRAHIM	204071	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6907	1	2025-07-08	3140429.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	182165.00	HOUSSINE	204075	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6920	1	2025-07-09	3141888.00	97.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7924.00	YOUSSEF	204088	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6927	1	2025-07-10	3142803.00	37.00	SORTIE	MANITOU	\N	486	f	2677.60	JAWAD	204095	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6932	1	2025-07-10	3143450.00	301.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	7776.00	SOULAYMAN	204100	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6934	1	2025-07-10	3143629.00	31.00	SORTIE	BERLINGO 41521A73	\N	487	f	31430.00	SAID	204102	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6937	1	2025-07-10	3143752.00	41.00	SORTIE	MANITOU	\N	485	f	3143.90	JAWAD	204105	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6940	1	2025-07-11	3143991.00	33.00	SORTIE	BERLINGO 41521A73	\N	487	f	32000.00	SAID	204108	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6943	1	2025-07-11	3144802.00	626.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1093724.00	SAID	204111	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6945	1	2025-07-11	3145217.00	300.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	7785.00	ABDENNASER	204113	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6950	1	2025-07-11	3145554.00	48.00	SORTIE	HYUNDAI 15991W6	\N	470	f	182454.00	HOUSSINE	204118	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6955	1	2025-07-12	3146885.00	342.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	8704.00	AHMED	204123	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6959	1	2025-07-12	3147200.00	139.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7935.10	YOUSSEF	204127	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6962	1	2025-07-12	3147829.00	29.00	SORTIE	MANITOU	\N	485	f	3159.30	HASSAN	204130	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6971	1	2025-07-14	3149279.00	650.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	320006.00	ABDELALI	204139	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6981	1	2025-07-15	3150623.00	319.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	8696.00	AHMED	204149	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6982	1	2025-07-15	3150778.00	156.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7948.50	YOUSSEF	204150	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6990	1	2025-07-16	3151933.00	56.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	116576.00	MBAREK	204158	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6996	1	2025-07-16	3152524.00	39.00	SORTIE	MANITOU	\N	485	f	3181.70	JAWAD	204164	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7003	1	2025-07-17	3153607.00	320.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	8223.00	SOULAYMAN	204171	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7005	1	2025-07-17	3153824.00	37.00	SORTIE	BERLINGO 41521A73	\N	487	f	32585.00	SAID	204173	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7006	1	2025-07-17	3153891.00	67.00	SORTIE	HYUNDAI 15991W6	\N	470	f	182838.00	HOUSSINE	204174	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7007	1	2025-07-17	3154002.00	112.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7957.80	YOUSSEF	204175	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7009	1	2025-07-17	3154533.00	36.00	SORTIE	MANITOU	\N	485	f	2701.20	JAWAD	204177	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7010	1	2025-07-17	3154555.00	22.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOGUI	204178	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7018	1	2025-07-18	3156163.00	620.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1095247.00	SAID	204186	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7019	1	2025-07-18	3157163.00	1000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	204187	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7021	1	2025-07-18	3157817.00	623.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	322010.00	ABDELAALI	204189	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7022	1	2025-07-18	3157848.00	31.00	SORTIE	MANITOU	\N	485	f	3200.00	JAWAD	204190	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7030	1	2025-07-19	3159210.00	342.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	9212.00	AHMED	204198	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7032	1	2025-07-19	3159346.00	19.00	SORTIE	BERLINGO 50313A6	\N	8	f	448491.00	RACHID	204200	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7033	1	2025-07-19	3159492.00	146.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7970.30	YOUSSEF	204201	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7035	1	2025-07-19	3159941.00	312.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	8241.00	ABDENNASER	204203	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7049	1	2025-07-21	3161305.00	41.00	SORTIE	BOBCAT	\N	414	f	4474.00	IBRAHIM	204217	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7053	1	2025-07-21	3161672.00	41.00	SORTIE	MANITOU	\N	485	f	3224.90	HASSAN	204221	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7059	1	2025-07-22	3162690.00	32.00	SORTIE	HYUNDAI 15991W6	\N	470	f	183114.00	HOUSSINE	204227	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7061	1	2025-07-23	3163184.00	34.00	SORTIE	BERLINGO 41521A73	\N	487	f	33174.00	SAID	204229	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7065	1	2025-07-23	3163872.00	160.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7983.50	YOUSSEF	204233	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7068	1	2025-07-23	3164486.00	295.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	9185.00	AHMED	204236	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7073	1	2025-07-23	3165209.00	34.00	SORTIE	MANITOU	\N	485	f	3244.90	HASSAN	204241	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7082	1	2025-07-24	3166046.00	308.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	8633.00	SOULAYMAN	204250	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7088	1	2025-07-24	3166747.00	133.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	7994.30	IBRAHIM	204256	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7092	1	2025-07-25	3167392.00	61.00	SORTIE	HYUNDAI 15991W6	\N	470	f	183391.00	HOUSSINE	204260	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7099	1	2025-07-25	3168278.00	38.00	SORTIE	MANITOU	\N	485	f	3265.90	HASSAN	204267	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7101	1	2025-07-25	3169120.00	800.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	324503.00	ABDELAALI	204269	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7108	1	2025-07-26	3169644.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	117279.00	MBAREK	204276	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7112	1	2025-07-26	3170245.00	38.00	SORTIE	MANITOU	\N	486	f	2727.60	JAWAD	204280	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7115	1	2025-07-26	3170317.00	26.00	SORTIE	BERLINGO 41521A73	\N	487	f	33593.00	SAID	204283	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7120	1	2025-07-28	3171138.00	40.00	SORTIE	MANITOU	\N	485	f	3286.60	JAWAD	204288	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7126	1	2025-07-28	3172298.00	109.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8004.20	YOUSSEF	204294	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7127	1	2025-07-28	3172580.00	282.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	8656.00	ABDENNASER	204295	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7136	1	2025-07-29	3173410.00	33.00	SORTIE	MANITOU	\N	485	f	3304.10	HASSAN	204310	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7137	1	2025-07-29	3173543.00	133.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8016.60	YOUSSEF	204311	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7146	1	2025-07-30	3175449.00	340.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	9891.00	AHMED	204320	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7147	1	2025-07-30	3175849.00	400.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1095775.00	SAID	204321	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7151	1	2025-07-31	3176456.00	46.00	SORTIE	BERLINGO 41521A73	\N	487	f	34384.00	SAID	204325	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7160	1	2025-07-31	3177142.00	43.00	SORTIE	MANITOU	\N	485	f	3324.60	HASSAN	204334	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7163	1	2025-08-01	3177458.00	62.00	SORTIE	HYUNDAI 15991W6	\N	470	f	183755.00	HOUSSINE	204337	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7164	1	2025-08-01	3177584.00	126.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8027.80	YOUSSEF	204338	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7167	1	2025-08-01	3178276.00	322.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	9695.00	AHMED	204341	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7169	1	2025-08-01	3178984.00	314.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	9091.00	SOULAYMAN	204343	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7180	1	2025-08-02	3179816.00	22.00	SORTIE	BERLINGO 41521A73	\N	487	f	34714.00	SAID	204354	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7181	1	2025-08-02	3180558.00	742.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	326941.00	ABDELALI	204355	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7184	1	2025-08-02	3180791.00	39.00	SORTIE	MANITOU	\N	485	f	3343.80	HASSAN	204358	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7186	1	2025-08-02	3180875.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	117952.00	MBAREK	204360	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7191	1	2025-08-04	3181503.00	142.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8040.80	YOUSSEF	204365	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7194	1	2025-08-04	3181802.00	30.00	SORTIE	BOBCAT	\N	414	f	4483.00	IBRAHIM	204368	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7195	1	2025-08-04	3182212.00	410.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1096859.00	SAID	204369	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7196	1	2025-08-04	3182253.00	41.00	SORTIE	MANITOU	\N	486	f	2757.10	JAWAD	204370	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7199	1	2025-08-04	3182473.00	36.00	SORTIE	MANITOU	\N	485	f	3366.90	JAWAD	204373	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7201	1	2025-08-04	3183139.00	47.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	204375	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7208	1	2025-08-05	3183951.00	310.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	9142.00	ABDENNASER	204382	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7212	1	2025-08-05	3184402.00	35.00	SORTIE	BERLINGO 41521A73	\N	487	f	35324.00	SAID	204386	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7214	1	2025-08-05	3184617.00	21.00	SORTIE	MANITOU	\N	485	f	3378.60	JAWAD	204388	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7224	1	2025-08-06	3185833.00	124.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8051.60	YOUSSEF	204398	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7234	1	2025-08-07	3186969.00	60.00	SORTIE	HYUNDAI 15991W6	\N	470	f	184126.00	HOUSSINE	204408	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7239	1	2025-08-07	3187361.00	40.00	SORTIE	MANITOU	\N	485	f	3399.00	JAWAD	204413	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7243	1	2025-08-08	3188912.00	615.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1098372.00	SAID	204417	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7245	1	2025-08-08	3189332.00	330.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	10386.00	AHMED	204419	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7261	1	2025-08-09	3191237.00	106.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8060.60	YOUSSEF	204435	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7262	1	2025-08-09	3191264.00	28.00	SORTIE	BERLINGO 41521A73	\N	487	f	35804.00	SAID	204436	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7266	1	2025-08-09	3191581.00	36.00	SORTIE	LINDE	\N	485	f	3418.40	HASSAN	204440	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7268	1	2025-08-09	3192151.00	548.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	328522.00	ABDELALI	204442	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7271	1	2025-08-11	3192525.00	60.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	118703.00	MBAREK	204445	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7274	1	2025-08-11	3193092.00	312.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	9510.00	SOULAYMAN	204448	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7276	1	2025-08-11	3193189.00	35.00	SORTIE	BERLINGO 41521A73	\N	487	f	36364.00	SAID	204450	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7277	1	2025-08-11	3193225.00	36.00	SORTIE	MANITOU	\N	486	f	2782.30	JAWAD	204451	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7280	1	2025-08-11	3193457.00	35.00	SORTIE	MANITOU	\N	485	f	3438.10	HASSAN	204454	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7292	1	2025-08-12	3194955.00	300.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	10172.00	AHMED	204466	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7298	1	2025-08-12	3195567.00	22.00	SORTIE	MANITOU	\N	485	f	3450.10	JAWAD	204472	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7300	1	2025-08-12	3195786.00	38.00	SORTIE	BERLINGO 41521A73	\N	487	f	36947.00	SAID	204474	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7302	1	2025-08-13	3196553.00	613.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1099973.00	SAID	204476	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7303	1	2025-08-13	3196619.00	66.00	SORTIE	HYUNDAI 15991W6	\N	470	f	184513.00	HOUSSINE	204477	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7304	1	2025-08-13	3196782.00	163.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8075.30	IBRAHIM	204478	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7306	1	2025-08-13	3197220.00	288.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	9532.00	ABDENNASER	204480	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7307	1	2025-08-13	3197239.00	19.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	204481	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7311	1	2025-08-13	3197504.00	22.00	SORTIE	MANITOU	\N	485	f	3460.60	JAWAD	204485	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7315	1	2025-08-14	3199880.00	2000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	204489	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7329	1	2025-08-15	3201874.00	41.00	SORTIE	MANITOU	\N	485	f	3481.50	JAWAD	205003	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7336	1	2025-08-16	3202708.00	115.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8087.60	IBRAHIM	205010	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7337	1	2025-08-16	3203038.00	330.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	10902.00	AHMED	205011	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7338	1	2025-08-16	3203072.00	35.00	SORTIE	BERLINGO 41521A73	\N	487	f	37528.00	SAID	205012	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7343	1	2025-08-16	3203591.00	22.00	SORTIE	MANITOU	\N	485	f	3492.40	HASSAN	205017	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7349	1	2025-08-18	3204605.00	351.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	331290.00	ABDELALI	205023	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7351	1	2025-08-18	3204887.00	250.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1101546.00	SAID	205025	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7353	1	2025-08-18	3204949.00	36.00	SORTIE	LINDE	\N	486	f	2808.30	JAWAD	205027	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7359	1	2025-08-18	3205299.00	35.00	SORTIE	MANITOU	\N	485	f	3511.60	JAWAD	205033	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7360	1	2025-08-19	3205349.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	184794.00	HOUSSINE	205034	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7363	1	2025-08-19	3205792.00	328.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	9955.00	SOULAYMAN	205037	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7364	1	2025-08-19	3205973.00	181.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8105.50	YOUSSEF	205038	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7372	1	2025-08-19	3207342.00	550.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1102004.00	SAID	205046	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7374	1	2025-08-20	3208207.00	824.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	332233.00	ABDELALI	205048	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7386	1	2025-08-21	3209636.00	37.00	SORTIE	MANITOU	\N	485	f	3531.80	HASSAN	205060	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7391	1	2025-08-22	3210501.00	293.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	10593.00	AHMED	205065	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7401	1	2025-08-23	3211601.00	26.00	SORTIE	BERLINGO 41521A73	\N	487	f	37999.00	SAID	205075	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7403	1	2025-08-23	3211912.00	131.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8116.80	YOUSSEF	205077	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7404	1	2025-08-23	3211923.00	11.00	SORTIE	BERLINGO 50313A6	\N	8	f	448634.00	RACHID	205078	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7406	1	2025-08-23	3211989.00	35.00	SORTIE	MANITOU	\N	485	f	3550.60	HASSAN	205080	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7407	1	2025-08-23	3212010.00	21.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205081	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7409	1	2025-08-23	3212318.00	273.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	11310.00	AHMED	205083	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7416	1	2025-08-25	3213389.00	319.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	9965.00	ABDENNASER	205090	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7417	1	2025-08-25	3214004.00	614.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1103442.00	SAID	205091	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7419	1	2025-08-25	3214072.00	38.00	SORTIE	MANITOU	\N	486	f	2836.20	MILOUD	205093	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7421	1	2025-08-25	3214432.00	24.00	SORTIE	MANITOU	\N	485	f	3564.90	HASSAN	205095	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7427	1	2025-08-26	3215012.00	138.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8128.20	YOUSSEF	205101	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7429	1	2025-08-26	3215539.00	307.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	10388.00	SOULAYMAN	205103	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7444	1	2025-08-27	3217783.00	679.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	334239.00	ABDELALI	205118	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7456	1	2025-08-28	3219035.00	38.00	SORTIE	MANITOU	\N	485	f	3587.70	HASSAN	205130	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7461	1	2025-08-29	3219585.00	40.00	SORTIE	BERLINGO 41521A73	\N	487	f	38698.00	SAID	205135	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7465	1	2025-08-29	3220047.00	137.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8140.40	YOUSSEF	205139	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7467	1	2025-08-29	3220126.00	3.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205141	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7473	1	2025-08-30	3221190.00	412.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1104425.00	SAID	205147	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7477	1	2025-08-30	3221739.00	304.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	11070.00	AHMED	205151	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7484	1	2025-08-30	3222889.00	32.00	SORTIE	MANITOU	\N	485	f	3605.60	HASSAN	205158	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7489	1	2025-09-01	3223687.00	310.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	11789.00	MOHAMED	205163	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7493	1	2025-09-01	3224121.00	43.00	SORTIE	MANITOU	\N	486	f	2866.00	JAWAD	205167	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7496	1	2025-09-01	3224440.00	38.00	SORTIE	MANITOU	\N	485	f	3625.80	JAWAD	205170	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7501	1	2025-09-02	3224756.00	40.00	SORTIE	BERLINGO 41521A73	\N	487	f	39421.00	SAID	205175	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7502	1	2025-09-02	3224906.00	150.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8154.40	YOUSSEF	205176	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7509	1	2025-09-02	3226104.00	314.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	10451.00	SAID	205183	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7515	1	2025-09-03	3226814.00	311.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	10792.00	SOULAYMAN	205189	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7521	1	2025-09-03	3227468.00	39.00	SORTIE	MANITOU	\N	485	f	3646.60	JAWAD	205195	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7522	1	2025-09-03	3227485.00	17.00	SORTIE	MANITOU	\N	486	f	2879.20	ABDELLAH	205196	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7523	1	2025-09-03	3227507.00	22.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205197	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7524	1	2025-09-04	3228317.00	810.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	336919.00	ABDELALI	205198	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7528	1	2025-09-04	3228687.00	51.00	SORTIE	HYUNDAI 15991W6	\N	470	f	85127.00	HOUSSINE	205202	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7529	1	2025-09-04	3228805.00	118.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8163.60	YOUSSEF	205203	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7534	1	2025-09-04	3229180.00	17.00	SORTIE	BERLINGO 41521A73	\N	487	f	39689.00	SAID	205208	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7535	1	2025-09-04	3229221.00	41.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	119218.00	MBAREK	205209	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7536	1	2025-09-04	3229237.00	16.00	SORTIE	MANITOU	\N	485	f	3655.40	HASSAN	205210	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7558	1	2025-09-09	3232176.00	34.00	SORTIE	MANITOU	\N	485	f	3677.50	JAWAD	205232	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7561	1	2025-09-10	3232394.00	30.00	SORTIE	BERLINGO 41521A73	\N	487	f	40173.00	SAID	205235	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7572	1	2025-09-11	3233929.00	58.00	SORTIE	HYUNDAI 15991W6	\N	470	f	185496.00	HOUSSINE	205246	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7573	1	2025-09-11	3234559.00	630.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1105913.00	SAID	205247	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7578	1	2025-09-11	3234979.00	37.00	SORTIE	MANITOU	\N	485	f	3698.90	JAWAD	205252	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7582	1	2025-09-12	3236073.00	705.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	339069.00	ABDELALI	205256	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7583	1	2025-09-12	3236113.00	40.00	SORTIE	BERLINGO 41521A73	\N	487	f	40873.00	SAID	205257	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7585	1	2025-09-12	3236285.00	135.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8175.10	IBRAHIM	205259	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7588	1	2025-09-12	3236757.00	43.00	SORTIE	MANITOU	\N	486	f	2908.60	JAWAD	205262	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7593	1	2025-09-12	3236954.00	21.00	SORTIE	MANITOU	\N	485	f	3710.10	JAWAD	205267	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7595	1	2025-09-12	3237030.00	31.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205269	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7601	1	2025-09-13	3237992.00	328.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	12320.00	AHMED	205275	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7606	1	2025-09-13	3238527.00	51.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	119768.00	MBAREK	205280	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7610	1	2025-09-13	3238758.00	21.00	SORTIE	MANITOU	\N	485	f	3720.30	JAWAD	205284	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7622	1	2025-09-16	3240209.00	315.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	11254.00	SOULAYMAN	205296	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7623	1	2025-09-16	3240517.00	308.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	11535.00	AHMED	205297	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7625	1	2025-09-16	3240743.00	41.00	SORTIE	MANITOU	\N	485	f	3747.10	HASSAN	205299	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7632	1	2025-09-17	3241463.00	53.00	SORTIE	HYUNDAI 15991W6	\N	470	f	185852.00	HOUSSINE	205306	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7640	1	2025-09-17	3242385.00	23.00	SORTIE	MANITOU	\N	485	f	3760.70	JAWAD	205314	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7644	1	2025-09-18	3242785.00	33.00	SORTIE	BERLINGO 41521A73	\N	487	f	41463.00	SAID	205318	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7647	1	2025-09-18	3243319.00	163.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8188.20	IBRAHIM	205321	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7649	1	2025-09-18	3243736.00	309.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	10902.00	SAID	205323	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7650	1	2025-09-18	3244258.00	522.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1107203.00	SAID	205324	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7659	1	2025-09-19	3245330.00	43.00	SORTIE	MANITOU	\N	485	f	3788.90	HASSAN	205333	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7673	1	2025-09-20	3246919.00	42.00	SORTIE	MANITOU	\N	486	f	2939.30	JAWAD	205347	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7679	1	2025-09-22	3247654.00	114.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8197.00	YOUSSEF	205353	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7681	1	2025-09-22	3248570.00	811.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	341720.00	ABDELALI	205355	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7682	1	2025-09-22	3248619.00	48.00	SORTIE	HYUNDAI 15991W6	\N	470	f	186144.00	HOUSSINE	205356	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7685	1	2025-09-22	3248753.00	49.00	SORTIE	MANITOU	\N	485	f	3815.00	HASSAN	205359	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7691	1	2025-09-23	3249627.00	57.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	120413.00	MBAREK	205365	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7695	1	2025-09-23	3250196.00	23.00	SORTIE	MANITOU	\N	485	f	3828.30	HASSAN	205369	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7701	1	2025-09-23	3251309.00	524.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1108525.00	SAID	205375	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7704	1	2025-09-24	3251929.00	150.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8210.00	YOUSSEF	205378	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7714	1	2025-09-25	3253102.00	36.00	SORTIE	BERLINGO 41521A73	\N	487	f	41991.00	SAID	205388	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7717	1	2025-09-25	3253670.00	309.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	12760.00	AHMED	205391	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7720	1	2025-09-25	3254210.00	309.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	11665.00	SOULAYMAN	205394	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7722	1	2025-09-25	3254585.00	321.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	12048.00	AHMED	205396	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7725	1	2025-09-25	3254769.00	51.00	SORTIE	MANITOU	\N	485	f	3854.90	HASSAN	205399	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7726	1	2025-09-26	3254901.00	132.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8220.40	YOUSSEF	205400	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7729	1	2025-09-26	3255003.00	57.00	SORTIE	HYUNDAI 15991W6	\N	470	f	186497.00	HOUSSINE	205403	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7734	1	2025-09-26	3255774.00	306.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	11405.00	SAID	205408	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7735	1	2025-09-26	3255810.00	36.00	SORTIE	MANITOU	\N	486	f	2966.80	JAWAD	205409	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7738	1	2025-09-26	3256860.00	433.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1109583.00	SAID	205412	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7745	1	2025-09-27	3257824.00	33.00	SORTIE	BERLINGO 50313A6	\N	8	f	449107.00	RACHID	205419	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7752	1	2025-09-27	3258444.00	23.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205426	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7757	1	2025-09-27	3258641.00	37.00	SORTIE	MANITOU	\N	485	f	3876.00	JAWAD	205431	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7760	1	2025-09-29	3259002.00	117.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8229.30	YOUSSEF	205434	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7768	1	2025-09-29	3259870.00	31.00	SORTIE	MANITOU	\N	485	f	3893.80	JAWAD	205442	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7780	1	2025-09-30	3261437.00	400.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1110986.00	SAID	205454	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7786	1	2025-10-01	3262348.00	31.00	SORTIE	BERLINGO 41521A73	\N	487	f	42500.00	SAID	205460	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7788	1	2025-10-01	3263350.00	832.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	344374.00	ABDELALI	205462	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7789	1	2025-10-01	3263392.00	42.00	SORTIE	MANITOU	\N	485	f	3916.90	JAWAD	205463	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7797	1	2025-10-02	3264064.00	56.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	121050.00	MBAREK	205471	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7799	1	2025-10-02	3264310.00	60.00	SORTIE	HYUNDAI 15991W6	\N	470	f	186880.00	HOUSSINE	205473	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7801	1	2025-10-02	3264742.00	295.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	13246.00	AHMED	205475	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7804	1	2025-10-02	3264903.00	47.00	SORTIE	MANITOU	\N	486	f	2999.70	JAWAD	205478	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7807	1	2025-10-02	3265406.00	147.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8241.20	YOUSSEF	205481	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7809	1	2025-10-02	3265757.00	312.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	12092.00	SOULAYMAN	205483	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7812	1	2025-10-03	3266452.00	355.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	12574.00	AHMED	205486	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7816	1	2025-10-03	3266994.00	15.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205490	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7817	1	2025-10-03	3267042.00	48.00	SORTIE	MANITOU	\N	485	f	3942.00	HASSAN	205491	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7821	1	2025-10-03	3267760.00	612.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1112184.00	SAID	205495	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7830	1	2025-10-04	3269240.00	442.00	SORTIE	VOLVO 87668W6	\N	KF	t	378430.00	MEZHOURI	207004	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7831	1	2025-10-04	3269535.00	295.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	11878.00	SAID	207005	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7839	1	2025-10-06	3270426.00	168.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8254.00	IBRAHIM	207013	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7844	1	2025-10-06	3271647.00	1000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	207018	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7853	1	2025-10-07	3272888.00	39.00	SORTIE	BERLINGO 41521A73	\N	487	f	43212.00	SAID	207027	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7861	1	2025-10-07	3274333.00	330.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	13779.00	AHMED	207035	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7862	1	2025-10-07	3274387.00	54.00	SORTIE	MANITOU	\N	485	f	3971.20	JAWAD	207036	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7868	1	2025-10-08	3274919.00	57.00	SORTIE	HYUNDAI 15991W6	\N	470	f	187250.00	HOUSSINE	207042	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7869	1	2025-10-08	3275035.00	116.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8264.00	YOUSSEF	207043	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7871	1	2025-10-08	3275765.00	500.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	346960.00	ABDELALI	207045	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7875	1	2025-10-08	3276367.00	314.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1112962.00	SAID	207049	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7880	1	2025-10-09	3277061.00	40.00	SORTIE	MANITOU	\N	486	f	3029.30	JAWAD	207054	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7886	1	2025-10-09	3277692.00	38.00	SORTIE	MANITOU 485	\N	485	f	3991.40	JAWAD	207060	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7890	1	2025-10-10	3278073.00	139.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8275.20	YOUSSEF	207064	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7892	1	2025-10-10	3278804.00	320.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	12511.00	SOULAYMAN	207066	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7893	1	2025-10-10	3279118.00	313.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	13050.00	AHMED	207067	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7904	1	2025-10-11	3280289.00	60.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	121716.00	MBAREK	207078	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7907	1	2025-10-11	3280568.00	27.00	SORTIE	BERLINGO 41521A73	\N	487	f	43662.00	SAID	207081	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7910	1	2025-10-11	3280756.00	42.00	SORTIE	MANITOU	\N	485	f	4015.30	JAWAD	207084	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7912	1	2025-10-11	3280994.00	17.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	207086	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7918	1	2025-10-13	3282119.00	703.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	348416.00	ABDELALI	207092	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7923	1	2025-10-13	3282934.00	288.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	12298.00	SAID	207097	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7926	1	2025-10-13	3283418.00	140.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8285.50	YOUSSEF	207100	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7932	1	2025-10-14	3283942.00	47.00	SORTIE	BERLINGO 41521A73	\N	487	f	44598.00	SAID	207106	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7934	1	2025-10-14	3284703.00	701.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1114683.00	SAID	207108	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7936	1	2025-10-14	3284949.00	61.00	SORTIE	HYUNDAI 15991W6	\N	470	f	187622.00	HOUSSINE	207110	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7943	1	2025-10-14	3285455.00	51.00	SORTIE	MANITOU	\N	485	f	4042.80	HASSAN	207117	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7944	1	2025-10-14	3285456.00	1.00	SORTIE	HAKIM	\N	MAINTENANCE	t	\N	HAKIM	207118	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7953	1	2025-10-15	3286287.00	46.00	SORTIE	MANITOU	\N	486	f	3062.50	MILOUD	207127	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7958	1	2025-10-16	3287442.00	510.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1115996.00	SAID	207132	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7962	1	2025-10-16	3287962.00	150.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8297.00	YOUSSEF	207136	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7963	1	2025-10-16	3288312.00	350.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	14324.00	AHMED	207137	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7973	1	2025-10-16	3288909.00	33.00	SORTIE	MANITOU	\N	485	f	4061.80	HASSAN	207147	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7979	1	2025-10-17	3290188.00	306.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	12875.00	SOULAYMAN	207153	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7981	1	2025-10-17	3290522.00	175.00	SORTIE	CHARGEUSE G 938	\N	4136	f	7898.50	ABDERRAHIM	207155	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7985	1	2025-10-17	3290726.00	15.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	207159	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7990	1	2025-10-18	3291168.00	32.00	SORTIE	BERLINGO 41521A73	\N	487	f	45112.00	SAID	207164	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7992	1	2025-10-18	3291394.00	150.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	13442.00	AHMED	207166	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7994	1	2025-10-18	3291598.00	70.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8305.20	IBRAHIM	207168	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7999	1	2025-10-18	3291830.00	38.00	SORTIE	MANITOU	\N	485	f	4082.30	HASSAN	207173	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8006	1	2025-10-20	3292907.00	58.00	SORTIE	HYUNDAI 15991W6	\N	470	f	187289.00	HOUSSINE	207180	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8011	1	2025-10-20	3293564.00	43.00	SORTIE	MANITOU	\N	486	f	\N	JAWAD	207185	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8013	1	2025-10-20	3293638.00	29.00	SORTIE	MANITOU	\N	485	f	4099.60	HASSAN	207187	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8025	1	2025-10-22	3295181.00	36.00	SORTIE	MANITOU	\N	485	f	4118.90	HASSAN	207202	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8028	1	2025-10-22	3295724.00	328.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	13714.00	AHMED	207205	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8031	1	2025-10-23	3296687.00	675.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1117616.00	SAID	207208	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8033	1	2025-10-23	3297047.00	115.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8326.00	YOUSSEF	207210	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8036	1	2025-10-23	3297892.00	296.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	12889.00	SAID	207213	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8037	1	2025-10-23	3298192.00	300.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	14787.00	AHMED	207214	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8042	1	2025-10-23	3299202.00	850.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	351190.00	ABDELALI	207219	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8044	1	2025-10-24	3299285.00	36.00	SORTIE	BERLINGO 41521A73	\N	487	f	45732.00	SAID	207221	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8048	1	2025-10-24	3299677.00	54.00	SORTIE	HYUNDAI 15991W6	\N	470	f	188354.00	HOUSSINE	207225	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8049	1	2025-10-24	3299954.00	277.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	13214.00	SOULAYMAN	207226	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8050	1	2025-10-24	3299984.00	30.00	SORTIE	BOBCAT	\N	414	f	4492.00	IBRAHIM	207227	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8057	1	2025-10-24	3301224.00	39.00	SORTIE	MANITOU	\N	485	f	4140.70	HASSAN	207234	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8060	1	2025-10-24	3301658.00	346.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1118481.00	SAID	207237	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8066	1	2025-10-25	3302437.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	122676.00	MBAREK	207243	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8072	1	2025-10-25	3302951.00	15.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	207249	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8075	1	2025-10-25	3303415.00	20.00	SORTIE	MANITOU	\N	485	f	4151.30	HASSAN	207252	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8083	1	2025-10-27	3304644.00	150.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8338.20	YOUSSEF	207260	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8089	1	2025-10-27	3304917.00	40.00	SORTIE	MANITOU	\N	486	f	3121.10	MILOUD	207266	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8090	1	2025-10-27	3304951.00	34.00	SORTIE	MANITOU	\N	485	f	4171.40	JAWAD	207267	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8095	1	2025-10-28	3305760.00	430.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	352596.00	ABDELALI	207272	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8108	1	2025-10-29	3307912.00	575.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1119871.00	SAID	207285	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8111	1	2025-10-29	3308299.00	119.00	SORTIE	DOSSAN DL 250	\N	ARMABETON	t	8347.40	YOUSSEF	207288	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8115	1	2025-10-29	3310689.00	2000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	207292	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8117	1	2025-10-29	3310815.00	39.00	SORTIE	MANITOU	\N	485	f	4194.90	JAWAD	207294	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8125	1	2025-10-30	3311703.00	60.00	SORTIE	HYUNDAI 15991W6	\N	470	f	188724.00	HOUSSINE	207302	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8126	1	2025-10-30	3311944.00	241.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	13287.00	SAID	207303	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8131	1	2025-10-31	3312508.00	36.00	SORTIE	BERLINGO 41521A73	\N	487	f	46315.00	SAID	207308	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8139	1	2025-10-31	3313167.00	17.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	207316	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8140	1	2025-10-31	3313494.00	327.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	15304.00	AHMED	207317	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8142	1	2025-10-31	3313581.00	37.00	SORTIE	MANITOU	\N	485	f	4215.80	JAWAD	207319	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8147	1	2025-11-01	3314240.00	308.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	13600.00	SOULAYMAN	208324	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8150	1	2025-11-01	3314889.00	335.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	14205.00	AHMED	208327	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8151	1	2025-11-01	3315023.00	134.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8358.60	IBRAHIM	208328	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8153	1	2025-11-01	3315195.00	62.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	383152.00	ABDESSLAM	208330	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8155	1	2025-11-01	3315710.00	485.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1121032.00	SAID	208332	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8157	1	2025-11-01	3315884.00	19.00	SORTIE	MANITOU	\N	485	f	4226.60	JAWAD	208334	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8171	1	2025-11-03	3316896.00	46.00	SORTIE	MANITOU	\N	486	f	3152.70	JAWAD	208348	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8172	1	2025-11-03	3317246.00	350.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	353724.00	ABDELALI	208349	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8178	1	2025-11-04	3317789.00	56.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	123336.00	MBAREK	208355	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8179	1	2025-11-04	3317945.00	156.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8371.30	YOUSSEF	208356	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8181	1	2025-11-04	3318123.00	48.00	SORTIE	HYUNDAI 15991W6	\N	470	f	189031.00	HOUSSINE	208358	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8187	1	2025-11-04	3319686.00	46.00	SORTIE	MANITOU	\N	485	f	4225.10	JAWAD	208364	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8195	1	2025-11-05	3320685.00	275.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	13748.00	SAID	208372	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8203	1	2025-11-05	3321255.00	36.00	SORTIE	BERLINGO 41521A73	\N	487	f	46937.00	SAID	208380	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8208	1	2025-11-06	3321836.00	137.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8382.20	YOUSSEF	208385	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8209	1	2025-11-06	3322149.00	313.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	15805.00	AHMED	208386	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8212	1	2025-11-06	3322368.00	35.00	SORTIE	MANITOU	\N	485	f	4273.00	JAWAD	208389	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8219	1	2025-11-07	3323908.00	308.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	14055.00	SOULAYMAN	208396	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8220	1	2025-11-07	3323947.00	39.00	SORTIE	BOBCAT	\N	414	f	4502.00	IBRAHIM	208397	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8228	1	2025-11-08	3324881.00	141.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8393.20	YOUSSEF	208405	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8229	1	2025-11-08	3325189.00	308.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	14622.00	MOHAMED	208406	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8231	1	2025-11-08	3325819.00	440.00	SORTIE	HYUNDAI 7181W6	\N	DARBOUAZZA	t	\N	HAMZA	208408	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8234	1	2025-11-08	3326009.00	15.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	208411	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8239	1	2025-11-08	3326186.00	43.00	SORTIE	MANITOU	\N	485	f	4296.60	JAWAD	208416	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8245	1	2025-11-10	3327025.00	58.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	384206.00	ABDESSLAM	208422	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8249	1	2025-11-10	3327811.00	46.00	SORTIE	MANITOU	\N	486	f	3185.20	MILOUD	208426	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8250	1	2025-11-10	3327845.00	34.00	SORTIE	MANITOU	\N	485	f	4315.60	HASSAN	208427	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8251	1	2025-11-10	3328539.00	694.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	355811.00	ABDELALI	208428	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8259	1	2025-11-11	3329610.00	117.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8402.70	YOUSSEF	208436	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8260	1	2025-11-11	3329672.00	62.00	SORTIE	HYUNDAI 15991W6	\N	470	f	189388.00	HOUSSINE	208437	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8271	1	2025-11-12	3330712.00	305.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	14251.00	SAID	208448	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8274	1	2025-11-12	3331322.00	133.00	SORTIE	CHARGEUSE  CH04	\N	KF	t	17025.00	MOUNIR	208451	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8275	1	2025-11-12	3331360.00	38.00	SORTIE	MANITOU	\N	485	f	4335.80	HASSAN	208452	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8279	1	2025-11-13	3331834.00	43.00	SORTIE	BERLINGO 41521A73	\N	487	f	47655.00	SAID	208456	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8285	1	2025-11-14	3332703.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	123932.00	MBAREK	208466	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8287	1	2025-11-14	3332969.00	147.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8415.20	YOUSSEF	208468	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8289	1	2025-11-14	3333206.00	13.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	208470	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8290	1	2025-11-14	3333240.00	34.00	SORTIE	MANITOU	\N	485	f	4354.00	HASSAN	208471	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8297	1	2025-11-15	3334782.00	262.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	15003.00	MOHAMED	208478	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8298	1	2025-11-15	3335106.00	324.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	16294.00	AHMED	208479	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8300	1	2025-11-15	3335780.00	288.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	14406.00	SOULAYMAN	208481	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8301	1	2025-11-15	3335840.00	61.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	385299.00	ABDESSLAM	208482	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8313	1	2025-11-17	3336910.00	58.00	SORTIE	HYUNDAI 15991W6	\N	470	f	189757.00	HOUSSAM	208494	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8314	1	2025-11-17	3337059.00	149.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8426.70	IBRAHIM	208495	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8320	1	2025-11-17	3337676.00	29.00	SORTIE	BERLINGO 41521A73	\N	487	f	42128.00	SAID	208501	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8321	1	2025-11-17	3337718.00	42.00	SORTIE	MANITOU	\N	485	f	4379.60	HASSAN	208502	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8325	1	2025-11-17	3338015.00	49.00	SORTIE	MANITOU	\N	486	f	3219.00	JAWAD	208506	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8332	1	2025-11-18	3339731.00	721.00	SORTIE	MAN 21961A81	\N	ARMATURE	t	358075.00	ABDELILAH	208513	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8338	1	2025-11-19	3340728.00	109.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8437.80	YOUSSEF	208519	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8340	1	2025-11-19	3340805.00	37.00	SORTIE	MANITOU	\N	485	f	4400.20	HASSAN	208521	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8352	1	2025-11-20	3342605.00	301.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	14734.00	SAID	208533	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8353	1	2025-11-20	3343262.00	657.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1122667.00	SAID	208534	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8356	1	2025-11-20	3343668.00	290.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	359046.00	ABDELALI	208537	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8366	1	2025-11-21	3344709.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	190042.00	HOUSSINE	208547	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8368	1	2025-11-21	3344870.00	39.00	SORTIE	BERLINGO 50313A6	\N	8	f	449587.00	RACHID	208549	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8373	1	2025-11-21	3345534.00	36.00	SORTIE	MANITOU	\N	485	f	4422.00	HASSAN	208554	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8375	1	2025-11-21	3345620.00	39.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	208556	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8380	1	2025-11-22	3346274.00	33.00	SORTIE	BERLINGO 41521A73	\N	487	f	48662.00	SAID	208561	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8382	1	2025-11-22	3346520.00	136.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8448.30	YOUSSEF	208563	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8383	1	2025-11-22	3346830.00	310.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	14840.00	SOULAYMAN	208564	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8384	1	2025-11-22	3347087.00	257.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	16674.00	AHMED	208565	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8385	1	2025-11-22	3347375.00	288.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	15366.00	MOHAMED	208566	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8386	1	2025-11-22	3347426.00	51.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	386159.00	ABDESSLAM	208567	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8399	1	2025-11-24	3348706.00	371.00	SORTIE	VOLVO 87668W6	\N	KKF	t	394192.00	ABDERRAHIM	208580	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8401	1	2025-11-24	3349309.00	32.00	SORTIE	MANITOU	\N	485	f	\N	JAWAD	208582	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8403	1	2025-11-24	3349597.00	137.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8459.90	YOUSSEF	208584	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8410	1	2025-11-25	3350550.00	56.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	124595.00	MBAREK	208591	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8414	1	2025-11-25	3350828.00	55.00	SORTIE	MANITOU	\N	486	f	3256.00	MILOUD	208595	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8420	1	2025-11-26	3351297.00	60.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	387207.00	ABDESSLAM	208601	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8423	1	2025-11-26	3351836.00	271.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	15160.00	SAID	208604	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8428	1	2025-11-26	3352092.00	41.00	SORTIE	MANITOU	\N	485	f	4461.50	JAWAD	208609	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8429	1	2025-11-26	3352235.00	143.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8771.40	YOUSSEF	208610	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8430	1	2025-11-26	3352961.00	726.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1124400.00	SAID	208611	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8434	1	2025-11-27	3354088.00	704.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	361058.00	ABDELALI	208615	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8435	1	2025-11-27	3354149.00	61.00	SORTIE	HYUNDAI 15991W6	\N	470	f	190407.00	HOUSSINE	208616	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8438	1	2025-11-27	3354706.00	286.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	15247.00	SOULAYMAN	208619	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8447	1	2025-11-28	3355634.00	36.00	SORTIE	BERLINGO 41521A73	\N	487	f	42245.00	SAID	208628	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8449	1	2025-11-28	3356184.00	321.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	17170.00	AHMED	208630	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8451	1	2025-11-28	3356665.00	296.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	15778.00	MOHAMED	208632	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8452	1	2025-11-28	3356683.00	18.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	208633	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8463	1	2025-11-29	3358073.00	138.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8482.30	YOUSSEF	208644	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8465	1	2025-11-29	3358171.00	42.00	SORTIE	BOBCAT	\N	414	f	4512.00	IBRAHIM	208646	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8490	1	2025-12-02	3361984.00	1000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDWAN	208671	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8491	1	2025-12-02	3362107.00	123.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8492.70	YOUSSEF	208672	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8492	1	2025-12-02	3362169.00	62.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	388229.00	ABDESSLAM	208673	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8501	1	2025-12-03	3363451.00	66.00	SORTIE	HYUNDAI 15991W6	\N	470	f	190794.00	HOUSSINE	208682	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8502	1	2025-12-03	3363735.00	284.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	15614.00	SAID	208683	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8506	1	2025-12-03	3363900.00	42.00	SORTIE	MANITOU	\N	486	f	3285.90	MILOUD	208687	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8510	1	2025-12-03	3364445.00	313.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	15640.00	SOULAYMAN	208691	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8511	1	2025-12-03	3364495.00	50.00	SORTIE	MANITOU	\N	485	f	4489.30	HASSAN	208692	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8515	1	2025-12-04	3364785.00	34.00	SORTIE	BERLINGO 41521A73	\N	487	f	49809.00	SAID	208696	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8517	1	2025-12-04	3365260.00	272.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	17545.00	AHMED	208698	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8518	1	2025-12-04	3365383.00	123.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8501.30	YOUSSEF	208699	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8528	1	2025-12-05	3366410.00	58.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	125242.00	MBAREK	208709	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8531	1	2025-12-05	3366808.00	305.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	16162.00	MOHAMED	208712	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8532	1	2025-12-05	3366826.00	18.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	208713	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8534	1	2025-12-05	3367024.00	41.00	SORTIE	MANITOU	\N	485	f	4513.10	JAWAD	208715	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8539	1	2025-12-06	3367695.00	126.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8510.70	YOUSSEF	208720	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8546	1	2025-12-06	3368637.00	17.00	SORTIE	MANITOU	\N	485	f	4524.60	HASSAN	208727	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8558	1	2025-12-08	3369713.00	28.00	SORTIE	MANITOU	\N	485	f	\N	HASSAN	208739	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8566	1	2025-12-09	3370485.00	133.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8521.80	YOUSSEF	208747	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8568	1	2025-12-09	3370631.00	59.00	SORTIE	HYUNDAI 15991W6	\N	470	f	191148.00	HOUSSINE	208749	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8571	1	2025-12-09	3370735.00	38.00	SORTIE	MANITOU	\N	486	f	3311.80	HASSAN	208752	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8577	1	2025-12-10	3371236.00	53.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	38950.00	ABDESSLAM	208758	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8578	1	2025-12-10	3371568.00	332.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	18053.00	AHMED	208759	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8579	1	2025-12-10	3371603.00	34.00	SORTIE	BERLINGO 41521A73	\N	487	f	50320.00	SAID	208760	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8580	1	2025-12-10	3372169.00	566.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	362549.00	ABDELALI	208761	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8582	1	2025-12-10	3372790.00	302.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	16035.00	SOULAYMAN	208763	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8583	1	2025-12-10	3373057.00	267.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	16031.00	SAID	208764	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8591	1	2025-12-11	3373944.00	120.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8530.00	YOUSSEF	208772	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8594	1	2025-12-11	3374069.00	46.00	SORTIE	MANITOU	\N	485	f	4567.60	HASSAN	208775	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8605	1	2025-12-12	3375256.00	283.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	16550.00	MOHAMED	208786	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8606	1	2025-12-12	3375667.00	411.00	SORTIE	VOLVO 87668W6	\N	KKF	t	400080.00	ABDERRAHIM	208787	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8607	1	2025-12-12	3375719.00	51.00	SORTIE	HYUNDAI 15991W6	\N	470	f	191466.00	HOUSSINE	208788	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8610	1	2025-12-12	3376266.00	18.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	208791	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8621	1	2025-12-13	3377270.00	24.00	SORTIE	MANITOU	\N	485	f	4581.80	HASSAN	208802	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8625	1	2025-12-15	3377960.00	141.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8540.60	IBRAHIM	208806	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8627	1	2025-12-15	3378201.00	54.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	125851.00	MBAREK	208808	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8633	1	2025-12-15	3379008.00	31.00	SORTIE	MANITOU	\N	485	f	4600.80	HASSAN	208814	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8634	1	2025-12-15	3379041.00	33.00	SORTIE	MANITOU	\N	486	f	3333.90	MILOUD	208815	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8637	1	2025-12-16	3379263.00	43.00	SORTIE	BERLINGO 41521A73	\N	487	f	51048.00	SAID	208818	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8638	1	2025-12-16	3379890.00	627.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1125717.00	SAID	208819	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8641	1	2025-12-17	3380550.00	229.00	SORTIE	MIT 11469A73	\N	969072	f	969072.00	ABDELKHALEK	208822	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8651	1	2025-12-17	3381861.00	29.00	SORTIE	MANITOU	\N	485	f	4616.60	HASSAN	208832	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8656	1	2025-12-18	3382252.00	63.00	SORTIE	HYUNDAI 15991W6	\N	470	f	191831.00	HOUSSINE	208837	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8658	1	2025-12-18	3382352.00	39.00	SORTIE	BERLINGO 50313A6	\N	8	f	449998.00	RACHID	208839	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8666	1	2025-12-19	3382935.00	116.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8550.50	YOUSSEF	208847	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8668	1	2025-12-20	3383026.00	41.00	SORTIE	BERLINGO 41521A73	\N	487	f	51762.00	SAID	208849	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8670	1	2025-12-20	3385066.00	2000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	208851	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8672	1	2025-12-20	3385460.00	259.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	16872.00	MOHAMED	208853	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8674	1	2025-12-20	3385509.00	17.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	208855	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8676	1	2025-12-20	3385602.00	33.00	SORTIE	MANITOU	\N	485	f	4635.90	HASSAN	208857	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8682	1	2025-12-22	3386582.00	142.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8560.60	YOUSSEF	208863	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8683	1	2025-12-22	3386906.00	324.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	18486.00	AHMED	208864	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8684	1	2025-12-22	3387202.00	296.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	16368.00	SOULAYMAN	208865	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8685	1	2025-12-22	3387528.00	326.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	16558.00	SAID	208866	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8686	1	2025-12-22	3387561.00	33.00	SORTIE	MANITOU	\N	486	f	3354.40	MILOUD	208867	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8694	1	2025-12-23	3389111.00	850.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	364909.00	ABDELALI	208875	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8702	1	2025-12-23	3390147.00	27.00	SORTIE	MANITOU	\N	485	f	4653.30	JAWAD	208883	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8707	1	2025-12-24	3390698.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	126440.00	MBAREK	208888	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8708	1	2025-12-24	3390760.00	62.00	SORTIE	HYUNDAI 15991W6	\N	470	f	192206.00	HOUSSINE	208889	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8710	1	2025-12-24	3390985.00	135.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8571.20	YOUSSEF	208891	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8716	1	2025-12-25	3391745.00	41.00	SORTIE	MANITOU	\N	485	f	4678.70	JAWAD	208897	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8667	1	2025-12-19	3382986.00	51.00	SORTIE	LINDE	\N	472	f	12714.00	AZIZ	208848	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8725	1	2025-12-26	3392867.00	34.00	SORTIE	BERLINGO 41521A73	\N	487	f	52260.00	SAID	208906	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8726	1	2025-12-26	3392928.00	61.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	391639.00	ABDESSLAM	208907	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8729	1	2025-12-26	3393481.00	37.00	SORTIE	MANITOU	\N	486	f	3376.60	MILOUD	208910	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8730	1	2025-12-26	3393495.00	14.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	208911	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8736	1	2025-12-27	3394129.00	136.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8582.30	YOUSSEF	208917	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8740	1	2025-12-27	3394293.00	45.00	SORTIE	MANITOU	\N	485	f	4705.00	JAWAD	208921	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8749	1	2025-12-29	3395038.00	35.00	SORTIE	MANITOU	\N	485	f	4727.00	JAWAD	208930	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8753	1	2025-12-30	3395447.00	63.00	SORTIE	HYUNDAI 15991W6	\N	470	f	192578.00	HOUSSINE	208934	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8759	1	2025-12-31	3395925.00	124.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8592.00	YOUSSEF	208940	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8763	1	2025-12-31	3396797.00	13.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	208944	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8768	1	2025-12-31	3397168.00	31.00	SORTIE	MANITOU	\N	486	f	3396.20	MILOUD	208949	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8769	1	2025-12-31	3397204.00	36.00	SORTIE	MANITOU	\N	485	f	4751.40	JAWAD	208950	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8719	1	2025-12-25	3392013.00	31.00	SORTIE	LINDE	\N	472	f	12754.10	ABDELLAH	208900	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8774	1	2026-01-01	3398557.00	797.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	367146.00	ABDELALI	208955	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8775	1	2026-01-01	3398614.00	57.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	392572.00	ABDESSLAM	208956	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8783	1	2026-01-02	3399456.00	40.00	SORTIE	BERLINGO 41521A73	\N	487	f	52872.00	SAID	208964	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8788	1	2026-01-02	3399732.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	127076.00	MBAREK	208969	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8789	1	2026-01-02	3400045.00	313.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	18933.00	AHMED	208970	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8790	1	2026-01-02	3400359.00	314.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	16750.00	SOULAYMAN	208971	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8799	1	2026-01-03	3401396.00	120.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8600.60	IBRAHIM	208980	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8800	1	2026-01-03	3401723.00	327.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	17029.00	SAID	208981	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8807	1	2026-01-03	3402302.00	22.00	SORTIE	MANITOU	\N	486	f	3410.40	MILOUD	208988	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8811	1	2026-01-03	3402430.00	48.00	SORTIE	MANITOU	\N	485	f	4779.70	JAWAD	208992	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8816	1	2026-01-05	3403093.00	47.00	SORTIE	HYUNDAI 15991W6	\N	470	f	192860.00	HOUSSINE	208997	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8817	1	2026-01-05	3403406.00	313.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	17258.00	ABDELILAH	208998	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8831	1	2026-01-06	3405386.00	37.00	SORTIE	MANITOU	\N	485	f	4803.50	HASSAN	205512	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8835	1	2026-01-07	3405894.00	124.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8612.50	YOUSSEF	205517	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8838	1	2026-01-07	3406041.00	20.00	SORTIE	MANITOU	\N	486	f	3423.00	MILOUD	205520	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8840	1	2026-01-07	3406105.00	43.00	SORTIE	BERLINGO 41521A73	\N	487	f	53545.00	SAID	205522	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8847	1	2026-01-08	3406832.00	29.00	SORTIE	MANITOU	\N	485	f	4819.00	HAMID	205529	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8855	1	2026-01-09	3407562.00	66.00	SORTIE	HYUNDAI 15991W6	\N	470	f	193233.00	HOUSSINE	205537	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8858	1	2026-01-09	3408000.00	23.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205540	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8860	1	2026-01-09	3408138.00	63.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	393845.00	ABDESSLAM	205542	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8865	1	2026-01-10	3408409.00	21.00	SORTIE	BERLINGO 41521A73	\N	487	f	53877.00	SAID	205547	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8871	1	2026-01-12	3408929.00	32.00	SORTIE	MANITOU	\N	486	f	3444.00	MILOUD	205557	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8873	1	2026-01-12	3409020.00	59.00	SORTIE	MANITOU	\N	485	f	4850.90	HASSAN	205559	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8878	1	2026-01-13	3409757.00	38.00	SORTIE	BOBCAT	\N	414	f	4522.30	IBRAHIM	205564	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8882	1	2026-01-13	3410352.00	126.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8635.00	YOUSSEF	205568	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8884	1	2026-01-13	3410838.00	330.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	19500.00	AHMED	205570	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8885	1	2026-01-13	3411135.00	297.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	17504.00	SAID	205571	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8887	1	2026-01-13	3411809.00	312.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	17640.00	ABDELILAH	205573	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8889	1	2026-01-13	3412140.00	298.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	17211.00	SOULAYMAN	205575	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8894	1	2026-01-13	3412334.00	29.00	SORTIE	BERLINGO 41521A73	\N	487	f	54391.00	SAID	205580	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8895	1	2026-01-13	3412390.00	56.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	127703.00	MBAREK	205581	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8899	1	2026-01-14	3413501.00	704.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	369272.00	SAID	205585	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8901	1	2026-01-14	3413609.00	43.00	SORTIE	MANITOU	\N	485	f	4872.00	HASSAN	205587	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8908	1	2026-01-15	3414281.00	43.00	SORTIE	AUDI 65923B72	\N	\N	f	\N	MAGHNIA	205594	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8917	1	2026-01-16	3415342.00	56.00	SORTIE	HYUNDAI 15991W6	\N	470	f	193593.00	HOUSSINE	205603	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8919	1	2026-01-16	3415612.00	182.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8649.00	YOUSSEF	205605	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8921	1	2026-01-16	3416012.00	33.00	SORTIE	MANITOU	\N	486	f	3465.70	MILOUD	205607	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8922	1	2026-01-16	3416031.00	19.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205608	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8923	1	2026-01-16	3416072.00	41.00	SORTIE	MANITOU	\N	485	f	4894.60	HASSAN	205609	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8890	1	2026-01-13	3412175.00	35.00	SORTIE	LINDE	\N	477	f	9473.90	CHAABI	205576	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8935	1	2026-01-17	3417398.00	60.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	394899.00	ABDESSLAM	205621	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8940	1	2026-01-17	3417689.00	24.00	SORTIE	MANITOU	\N	485	f	4907.70	HASSAN	205626	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8946	1	2026-01-19	3418164.00	155.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8661.90	YOUSSEF	205632	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8949	1	2026-01-19	3418383.00	23.00	SORTIE	MANITOU	\N	486	f	3479.50	MILOUD	205635	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8952	1	2026-01-19	3418641.00	32.00	SORTIE	MANITOU	\N	485	f	4926.30	JAWAD	205638	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8957	1	2026-01-20	3419177.00	37.00	SORTIE	BERLINGO 41521A73	\N	487	f	54979.00	SAID	205643	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8966	1	2026-01-21	3420662.00	477.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	370796.00	SAID	205652	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8967	1	2026-01-21	3420996.00	334.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	18119.00	ABDELILAH	205653	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8969	1	2026-01-21	3421740.00	317.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	17626.00	SOULAYMAN	205655	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8973	1	2026-01-21	3421998.00	37.00	SORTIE	MANITOU	\N	485	f	4946.50	JAWAD	205659	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8978	1	2026-01-22	3422799.00	62.00	SORTIE	HYUNDAI 15991W6	\N	470	f	193965.00	HOUSSINE	205664	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8979	1	2026-01-22	3423133.00	334.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	20025.00	AHMED	205665	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8984	1	2026-01-22	3423511.00	27.00	SORTIE	MANITOU	\N	486	f	3496.30	MILOUD	205670	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8989	1	2026-01-23	3424520.00	319.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	17995.00	SAID	205675	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8991	1	2026-01-23	3424732.00	56.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	128376.00	MBAREK	205677	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8992	1	2026-01-23	3424888.00	156.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8675.00	YOUSSEF	205678	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8993	1	2026-01-23	3424924.00	36.00	SORTIE	MANITOU	\N	485	f	4968.80	JAWAD	205679	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8999	1	2026-01-24	3425894.00	32.00	SORTIE	BERLINGO 41521A73	\N	487	f	55494.00	SAID	205685	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9004	1	2026-01-24	3426119.00	16.00	SORTIE	MANITOU	\N	485	f	4978.60	JAWAD	205690	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9016	1	2026-01-26	3427273.00	60.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	395892.00	ABDESSLAM	205702	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9026	1	2026-01-27	3428588.00	159.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8688.80	YOUSSEF	205712	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9028	1	2026-01-27	3428839.00	57.00	SORTIE	MANITOU	\N	485	f	5011.60	JAWAD	205714	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9032	1	2026-01-27	3429107.00	33.00	SORTIE	MANITOU	\N	486	f	3513.80	MILOUD	205718	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8983	1	2026-01-22	3423484.00	55.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	205669	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9036	1	2026-01-28	3429453.00	66.00	SORTIE	HYUNDAI 15991W6	\N	470	f	194338.00	HOUSSINE	205722	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9050	1	2026-01-29	3431354.00	317.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	18028.00	SOULAYMAN	205736	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9051	1	2026-01-29	3431659.00	305.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	18529.00	ABDELILAH	205737	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9054	1	2026-01-29	3431757.00	41.00	SORTIE	MANITOU	\N	485	f	5034.90	JAWAD	205740	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9057	1	2026-01-30	3431925.00	33.00	SORTIE	BERLINGO 41521A73	\N	487	f	55962.00	SAID	205743	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9058	1	2026-01-30	3432238.00	313.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	20474.00	AHMED	205744	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9062	1	2026-01-30	3432643.00	151.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8700.70	YOUSSEF	205748	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9064	1	2026-01-30	3433063.00	22.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205750	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9072	1	2026-01-31	3434171.00	50.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	373436.00	SAID	205758	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9073	1	2026-01-31	3434200.00	29.00	SORTIE	MANITOU	\N	486	f	3531.40	MILOUD	205759	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9078	1	2026-01-31	3434423.00	20.00	SORTIE	BERLINGO 50313A6	\N	8	f	450284.00	AHMED	205764	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9080	1	2026-01-31	3434496.00	43.00	SORTIE	MANITOU	\N	485	f	5058.70	JAWAD	205766	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9084	1	2026-02-02	3434801.00	59.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	397120.00	ABDESSLAM	205770	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9086	1	2026-02-02	3434863.00	31.00	SORTIE	MANITOU	\N	485	f	5075.50	HASSAN	205772	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9091	1	2026-02-03	3436037.00	794.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	373569.00	SAID	205783	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9094	1	2026-02-04	3436514.00	213.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	20793.00	AHMED	205786	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9096	1	2026-02-04	3436845.00	253.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	18365.00	SOULAYMAN	205788	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9097	1	2026-02-04	3437165.00	320.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	18728.00	SAID	205789	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9098	1	2026-02-04	3437445.00	280.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	18875.00	ABDELILAH	205790	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9099	1	2026-02-04	3437917.00	472.00	SORTIE	VOLVO 60518E6	\N	KF	t	465606.00	AZIZ	205791	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9100	1	2026-02-04	3438430.00	513.00	SORTIE	VOLVO 60517E6	\N	KF	t	469303.00	MOHAMED	205792	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9101	1	2026-02-04	3438460.00	30.00	SORTIE	BERLINGO 41521A73	\N	487	f	56433.00	SAID	205793	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9104	1	2026-02-04	3439812.00	1000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	205796	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9106	1	2026-02-04	3439889.00	47.00	SORTIE	MANITOU	\N	485	f	5099.00	HASSAN	205798	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9107	1	2026-02-04	3439919.00	30.00	SORTIE	MANITOU	\N	486	f	3549.50	MILOUD	205799	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9109	1	2026-02-05	3440211.00	161.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8730.10	YOUSSEF	205801	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9115	1	2026-02-05	3440882.00	12.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205807	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9123	1	2026-02-06	3442273.00	48.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	129248.00	MBAREK	205815	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9126	1	2026-02-06	3442495.00	44.00	SORTIE	LINDE	\N	485	f	5121.80	HASSAN	205818	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9135	1	2026-02-07	3443250.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	195101.00	HOUSSINE	205827	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9146	1	2026-02-09	3443946.00	30.00	SORTIE	BERLINGO 41521A73	\N	487	f	56896.00	SAID	205838	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9155	1	2026-02-10	3444864.00	40.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	398231.00	ABDESSLAM	205847	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9163	1	2026-02-12	3446032.00	350.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	21287.00	AHMED	205871	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9165	1	2026-02-12	3446550.00	172.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8768.00	IBRAHIM	205873	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9167	1	2026-02-12	3446883.00	293.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	19405.00	ABDELILAH	205875	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9168	1	2026-02-12	3447126.00	243.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	19099.00	SAID	205876	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9170	1	2026-02-12	3447584.00	315.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	18918.00	SOULAYMAN	205878	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9172	1	2026-02-13	3447648.00	33.00	SORTIE	BERLINGO 41521A73	\N	487	f	57439.00	SAID	205880	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9177	1	2026-02-13	3448149.00	16.00	SORTIE	DACIA 36119A9	\N	\N	f	\N	LAMTOUGI	205885	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9179	1	2026-02-13	3448329.00	144.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8776.90	YOUSSEF	205887	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9181	1	2026-02-13	3448421.00	47.00	SORTIE	MANITOU	\N	485	f	5187.00	JAWAD	205889	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9187	1	2026-02-14	3449003.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	129859.00	MBAREK	205895	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9189	1	2026-02-14	3449247.00	54.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	398796.00	ABDESSLAM	205897	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9194	1	2026-02-14	3449653.00	26.00	SORTIE	MANITOU	\N	485	f	5199.70	HASSAN	205902	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9202	1	2026-02-16	3451486.00	282.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	21732.00	AHMED	205910	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9203	1	2026-02-16	3451647.00	161.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8789.00	IBRAHIM	205911	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9209	1	2026-02-16	3452146.00	30.00	SORTIE	MANITOU	\N	485	f	5216.60	JAWAD	205917	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9211	1	2026-02-17	3452415.00	62.00	SORTIE	HYUNDAI 15991W6	\N	470	f	195782.00	HOUSSINE	205919	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9212	1	2026-02-17	3452708.00	293.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	19561.00	SAID	205920	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9213	1	2026-02-17	3453016.00	308.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	19814.00	ABDELILAH	205921	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9217	1	2026-02-17	3453181.00	45.00	SORTIE	MANITOU	\N	486	f	3609.90	MILOUD	205925	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9220	1	2026-02-18	3453408.00	38.00	SORTIE	BERLINGO 41521A73	\N	487	f	58064.00	SAID	205928	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9221	1	2026-02-18	3453558.00	150.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8804.00	YOUSSEF	205929	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9224	1	2026-02-18	3454107.00	297.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	19319.00	SOULAYMAN	205932	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9233	1	2026-02-18	3455029.00	56.00	SORTIE	MANITOU	\N	485	f	5245.00	JAWAD	205941	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9236	1	2026-02-19	3455826.00	510.00	SORTIE	VOLVO 60517W6	\N	KKF	t	472497.00	MOHAMED	205944	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9238	1	2026-02-19	3455944.00	31.00	SORTIE	BOBCAT	\N	414	f	4530.00	IBRAHIM	205946	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9239	1	2026-02-19	3456076.00	132.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8815.30	YOUSSEF	205947	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9241	1	2026-02-19	3456816.00	682.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	375485.00	ABDELALI	205949	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9248	1	2026-02-20	3457460.00	37.00	SORTIE	BERLINGO 41521A73	\N	487	f	58731.00	SAID	205956	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9250	1	2026-02-20	3457539.00	49.00	SORTIE	HYUNDAI 15991W6	\N	470	f	196092.00	HOUSSINE	205958	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9253	1	2026-02-20	3457681.00	35.00	SORTIE	MANITOU	\N	485	f	52651.00	JAWAD	205961	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9258	1	2026-02-21	3458794.00	298.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	22154.00	AHMED	205966	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9259	1	2026-02-21	3460794.00	2000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	205967	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9264	1	2026-02-21	3461268.00	153.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8827.80	YOUSSEF	205972	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9269	1	2026-02-21	3461440.00	33.00	SORTIE	MANITOU	\N	486	f	3631.90	ABDELLAH	205977	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9270	1	2026-02-21	3461492.00	52.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	130190.00	MBAREK	205978	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9279	1	2026-02-23	3463020.00	42.00	SORTIE	MANITOU	\N	485	f	5290.10	JAWAD	205987	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9282	1	2026-02-24	3463402.00	293.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	20184.00	ABDELILAH	205990	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9292	1	2026-02-24	3464278.00	144.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8839.80	YOUSSEF	206000	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9294	1	2026-02-25	3464508.00	38.00	SORTIE	BERLINGO 41521A73	\N	487	f	59328.00	SAID	206752	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9296	1	2026-02-25	3464933.00	286.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	19672.00	SOULAYMAN	206754	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9299	1	2026-02-25	3465241.00	45.00	SORTIE	MANITOU	\N	486	f	3660.00	JAWAD	206757	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9306	1	2026-02-26	3466504.00	554.00	SORTIE	VOLVO  87668E6	\N	KF	t	417492.00	ABDERRAHIM	206764	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9308	1	2026-02-26	3466851.00	304.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	19965.00	SAID	206766	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9312	1	2026-02-26	3467240.00	146.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8852.50	YOUSSEF	206770	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9313	1	2026-02-26	3467289.00	49.00	SORTIE	MANITOU	\N	485	f	5316.00	JAWAD	206771	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9318	1	2026-02-27	3467723.00	32.00	SORTIE	BERLINGO 41521A73	\N	487	f	59862.00	SAID	206776	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9333	1	2026-02-28	3469099.00	31.00	SORTIE	BERLINGO 41521A73	\N	487	f	60449.00	SAID	206791	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9334	1	2026-02-28	3469203.00	105.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8861.00	YOUSSEF	206792	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9335	1	2026-02-28	3469320.00	117.00	SORTIE	MAN 10362B6	\N	KF DAR B	t	18113.00	AHMED	206793	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9336	1	2026-02-28	3469952.00	631.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	377332.00	ABDELALI	206794	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9337	1	2026-02-28	3470255.00	303.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	22596.00	AHMED	206795	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9340	1	2026-02-28	3470410.00	63.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	401136.00	ABDESSLAM	206798	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9342	1	2026-02-28	3470631.00	32.00	SORTIE	MANITOU	\N	486	f	3681.20	ABDELLAH	206800	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9346	1	2026-03-02	3470966.00	50.00	SORTIE	HYUNDAI 15991W6	\N	470	f	196390.00	HOUSSINE	206804	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9347	1	2026-03-02	3470984.00	17.00	SORTIE	MANITOU	\N	486	f	3692.00	AZIZ	206805	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9353	1	2026-03-02	3472185.00	660.00	SORTIE	VOLVO 74802B6	\N	KF DAR B	t	1231814.00	IDRISS	206811	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9356	1	2026-03-03	3472561.00	41.00	SORTIE	AUDI 65923B72	\N	\N	f	\N	MAGHNIA	206814	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9358	1	2026-03-03	3472655.00	58.00	SORTIE	MANITOU	\N	485	f	5349.00	HASSAN	206816	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9366	1	2026-02-04	3474174.00	60.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	131180.00	MBAREK	206824	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9367	1	2026-02-04	3474510.00	336.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	20631.00	ABDELILAH	206825	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9368	1	2026-02-04	3474550.00	40.00	SORTIE	HYUNDAI 15991W6	\N	470	f	196671.00	HOUSSINE	206826	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9369	1	2026-02-04	3474707.00	157.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8873.50	YOUSSEF	206827	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9370	1	2026-02-04	3474736.00	30.00	SORTIE	LINDE	\N	486	f	3709.40	AZIZ	206828	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9384	1	2026-03-06	3476702.00	294.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	20042.00	SOULAYMAN	206842	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9388	1	2026-03-06	3477639.00	531.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1126681.00	SAID	206846	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9389	1	2026-03-06	3477668.00	29.00	SORTIE	MANITOU	\N	486	f	3726.00	AZIZ	206847	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9390	1	2026-03-06	3477709.00	41.00	SORTIE	MANITOU	\N	485	f	5372.00	HASSAN	206848	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9397	1	2026-03-07	3478305.00	34.00	SORTIE	BERLINGO 41521A73	\N	487	f	60954.00	SAID	206855	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9399	1	2026-03-07	3478747.00	282.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	20421.00	SAID	206857	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9401	1	2026-03-07	3479082.00	148.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8884.60	YOUSSEF	206859	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9411	1	2026-03-09	3480003.00	39.00	SORTIE	MANITOU	\N	486	f	3749.50	AZIZ	206869	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9413	1	2026-03-09	3480231.00	56.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	402099.00	ABDESSLAM	206871	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9418	1	2026-03-09	3480516.00	38.00	SORTIE	MANITOU	\N	485	f	5395.40	JAWAD	206876	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9423	1	2026-03-10	3481077.00	287.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	20997.00	ABDELILAH	206881	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9424	1	2026-03-10	3481139.00	62.00	SORTIE	HYUNDAI 15991W6	\N	470	f	197035.00	HOUSSINE	206882	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9425	1	2026-03-10	3481192.00	53.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	131804.00	MBAREK	206883	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9428	1	2026-03-10	3481497.00	135.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8896.70	YOUSSEF	206886	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9430	1	2026-03-11	3481951.00	284.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	20415.00	SOULAYMAN	206888	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9433	1	2026-03-11	3482246.00	28.00	SORTIE	MANITOU	\N	486	f	3767.00	AZIZ	206891	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9438	1	2026-03-12	3483835.00	313.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	23043.00	AHMED	206896	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9443	1	2026-03-12	3484439.00	47.00	SORTIE	MANITOU	\N	485	f	5421.70	ABDELMALEK	206901	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9445	1	2026-03-12	3484774.00	153.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8909.70	YOUSSEF	206903	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9449	1	2026-03-12	3485000.00	19.00	SORTIE	MANITOU	\N	486	f	3779.30	AZIZ	206907	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9453	1	2026-03-13	3485357.00	37.00	SORTIE	BOBCAT	\N	414	f	4544.00	IBRAHIM	206911	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9455	1	2026-03-13	3485486.00	48.00	SORTIE	HYUNDAI 15991W6	\N	470	f	197321.00	HOUSSINE	206913	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9463	1	2026-03-14	3486337.00	319.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	20903.00	SAID	206921	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9466	1	2026-03-14	3487019.00	306.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	21405.00	ABDELLAH	206924	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9467	1	2026-03-14	3487038.00	19.00	SORTIE	MANITOU	\N	486	f	3791.70	AZIZ	206925	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9468	1	2026-03-14	3487569.00	531.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1127988.00	SAID	206926	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9469	1	2026-03-14	3487710.00	141.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8920.00	YOUSSEF	206927	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9478	1	2026-03-16	3489055.00	25.00	SORTIE	AUDI 65923B72	\N	\N	f	\N	MAGHNIA	206936	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9479	1	2026-03-16	3489114.00	59.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	132512.00	MBAREK	206937	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9482	1	2026-03-16	3489559.00	276.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	20768.00	SOULAYMAN	206940	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9483	1	2026-03-16	3490299.00	740.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	379257.00	ABDELALI	206941	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9488	1	2026-03-16	3490805.00	28.00	SORTIE	MANITOU	\N	486	f	3808.70	ABDELLAH	206946	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9489	1	2026-03-16	3490855.00	50.00	SORTIE	MANITOU	\N	485	f	5451.00	JAWAD	206947	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9490	1	2026-03-16	3491005.00	150.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8933.00	YOUSSEF	206948	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9493	1	2026-03-17	3491263.00	40.00	SORTIE	BERLINGO 41521A73	\N	487	f	61573.00	SAID	206951	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9502	1	2026-03-18	3493024.00	317.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	23508.00	AHMED	206960	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9504	1	2026-03-18	3493149.00	97.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8941.60	YOUSSEF	206962	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9506	1	2026-03-18	3493259.00	32.00	SORTIE	MANITOU	\N	486	f	3825.70	ABDELLAH	206964	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9514	1	2026-03-19	3494200.00	61.00	SORTIE	HYUNDAI 15991W6	\N	470	f	197691.00	HOUSSINE	206972	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9515	1	2026-03-19	3494254.00	54.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	403180.00	ABDESSLAM	206973	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9517	1	2026-03-19	3494334.00	42.00	SORTIE	MANITOU	\N	485	f	5477.00	JAWAD	206975	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9518	1	2026-03-19	3494348.00	14.00	SORTIE	BERLINGO 41521A73	\N	487	f	61775.00	SAID	206976	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9529	1	2026-03-26	3495674.00	43.00	SORTIE	MANITOU	\N	486	f	3851.00	ABDELLAH	206987	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9539	1	2026-03-28	3496483.00	63.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	404252.00	ABDESSLAM	206997	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9541	1	2026-03-28	3496708.00	43.00	SORTIE	MANITOU	\N	485	f	5504.00	JAWAD	206999	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9542	1	2026-03-28	3496739.00	31.00	SORTIE	MANITOU	\N	486	f	3867.70	ABDELLAH	207000	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9546	1	2026-03-30	3497093.00	62.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	133700.00	MBAREK	206704	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9549	1	2026-03-30	3497568.00	60.00	SORTIE	HYUNDAI 15991W6	\N	470	f	198066.00	HASSAN	206707	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9550	1	2026-03-30	3497595.00	27.00	SORTIE	MANITOU	\N	486	f	3883.50	AZIZ	206708	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9557	1	2026-03-31	3498377.00	37.00	SORTIE	AUDI 65923B72	\N	\N	f	\N	MAGHNIA	206715	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9558	1	2026-03-31	3498557.00	180.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8955.90	YOUSSEF	206716	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9559	1	2026-03-31	3498854.00	297.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	21833.00	ABDELILAH	206717	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9562	1	2026-03-31	3499432.00	489.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1129194.00	SAID	206720	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9568	1	2026-04-01	3500478.00	296.00	SORTIE	VOLVO 74802B6	\N	KF DAR B	t	1233217.00	IDRISS	206726	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9570	1	2026-04-01	3501045.00	297.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	21576.00	SAID	206728	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9575	1	2026-04-01	3501779.00	38.00	SORTIE	MANITOU	\N	485	f	5527.00	HASSAN	206733	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9585	1	2026-04-02	3502901.00	43.00	SORTIE	MANITOU	\N	486	f	3910.00	AZIZ	206743	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9592	1	2026-04-03	3503676.00	61.00	SORTIE	HYUNDAI 15991W6	\N	470	f	198436.00	HOUSSINE	206750	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9602	1	2026-04-04	3505548.00	294.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	21180.00	SOULAYMAN	206660	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9605	1	2026-04-04	3505957.00	62.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	405556.00	ABDESSLAM	206663	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9608	1	2026-04-04	3506340.00	167.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8972.50	YOUSSEF	206666	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9609	1	2026-04-04	3506371.00	31.00	SORTIE	MANITOU	\N	486	f	3930.80	AZIZ	206667	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9612	1	2026-04-04	3506475.00	5.00	SORTIE	CAB	\N	ARMABETON	t	\N	CHOUAIB	206670	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9614	1	2026-04-04	3506563.00	50.00	SORTIE	MANITOU	\N	485	f	555.90	HASSAN	206672	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9621	1	2026-04-06	3507313.00	60.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	134453.00	MBAREK	206679	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9624	1	2026-04-06	3507734.00	42.00	SORTIE	BOBCAT	\N	414	f	4560.00	IBRAHIM	206682	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9628	1	2026-04-06	3508592.00	293.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	23959.00	AHMED	206686	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9632	1	2026-04-06	3508930.00	30.00	SORTIE	LINDE	\N	8081.5	t	8081.50	MILOUD	206690	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9633	1	2026-04-06	3508957.00	27.00	SORTIE	MANITOU	\N	486	f	3949.50	AZIZ	206691	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9635	1	2026-04-07	3509025.00	46.00	SORTIE	BERLINGO 41521A73	\N	487	f	62552.00	SAID	206693	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9643	1	2026-04-07	3510217.00	544.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	380918.00	ABDELALI	206601	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9644	1	2026-04-07	3510258.00	41.00	SORTIE	MANITOU	\N	485	f	5577.60	HASSAN	206602	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9649	1	2026-04-08	3511364.00	440.00	SORTIE	VOLVO 87668W6	\N	KFF	t	428756.00	ABDERRAHIM	206607	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9650	1	2026-04-08	3511567.00	203.00	SORTIE	MIT 30114D6	\N	KKF	t	481215.00	MEHDI	206608	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9651	1	2026-04-08	3512567.00	1000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	206609	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9656	1	2026-04-08	3512944.00	35.00	SORTIE	MANITOU	\N	486	f	3972.00	AZIZ	206614	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9663	1	2026-04-09	3513811.00	56.00	SORTIE	HYUNDAI 15991W6	\N	470	f	198794.00	HOUSSINE	206621	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9664	1	2026-04-09	3513964.00	153.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8988.00	YOUSSEF	206622	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9667	1	2026-04-09	3515152.00	667.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	113070.00	SAID	206625	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9669	1	2026-04-09	3515231.00	36.00	SORTIE	MANITOU	\N	485	f	5598.00	HASSAN	206627	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9683	1	2026-04-10	3516776.00	59.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	406970.00	ABDESSLAM	206641	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9688	1	2026-04-11	3517542.00	140.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	8979.30	YOUSSEF	206646	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9690	1	2026-04-11	3518005.00	316.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	22256.00	ABDELILAH	206648	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9692	1	2026-04-11	3518233.00	26.00	SORTIE	BERLINGO 41521A73	\N	487	f	62947.00	SAID	206650	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9693	1	2026-04-11	3518272.00	39.00	SORTIE	MANITOU	\N	486	f	3998.70	AZIZ	206651	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9694	1	2026-04-11	3518310.00	38.00	SORTIE	MANITOU	\N	485	f	5617.30	KAMAL	206652	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9708	1	2026-04-14	3520210.00	57.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	135173.00	MBAREK	206566	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9709	1	2026-04-14	3520530.00	320.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	21868.00	SAID	206567	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9710	1	2026-04-14	3520690.00	160.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	9012.10	YOUSSEF	206568	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9711	1	2026-04-14	3520713.00	23.00	SORTIE	BOBCAT	\N	414	f	4567.00	IBRAHIM	206569	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9712	1	2026-04-14	3521023.00	310.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	21580.00	SOULAYMAN	206570	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9713	1	2026-04-14	3521678.00	655.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1132207.00	SAID	206571	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9718	1	2026-04-14	3522447.00	22.00	SORTIE	MANITOU	\N	486	f	4013.30	ABDELLAH	206576	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9723	1	2026-04-15	3523191.00	48.00	SORTIE	AUDI 65923B72	\N	\N	f	\N	MAGHNIA	206581	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9674	1	2026-04-10	3515779.00	49.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	206632	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9729	1	2026-04-15	3523692.00	58.00	SORTIE	HYUNDAI 15991W6	\N	470	f	199158.00	HOUSSINE	206587	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9730	1	2026-04-15	3524003.00	311.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	24402.00	AHMED	206588	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9734	1	2026-04-16	3524278.00	160.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	9024.80	YOUSSEF	206592	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9740	1	2026-04-16	3525970.00	294.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	22755.00	ABDELILAH	206598	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9744	1	2026-04-16	3526376.00	30.00	SORTIE	MANITOU	\N	486	f	4033.90	ABDELLAH	206502	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9745	1	2026-04-16	3526976.00	600.00	SORTIE	VOLVO 21961A81	\N	ARMATURE	t	383183.00	ABDELALI	206503	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9752	1	2026-04-17	3527392.00	29.00	SORTIE	BERLINGO 41521A73	\N	487	f	63413.00	SAID	206510	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9753	1	2026-04-17	3527450.00	58.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	408020.00	ABDESSLAM	206511	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9755	1	2026-04-17	3527500.00	33.00	SORTIE	MANITOU	\N	485	f	5656.00	JAWAD	206514	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9759	1	2026-04-18	3527993.00	115.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	9034.90	YOUSSEF	206518	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9761	1	2026-04-18	3528083.00	48.00	SORTIE	BERLINGO 41521A73	\N	487	f	64370.00	SAID	206520	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9770	1	2026-04-20	3529133.00	100.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	22332.00	SAID	206529	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9773	1	2026-04-20	3529506.00	41.00	SORTIE	MANITOU	\N	485	f	5680.00	JAWAD	206532	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9776	1	2026-04-20	3529588.00	31.00	SORTIE	MANITOU	\N	486	f	4054.40	ABDELLAH	206535	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9779	1	2026-04-21	3529865.00	57.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	135870.00	MBAREK	206538	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9780	1	2026-04-21	3529924.00	59.00	SORTIE	HYUNDAI 15991W6	\N	470	f	199517.00	HOUSSINE	206539	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9797	1	2026-04-22	3532127.00	36.00	SORTIE	MANITOU	\N	485	f	5700.00	JAWAD	206006	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9800	1	2026-04-23	3532736.00	306.00	SORTIE	SITRAK 70223D8	\N	ARMABETON	t	22185.00	SOULAYMAN	206009	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9803	1	2026-04-23	3533188.00	330.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	25078.00	AHMED	206012	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9805	1	2026-04-23	3533494.00	148.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	9060.00	YOUSSEF	206014	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9806	1	2026-04-23	3533786.00	292.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	23188.00	ABDELILAH	206015	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9807	1	2026-04-23	3534078.00	292.00	SORTIE	SITRAK 70226D8	\N	ARMABETON	t	22602.00	SAID	206016	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9811	1	2026-04-23	3534358.00	38.00	SORTIE	MANITOU	\N	486	f	4078.00	ABDELAH	206020	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9813	1	2026-04-23	3534942.00	558.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1133411.00	SAID	206022	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9818	1	2026-04-24	3535288.00	34.00	SORTIE	BERLINGO 41521A73	\N	487	f	64934.00	SAID	206027	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9821	1	2026-04-24	3535784.00	63.00	SORTIE	BERLINGO 10591A73	\N	SINASTONE	t	409098.00	ABDESSLAM	206030	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9822	1	2026-04-24	3535874.00	90.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	9068.00	YOUSSEF	206031	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9825	1	2026-04-24	3536137.00	34.00	SORTIE	MANITOU	\N	485	f	5720.60	JAWAD	206034	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9836	1	2026-04-25	3539750.00	2000.00	SORTIE	MIT 10843A73	\N	SINASTONE	t	\N	REDOUAN	206045	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9843	1	2026-04-25	3540066.00	27.00	SORTIE	MANITOU	\N	486	f	4095.50	ABDELLAH	206052	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9853	1	2026-04-27	3541233.00	146.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	9080.70	YOUSSEF	206062	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9855	1	2026-04-27	3541468.00	56.00	SORTIE	HYUNDAI 15991W6	\N	470	f	199864.00	HOUSSINE	206064	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9859	1	2026-04-27	3541850.00	28.00	SORTIE	MANITOU	\N	486	f	4115.00	AZIZ	206068	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9860	1	2026-04-27	3541893.00	43.00	SORTIE	MANITOU	\N	485	f	5744.00	JAWAD	206069	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9864	1	2026-04-28	3542306.00	45.00	SORTIE	AUDI 65923B72	\N	\N	f	\N	MAGHNIA	206073	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9865	1	2026-04-28	3542826.00	520.00	SORTIE	MAN 28661D1	\N	ARMATURE	t	1134549.00	SAID	206074	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9880	1	2026-04-29	3544332.00	55.00	SORTIE	MIT 40873D8	\N	ARMABETON	t	136527.00	MBAREK	206089	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9882	1	2026-04-29	3544632.00	124.00	SORTIE	DOOSAN DL 250A	\N	ARMABETON	t	9091.00	YOUSSEF	206091	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9883	1	2026-04-29	3544934.00	302.00	SORTIE	SITRAK 70225D8	\N	ARMABETON	t	23622.00	ABDELILAH	206092	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9834	1	2026-04-25	3537579.00	78.00	SORTIE	MANITOU	\N	484	f	6716.00	SAID	206043	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9889	1	2026-04-29	3545485.00	40.00	SORTIE	MANITOU	\N	485	f	5764.30	HASSAN	206098	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9893	1	2026-04-30	3545863.00	100.00	SORTIE	SITRAK 70224D8	\N	ARMABETON	t	25695.00	AHMED	206102	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4948	1	2025-01-01	2874416.00	68.00	SORTIE	MIT 11469A73	\N	435	f	878784.00	ABDELKHALEK	201564	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4949	1	2025-01-01	2874590.00	174.00	SORTIE	MIT 11470A73	\N	436	f	5778.00	MOHAMED	201565	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4950	1	2025-01-01	2874661.00	71.00	SORTIE	ISUZU 26128A8	\N	401	f	853638.00	TOUFIK	201566	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4951	1	2025-01-01	2874822.00	161.00	SORTIE	VOLVO 22300A73	\N	481	f	632978.00	MUSTAPHA	201567	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4952	1	2025-01-01	2874949.00	127.00	SORTIE	VOLVO 22299A73	\N	480	f	540935.00	THAMI	201568	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4953	1	2025-01-01	2875096.00	147.00	SORTIE	RENAULT 25636A13	\N	411	f	57995.00	YASSINE	201569	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4954	1	2025-01-01	2875116.00	20.00	SORTIE	VOLVO 22300A73	\N	481	f	632993.00	MUSTAPHA	201570	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4956	1	2025-01-01	2875160.00	19.00	SORTIE	LINDE	\N	434	f	6820.70	MILOUD	201572	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4957	1	2025-01-01	2875289.00	129.00	SORTIE	CHARGEUSE G 938	\N	413	f	6771.90	ABDERRAHIM	201573	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4958	1	2025-01-02	2875421.00	132.00	SORTIE	MIT 4969A73	\N	409	f	921537.00	CHOUAIB	201574	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4959	1	2025-01-02	2875523.00	102.00	SORTIE	MIT 11469A73	\N	435	f	879151.00	ABDELKHALEK	201575	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4960	1	2025-01-02	2875580.00	57.00	SORTIE	MIT 11470A73	\N	436	f	5948.00	MOHAMED	201576	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4961	1	2025-01-02	2875744.00	164.00	SORTIE	VOLVO 22299A73	\N	480	f	541476.00	THAMI	201577	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4962	1	2025-01-02	2875929.00	185.00	SORTIE	RENAULT 25636A13	\N	411	f	58685.00	YASSINE	201578	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4963	1	2025-01-02	2875971.00	42.00	SORTIE	MIT 11469A73	\N	435	f	879268.00	ABDELKHALEK	201579	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4964	1	2025-01-02	2876121.00	150.00	SORTIE	MIT 4703A73	\N	408	f	556394.00	MUSTAPHA	201580	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4965	1	2025-01-02	2876156.00	35.00	SORTIE	LINDE	\N	477	f	8145.90	CHAABI	201581	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4966	1	2025-01-02	2876197.00	41.00	SORTIE	LINDE	\N	472	f	9987.40	SEKOURI	201582	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4967	1	2025-01-02	2876227.00	30.00	SORTIE	FENWICK	\N	430	f	27025.00	SAID	201583	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4968	1	2025-01-02	2876241.00	14.00	SORTIE	LINDE	\N	428	f	3934.90	JAWAD	201584	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4970	1	2025-01-02	2876850.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	293693.00	ADIL	201586	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4971	1	2025-01-03	2876902.00	52.00	SORTIE	ISUZU 26128A8	\N	401	f	853882.00	TOUFIK	201587	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4972	1	2025-01-03	2876996.00	94.00	SORTIE	MIT 11470A73	\N	436	f	6286.00	MOHAMED	201588	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4974	1	2025-01-03	2877205.00	82.00	SORTIE	VOLVO 22299A73	\N	480	f	541735.00	THAMI	201590	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4976	1	2025-01-03	2878199.00	434.00	SORTIE	VOLVO 17886A73	\N	439	f	599830.00	ABDELMAJID	201592	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4977	1	2025-01-03	2878275.00	76.00	SORTIE	MANITOU	\N	484	f	4248.00	SAID	201593	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4978	1	2025-01-03	2878315.00	40.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201594	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4979	1	2025-01-04	2878521.00	206.00	SORTIE	VOLVO 22300A73	\N	481	f	633675.00	MUSTAPHA	201595	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4980	1	2025-01-04	2878618.00	97.00	SORTIE	MIT 11470A73	\N	436	f	6603.00	MOHAMED	201596	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4981	1	2025-01-04	2878789.00	171.00	SORTIE	MIT 11469A73	\N	435	f	879922.00	ABDELKHALEK	201597	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4982	1	2025-01-04	2878958.00	169.00	SORTIE	CHARGEUSE G 938	\N	413	f	6785.50	ABDERRAHIM	201598	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4983	1	2025-01-04	2879087.00	129.00	SORTIE	VOLVO 22299A73	\N	480	f	542242.00	THAMI	201599	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4984	1	2025-01-04	2879142.00	55.00	SORTIE	HYUNDAI 22772A73	\N	479	f	225642.00	BOUJAIR	201600	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4985	1	2025-01-04	2879169.00	27.00	SORTIE	HYUNDAI 18516A73	\N	471	f	293860.00	ADIL	201601	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4987	1	2025-01-04	2879343.00	133.00	SORTIE	MIT 4969A73	\N	409	f	921962.00	CHOUAIB	201603	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4988	1	2025-01-04	2879385.00	42.00	SORTIE	HYUNDAI 22368A73	\N	482	f	188474.00	IDRISS	201604	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4989	1	2025-01-04	2879415.00	30.00	SORTIE	LINDE	\N	434	f	6233.60	MILOUD	201605	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4990	1	2025-01-04	2879626.00	211.00	SORTIE	RENAULT 25636A13	\N	411	f	59477.00	YASSINE	201606	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4991	1	2025-01-04	2879653.00	27.00	SORTIE	LINDE	\N	428	f	3936.40	JAWAD	201607	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4992	1	2025-01-04	2879699.00	46.00	SORTIE	LINDE	\N	472	f	10006.90	SEKOURI	201608	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4993	1	2025-01-06	2879867.00	168.00	SORTIE	VOLVO 70352A2	\N	406	f	499431.00	MOHAMED	201609	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4994	1	2025-01-06	2879933.00	66.00	SORTIE	VOLVO 22299A73	\N	480	f	543466.00	THAMI	201610	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4995	1	2025-01-06	2880579.00	646.00	SORTIE	VOLVO 17885A73	\N	438	f	628948.00	HOSSAM	201611	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4996	1	2025-01-06	2880757.00	178.00	SORTIE	VOLVO 22300A73	\N	481	f	634345.00	MUSTAPHA	201612	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4997	1	2025-01-06	2880825.00	67.00	SORTIE	MIT 11470A73	\N	436	f	6854.00	MOHAMED	201613	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
4999	1	2025-01-06	2880925.00	49.00	SORTIE	LINDE	\N	472	f	10029.90	SEKOURI	201615	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5000	1	2025-01-06	2881327.00	402.00	SORTIE	MAN 28659D1	\N	410	f	990754.00	CHOUAIB	201616	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5001	1	2025-01-06	2881358.00	31.00	SORTIE	FENWICK	\N	430	f	27037.00	ABDELKHALEK	201617	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5002	1	2025-01-06	2881405.00	47.00	SORTIE	VOLVO 22300A73	\N	481	f	634459.00	MUSTAPHA	201618	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5003	1	2025-01-06	2881424.00	19.00	SORTIE	LINDE	\N	428	f	3937.50	HASSAN	201619	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5004	1	2025-01-06	2881580.00	156.00	SORTIE	CHARGEUSE G 938	\N	413	f	6798.90	ABDERRAHIM	201620	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5005	1	2025-01-07	2881771.00	191.00	SORTIE	RENAULT 25636A13	\N	411	f	60154.00	YASSINE	201621	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5006	1	2025-01-07	2881958.00	187.00	SORTIE	MIT 11470A73	\N	436	f	7495.00	MOHAMED	201622	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5007	1	2025-01-07	2882018.00	60.00	SORTIE	ISUZU 26128A8	\N	401	f	854148.00	TOUFIK	201623	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5009	1	2025-01-07	2882248.00	101.00	SORTIE	MAN 706A73	\N	407	f	122940.00	ABDELKARIM	201625	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5010	1	2025-01-07	2882307.00	59.00	SORTIE	BERLINGO 10591A73	\N	433	f	340219.00	ABDESLAM	201626	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5011	1	2025-01-07	2882592.00	285.00	SORTIE	VOLVO 17886A73	\N	439	f	600773.00	ABDELMAJID	201627	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5012	1	2025-01-07	2882738.00	146.00	SORTIE	VOLVO 22299A73	\N	480	f	542961.00	THAMI	201628	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5013	1	2025-01-07	2882781.00	43.00	SORTIE	LINDE	\N	477	f	8161.40	CHAABI	201629	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5014	1	2025-01-07	2882794.00	13.00	SORTIE	LINDE	\N	428	f	3938.00	HASSAN	201630	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5015	1	2025-01-07	2883164.00	370.00	SORTIE	VOLVO 17885A73	\N	438	f	630046.00	HOSSAM	201631	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5016	1	2025-01-08	2883442.00	278.00	SORTIE	MAN 706A73	\N	407	f	122999.00	ABDELKARIM	201632	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5017	1	2025-01-08	2883683.00	241.00	SORTIE	MAN 28659D1	\N	410	f	991511.00	CHOUAIB	201633	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5018	1	2025-01-08	2883837.00	154.00	SORTIE	RENAULT 25636A13	\N	411	f	60774.00	YASSINE	201634	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5019	1	2025-01-08	2883935.00	98.00	SORTIE	MIT 11470A73	\N	436	f	7824.00	MOHAMED	201635	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5020	1	2025-01-08	2883985.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	228936.00	BOUJAIR	201636	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5023	1	2025-01-08	2885002.00	208.00	SORTIE	VOLVO 22300A73	\N	481	f	635209.00	MUSTAPHA	201639	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5024	1	2025-01-08	2885029.00	27.00	SORTIE	LINDE	\N	434	f	6845.10	MILOUD	201640	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5026	1	2025-01-08	2885274.00	127.00	SORTIE	MIT 4969A73	\N	409	f	922328.00	CHOUAIB	201642	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5027	1	2025-01-08	2885288.00	14.00	SORTIE	LINDE	\N	428	f	39388.00	JAWAD	201643	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5028	1	2025-01-08	2885334.00	46.00	SORTIE	LINDE	\N	472	f	10052.40	SEKOURI	201644	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5029	1	2025-01-08	2885390.00	56.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201645	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5030	1	2025-01-08	2885429.00	39.00	SORTIE	KANGO 4812A73	\N	419	f	227377.00	TARMOUNIA	201646	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5031	1	2025-01-08	2885567.00	138.00	SORTIE	CHARGEUSE G 938	\N	413	f	6811.10	ABDERRAHIM	201647	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5032	1	2025-01-08	2885814.00	247.00	SORTIE	VOLVO 17886A73	\N	439	f	601608.00	ABDELMAJID	201648	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5033	1	2025-01-08	2885949.00	135.00	SORTIE	VOLVO 22299A73	\N	480	f	543481.00	THAMI	201649	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5034	1	2025-01-09	2886079.00	130.00	SORTIE	MIT 11469A73	\N	435	f	880366.00	ABDELKHALEK	201650	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5035	1	2025-01-09	2886165.00	86.00	SORTIE	RENAULT 25636A13	\N	411	f	61066.00	YASSINE	201651	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5036	1	2025-01-09	2886216.00	51.00	SORTIE	HYUNDAI 22368A73	\N	482	f	188940.00	IDRISS	201652	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5037	1	2025-01-09	2886422.00	206.00	SORTIE	MAN 28659D1	\N	410	f	992219.00	CHOUAIB	201653	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5039	1	2025-01-09	2886630.00	165.00	SORTIE	MIT 11470A73	\N	436	f	8410.00	MOHAMED	201655	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5042	1	2025-01-09	2887506.00	480.00	SORTIE	VOLVO 17885A73	\N	438	f	631507.00	HOSSAM	201658	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5043	1	2025-01-09	2887522.00	16.00	SORTIE	LINDE	\N	428	f	3939.80	HASSAN	201659	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5044	1	2025-01-09	2887571.00	49.00	SORTIE	FENWICK	\N	430	f	27053.00	SAID	201660	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5046	1	2025-01-10	2887687.00	66.00	SORTIE	ISUZU 26128A8	\N	401	f	854491.00	TOUFIK	201662	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5047	1	2025-01-10	2887807.00	120.00	SORTIE	MIT 11470A73	\N	436	f	8848.00	MOHAMED	201663	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5050	1	2025-01-10	2888782.00	112.00	SORTIE	VOLVO 22299A73	\N	480	f	543893.00	THAMI	201666	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5051	1	2025-01-10	2888812.00	30.00	SORTIE	BERLINGO 981A73	\N	417	f	292659.00	MAGHNIA	201667	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5052	1	2025-01-10	2888960.00	148.00	SORTIE	RENAULT 25636A13	\N	411	f	61619.00	YASSINE	201668	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5054	1	2025-01-10	2889030.00	52.00	SORTIE	LINDE	\N	472	f	10076.30	ABDELAZIZ	201670	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5055	1	2025-01-10	2889192.00	162.00	SORTIE	VOLVO 17886A73	\N	439	f	602068.00	ABDELMAJID	201671	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5056	1	2025-01-10	2889224.00	32.00	SORTIE	LINDE	\N	477	f	8172.90	CHAABI	201672	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5057	1	2025-01-10	2889266.00	42.00	SORTIE	HYUNDAI 18516A73	\N	471	f	294108.00	HAMZA	201673	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5059	1	2025-01-10	2889487.00	90.00	SORTIE	MANITOU	\N	484	f	4288.00	SAID	201675	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5060	1	2025-01-10	2889632.00	145.00	SORTIE	CHARGEUSE G 938	\N	413	f	6824.00	ABDERRAHIM	201676	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5061	1	2025-01-10	2889647.00	15.00	SORTIE	LINDE	\N	428	f	39406.00	JAWAD	201677	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5062	1	2025-01-11	2889806.00	159.00	SORTIE	MIT 4703A73	\N	408	f	557130.00	MUSTAPHA	201678	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5063	1	2025-01-11	2889966.00	160.00	SORTIE	VOLVO 70352A2	\N	406	f	499806.00	MOHAMED	201679	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5064	1	2025-01-11	2890133.00	167.00	SORTIE	MIT 11470A73	\N	436	f	9419.00	MOHAMED	201680	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5065	1	2025-01-11	2890326.00	193.00	SORTIE	VOLVO 22300A73	\N	481	f	635886.00	MUSTAPHA	201681	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5066	1	2025-01-11	2890369.00	43.00	SORTIE	HYUNDAI 22772A73	\N	479	f	226213.00	BOUJAIR	201682	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5068	1	2025-01-11	2890528.00	120.00	SORTIE	RENAULT 25636A13	\N	411	f	62073.00	YASSINE	201684	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5070	1	2025-01-11	2890883.00	297.00	SORTIE	MAN 28659D1	\N	410	f	993148.00	CHOUAIB	201686	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5071	1	2025-01-11	2890915.00	32.00	SORTIE	LINDE	\N	434	f	6860.10	MILOUD	201687	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5072	1	2025-01-11	2890937.00	22.00	SORTIE	LINDE	\N	472	f	10086.10	ABDELAZIZ	201688	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5073	1	2025-01-11	2891011.00	74.00	SORTIE	VOLVO 22300A73	\N	481	f	636134.00	MUSTAPHA	201689	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5074	1	2025-01-11	2891026.00	15.00	SORTIE	LINDE	\N	428	f	39415.00	HASSAN	201690	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5075	1	2025-01-13	2891202.00	176.00	SORTIE	RENAULT 25636A13	\N	411	f	62714.00	YASSINE	201691	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5076	1	2025-01-13	2891322.00	120.00	SORTIE	MIT 4969A73	\N	409	f	922676.00	CHOUAIB	201692	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5077	1	2025-01-13	2891671.00	349.00	SORTIE	VOLVO 17886A73	\N	439	f	603186.00	ABDELMAJID	201693	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5078	1	2025-01-13	2891771.00	100.00	SORTIE	MIT 11470A73	\N	436	f	9780.00	MOHAMED	201694	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5080	1	2025-01-13	2892193.00	74.00	SORTIE	ISUZU 26128A8	\N	401	f	854861.00	TOUFIK	201696	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5081	1	2025-01-13	2892221.00	28.00	SORTIE	HYUNDAI 18516A73	\N	471	f	294247.00	HAMZA	201697	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5083	1	2025-01-13	2892365.00	24.00	SORTIE	LINDE	\N	428	f	3943.90	HASSAN	201699	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5084	1	2025-01-13	2892399.00	34.00	SORTIE	LINDE	\N	472	f	10100.50	ABDELAZIZ	201700	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5085	1	2025-01-13	2892443.00	44.00	SORTIE	RENAULT 25636A13	\N	411	f	62865.00	YASSINE	201701	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5087	1	2025-01-14	2892493.00	42.00	SORTIE	HYUNDAI 22772A73	\N	479	f	226493.00	BOUJAIR	201703	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5088	1	2025-01-14	2892741.00	248.00	SORTIE	MAN 28659D1	\N	410	f	994005.00	CHOUAIB	201704	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5089	1	2025-01-14	2892911.00	170.00	SORTIE	VOLVO 22300A73	\N	481	f	636732.00	MUSTAPHA	201705	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5090	1	2025-01-14	2893100.00	189.00	SORTIE	VOLVO 22299A73	\N	480	f	544536.00	THAMI	201706	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5091	1	2025-01-14	2893260.00	160.00	SORTIE	MIT 11470A73	\N	436	f	10343.00	MOHAMED	201707	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5092	1	2025-01-14	2893300.00	40.00	SORTIE	VOLVO 22300A73	\N	481	f	636865.00	MUSTAPHA	201708	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5093	1	2025-01-14	2893809.00	509.00	SORTIE	VOLVO 17885A73	\N	438	f	633062.00	HOSSAM	201709	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5094	1	2025-01-15	2893955.00	146.00	SORTIE	MIT 11470A73	\N	436	f	10878.00	MOHAMED	201710	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5095	1	2025-01-15	2894095.00	140.00	SORTIE	MIT 11469A73	\N	435	f	880794.00	ABDELKHALEK	201711	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5096	1	2025-01-15	2894145.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	189433.00	IDRISS	201712	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5097	1	2025-01-15	2894337.00	192.00	SORTIE	VOLVO 22299A73	\N	480	f	545236.00	THAMI	201713	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5098	1	2025-01-15	2894478.00	141.00	SORTIE	RENAULT 25636A13	\N	411	f	63400.00	YASSINE	201714	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5099	1	2025-01-15	2894652.00	174.00	SORTIE	CHARGEUSE G 938	\N	413	f	6839.00	ABDERRAHIM	201715	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5101	1	2025-01-15	2894985.00	28.00	SORTIE	LINDE	\N	434	f	6873.20	MILOUD	201717	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5103	1	2025-01-15	2895105.00	77.00	SORTIE	VOLVO 22300A73	\N	481	f	637095.00	MUSTAPHA	201719	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5105	1	2025-01-15	2895311.00	71.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201721	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5106	1	2025-01-15	2895349.00	38.00	SORTIE	LINDE	\N	472	f	10114.80	ABDELAZIZ	201722	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5107	1	2025-01-15	2895377.00	28.00	SORTIE	LINDE	\N	428	f	3944.50	HASSAN	201723	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5108	1	2025-01-15	2895430.00	53.00	SORTIE	FENWICK	\N	430	f	27072.00	ABDELKHALEK	201724	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5109	1	2025-01-15	2895469.00	39.00	SORTIE	HYUNDAI 22772A73	\N	479	f	226746.00	HAMZA	201725	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5110	1	2025-01-15	2895514.00	45.00	SORTIE	HYUNDAI 18516A73	\N	471	f	294482.00	HAMZA	201726	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5112	1	2025-01-16	2895715.00	153.00	SORTIE	MIT 4703A73	\N	408	f	557953.00	MUSTAPHA	201728	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5113	1	2025-01-16	2895867.00	152.00	SORTIE	MIT 11470A73	\N	436	f	11407.00	MOHAMED	201729	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5114	1	2025-01-16	2896025.00	158.00	SORTIE	RENAULT 25636A13	\N	411	f	64016.00	YASSINE	201730	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5115	1	2025-01-16	2896082.00	57.00	SORTIE	BERLINGO 10591A73	\N	433	f	341108.00	ABDESLAM	201731	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5118	1	2025-01-16	2897167.00	182.00	SORTIE	MAN 28659D1	\N	410	f	994479.00	CHOUAIB	201734	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5120	1	2025-01-16	2897951.00	75.00	SORTIE	ISUZU 26128A8	\N	401	f	855186.00	TOUFIK	201736	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5121	1	2025-01-16	2898380.00	429.00	SORTIE	VOLVO 17885A73	\N	438	f	634343.00	HOSSAM	201737	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5122	1	2025-01-16	2898770.00	390.00	SORTIE	VOLVO 17886A73	\N	439	f	604497.00	ABDELMAJID	201738	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5123	1	2025-01-16	2898808.00	38.00	SORTIE	LINDE	\N	477	f	8186.50	CHAABI	201739	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5124	1	2025-01-16	2898844.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	294685.00	HAMZA	201740	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5125	1	2025-01-16	2898858.00	14.00	SORTIE	MIT 11470A73	\N	436	f	11448.00	MOHAMED	201741	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5126	1	2025-01-17	2898958.00	100.00	SORTIE	MIT 4969A73	\N	409	f	923229.00	CHOUAIB	201742	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5127	1	2025-01-17	2899100.00	142.00	SORTIE	VOLVO 22300A73	\N	481	f	637609.00	MUSTAPHA	201743	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5128	1	2025-01-17	2899332.00	232.00	SORTIE	VOLVO 17886A73	\N	439	f	605334.00	ABDELMAJID	201744	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5130	1	2025-01-17	2899546.00	183.00	SORTIE	RENAULT 25636A13	\N	411	f	64685.00	YASSINE	201746	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5131	1	2025-01-17	2899636.00	90.00	SORTIE	MANITOU	\N	484	f	4325.00	SAID	201747	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5132	1	2025-01-17	2899697.00	61.00	SORTIE	HYUNDAI 22772A73	\N	479	f	227151.00	HAMZA	201748	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5134	1	2025-01-17	2899788.00	50.00	SORTIE	LINDE	\N	472	f	101340.00	ABDELAZIZ	201750	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5136	1	2025-01-17	2899958.00	142.00	SORTIE	CHARGEUSE G 938	\N	413	f	6851.40	ABDERRAHIM	201752	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5137	1	2025-01-17	2900097.00	139.00	SORTIE	MIT 11469A73	\N	435	f	881229.00	ABDELKHALEK	201753	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5138	1	2025-01-18	2900382.00	285.00	SORTIE	MAN 28659D1	\N	410	f	995359.00	CHOUAIB	201754	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5139	1	2025-01-18	2900521.00	139.00	SORTIE	MIT 11470A73	\N	436	f	11918.00	MOHAMED	201755	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5140	1	2025-01-18	2900665.00	144.00	SORTIE	VOLVO 22300A73	\N	481	f	638125.00	MUSTAPHA	201756	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5143	1	2025-01-18	2901508.00	369.00	SORTIE	VOLVO 17885A73	\N	438	f	635494.00	HOSSAM	201759	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5144	1	2025-01-18	2901555.00	47.00	SORTIE	HYUNDAI 22368A73	\N	482	f	189977.00	IDRISS	201760	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5145	1	2025-01-18	2901586.00	31.00	SORTIE	LINDE	\N	428	f	3946.00	HASSAN	201761	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5146	1	2025-01-18	2901624.00	38.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201762	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5147	1	2025-01-18	2901655.00	31.00	SORTIE	KANGO 4812A73	\N	419	f	227845.00	TARMOUNIA	201763	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5148	1	2025-01-18	2901745.00	90.00	SORTIE	VOLVO 22299A73	\N	480	f	545464.00	THAMI	201764	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5149	1	2025-01-18	2901770.00	25.00	SORTIE	LINDE	\N	477	f	10143.30	ABDELAZIZ	201765	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5150	1	2025-01-18	2901833.00	63.00	SORTIE	ISUZU 26128A8	\N	401	f	855486.00	TOUFIK	201766	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5151	1	2025-01-20	2902017.00	184.00	SORTIE	RENAULT 25636A13	\N	411	f	65390.00	YASSINE	201767	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5152	1	2025-01-20	2902161.00	144.00	SORTIE	VOLVO 70352A2	\N	406	f	500142.00	MOHAMED	201768	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5153	1	2025-01-20	2902221.00	60.00	SORTIE	HYUNDAI 22772A73	\N	479	f	227571.00	BOUJAIR	201769	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5154	1	2025-01-20	2902296.00	75.00	SORTIE	VOLVO 22300A73	\N	481	f	638329.00	MUSTAPHA	201770	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5155	1	2025-01-20	2902376.00	80.00	SORTIE	MIT 11470A73	\N	436	f	12177.00	MOHAMED	201771	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5156	1	2025-01-20	2902641.00	265.00	SORTIE	VOLVO 17886A73	\N	439	f	606273.00	ABDELMAJID	201772	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5158	1	2025-01-20	2902783.00	28.00	SORTIE	LINDE	\N	434	f	6885.40	MILOUD	201774	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5159	1	2025-01-20	2902834.00	51.00	SORTIE	LINDE	\N	472	f	10162.70	SEKOURI	201775	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5160	1	2025-01-20	2903094.00	260.00	SORTIE	MAN 28659D1	\N	410	f	996208.00	CHOUAIB	201776	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5162	1	2025-01-20	2903173.00	39.00	SORTIE	FENWICK	\N	430	f	27085.20	ABDELKHALEK	201778	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5163	1	2025-01-20	2903343.00	170.00	SORTIE	MIT 4969A73	\N	409	f	923537.00	CHOUAIB	201779	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5165	1	2025-01-20	2903539.00	147.00	SORTIE	CHARGEUSE G 938	\N	413	f	6863.40	ABDERRAHIM	201781	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5166	1	2025-01-20	2903598.00	59.00	SORTIE	HYUNDAI 18516A73	\N	471	f	295249.00	HAMZA	201782	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5167	1	2025-01-20	2903944.00	346.00	SORTIE	VOLVO 17885A73	\N	438	f	636460.00	HOSSAM	201783	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5168	1	2025-01-21	2904123.00	179.00	SORTIE	MIT 11469A73	\N	435	f	881844.00	ABDELKHALEK	201784	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5169	1	2025-01-21	2904253.00	130.00	SORTIE	MIT 11470A73	\N	436	f	12642.00	MOHAMED	201785	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5170	1	2025-01-21	2904277.00	24.00	SORTIE	LINDE	\N	427	f	30073.80	ABDERRAHIM	201786	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5171	1	2025-01-21	2904362.00	85.00	SORTIE	RENAULT 25636A13	\N	411	f	65675.00	YASSINE	201787	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5172	1	2025-01-21	2904580.00	218.00	SORTIE	VOLVO 22299A73	\N	480	f	546232.00	THAMI	201788	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5176	1	2025-01-21	2905080.00	26.00	SORTIE	LINDE	\N	477	f	8196.60	CHAABI	201792	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5177	1	2025-01-21	2905117.00	37.00	SORTIE	LINDE	\N	428	f	3948.00	JAWAD	201793	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5178	1	2025-01-21	2905296.00	179.00	SORTIE	VOLVO 22300A73	\N	481	f	638947.00	MUSTAPHA	201794	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5179	1	2025-01-22	2905457.00	161.00	SORTIE	RENAULT 25636A13	\N	411	f	66302.00	YASSINE	201795	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5180	1	2025-01-22	2905524.00	67.00	SORTIE	ISUZU 26128A8	\N	401	f	855822.00	TOUFIK	201796	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5181	1	2025-01-22	2905564.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	190433.00	IDRISS	201797	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5182	1	2025-01-22	2905621.00	57.00	SORTIE	MIT 11470A73	\N	436	f	12823.00	MOHAMED	201798	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5184	1	2025-01-22	2905725.00	50.00	SORTIE	VOLVO 22299A73	\N	480	f	546368.00	THAMI	201800	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5187	1	2025-01-22	2906500.00	116.00	SORTIE	MIT 11469A73	\N	435	f	882264.00	ABDELKHALEK	201803	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5188	1	2025-01-22	2906776.00	276.00	SORTIE	MAN 28659D1	\N	410	f	997069.00	CHOUAIB	201804	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5189	1	2025-01-22	2906827.00	51.00	SORTIE	LINDE	\N	472	f	10182.40	SEKOURI	201805	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5190	1	2025-01-22	2906860.00	33.00	SORTIE	RENAULT 25636A13	\N	411	f	66400.00	YASSINE	201806	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5191	1	2025-01-22	2906884.00	24.00	SORTIE	LINDE	\N	434	f	6896.40	MILOUD	201807	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5192	1	2025-01-22	2907034.00	150.00	SORTIE	CHARGEUSE G 938	\N	413	f	6876.30	ABDERRAHIM	201808	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5193	1	2025-01-22	2907077.00	43.00	SORTIE	HYUNDAI 18516A73	\N	471	f	295509.00	HAMZA	201809	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5194	1	2025-01-23	2907490.00	413.00	SORTIE	VOLVO 17885A73	\N	438	f	637717.00	HOSSAM	201810	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5195	1	2025-01-23	2907709.00	219.00	SORTIE	VOLVO 22299A73	\N	480	f	547158.00	THAMI	201811	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5196	1	2025-01-23	2907872.00	163.00	SORTIE	MIT 11470A73	\N	436	f	13391.00	MOHAMED	201812	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5200	1	2025-01-23	2908821.00	169.00	SORTIE	VOLVO 22300A73	\N	481	f	639602.00	MUSTAPHA	201816	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5201	1	2025-01-23	2908847.00	26.00	SORTIE	BERLINGO 981A73	\N	417	f	293009.00	MAGHNIA	201817	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5202	1	2025-01-23	2909279.00	432.00	SORTIE	VOLVO 17886A73	\N	439	f	607735.00	ABDELMAJID	201818	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5203	1	2025-01-23	2909430.00	151.00	SORTIE	MAN 28659D1	\N	410	f	997568.00	CHOUAIB	201819	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5204	1	2025-01-23	2909465.00	35.00	SORTIE	FENWICK	\N	430	f	27097.00	SAID	201820	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5205	1	2025-01-23	2909490.00	25.00	SORTIE	LINDE	\N	428	f	3949.40	JAWAD	201821	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5207	1	2025-01-23	2909621.00	81.00	SORTIE	VOLVO 22300A73	\N	481	f	639870.00	MUSTAPHA	201823	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5208	1	2025-01-23	2909643.00	22.00	SORTIE	HYUNDAI 18516A73	\N	471	f	295641.00	HAMZA	201824	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5209	1	2025-01-24	2909840.00	197.00	SORTIE	MIT 11470A73	\N	436	f	14077.00	MOHAMED	201825	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5210	1	2025-01-24	2910033.00	193.00	SORTIE	RENAULT 25636A13	\N	411	f	67125.00	YASSINE	201826	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5211	1	2025-01-24	2910198.00	165.00	SORTIE	MIT 11469A73	\N	435	f	882884.00	ABDELKHALEK	201827	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5212	1	2025-01-24	2910354.00	156.00	SORTIE	MIT 4703A73	\N	408	f	558629.00	MUSTAPHA	201828	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5213	1	2025-01-24	2910408.00	54.00	SORTIE	HYUNDAI 22772A73	\N	479	f	227908.00	BOUJAIR	201829	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5215	1	2025-01-24	2910507.00	65.00	SORTIE	ISUZU 26128A8	\N	401	f	856141.00	TOUFIK	201831	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5217	1	2025-01-24	2911366.00	159.00	SORTIE	MIT 4969A73	\N	409	f	924057.00	CHOUAIB	201834	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5218	1	2025-01-24	2911468.00	102.00	SORTIE	VOLVO 22299A73	\N	480	f	547480.00	THAMI	201835	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5219	1	2025-01-24	2911528.00	60.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201836	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5220	1	2025-01-24	2911612.00	84.00	SORTIE	MANITOU	\N	484	f	4362.00	SAID	201837	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5221	1	2025-01-24	2911662.00	50.00	SORTIE	LINDE	\N	472	f	102020.00	SEKOURI	201838	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5222	1	2025-01-24	2911693.00	31.00	SORTIE	LINDE	\N	477	f	8207.80	CHAABI	201839	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5223	1	2025-01-24	2911707.00	14.00	SORTIE	KANGO 4812A73	\N	419	f	228059.00	TARMOUNIA	201840	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5224	1	2025-01-25	2911799.00	92.00	SORTIE	MIT 4969A73	\N	409	f	924416.00	CHOUAIB	201841	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5225	1	2025-01-25	2911970.00	171.00	SORTIE	MIT 11470A73	\N	436	f	14661.00	MOHAMED	201842	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5226	1	2025-01-25	2912088.00	118.00	SORTIE	MIT 11469A73	\N	435	f	883333.00	ABDELKHALEK	201843	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5227	1	2025-01-25	2912138.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	190942.00	IDRISS	201844	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5228	1	2025-01-25	2912239.00	101.00	SORTIE	VOLVO 22300A73	\N	481	f	640237.00	MUSTAPHA	201845	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5229	1	2025-01-25	2912345.00	106.00	SORTIE	RENAULT 25636A13	\N	411	f	67539.00	YASSINE	201846	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5230	1	2025-01-25	2912369.00	24.00	SORTIE	LINDE	\N	427	f	30037.80	ABDERRAHIM	201847	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5232	1	2025-01-25	2912617.00	129.00	SORTIE	VOLVO 22299A73	\N	480	f	547934.00	THAMI	201849	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5233	1	2025-01-25	2912657.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	295871.00	HAMZA	201850	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5234	1	2025-01-25	2912720.00	63.00	SORTIE	BERLINGO 10591A73	\N	433	f	342320.00	ABDESLAM	201851	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5235	1	2025-01-25	2912742.00	22.00	SORTIE	LINDE	\N	434	f	6906.60	MILOUD	201852	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5236	1	2025-01-25	2912905.00	163.00	SORTIE	CHARGEUSE G 938	\N	413	f	6889.30	ABDERRAHIM	201853	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5238	1	2025-01-25	2913242.00	321.00	SORTIE	VOLVO 17886A73	\N	439	f	608812.00	ABDELMAJID	201855	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5239	1	2025-01-25	2913273.00	31.00	SORTIE	LINDE	\N	428	f	3951.20	JAWAD	201856	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5240	1	2025-01-25	2913670.00	397.00	SORTIE	VOLVO 17885A73	\N	438	f	639040.00	HOUSSIN	201857	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5241	1	2025-01-25	2913703.00	33.00	SORTIE	LINDE	\N	472	f	10215.30	SEKOURI	201858	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5242	1	2025-01-27	2913861.00	158.00	SORTIE	RENAULT 25636A13	\N	411	f	68175.00	YASSINE	201859	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5243	1	2025-01-27	2913936.00	75.00	SORTIE	MIT 11470A73	\N	436	f	14917.00	MOHAMED	201860	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5244	1	2025-01-27	2914086.00	150.00	SORTIE	MIT 11469A73	\N	435	f	883910.00	ABDELKHALEK	201861	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5245	1	2025-01-27	2914192.00	106.00	SORTIE	VOLVO 22299A73	\N	480	f	548334.00	THAMI	201862	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5246	1	2025-01-27	2914347.00	155.00	SORTIE	VOLVO 70352A2	\N	406	f	500522.00	MOHAMED	201863	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5247	1	2025-01-27	2914442.00	95.00	SORTIE	VOLVO 22300A73	\N	481	f	640515.00	MUSTAPHA	201864	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5249	1	2025-01-27	2915143.00	21.00	SORTIE	HYUNDAI 18516A73	\N	471	f	296018.00	HAMZA	201866	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5253	1	2025-01-27	2915659.00	42.00	SORTIE	VOLVO 22300A73	\N	481	f	640668.00	MUSTAPHA	201870	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5254	1	2025-01-27	2915697.00	38.00	SORTIE	FENWICK	\N	430	f	\N	ABDELKHALEK	201871	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5255	1	2025-01-27	2915747.00	50.00	SORTIE	LINDE	\N	472	f	10234.70	ABDELALI	201872	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5256	1	2025-01-27	2915770.00	23.00	SORTIE	LINDE	\N	428	f	39526.00	JAWAD	201873	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5257	1	2025-01-27	2916041.00	271.00	SORTIE	VOLVO 17886A73	\N	439	f	609712.00	ABDELMAJID	201874	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5258	1	2025-01-27	2916124.00	83.00	SORTIE	VOLVO 22299A73	\N	480	f	548645.00	THAMI	201875	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5259	1	2025-01-28	2916204.00	80.00	SORTIE	MIT 11470A73	\N	436	f	15181.00	MOHAMED	201876	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5260	1	2025-01-28	2916301.00	97.00	SORTIE	MIT 11469A73	\N	435	f	884279.00	ABDELKHALEK	201877	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5261	1	2025-01-28	2916354.00	53.00	SORTIE	HYUNDAI 22772A73	\N	479	f	228200.00	BOUJAIR	201878	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5262	1	2025-01-29	2916535.00	181.00	SORTIE	VOLVO 22300A73	\N	481	f	641328.00	MUSTAPHA	201890	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5263	1	2025-01-29	2916619.00	84.00	SORTIE	MIT 11470A73	\N	436	f	15426.00	MOHAMED	201891	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5264	1	2025-01-29	2916777.00	158.00	SORTIE	MIT 11469A73	\N	435	f	884890.00	ABDELKHALEK	201892	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5265	1	2025-01-29	2916805.00	28.00	SORTIE	HYUNDAI 18516A73	\N	471	f	296315.00	HAMZA	201893	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5267	1	2025-01-29	2917356.00	400.00	SORTIE	VOLVO 17886A73	\N	439	f	610867.00	ABDELMAJID	201895	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5268	1	2025-01-29	2917563.00	207.00	SORTIE	RENAULT 25636A13	\N	411	f	69382.00	YASSINE	201896	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5270	1	2025-01-29	2917640.00	41.00	SORTIE	LINDE	\N	472	f	10250.90	SEKOURI	201898	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5271	1	2025-01-29	2917673.00	33.00	SORTIE	LINDE	\N	434	f	6921.70	MILOUD	201899	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5272	1	2025-01-29	2917710.00	37.00	SORTIE	LINDE	\N	428	f	3954.70	JAWAD	201900	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5273	1	2025-01-29	2917760.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	191460.00	IDRISS	201901	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5274	1	2025-01-30	2918032.00	272.00	SORTIE	MAN 28659D1	\N	410	f	999307.00	CHOUAIB	201902	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5275	1	2025-01-30	2918188.00	156.00	SORTIE	MIT 11470A73	\N	436	f	15996.00	MOHAMED	201903	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5276	1	2025-01-30	2918248.00	60.00	SORTIE	LINDE	\N	420	f	17713.00	ABDERRAHIM	201905	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5278	1	2025-01-30	2918657.00	67.00	SORTIE	MIT 11469A73	\N	435	f	885135.00	ABDELKHALEK	201907	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5280	1	2025-01-30	2919433.00	21.00	SORTIE	KANGO 4812A73	\N	419	f	228558.00	TARMOUNIA	201909	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5281	1	2025-01-30	2919449.00	16.00	SORTIE	BERLINGO 981A73	\N	417	f	293237.00	MAGHNIA	201910	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5282	1	2025-01-30	2919599.00	150.00	SORTIE	VOLVO 22300A73	\N	481	f	641812.00	MUSTAPHA	201911	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5283	1	2025-01-30	2919624.00	25.00	SORTIE	HYUNDAI 18516A73	\N	471	f	296458.00	HAMZA	201912	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5284	1	2025-01-30	2919786.00	162.00	SORTIE	MIT 4703A73	\N	408	f	559352.00	MUSTAPHA	201913	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5286	1	2025-01-30	2919835.00	36.00	SORTIE	FENWICK	\N	430	f	\N	SAID	201915	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5287	1	2025-01-31	2920244.00	409.00	SORTIE	VOLVO 17885A73	\N	438	f	641062.00	HOSSAM	201916	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5288	1	2025-01-31	2920327.00	83.00	SORTIE	ISUZU 26128A8	\N	401	f	856535.00	TOUFIK	201917	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5291	1	2025-01-31	2920564.00	147.00	SORTIE	MIT 4969A73	\N	409	f	925375.00	CHOUAIB	201920	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5292	1	2025-01-31	2920646.00	82.00	SORTIE	MIT 11470A73	\N	436	f	16226.00	MOHAMED	201921	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5293	1	2025-01-31	2920702.00	56.00	SORTIE	BERLINGO 10591A73	\N	433	f	343407.00	ABDESLAM	201922	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5294	1	2025-01-31	2920879.00	177.00	SORTIE	MIT 11469A73	\N	435	f	885797.00	ABDELKHALEK	201923	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5295	1	2025-01-31	2920932.00	53.00	SORTIE	LINDE	\N	472	f	10273.10	ABDELALI	201924	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5296	1	2025-01-31	2920959.00	27.00	SORTIE	LINDE	\N	477	f	8228.40	CHAABI	201925	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5297	1	2025-01-31	2921135.00	176.00	SORTIE	CHARGEUSE G 938	\N	413	f	6917.70	ABDERRAHIM	201926	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5298	1	2025-01-31	2921162.00	27.00	SORTIE	LINDE	\N	428	f	3956.20	JAWAD	201927	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5299	1	2025-01-31	2921365.00	203.00	SORTIE	RENAULT 25636A13	\N	411	f	70131.00	YASSINE	201928	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5302	1	2025-01-31	2922046.00	88.00	SORTIE	MANITOU	\N	484	f	4401.00	SAID	201931	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5304	1	2025-01-31	2922129.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	296664.00	HAMZA	201933	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5305	1	2025-02-01	2922330.00	201.00	SORTIE	MIT 11469A73	\N	435	f	886559.00	ABDELKHALEK	201934	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5306	1	2025-02-01	2922502.00	172.00	SORTIE	VOLVO 22300A73	\N	481	f	642419.00	MUSTAPHA	201935	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5307	1	2025-02-01	2922623.00	121.00	SORTIE	MIT 11470A73	\N	436	f	16675.00	MOHAMED	201936	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5308	1	2025-02-01	2922899.00	276.00	SORTIE	MAN 28659D1	\N	410	f	185.00	CHOUAIB	201937	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5312	1	2025-02-01	2923382.00	27.00	SORTIE	LINDE	\N	434	f	6932.70	MILOUD	201941	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5313	1	2025-02-01	2923415.00	33.00	SORTIE	VOLVO 22300A73	\N	481	f	642507.00	MUSTAPHA	201942	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5314	1	2025-02-01	2923433.00	18.00	SORTIE	KANGO 4812A73	\N	419	f	228621.00	TARMOUNIA	201943	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5315	1	2025-02-01	2923478.00	45.00	SORTIE	HYUNDAI 22772A73	\N	479	f	228474.00	BOUJAIR	201944	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5316	1	2025-02-01	2923858.00	380.00	SORTIE	VOLVO 17886A73	\N	439	f	612235.00	ABDELMAJID	201945	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5317	1	2025-02-01	2923884.00	26.00	SORTIE	HYUNDAI 18516A73	\N	471	f	296842.00	HAMZA	201946	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5318	1	2025-02-01	2923949.00	65.00	SORTIE	ISUZU 26128A8	\N	401	f	856853.00	TOUFIK	201947	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5319	1	2025-02-01	2923968.00	19.00	SORTIE	LINDE	\N	472	f	10281.20	SEKOURI	201948	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5320	1	2025-02-01	2924012.00	44.00	SORTIE	HYUNDAI 22368A73	\N	482	f	192011.00	IDRISS	201949	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5321	1	2025-02-03	2924174.00	162.00	SORTIE	MIT 4969A73	\N	409	f	925934.00	CHOUAIB	201950	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5322	1	2025-02-03	2924341.00	167.00	SORTIE	MIT 11470A73	\N	436	f	17214.00	MOHAMED	201951	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5323	1	2025-02-03	2924525.00	184.00	SORTIE	RENAULT 25636A13	\N	411	f	70816.00	YASSINE	201952	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5324	1	2025-02-03	2924552.00	27.00	SORTIE	HYUNDAI 18516A73	\N	471	f	296996.00	HAMZA	201953	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5325	1	2025-02-03	2924666.00	114.00	SORTIE	MIT 11469A73	\N	435	f	886938.00	ABDELKHALEK	201954	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5326	1	2025-02-03	2924728.00	62.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201955	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5328	1	2025-02-03	2925201.00	170.00	SORTIE	VOLVO 70352A2	\N	406	f	500930.00	MOHAMED	201957	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5329	1	2025-02-03	2925246.00	45.00	SORTIE	LINDE	\N	472	f	10299.80	SEKOURI	201958	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5333	1	2025-02-03	2926563.00	157.00	SORTIE	CHARGEUSE G 938	\N	413	f	6927.30	ABDERRAHIM	201962	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5335	1	2025-02-03	2926627.00	34.00	SORTIE	LINDE	\N	428	f	3958.20	HASSAN	201964	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5336	1	2025-02-03	2926770.00	143.00	SORTIE	MAN 28659D1	\N	410	f	583.00	CHOUAIB	201965	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5337	1	2025-02-03	2926799.00	29.00	SORTIE	FENWICK	\N	430	f	27135.00	ABDELKHALEK	201966	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5338	1	2025-02-04	2926854.00	55.00	SORTIE	MIT 11470A73	\N	436	f	17412.00	MOHAMED	201967	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5339	1	2025-02-04	2927022.00	168.00	SORTIE	VOLVO 22300A73	\N	481	f	643116.00	MUSTAPHA	201968	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5340	1	2025-02-04	2927154.00	132.00	SORTIE	MIT 11469A73	\N	435	f	887442.00	ABDELKHALEK	201969	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5341	1	2025-02-04	2927362.00	208.00	SORTIE	RENAULT 25636A13	\N	411	f	71630.00	YASSINE	201970	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5342	1	2025-02-04	2927392.00	30.00	SORTIE	HYUNDAI 18516A73	\N	471	f	297192.00	HAMZA	201971	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5343	1	2025-02-04	2927995.00	603.00	SORTIE	VOLVO 17885A73	\N	438	f	642917.00	HOUSSAM	201972	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5345	1	2025-02-04	2928075.00	29.00	SORTIE	LINDE	\N	477	f	8339.50	CHAABI	201974	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5346	1	2025-02-04	2928110.00	45.00	SORTIE	LINDE	\N	472	f	10313.70	ABDELAZIZ	201975	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5347	1	2025-02-04	2928153.00	43.00	SORTIE	HYUNDAI 22772A73	\N	479	f	228772.00	BOUJAIR	201976	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5348	1	2025-02-04	2928361.00	208.00	SORTIE	MAN 28659D1	\N	410	f	1242.00	CHOUAIB	201977	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5349	1	2025-02-05	2928532.00	171.00	SORTIE	MIT 11469A73	\N	435	f	888100.00	ABDELKHALEK	201978	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5350	1	2025-02-05	2928571.00	39.00	SORTIE	ISUZU 26128A8	\N	401	f	857006.00	TOUFIK	201979	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5351	1	2025-02-05	2928678.00	107.00	SORTIE	MIT 11470A73	\N	436	f	17783.00	MOHAMED	201980	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5352	1	2025-02-05	2928879.00	201.00	SORTIE	VOLVO 22299A73	\N	480	f	549355.00	THAMI	201981	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5353	1	2025-02-05	2928972.00	93.00	SORTIE	VOLVO 22300A73	\N	481	f	643420.00	MUSTAPHA	201982	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5354	1	2025-02-05	2929280.00	308.00	SORTIE	MAN 706A73	\N	407	f	123917.00	ABDELKARIM	201983	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5355	1	2025-02-05	2929590.00	310.00	SORTIE	VOLVO 17886A73	\N	439	f	613185.00	ABDELMAJID	201984	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5356	1	2025-02-05	2929623.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	297398.00	HAMZA	201985	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5357	1	2025-02-05	2929649.00	26.00	SORTIE	LINDE	\N	434	f	6943.30	MILOUD	201986	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5358	1	2025-02-05	2929839.00	190.00	SORTIE	RENAULT 25636A13	\N	411	f	72270.00	YASSINE	201987	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5361	1	2025-02-05	2930160.00	157.00	SORTIE	MIT 4703A73	\N	408	f	560087.00	MUSTAPHA	201990	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5363	1	2025-02-06	2930850.00	130.00	SORTIE	VOLVO 22299A73	\N	480	f	549802.00	THAMI	201992	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5364	1	2025-02-06	2930975.00	125.00	SORTIE	MIT 4969A73	\N	409	f	926284.00	CHOUAIB	201993	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5365	1	2025-02-06	2931113.00	138.00	SORTIE	MIT 11469A73	\N	435	f	888599.00	ABDELKHALEK	201994	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5366	1	2025-02-06	2931130.00	17.00	SORTIE	HYUNDAI 18516A73	\N	471	f	297522.00	HAMZA	201995	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5367	1	2025-02-06	2931173.00	42.00	SORTIE	HYUNDAI 22368A73	\N	482	f	192470.00	IDRISS	201996	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5368	1	2025-02-06	2931340.00	167.00	SORTIE	MIT 11470A73	\N	436	f	18332.00	MOHAMED	201997	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5369	1	2025-02-06	2931502.00	162.00	SORTIE	VOLVO 22300A73	\N	481	f	643989.00	MUSTAPHA	201998	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5370	1	2025-02-06	2931541.00	39.00	SORTIE	VOLVO 22300A73	\N	481	f	644154.00	MUSTAPHA	201999	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5371	1	2025-02-06	2931969.00	428.00	SORTIE	VOLVO 17885A73	\N	438	f	644199.00	HOUSSAM	202000	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5372	1	2025-02-06	2932022.00	53.00	SORTIE	LINDE	\N	472	f	10333.50	ABDELAZIZ	201001	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5373	1	2025-02-06	2932064.00	42.00	SORTIE	FENWICK	\N	430	f	27150.00	SAID	201002	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5374	1	2025-02-06	2932175.00	111.00	SORTIE	VOLVO 22299A73	\N	480	f	550214.00	THAMI	201003	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5375	1	2025-02-06	2932227.00	52.00	SORTIE	HYUNDAI 22772A73	\N	479	f	229144.00	CHOUAIB	201004	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5379	1	2025-02-10	2933356.00	191.00	SORTIE	MAN 706A73	\N	407	f	124281.00	ABDELKARIM	201039	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5381	1	2025-02-10	2933739.00	321.00	SORTIE	MAN 28659D1	\N	410	f	2945.00	CHOUAIB	201041	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5382	1	2025-02-10	2933774.00	35.00	SORTIE	FENWICK	\N	430	f	27162.00	ABDELKHALEK	201042	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5383	1	2025-02-10	2933810.00	36.00	SORTIE	LINDE	\N	472	f	10368.80	ABDELAZIZ	201043	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5384	1	2025-02-10	2933993.00	183.00	SORTIE	CHARGEUSE G 938	\N	413	f	6957.10	ABDERRAHIM	201044	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5387	1	2025-02-10	2934440.00	73.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201047	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5388	1	2025-02-10	2934732.00	292.00	SORTIE	VOLVO 17885A73	\N	438	f	645082.00	HOUSSAM	201048	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5389	1	2025-02-11	2934865.00	133.00	SORTIE	VOLVO 70352A2	\N	406	f	501232.00	MOHAMED	201049	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5390	1	2025-02-11	2935021.00	156.00	SORTIE	MIT 11469A73	\N	435	f	890312.00	ABDELKHALEK	201050	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5391	1	2025-02-11	2935067.00	46.00	SORTIE	ISUZU 26128A8	\N	401	f	857604.00	TOUFIK	201051	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5392	1	2025-02-11	2935217.00	150.00	SORTIE	RENAULT 25636A13	\N	411	f	74047.00	YASSINE	201052	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5393	1	2025-02-11	2935270.00	53.00	SORTIE	HYUNDAI 22772A73	\N	479	f	229867.00	BOUJAIR	201053	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5394	1	2025-02-11	2935346.00	76.00	SORTIE	HYUNDAI 18516A73	\N	471	f	298278.00	BOUJAIR	201054	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5396	1	2025-02-11	2935539.00	55.00	SORTIE	VOLVO 22300A73	\N	481	f	645132.00	MUSTAPHA	201056	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5397	1	2025-02-11	2935776.00	237.00	SORTIE	VOLVO 22299A73	\N	480	f	551748.00	THAMI	201057	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5398	1	2025-02-11	2935992.00	216.00	SORTIE	MIT 11470A73	\N	436	f	20410.00	MOHAMED	201058	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5399	1	2025-02-11	2936143.00	151.00	SORTIE	MAN 28659D1	\N	410	f	3429.00	CHOUAIB	201059	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5401	1	2025-02-11	2938177.00	34.00	SORTIE	LINDE	\N	477	f	8263.70	CHAABI	201061	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5403	1	2025-02-11	2938369.00	154.00	SORTIE	MIT 4703A73	\N	408	f	560898.00	MUSTAPHA	201063	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5404	1	2025-02-11	2938533.00	164.00	SORTIE	MIT 4969A73	\N	409	f	927338.00	CHOUAIB	201064	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5405	1	2025-02-12	2938699.00	165.00	SORTIE	VOLVO 22300A73	\N	481	f	645402.00	MUSTAPHA	201065	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5406	1	2025-02-12	2938734.00	35.00	SORTIE	BERLINGO 981A73	\N	417	f	293688.00	MAGHNIA	201066	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5407	1	2025-02-12	2938899.00	165.00	SORTIE	RENAULT 25636A13	\N	411	f	74696.00	YASSINE	201067	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5408	1	2025-02-12	2939026.00	127.00	SORTIE	MIT 11470A73	\N	436	f	20861.00	MOHAMED	201068	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5409	1	2025-02-12	2939390.00	364.00	SORTIE	VOLVO 17885A73	\N	438	f	646159.00	HOUSSAM	201069	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5410	1	2025-02-12	2939444.00	54.00	SORTIE	HYUNDAI 18516A73	\N	471	f	298625.00	BOUJAIR	201070	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5411	1	2025-02-12	2939479.00	36.00	SORTIE	LINDE	\N	434	f	6971.60	MILOUD	201071	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5412	1	2025-02-12	2939514.00	35.00	SORTIE	LINDE	\N	472	f	10382.70	ABDELAZIZ	201072	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5413	1	2025-02-13	2939651.00	137.00	SORTIE	RENAULT 25636A13	\N	411	f	75245.00	YASSINE	201073	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5414	1	2025-02-13	2939951.00	300.00	SORTIE	MAN 28659D1	\N	410	f	4398.00	CHOUAIB	201074	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5415	1	2025-02-13	2940006.00	54.00	SORTIE	HYUNDAI 22368A73	\N	482	f	193495.00	IDRISS	201075	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5416	1	2025-02-13	2940134.00	128.00	SORTIE	MIT 11470A73	\N	436	f	21310.00	MOHAMED	201076	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5417	1	2025-02-13	2940187.00	53.00	SORTIE	VOLVO 22300A73	\N	481	f	645862.00	MUSTAPHA	201077	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5418	1	2025-02-13	2940339.00	152.00	SORTIE	VOLVO 22299A73	\N	480	f	552263.00	THAMI	201078	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5419	1	2025-02-13	2940779.00	440.00	SORTIE	VOLVO 17886A73	\N	439	f	614536.00	ABDELMAJID	201079	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5421	1	2025-02-13	2941100.00	170.00	SORTIE	CHARGEUSE G 938	\N	413	f	6971.30	ABDERRAHIM	201081	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5422	1	2025-02-13	2941173.00	73.00	SORTIE	ISUZU 26128A8	\N	401	f	857960.00	TOUFIK	201082	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5423	1	2025-02-13	2941218.00	45.00	SORTIE	HYUNDAI 18516A73	\N	471	f	298899.00	NOURDDIN	201083	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5425	1	2025-02-13	2941287.00	34.00	SORTIE	FENWICK	\N	430	f	27174.00	SAID	201085	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5426	1	2025-02-13	2941323.00	36.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201086	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5427	1	2025-02-13	2941384.00	61.00	SORTIE	BERLINGO 10591A73	\N	433	f	345658.00	ABDESLAM	201087	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5428	1	2025-02-14	2941512.00	128.00	SORTIE	MIT 4969A73	\N	409	f	927789.00	CHOUAIB	201088	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5429	1	2025-02-14	2941638.00	126.00	SORTIE	MIT 11470A73	\N	436	f	21755.00	MOHAMED	201089	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5430	1	2025-02-14	2941842.00	204.00	SORTIE	VOLVO 22300A73	\N	481	f	646656.00	MUSTAPHA	201090	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5432	1	2025-02-14	2942479.00	54.00	SORTIE	LINDE	\N	472	f	10403.30	ABDELLAH	201092	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5433	1	2025-02-14	2942507.00	28.00	SORTIE	LINDE	\N	477	f	8274.00	CHAABI	201093	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5435	1	2025-02-14	2942590.00	41.00	SORTIE	HYUNDAI 18516A73	\N	471	f	299170.00	BOUJAIR	201095	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5436	1	2025-02-14	2942800.00	210.00	SORTIE	VOLVO 22299A73	\N	480	f	553033.00	THAMI	201096	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5440	1	2025-02-15	2943548.00	162.00	SORTIE	MIT 11470A73	\N	436	f	22302.00	MOHAMED	201100	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5441	1	2025-02-15	2943596.00	48.00	SORTIE	ISUZU 26128A8	\N	401	f	858170.00	TOUFIK	201101	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5442	1	2025-02-15	2943689.00	93.00	SORTIE	VOLVO 22300A73	\N	481	f	647030.00	MUSTAPHA	201102	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5444	1	2025-02-15	2944136.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	230158.00	BOUJAIR	201104	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5446	1	2025-02-15	2944355.00	172.00	SORTIE	RENAULT 25636A13	\N	411	f	75798.00	YASSINE	201106	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5448	1	2025-02-15	2944470.00	82.00	SORTIE	MANITOU	\N	484	f	4479.00	SAID	201108	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5449	1	2025-02-15	2944766.00	296.00	SORTIE	MAN 706A73	\N	407	f	124974.00	ABDELKARIM	201109	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5450	1	2025-02-15	2945139.00	373.00	SORTIE	MAN 28659D1	\N	410	f	5550.00	CHOUAIB	201110	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5452	1	2025-02-15	2945301.00	26.00	SORTIE	LINDE	\N	434	f	6982.80	MILOUD	201112	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5453	1	2025-02-15	2945444.00	143.00	SORTIE	MIT 4703A73	\N	408	f	561599.00	MUSTAPHA	201113	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5454	1	2025-02-15	2945723.00	279.00	SORTIE	VOLVO 17886A73	\N	439	f	615544.00	ABDELMAJID	201114	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5455	1	2025-02-15	2945749.00	26.00	SORTIE	KANGO 4812A73	\N	419	f	229435.00	TARMOUNIA	201115	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5457	1	2025-02-15	2945801.00	23.00	SORTIE	LINDE	\N	472	f	10414.00	ABDELAZIZ	201117	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5459	1	2025-02-15	2946165.00	42.00	SORTIE	HYUNDAI 18516A73	\N	471	f	299426.00	ABDELHAMID	201119	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5460	1	2025-02-17	2946357.00	192.00	SORTIE	RENAULT 25636A13	\N	411	f	76511.00	YASSINE	201120	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5461	1	2025-02-17	2946449.00	92.00	SORTIE	MIT 4969A73	\N	409	f	928127.00	CHOUAIB	201121	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5462	1	2025-02-17	2946486.00	37.00	SORTIE	HYUNDAI 22368A73	\N	482	f	193947.00	IDRISS	201122	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5464	1	2025-02-17	2947301.00	150.00	SORTIE	MIT 11470A73	\N	436	f	22827.00	MOHAMED	201124	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5465	1	2025-02-17	2947921.00	620.00	SORTIE	VOLVO 17885A73	\N	438	f	647886.00	HOUSSAM	201125	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5466	1	2025-02-17	2947994.00	73.00	SORTIE	HYUNDAI 18516A73	\N	471	f	299919.00	HAMZA	201126	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5467	1	2025-02-17	2948169.00	175.00	SORTIE	VOLVO 22299A73	\N	480	f	553686.00	THAMI	201127	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5468	1	2025-02-17	2948257.00	88.00	SORTIE	VOLVO 22300A73	\N	481	f	647364.00	MUSTAPHA	201128	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5469	1	2025-02-18	2948318.00	61.00	SORTIE	ISUZU 26128A8	\N	401	f	858480.00	TOUFIK	201129	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5470	1	2025-02-18	2948362.00	44.00	SORTIE	MIT 11470A73	\N	436	f	22939.00	MOHAMED	201130	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5471	1	2025-02-18	2948401.00	39.00	SORTIE	RENAULT 25636A13	\N	411	f	76636.00	YASSINE	201131	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5472	1	2025-02-18	2948457.00	56.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	201132	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5473	1	2025-02-18	2948495.00	38.00	SORTIE	LINDE	\N	472	f	10429.00	ABDELLAH	201133	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5475	1	2025-02-18	2948802.00	205.00	SORTIE	CHARGEUSE G 938	\N	413	f	6988.80	ABDERRAHIM	201135	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5476	1	2025-02-18	2949049.00	247.00	SORTIE	MAN 28659D1	\N	410	f	6388.00	CHOUAIB	201136	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5477	1	2025-02-18	2949098.00	49.00	SORTIE	FENWICK	\N	430	f	27192.00	SAID	201137	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5478	1	2025-02-18	2949126.00	28.00	SORTIE	LINDE	\N	477	f	8283.80	CHAABI	201138	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5480	1	2025-02-18	2949195.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	300131.00	HAMZA	201140	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5481	1	2025-02-19	2949330.00	135.00	SORTIE	RENAULT 25636A13	\N	411	f	77118.00	YASSINE	201141	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5482	1	2025-02-19	2949450.00	120.00	SORTIE	MIT 11470A73	\N	436	f	23344.00	MOHAMED	201142	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5483	1	2025-02-19	2949468.00	18.00	SORTIE	HYUNDAI 18516A73	\N	471	f	300237.00	HAMZA	201143	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5484	1	2025-02-19	2949578.00	110.00	SORTIE	VOLVO 22300A73	\N	481	f	647707.00	MUSTAPHA	201144	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5485	1	2025-02-19	2949605.00	27.00	SORTIE	MAN 4790B8	\N	403	f	955821.00	KARDODI	201145	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5486	1	2025-02-19	2949810.00	205.00	SORTIE	VOLVO 22299A73	\N	480	f	554457.00	THAMI	201146	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5488	1	2025-02-19	2950495.00	365.00	SORTIE	VOLVO 17886A73	\N	439	f	616724.00	ABDELMAJID	201148	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5490	1	2025-02-19	2951121.00	319.00	SORTIE	MAN 706A73	\N	407	f	125769.00	ABDELKARIM	201150	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5492	1	2025-02-19	2951468.00	27.00	SORTIE	LINDE	\N	434	f	6995.40	MILOUD	201152	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5494	1	2025-02-19	2951571.00	51.00	SORTIE	HYUNDAI 22368A73	\N	482	f	194439.00	IDRISS	201154	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5495	1	2025-02-20	2951881.00	310.00	SORTIE	VOLVO 17885A73	\N	438	f	648775.00	HOUSSAM	201155	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5496	1	2025-02-20	2952069.00	188.00	SORTIE	MIT 11470A73	\N	436	f	23974.00	MOHAMED	201156	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5497	1	2025-02-20	2952205.00	136.00	SORTIE	VOLVO 70352A2	\N	406	f	501520.00	MOHAMED	201157	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5498	1	2025-02-20	2952391.00	186.00	SORTIE	VOLVO 22300A73	\N	481	f	648390.00	MUSTAPHA	201158	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5499	1	2025-02-20	2952442.00	51.00	SORTIE	HYUNDAI 22772A73	\N	479	f	230457.00	BOUJAIR	201159	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5500	1	2025-02-20	2952472.00	30.00	SORTIE	HYUNDAI 18516A73	\N	471	f	300417.00	HAMZA	201160	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5501	1	2025-02-20	2952567.00	95.00	SORTIE	RENAULT 25636A13	\N	411	f	77462.00	YASSINE	201161	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5504	1	2025-02-20	2953031.00	103.00	SORTIE	VOLVO 22299A73	\N	480	f	554820.00	THAMI	201164	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5505	1	2025-02-20	2953092.00	61.00	SORTIE	BERLINGO 10591A73	\N	433	f	346728.00	ABDESLAM	201165	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5506	1	2025-02-20	2953144.00	52.00	SORTIE	LINDE	\N	472	f	10450.00	SEKOURI	201166	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5507	1	2025-02-20	2953302.00	158.00	SORTIE	MIT 4969A73	\N	409	f	928462.00	CHOUAIB	201167	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5508	1	2025-02-20	2953324.00	22.00	SORTIE	LINDE	\N	428	f	3959.40	JAWAD	201168	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5509	1	2025-02-20	2953343.00	19.00	SORTIE	LINDE	\N	477	f	8290.90	CHAABI	201169	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5515	1	2025-02-21	2955198.00	380.00	SORTIE	MAN 28659D1	\N	410	f	7445.00	CHOUAIB	201175	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5516	1	2025-02-21	2955330.00	132.00	SORTIE	MIT 11469A73	\N	435	f	890746.00	ABDELKHALEK	201176	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5517	1	2025-02-21	2955451.00	121.00	SORTIE	VOLVO 22299A73	\N	480	f	555262.00	THAMI	201177	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5518	1	2025-02-21	2955532.00	81.00	SORTIE	ISUZU 26128A8	\N	401	f	858870.00	TOUFIK	201178	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5519	1	2025-02-21	2955705.00	173.00	SORTIE	MIT 11470A73	\N	436	f	24570.00	MOHAMED	201179	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5520	1	2025-02-21	2955735.00	30.00	SORTIE	HYUNDAI 18516A73	\N	471	f	300592.00	HAMZA	201180	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5521	1	2025-02-21	2955784.00	49.00	SORTIE	VOLVO 22300A73	\N	481	f	648524.00	MUSTAPHA	201181	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5523	1	2025-02-21	2955940.00	27.00	SORTIE	BERLINGO 981A73	\N	417	f	294021.00	MAGHNIA	201183	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5526	1	2025-02-21	2956596.00	327.00	SORTIE	VOLVO 17885A73	\N	438	f	649580.00	HOUSSAM	201186	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5528	1	2025-02-21	2956819.00	181.00	SORTIE	CHARGEUSE G 938	\N	413	f	7004.40	ABDERRAHIM	201188	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5529	1	2025-02-21	2956843.00	24.00	SORTIE	FENWICK	\N	430	f	27199.00	ABDELKHALEK	201189	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5530	1	2025-02-21	2956869.00	26.00	SORTIE	KANGO 4812A73	\N	419	f	229848.00	TARMOUNIA	201190	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5534	1	2025-02-21	2958216.00	131.00	SORTIE	VOLVO 22299A73	\N	480	f	555704.00	THAMI	201194	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5535	1	2025-02-22	2958384.00	168.00	SORTIE	MIT 11470A73	\N	436	f	25124.00	MOHAMED	201195	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5536	1	2025-02-22	2958605.00	221.00	SORTIE	MAN 28659D1	\N	410	f	8214.00	CHOUAIB	201196	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5538	1	2025-02-22	2959149.00	136.00	SORTIE	RENAULT 25636A13	\N	411	f	77988.00	YASSINE	201198	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5539	1	2025-02-22	2959165.00	16.00	SORTIE	HYUNDAI 18516A73	\N	471	f	300704.00	HAMZA	201199	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5540	1	2025-02-22	2959330.00	165.00	SORTIE	VOLVO 22300A73	\N	481	f	649081.00	MUSTAPHA	201200	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5541	1	2025-02-22	2959390.00	60.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201201	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5542	1	2025-02-22	2959473.00	83.00	SORTIE	MANITOU	\N	484	f	4517.00	SAID	201202	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5544	1	2025-02-22	2960275.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	194949.00	IDRISS	201204	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5545	1	2025-02-22	2960295.00	20.00	SORTIE	LINDE	\N	428	f	3960.00	KAMAL	201205	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5546	1	2025-02-22	2960338.00	43.00	SORTIE	LINDE	\N	472	f	10469.00	SEKOURI	201206	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5547	1	2025-02-22	2960370.00	32.00	SORTIE	LINDE	\N	434	f	7011.50	MILOUD	201207	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5550	1	2025-02-22	2960716.00	291.00	SORTIE	VOLVO 17886A73	\N	439	f	617648.00	ABDELMAJID	201210	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5551	1	2025-02-24	2960842.00	126.00	SORTIE	MIT 4969A73	\N	409	f	928919.00	CHOUAIB	201211	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5552	1	2025-02-24	2960902.00	60.00	SORTIE	ISUZU 26128A8	\N	401	f	859190.00	TOUFIK	201212	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5553	1	2025-02-24	2961016.00	114.00	SORTIE	MIT 11469A73	\N	435	f	891111.00	ABDELKHALEK	201213	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5554	1	2025-02-24	2961169.00	153.00	SORTIE	RENAULT 25636A13	\N	411	f	78539.00	YASSINE	201214	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5555	1	2025-02-24	2961308.00	139.00	SORTIE	MAN 4790B8	\N	403	f	\N	KARDODI	201215	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5556	1	2025-02-24	2961521.00	213.00	SORTIE	VOLVO 22299A73	\N	480	f	556480.00	THAMI	201216	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5557	1	2025-02-24	2961563.00	42.00	SORTIE	LINDE	\N	427	f	30043.00	MILOUD	201217	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5558	1	2025-02-24	2961608.00	45.00	SORTIE	HYUNDAI 22772A73	\N	479	f	230737.00	BOUJAIR	201218	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5559	1	2025-02-24	2961645.00	37.00	SORTIE	HYUNDAI 18516A73	\N	471	f	300918.00	HAMZA	201219	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5560	1	2025-02-24	2961812.00	167.00	SORTIE	VOLVO 22300A73	\N	481	f	649734.00	MUSTAPHA	201220	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5561	1	2025-02-24	2962022.00	210.00	SORTIE	MIT 11470A73	\N	436	f	25858.00	MOHAMED	201221	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5563	1	2025-02-24	2962214.00	32.00	SORTIE	LINDE	\N	420	f	17726.00	\N	201223	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5564	1	2025-02-24	2962247.00	33.00	SORTIE	LINDE	\N	477	f	83028.00	CHAABI	201224	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5565	1	2025-02-24	2962280.00	33.00	SORTIE	LINDE	\N	428	f	3962.20	JAWAD	201225	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5568	1	2025-02-24	2962799.00	150.00	SORTIE	VOLVO 22299A73	\N	480	f	556993.00	THAMI	201228	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5569	1	2025-02-25	2962973.00	174.00	SORTIE	MIT 11470A73	\N	436	f	26496.00	MOHAMED	201229	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5570	1	2025-02-25	2963095.00	122.00	SORTIE	VOLVO 22300A73	\N	481	f	650210.00	MUSTAPHA	201230	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5571	1	2025-02-25	2963128.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	301110.00	HAMZA	201231	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5572	1	2025-02-25	2963288.00	160.00	SORTIE	MIT 4703A73	\N	408	f	562298.00	MUSTAPHA	201232	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5573	1	2025-02-25	2963335.00	47.00	SORTIE	FENWICK	\N	430	f	27215.00	SEKOURI	201233	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5574	1	2025-02-25	2963576.00	241.00	SORTIE	VOLVO 17886A73	\N	439	f	618448.00	ABDELMAJID	201234	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5575	1	2025-02-25	2963750.00	174.00	SORTIE	CHARGEUSE G 938	\N	413	f	7020.00	ABDERRAHIM	201235	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5576	1	2025-02-26	2963904.00	154.00	SORTIE	MIT 11470A73	\N	436	f	27058.00	MOHAMED	201236	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5577	1	2025-02-26	2964085.00	180.00	SORTIE	VOLVO 22300A73	\N	481	f	650828.00	MUSTAPHA	201237	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5578	1	2025-02-26	2964170.00	85.00	SORTIE	MIT 4969A73	\N	409	f	929219.00	CHOUAIB	201238	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5579	1	2025-02-26	2964278.00	108.00	SORTIE	MIT 11469A73	\N	435	f	891421.00	ABDELKHALEK	201239	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5580	1	2025-02-26	2964459.00	181.00	SORTIE	RENAULT 25636A13	\N	411	f	79238.00	YASSINE	201240	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5581	1	2025-02-26	2964482.00	23.00	SORTIE	HYUNDAI 18516A73	\N	471	f	301264.00	HAMZA	201241	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5582	1	2025-02-26	2964710.00	228.00	SORTIE	VOLVO 22299A73	\N	480	f	557871.00	THAMI	201242	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5583	1	2025-02-26	2964789.00	79.00	SORTIE	ISUZU 26128A8	\N	401	f	859557.00	TOUFIK	201243	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5584	1	2025-02-26	2964830.00	41.00	SORTIE	LINDE	\N	428	f	3964.70	JAWAD	201244	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5585	1	2025-02-26	2964890.00	60.00	SORTIE	BERLINGO 10591A73	\N	433	f	843055.00	ABDESLAM	201245	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5590	1	2025-02-27	2965763.00	47.00	SORTIE	VOLVO 22300A73	\N	481	f	650913.00	MUSTAPHA	201250	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5591	1	2025-02-27	2965999.00	236.00	SORTIE	MAN 706A73	\N	407	f	126253.00	HOUSSAM	201251	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5592	1	2025-02-27	2966143.00	144.00	SORTIE	MIT 11469A73	\N	435	f	892031.00	ABDELKHALEK	201252	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5593	1	2025-02-27	2966252.00	109.00	SORTIE	MIT 4969A73	\N	409	f	929615.00	CHOUAIB	201253	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5594	1	2025-02-27	2966306.00	54.00	SORTIE	HYUNDAI 22368A73	\N	482	f	195523.00	IDRISS	201254	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5595	1	2025-02-27	2966386.00	80.00	SORTIE	RENAULT 25636A13	\N	411	f	79531.00	YASSINE	201255	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5597	1	2025-02-27	2966681.00	251.00	SORTIE	MAN 28659D1	\N	410	f	9847.00	CHOUAIB	201257	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5599	1	2025-02-27	2966882.00	46.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201259	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5600	1	2025-02-27	2966900.00	18.00	SORTIE	LINDE	\N	428	f	8965.00	KAMAL	201260	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5601	1	2025-02-27	2966930.00	30.00	SORTIE	LINDE	\N	477	f	8313.70	CHAABI	201261	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5602	1	2025-02-27	2966961.00	31.00	SORTIE	LINDE	\N	420	f	17738.00	SAID	201262	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5604	1	2025-02-27	2967140.00	129.00	SORTIE	VOLVO 22299A73	\N	480	f	558323.00	THAMI	201264	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5605	1	2025-02-28	2967861.00	721.00	SORTIE	VOLVO 17885A73	\N	438	f	651601.00	ABDELKARIM	201265	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5606	1	2025-02-28	2968037.00	176.00	SORTIE	VOLVO 70352A2	\N	406	f	501958.00	MOHAMED	201266	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5607	1	2025-02-28	2968149.00	112.00	SORTIE	MIT 11470A73	\N	436	f	27422.00	MOHAMED	201267	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5608	1	2025-02-28	2968326.00	176.00	SORTIE	VOLVO 22300A73	\N	481	f	651595.00	MUSTAPHA	201268	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5609	1	2025-02-28	2968391.00	65.00	SORTIE	FENWICK	\N	430	f	27237.00	ABDELKHALEK	201269	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5610	1	2025-02-28	2968450.00	59.00	SORTIE	HYUNDAI 18516A73	\N	471	f	301641.00	HAMZA	201270	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5611	1	2025-02-28	2968470.00	20.00	SORTIE	BERLINGO 981A73	\N	417	f	294276.00	MAGHNIA	201271	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5612	1	2025-02-28	2968535.00	65.00	SORTIE	MIT 11469A73	\N	435	f	892221.00	ABDELKHALEK	201272	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5616	1	2025-02-28	2969557.00	144.00	SORTIE	RENAULT 25636A13	\N	411	f	80081.00	YASSINE	201276	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5618	1	2025-02-28	2969908.00	50.00	SORTIE	LINDE	\N	472	f	10489.80	SEKOURI	201278	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5619	1	2025-02-28	2970326.00	418.00	SORTIE	VOLVO 17886A73	\N	439	f	619919.00	ABDELMAJID	201279	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5621	1	2025-02-28	2970537.00	204.00	SORTIE	VOLVO 22299A73	\N	480	f	559008.00	THAMI	201281	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5622	1	2025-03-01	2970735.00	198.00	SORTIE	MAN 28659D1	\N	410	f	10402.00	CHOUAIB	201282	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5623	1	2025-03-01	2970816.00	81.00	SORTIE	VOLVO 22300A73	\N	481	f	651877.00	MUSTAPHA	201283	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5624	1	2025-03-01	2970987.00	171.00	SORTIE	MIT 11470A73	\N	436	f	27989.00	MOHAMED	201284	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5625	1	2025-03-01	2971058.00	71.00	SORTIE	ISUZU 26128A8	\N	401	f	859895.00	TOUFIK	201285	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5626	1	2025-03-01	2971204.00	146.00	SORTIE	MIT 11469A73	\N	435	f	892735.00	ABDELKHALEK	201286	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5627	1	2025-03-01	2971343.00	139.00	SORTIE	RENAULT 25636A13	\N	411	f	80563.00	YASSINE	201287	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5628	1	2025-03-01	2971433.00	90.00	SORTIE	MANITOU	\N	484	f	4558.00	SAID	201288	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5629	1	2025-03-01	2971451.00	18.00	SORTIE	LINDE	\N	434	f	7010.90	MILOUD	201289	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5631	1	2025-03-01	2972331.00	31.00	SORTIE	KANGO 4812A73	\N	419	f	230279.00	TARMOUNIA	201291	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5632	1	2025-03-01	2972452.00	121.00	SORTIE	VOLVO 22299A73	\N	480	f	559439.00	THAMI	201292	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5633	1	2025-03-01	2972492.00	40.00	SORTIE	LINDE	\N	428	f	3967.00	JAWAD	201293	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5634	1	2025-03-01	2972620.00	128.00	SORTIE	MIT 11469A73	\N	435	f	893188.00	ABDELKHALEK	201294	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5635	1	2025-03-01	2972639.00	18.00	SORTIE	LINDE	\N	477	f	8320.50	CHAABI	201295	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5637	1	2025-03-03	2973154.00	76.00	SORTIE	HYUNDAI 18516A73	\N	471	f	302112.00	HAMZA	201297	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5638	1	2025-03-03	2973326.00	172.00	SORTIE	VOLVO 22300A73	\N	481	f	652482.00	MUSTAPHA	201298	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5639	1	2025-03-03	2973380.00	54.00	SORTIE	HYUNDAI 22368A73	\N	482	f	196069.00	IDRISS	201299	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5642	1	2025-03-03	2973591.00	48.00	SORTIE	VOLVO 22300A73	\N	481	f	652623.00	MUSTAPHA	201302	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5643	1	2025-03-03	2973843.00	252.00	SORTIE	MAN 28659D1	\N	410	f	11214.00	CHOUAIB	201303	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5644	1	2025-03-03	2973872.00	29.00	SORTIE	LINDE	\N	428	f	\N	JAWAD	201304	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5645	1	2025-03-03	2973909.00	37.00	SORTIE	LINDE	\N	472	f	10505.00	ABDELAZIZ	201305	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5646	1	2025-03-03	2973955.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	231005.00	ABDELHAMID	201306	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5647	1	2025-03-03	2974335.00	380.00	SORTIE	VOLVO 17886A73	\N	439	f	621202.00	ABDELMAJID	201307	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5649	1	2025-03-03	2974508.00	135.00	SORTIE	RENAULT 25636A13	\N	411	f	81073.00	YASSINE	201309	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5651	1	2025-03-03	2974661.00	113.00	SORTIE	MIT 11470A73	\N	436	f	28302.00	MOHAMED	201311	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5652	1	2025-03-04	2974711.00	50.00	SORTIE	ISUZU 26128A8	\N	401	f	860207.00	TOUFIK	201312	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5653	1	2025-03-04	2974903.00	192.00	SORTIE	MIT 11469A73	\N	435	f	893886.00	ABDELKHALEK	201313	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5654	1	2025-03-04	2975003.00	100.00	SORTIE	MAN 4790B8	\N	403	f	306958.00	KARDODI	201314	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5656	1	2025-03-04	2975087.00	50.00	SORTIE	CHARGEUSE G 938	\N	413	f	7032.90	ABDERRAHIM	201316	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5657	1	2025-03-04	2975130.00	43.00	SORTIE	FENWICK	\N	430	f	27254.00	ABDELHAK	201319	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5659	1	2025-03-05	2975469.00	197.00	SORTIE	CHARGEUSE G 938	\N	413	f	7038.90	ABDERRAHIM	201327	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5660	1	2025-03-05	2975530.00	61.00	SORTIE	BERLINGO 9660A73	\N	432	f	349099.00	ABDESLAM	201328	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5661	1	2025-03-05	2975588.00	58.00	SORTIE	HYUNDAI 22772A73	\N	479	f	231394.00	HAMZA	201329	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5662	1	2025-03-05	2975776.00	188.00	SORTIE	MIT 4703A73	\N	408	f	563199.00	MUSTAPHA	201330	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5663	1	2025-03-05	2975804.00	28.00	SORTIE	LINDE	\N	477	f	8330.80	CHAABI	201331	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5665	1	2025-03-05	2975896.00	51.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201333	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5666	1	2025-03-05	2975937.00	41.00	SORTIE	LINDE	\N	428	f	3971.50	JAWAD	201334	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5667	1	2025-03-05	2975957.00	20.00	SORTIE	LINDE	\N	434	f	7028.50	MILOUD	201335	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5668	1	2025-03-05	2976004.00	47.00	SORTIE	LINDE	\N	472	f	1050023.70	ABDELAZIZ	201336	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5669	1	2025-03-06	2976166.00	162.00	SORTIE	MAN 28659D1	\N	410	f	12285.00	CHOUAIB	201337	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5670	1	2025-03-06	2976324.00	158.00	SORTIE	MIT 11469A73	\N	435	f	894567.00	ABDELKHALEK	201338	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5671	1	2025-03-06	2976506.00	182.00	SORTIE	MIT 11470A73	\N	436	f	28885.00	MOHAMED	201339	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5672	1	2025-03-06	2976723.00	217.00	SORTIE	VOLVO 22299A73	\N	480	f	560580.00	THAMI	201340	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5673	1	2025-03-06	2976882.00	159.00	SORTIE	VOLVO 22300A73	\N	481	f	653642.00	MUSTAPHA	201341	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5676	1	2025-03-06	2977232.00	238.00	SORTIE	MAN 706A73	\N	407	f	126773.00	HOUSSAM	201344	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5677	1	2025-03-06	2977272.00	40.00	SORTIE	MIT 11470A73	\N	436	f	28999.00	MOHAMED	201345	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5678	1	2025-03-06	2977355.00	83.00	SORTIE	RENAULT 25636A13	\N	411	f	82036.00	YASSINE	201346	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5679	1	2025-03-06	2977473.00	118.00	SORTIE	MAN 4790B8	\N	403	f	307218.00	KARDODI	201347	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5680	1	2025-03-07	2977551.00	78.00	SORTIE	ISUZU 26128A8	\N	401	f	860513.00	TOUFIK	201348	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5681	1	2025-03-07	2977600.00	49.00	SORTIE	HYUNDAI 22368A73	\N	482	f	196573.00	IDRISS	201349	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5682	1	2025-03-07	2977745.00	145.00	SORTIE	VOLVO 70352A2	\N	406	f	502308.00	KARMY	201350	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5684	1	2025-03-07	2978071.00	50.00	SORTIE	VOLVO 22300A73	\N	481	f	653718.00	MUSTAPHA	201352	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5687	1	2025-03-07	2978295.00	41.00	SORTIE	LINDE	\N	472	f	10541.00	ABDELAZIZ	201355	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5688	1	2025-03-07	2978424.00	129.00	SORTIE	MAN 28659D1	\N	410	f	12508.00	CHOUAIB	201356	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5689	1	2025-03-07	2978509.00	85.00	SORTIE	MIT 11469A73	\N	435	f	894837.00	ABDELKHALEK	201357	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5690	1	2025-03-07	2978549.00	40.00	SORTIE	LINDE	\N	428	f	\N	JAWAD	201358	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5691	1	2025-03-07	2978595.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	231723.00	ABDELHAMID	201359	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5692	1	2025-03-08	2978772.00	177.00	SORTIE	MIT 11470A73	\N	436	f	29859.00	MUSTAPHA	201360	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5693	1	2025-03-08	2978923.00	151.00	SORTIE	VOLVO 22299A73	\N	480	f	561043.00	THAMI	201361	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5697	1	2025-03-08	2979385.00	89.00	SORTIE	MANITOU	\N	484	f	4601.00	SAID	201365	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5698	1	2025-03-08	2979533.00	148.00	SORTIE	RENAULT 25636A13	\N	411	f	82536.00	YASSINE	201366	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5699	1	2025-03-08	2979722.00	189.00	SORTIE	VOLVO 22300A73	\N	481	f	654418.00	MUSTAPHA	201367	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5700	1	2025-03-08	2979740.00	18.00	SORTIE	LINDE	\N	434	f	7035.00	MILOUD	201368	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5701	1	2025-03-10	2979803.00	63.00	SORTIE	HYUNDAI 18516A73	\N	471	f	302485.00	HAMZA	201369	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5702	1	2025-03-10	2979874.00	70.00	SORTIE	ISUZU 26128A8	\N	401	f	860269.00	TOUFIK	201370	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5703	1	2025-03-10	2980097.00	223.00	SORTIE	MAN 28659D1	\N	410	f	13064.00	CHOUAIB	201371	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5705	1	2025-03-10	2980598.00	181.00	SORTIE	MIT 11469A73	\N	435	f	895456.00	ABDELKHALEK	201373	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5706	1	2025-03-10	2980645.00	47.00	SORTIE	HYUNDAI 22772A73	\N	479	f	232065.00	BOUJAIR	201374	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5711	1	2025-03-10	2981514.00	163.00	SORTIE	VOLVO 22299A73	\N	480	f	561513.00	THAMI	201379	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5713	1	2025-03-10	2981940.00	144.00	SORTIE	MIT 4969A73	\N	409	f	930661.00	CHOUAIB	201381	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5715	1	2025-03-10	2982280.00	36.00	SORTIE	LINDE	\N	477	f	8343.60	CHAABI	201383	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5716	1	2025-03-10	2982396.00	116.00	SORTIE	MIT 11470A73	\N	436	f	29928.00	MOHAMED	201384	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5717	1	2025-03-10	2982453.00	57.00	SORTIE	FENWICK	\N	430	f	27266.00	ABDELKHALEK	201385	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5718	1	2025-03-10	2982490.00	37.00	SORTIE	LINDE	\N	472	f	10555.30	ABDELAZIZ	201386	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5720	1	2025-03-10	2982674.00	54.00	SORTIE	MIT 11469A73	\N	435	f	895645.00	MUSTAPHA	201388	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5722	1	2025-03-10	2983606.00	258.00	SORTIE	VOLVO 17885A73	\N	438	f	655144.00	ABDELKARIM	201390	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5723	1	2025-03-10	2983649.00	43.00	SORTIE	LINDE	\N	428	f	3975.00	JAWAD	201391	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5724	1	2025-03-11	2983696.00	47.00	SORTIE	HYUNDAI 22368A73	\N	482	f	197011.00	IDRISS	201392	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5725	1	2025-03-11	2983879.00	183.00	SORTIE	VOLVO 22300A73	\N	481	f	655040.00	MUSTAPHA	201393	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5726	1	2025-03-11	2984056.00	177.00	SORTIE	RENAULT 25636A13	\N	411	f	83139.00	YASSINE	201394	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5728	1	2025-03-11	2984548.00	132.00	SORTIE	MAN 4790B8	\N	403	f	307670.00	KARDODI	201396	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5731	1	2025-03-11	2984703.00	57.00	SORTIE	RENAULT 25636A13	\N	411	f	83356.00	YASSINE	201399	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5732	1	2025-03-12	2984863.00	160.00	SORTIE	MIT 4969A73	\N	409	f	931197.00	CHOUAIB	201400	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5733	1	2025-03-12	2985071.00	208.00	SORTIE	MIT 11470A73	\N	436	f	30574.00	MOHAMED	201401	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5734	1	2025-03-12	2985173.00	102.00	SORTIE	MAN 4790B8	\N	403	f	308560.00	KARDODI	201402	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5735	1	2025-03-12	2985350.00	177.00	SORTIE	MIT 11469A73	\N	435	f	896278.00	ABDELKHALEK	201403	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5736	1	2025-03-12	2985968.00	618.00	SORTIE	VOLVO 17885A73	\N	438	f	656114.00	ABDELKARIM	201404	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5737	1	2025-03-12	2986047.00	79.00	SORTIE	HYUNDAI 18516A73	\N	471	f	302983.00	HAMZA	201405	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5738	1	2025-03-12	2986278.00	231.00	SORTIE	VOLVO 22299A73	\N	480	f	562151.00	THAMI	201406	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5739	1	2025-03-12	2986354.00	76.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	201407	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5740	1	2025-03-12	2986388.00	34.00	SORTIE	MIT 11469A73	\N	435	f	896363.00	ABDELKHALEK	201408	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5742	1	2025-03-12	2986738.00	300.00	SORTIE	VOLVO 17886A73	\N	439	f	622419.00	ABDELMAJID	201410	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5743	1	2025-03-12	2986782.00	44.00	SORTIE	LINDE	\N	428	f	3977.00	JAWAD	201411	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5744	1	2025-03-12	2986879.00	97.00	SORTIE	VOLVO 22299A73	\N	480	f	562468.00	THAMI	201412	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5745	1	2025-03-12	2986909.00	30.00	SORTIE	MIT 11470A73	\N	436	f	30652.00	MOHAMED	201413	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5746	1	2025-03-13	2987083.00	174.00	SORTIE	RENAULT 25636A13	\N	411	f	83784.00	YASSINE	201414	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5747	1	2025-03-13	2987148.00	65.00	SORTIE	ISUZU 26128A8	\N	401	f	861182.00	TOUFIK	201415	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5748	1	2025-03-13	2987419.00	271.00	SORTIE	MAN 28659D1	\N	410	f	13873.00	CHOUAIB	201416	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5749	1	2025-03-13	2987446.00	27.00	SORTIE	BERLINGO 981A73	\N	417	f	294614.00	MAGHNIA	201417	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5750	1	2025-03-13	2987581.00	135.00	SORTIE	MIT 4969A73	\N	409	f	931656.00	CHOUAIB	201418	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5751	1	2025-03-13	2987754.00	173.00	SORTIE	CHARGEUSE G 938	\N	413	f	7051.00	ABDERRAHIM	201419	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5752	1	2025-03-13	2987803.00	49.00	SORTIE	HYUNDAI 22772A73	\N	479	f	303279.00	BOUJAIR	201420	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5754	1	2025-03-13	2988124.00	18.00	SORTIE	LINDE	\N	434	f	7043.50	MILOUD	201422	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5756	1	2025-03-13	2988307.00	41.00	SORTIE	HYUNDAI 22368A73	\N	482	f	197469.00	IDRISS	201424	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5757	1	2025-03-13	2988433.00	126.00	SORTIE	VOLVO 22300A73	\N	481	f	655442.00	MUSTAPHA	201425	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5759	1	2025-03-13	2988714.00	223.00	SORTIE	MAN 706A73	\N	407	f	127254.00	HOUSSAM	201427	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5760	1	2025-03-13	2988855.00	141.00	SORTIE	MIT 4703A73	\N	408	f	563806.00	MUSTAPHA	201428	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5761	1	2025-03-13	2988888.00	33.00	SORTIE	RENAULT 25636A13	\N	411	f	84073.00	YASSINE	201429	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5762	1	2025-03-14	2989034.00	146.00	SORTIE	MAN 4790B8	\N	403	f	308597.00	KARDODI	201430	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5763	1	2025-03-14	2989145.00	111.00	SORTIE	MIT 4969A73	\N	409	f	932039.00	CHOUAIB	201431	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5764	1	2025-03-14	2989337.00	192.00	SORTIE	MIT 11470A73	\N	436	f	31241.00	MUSTAPHA	201432	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5766	1	2025-03-14	2990044.00	202.00	SORTIE	MIT 11469A73	\N	435	f	897115.00	ABDELKHALEK	201434	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5767	1	2025-03-14	2990098.00	54.00	SORTIE	HYUNDAI 22772A73	\N	479	f	232375.00	BOUJAIR	201435	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5769	1	2025-03-14	2990417.00	45.00	SORTIE	HYUNDAI 18516A73	\N	471	f	303579.00	BOUJAIR	201437	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5771	1	2025-03-14	2990681.00	225.00	SORTIE	VOLVO 22299A73	\N	480	f	563217.00	THAMI	201439	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5773	1	2025-03-14	2990938.00	204.00	SORTIE	VOLVO 70352A2	\N	406	f	502819.00	MOHAMED	201441	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5775	1	2025-03-14	2991003.00	42.00	SORTIE	LINDE	\N	472	f	10593.40	ABDELAZIZ	201443	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5776	1	2025-03-14	2991098.00	95.00	SORTIE	VOLVO 22299A73	\N	480	f	563545.00	THAMI	201444	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5777	1	2025-03-14	2991129.00	31.00	SORTIE	MANITOU	\N	426	f	12789.00	SAID	201445	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5780	1	2025-03-14	2992419.00	441.00	SORTIE	VOLVO 17886A73	\N	439	f	623447.00	ABDELMAJID	201448	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5781	1	2025-03-15	2992586.00	167.00	SORTIE	RENAULT 25636A13	\N	411	f	84642.00	YASSINE	201449	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5782	1	2025-03-15	2992652.00	66.00	SORTIE	ISUZU 26128A8	\N	401	f	861511.00	TOUFIK	201450	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5783	1	2025-03-15	2992795.00	143.00	SORTIE	MIT 11470A73	\N	436	f	31662.00	MUSTAPHA	201451	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5784	1	2025-03-15	2992957.00	162.00	SORTIE	VOLVO 22300A73	\N	481	f	655985.00	MUSTAPHA	201452	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5786	1	2025-03-15	2993059.00	48.00	SORTIE	HYUNDAI 18516A73	\N	471	f	303849.00	BOUJAIR	201454	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5787	1	2025-03-15	2993087.00	28.00	SORTIE	FENWICK	\N	430	f	2727.40	ABDELKHALEK	201455	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5788	1	2025-03-15	2993119.00	32.00	SORTIE	LINDE	\N	477	f	8355.30	CHAABI	201456	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5789	1	2025-03-15	2993526.00	407.00	SORTIE	MAN 28659D1	\N	410	f	14882.00	CHOUAIB	201457	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5790	1	2025-03-15	2993541.00	15.00	SORTIE	KANGO 4812A73	\N	419	f	230469.00	TARMOUNIA	201458	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5791	1	2025-03-15	2993675.00	134.00	SORTIE	MIT 11469A73	\N	435	f	897571.00	ABDELKHALEK	201459	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5792	1	2025-03-15	2993718.00	43.00	SORTIE	LINDE	\N	428	f	39801.00	JAWAD	201460	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5793	1	2025-03-17	2993773.00	55.00	SORTIE	HYUNDAI 18516A73	\N	471	f	304227.00	HAMZA	201461	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5794	1	2025-03-17	2993989.00	216.00	SORTIE	VOLVO 22299A73	\N	480	f	564300.00	THAMI	201462	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5796	1	2025-03-17	2994231.00	89.00	SORTIE	MANITOU	\N	484	f	4642.00	SAID	201464	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5797	1	2025-03-17	2994403.00	172.00	SORTIE	CHARGEUSE G 938	\N	413	f	7064.80	ABDERRAHIM	201465	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5799	1	2025-03-17	2995164.00	55.00	SORTIE	LINDE	\N	472	f	10614.60	SEKOURI	201467	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5800	1	2025-03-17	2995771.00	607.00	SORTIE	VOLVO 17885A73	\N	438	f	657880.00	ABDELKARIM	201468	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5801	1	2025-03-17	2995800.00	29.00	SORTIE	LINDE	\N	434	f	7058.20	MILOUD	201469	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5802	1	2025-03-17	2995922.00	122.00	SORTIE	MIT 11470A73	\N	436	f	31998.00	MOHAMED	201470	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5803	1	2025-03-17	2996303.00	381.00	SORTIE	VOLVO 17886A73	\N	439	f	624782.00	ABDELMAJID	201471	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5804	1	2025-03-17	2996347.00	44.00	SORTIE	ISUZU 26128A8	\N	401	f	861724.00	TOUFIK	201472	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5805	1	2025-03-17	2996437.00	90.00	SORTIE	MAN 4790B8	\N	403	f	308893.00	KARDODI	201473	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5806	1	2025-03-17	2996525.00	88.00	SORTIE	VOLVO 22300A73	\N	481	f	656249.00	MUSTAPHA	201474	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5807	1	2025-03-18	2996696.00	171.00	SORTIE	MIT 4969A73	\N	409	f	932546.00	CHOUAIB	201475	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5808	1	2025-03-18	2996876.00	180.00	SORTIE	VOLVO 22299A73	\N	480	f	564827.00	THAMI	201476	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5809	1	2025-03-18	2997194.00	318.00	SORTIE	MAN 28659D1	\N	410	f	15767.00	CHOUAIB	201477	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5810	1	2025-03-18	2997374.00	180.00	SORTIE	MIT 11469A73	\N	435	f	898209.00	ABDELKHALEK	201478	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5811	1	2025-03-18	2997421.00	47.00	SORTIE	HYUNDAI 22772A73	\N	479	f	232642.00	BOUJAIR	201479	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5812	1	2025-03-18	2997448.00	27.00	SORTIE	HYUNDAI 18516A73	\N	471	f	304387.00	HAMZA	201480	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5814	1	2025-03-18	2997856.00	95.00	SORTIE	RENAULT 25636A13	\N	411	f	84893.00	YASSINE	201482	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5815	1	2025-03-18	2997897.00	41.00	SORTIE	LINDE	\N	428	f	39821.00	JAWAD	201483	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5816	1	2025-03-19	2998092.00	195.00	SORTIE	MIT 11470A73	\N	436	f	32617.00	MOHAMED	201484	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5817	1	2025-03-19	2998247.00	155.00	SORTIE	VOLVO 22300A73	\N	481	f	656754.00	MUSTAPHA	201485	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5818	1	2025-03-19	2998295.00	48.00	SORTIE	HYUNDAI 22368A73	\N	482	f	197956.00	IDRISS	201486	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5819	1	2025-03-19	2998328.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	304590.00	HAMZA	201487	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5823	1	2025-03-19	2998879.00	58.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	201491	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5824	1	2025-03-19	2999038.00	159.00	SORTIE	CHARGEUSE G 938	\N	413	f	7076.80	ABDERRAHIM	201492	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5825	1	2025-03-19	2999085.00	47.00	SORTIE	MAN 28659D1	\N	410	f	15886.00	CHOUAIB	201493	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5826	1	2025-03-19	2999105.00	20.00	SORTIE	VOLVO 22300A73	\N	481	f	656803.00	MUSTAPHA	201494	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5827	1	2025-03-19	2999161.00	56.00	SORTIE	LINDE	\N	472	f	10637.50	ABDELLAH	201495	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5828	1	2025-03-19	2999202.00	41.00	SORTIE	MIT 11470A73	\N	436	f	32743.00	MOHAMED	201496	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5829	1	2025-03-19	2999358.00	156.00	SORTIE	RENAULT 25636A13	\N	411	f	85482.00	YASSINE	201497	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5830	1	2025-03-20	2999413.00	55.00	SORTIE	ISUZU 26128A8	\N	401	f	861978.00	TOUFIK	201498	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5831	1	2025-03-20	2999546.00	133.00	SORTIE	MIT 11469A73	\N	435	f	898662.00	MUSTAPHA	201499	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5833	1	2025-03-20	2999677.00	98.00	SORTIE	MAN 4790B8	\N	403	f	309201.00	KARDODI	203001	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5834	1	2025-03-20	2999703.00	26.00	SORTIE	BERLINGO 981A73	\N	417	f	294976.00	MAGHNIA	203002	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5835	1	2025-03-20	2999733.00	30.00	SORTIE	LINDE	\N	428	f	39836.00	HASSAN	203003	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5838	1	2025-03-20	2999851.00	33.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203006	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5839	1	2025-03-20	2999876.00	25.00	SORTIE	LINDE	\N	434	f	7068.90	MILOUD	203007	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5840	1	2025-03-20	2999934.00	58.00	SORTIE	MIT 11469A73	\N	435	f	898855.00	MUSTAPHA	203008	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5841	1	2025-03-20	2999972.00	38.00	SORTIE	LINDE	\N	477	f	8369.40	CHAABI	203009	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5842	1	2025-03-20	3000009.00	37.00	SORTIE	FENWICK	\N	430	f	27286.90	ABDELKHALEK	203010	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5843	1	2025-03-20	3000159.00	150.00	SORTIE	MIT 4969A73	\N	409	f	933005.00	CHOUAIB	203011	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5844	1	2025-03-20	3000187.00	28.00	SORTIE	HYUNDAI 18516A73	\N	471	f	304754.00	HAMZA	203012	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5845	1	2025-03-21	3000378.00	191.00	SORTIE	RENAULT 25636A13	\N	411	f	86180.00	YASSINE	203013	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5846	1	2025-03-21	3000506.00	128.00	SORTIE	VOLVO 70352A2	\N	406	f	503129.00	MOHAMED	203014	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5847	1	2025-03-21	3000666.00	160.00	SORTIE	VOLVO 22299A73	\N	480	f	565307.00	THAMI	203015	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5848	1	2025-03-21	3000856.00	190.00	SORTIE	MIT 11470A73	\N	436	f	33358.00	MOHAMED	203016	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5849	1	2025-03-21	3000880.00	24.00	SORTIE	HYUNDAI 18516A73	\N	471	f	304896.00	HAMZA	203017	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5852	1	2025-03-21	3001456.00	100.00	SORTIE	MAN 4790B8	\N	403	f	309593.00	KARDODI	203020	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5853	1	2025-03-21	3001505.00	49.00	SORTIE	LINDE	\N	472	f	40658.20	ABDELLAH	203021	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5854	1	2025-03-21	3001568.00	63.00	SORTIE	MIT 11469A73	\N	435	f	899047.00	ABDELKHALEK	203022	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5855	1	2025-03-21	3001626.00	58.00	SORTIE	BERLINGO 10591A73	\N	433	f	351316.00	ABDESLAM	203023	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5856	1	2025-03-21	3001652.00	26.00	SORTIE	VOLVO 22299A73	\N	480	f	565450.00	THAMI	203024	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5857	1	2025-03-22	3001703.00	51.00	SORTIE	ISUZU 26128A8	\N	401	f	862198.00	TOUFIK	203025	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5858	1	2025-03-22	3001955.00	252.00	SORTIE	MAN 706A73	\N	407	f	127754.00	HOUSSAM	203026	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5861	1	2025-03-22	3002496.00	204.00	SORTIE	CHARGEUSE G 938	\N	413	f	7093.60	ABDERRAHIM	203029	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5863	1	2025-03-22	3003184.00	81.00	SORTIE	MANITOU	\N	484	f	4678.00	SAID	203031	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5865	1	2025-03-22	3003865.00	91.00	SORTIE	RENAULT 25636A13	\N	411	f	86463.00	YASSINE	203033	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5866	1	2025-03-22	3004146.00	281.00	SORTIE	VOLVO 17886A73	\N	439	f	625544.00	ABDELMAJID	203034	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5867	1	2025-03-22	3004168.00	22.00	SORTIE	LINDE	\N	434	f	7077.30	MILOUD	203035	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5868	1	2025-03-22	3004204.00	36.00	SORTIE	LINDE	\N	428	f	3985.50	JAWAD	203036	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5869	1	2025-03-22	3004247.00	43.00	SORTIE	HYUNDAI 22368A73	\N	482	f	198479.00	IDRISS	203037	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5870	1	2025-03-24	3004873.00	626.00	SORTIE	VOLVO 17885A73	\N	438	f	659477.00	ABDELKARIM	203038	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5871	1	2025-03-24	3005076.00	203.00	SORTIE	MIT 11469A73	\N	435	f	899795.00	ABDELKHALEK	203039	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5872	1	2025-03-24	3005241.00	165.00	SORTIE	RENAULT 25636A13	\N	411	f	87094.00	YASSINE	203040	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5873	1	2025-03-24	3005360.00	119.00	SORTIE	MIT 4969A73	\N	409	f	933376.00	CHOUAIB	203041	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5874	1	2025-03-24	3005526.00	166.00	SORTIE	MIT 4703A73	\N	408	f	564493.00	MUSTAPHA	203042	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5876	1	2025-03-24	3005630.00	69.00	SORTIE	HYUNDAI 18516A73	\N	471	f	305316.00	NOURDINE	203044	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5877	1	2025-03-24	3005673.00	43.00	SORTIE	HYUNDAI 22772A73	\N	479	f	232881.00	NOURDINE	203045	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5881	1	2025-03-24	3005980.00	43.00	SORTIE	LINDE	\N	472	f	10677.30	ABDELLAH	203049	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5882	1	2025-03-24	3006011.00	31.00	SORTIE	RENAULT 25636A13	\N	411	f	87197.00	YASSINE	203050	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5883	1	2025-03-24	3006038.00	27.00	SORTIE	MIT 11469A73	\N	435	f	899860.00	ABDELKHALEK	203051	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5884	1	2025-03-24	3006066.00	28.00	SORTIE	KANGO 4812A73	\N	419	f	230880.00	TARMOUNIA	203052	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5886	1	2025-03-24	3006129.00	33.00	SORTIE	LINDE	\N	428	f	3987.20	JAWAD	203054	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5887	1	2025-03-24	3006274.00	145.00	SORTIE	MIT 11470A73	\N	436	f	33763.00	MOHAMED	203055	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5888	1	2025-03-25	3006434.00	160.00	SORTIE	MAN 4790B8	\N	403	f	956577.00	KARDODI	203056	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5889	1	2025-03-25	3006490.00	56.00	SORTIE	HYUNDAI 18516A73	\N	471	f	305673.00	HAMZA	203057	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5891	1	2025-03-25	3006680.00	40.00	SORTIE	LINDE	\N	477	f	8384.10	CHAABI	203059	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5892	1	2025-03-25	3006712.00	32.00	SORTIE	FENWICK	\N	430	f	2729.70	ABDELKHALEK	203060	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5893	1	2025-03-25	3006948.00	236.00	SORTIE	VOLVO 22299A73	\N	480	f	566188.00	THAMI	203061	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5894	1	2025-03-25	3006997.00	49.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203062	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5895	1	2025-03-26	3007069.00	72.00	SORTIE	ISUZU 26128A8	\N	401	f	862548.00	TOUFIK	203063	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5896	1	2025-03-26	3007394.00	325.00	SORTIE	MAN 28659D1	\N	410	f	16881.00	CHOUAIB	203064	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5897	1	2025-03-26	3007443.00	49.00	SORTIE	HYUNDAI 18516A73	\N	471	f	305978.00	HAMZA	203065	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5898	1	2025-03-26	3007595.00	152.00	SORTIE	RENAULT 25636A13	\N	411	f	87747.00	YASSINE	203066	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5900	1	2025-03-26	3007928.00	190.00	SORTIE	CHARGEUSE G 938	\N	413	f	7107.50	ABDERRAHIM	203068	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5901	1	2025-03-26	3007979.00	51.00	SORTIE	LINDE	\N	472	f	10698.30	ABDELLAH	203069	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5902	1	2025-03-26	3008072.00	93.00	SORTIE	MIT 11470A73	\N	436	f	34032.00	MOHAMED	203070	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5903	1	2025-03-26	3008140.00	68.00	SORTIE	RENAULT 25636A13	\N	411	f	88037.00	YASSINE	203071	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5904	1	2025-03-26	3008181.00	41.00	SORTIE	LINDE	\N	428	f	3989.30	JAWAD	203072	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5905	1	2025-03-26	3008223.00	42.00	SORTIE	HYUNDAI 22368A73	\N	482	f	199020.00	IDRISS	203073	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5906	1	2025-03-27	3008256.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	360172.00	HAMZA	203074	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5908	1	2025-03-27	3008625.00	62.00	SORTIE	LINDE	\N	420	f	17774.00	ABDERRAHIM	203076	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5910	1	2025-03-27	3008705.00	28.00	SORTIE	VOLVO 22300A73	\N	481	f	656805.00	MUSTAPHA	203078	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5911	1	2025-03-27	3008869.00	164.00	SORTIE	MIT 11469A73	\N	435	f	900432.00	ABDELKHALEK	203079	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5912	1	2025-03-28	3009048.00	179.00	SORTIE	RENAULT 25636A13	\N	411	f	88708.00	YASSINE	203080	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5913	1	2025-03-28	3009107.00	58.00	SORTIE	ISUZU 26128A8	\N	401	f	862862.00	TOUFIK	203081	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5914	1	2025-03-28	3009297.00	190.00	SORTIE	MIT 11470A73	\N	436	f	34671.00	MOHAMED	203082	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5915	1	2025-03-28	3009415.00	118.00	SORTIE	MIT 4969A73	\N	409	f	933691.00	CHOUAIB	203083	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5916	1	2025-03-28	3009558.00	143.00	SORTIE	MAN 4790B8	\N	403	f	957086.00	KARDODI	203084	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5921	1	2025-03-28	3010210.00	31.00	SORTIE	RENAULT 25636A13	\N	411	f	88810.00	YASSINE	203089	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5922	1	2025-03-28	3010237.00	27.00	SORTIE	LINDE	\N	434	f	7090.20	MILOUD	203090	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5923	1	2025-03-28	3010293.00	56.00	SORTIE	MIT 11470A73	\N	436	f	34839.00	MOHAMED	203091	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5924	1	2025-03-28	3010319.00	26.00	SORTIE	LINDE	\N	428	f	39905.00	JAWAD	203092	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5925	1	2025-03-28	3010367.00	48.00	SORTIE	LINDE	\N	472	f	10718.70	SEKOURI	203093	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5927	1	2025-03-28	3010440.00	33.00	SORTIE	HYUNDAI 22368A73	\N	482	f	199303.00	IDRISS	203095	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5928	1	2025-03-29	3010486.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	233147.00	NOURDINE	203096	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5929	1	2025-03-29	3010650.00	164.00	SORTIE	VOLVO 22299A73	\N	480	f	566689.00	THAMI	203097	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5930	1	2025-03-29	3010815.00	165.00	SORTIE	VOLVO 70352A2	\N	406	f	503534.00	MOHAMED	203098	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5932	1	2025-03-29	3011009.00	168.00	SORTIE	VOLVO 22300A73	\N	481	f	657415.00	MUSTAPHA	203100	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5935	1	2025-03-29	3011336.00	150.00	SORTIE	CHARGEUSE G 938	\N	413	f	7119.00	ABDERRAHIM	203103	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5936	1	2025-03-29	3011372.00	36.00	SORTIE	BERLINGO 10591A73	\N	433	f	351960.00	ABDESLAM	203104	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5937	1	2025-03-29	3011389.00	17.00	SORTIE	LINDE	\N	428	f	39913.00	HOUSSAM	203105	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5939	1	2025-03-29	3013401.00	10.00	SORTIE	KANGO 4812A73	\N	419	f	230963.00	TARMOUNIA	203107	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5940	1	2025-04-03	3013437.00	36.00	SORTIE	BERLINGO 981A73	\N	417	f	295486.00	MAGHNIA	203108	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5941	1	2025-04-03	3013525.00	88.00	SORTIE	MANITOU	\N	484	f	4720.00	SAID	203109	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5942	1	2025-04-03	3013547.00	22.00	SORTIE	LINDE	\N	428	f	3992.00	HASSAN	203110	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5943	1	2025-04-03	3013598.00	51.00	SORTIE	HYUNDAI 22772A73	\N	479	f	233471.00	NOURDINE	203111	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5944	1	2025-04-04	3013653.00	55.00	SORTIE	LINDE	\N	472	f	10742.80	SEKOURI	203112	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5945	1	2025-04-04	3013833.00	180.00	SORTIE	CHARGEUSE G 938	\N	413	f	7132.90	ABDERRAHIM	203113	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5946	1	2025-04-04	3013857.00	24.00	SORTIE	LINDE	\N	428	f	3993.50	HASSAN	203114	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5948	1	2025-04-04	3014526.00	41.00	SORTIE	HYUNDAI 22368A73	\N	482	f	199793.00	IDRISS	203116	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5950	1	2025-04-05	3015303.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	233830.00	NOURDINE	203118	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5952	1	2025-04-05	3015403.00	63.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203120	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5953	1	2025-04-05	3015426.00	23.00	SORTIE	LINDE	\N	428	f	3994.50	HASSAN	203121	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5954	1	2025-04-05	3015455.00	29.00	SORTIE	LINDE	\N	472	f	10755.70	AZIZ	203122	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5955	1	2025-04-07	3015579.00	124.00	SORTIE	VOLVO 22300A73	\N	481	f	657859.00	MUSTAPHA	203123	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5956	1	2025-04-07	3015614.00	35.00	SORTIE	HYUNDAI 22772A73	\N	479	f	234053.00	NOURDINE	203124	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5958	1	2025-04-07	3015772.00	93.00	SORTIE	RENAULT 25636A13	\N	411	f	89151.00	YASSINE	203126	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5960	1	2025-04-07	3016202.00	152.00	SORTIE	MAN 28659D1	\N	410	f	17306.00	CHOUAIB	203128	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5961	1	2025-04-07	3016234.00	32.00	SORTIE	KANGO 4812A73	\N	419	f	231491.00	TARMOUNIA	203129	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5962	1	2025-04-07	3016250.00	16.00	SORTIE	LINDE	\N	428	f	3995.30	HASSAN	203130	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5964	1	2025-04-07	3016325.00	41.00	SORTIE	LINDE	\N	477	f	8399.70	CHAABI	203132	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5965	1	2025-04-07	3016365.00	40.00	SORTIE	FENWICK	\N	430	f	27310.00	ABDELKHALEK	203133	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5967	1	2025-04-07	3016595.00	179.00	SORTIE	VOLVO 22299A73	\N	480	f	567298.00	THAMI	203135	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5968	1	2025-04-07	3016941.00	346.00	SORTIE	VOLVO 17886A73	\N	439	f	626510.00	ABDELMAJID	203136	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5969	1	2025-04-08	3017536.00	594.00	SORTIE	VOLVO 17885A73	\N	438	f	660957.00	ABDELKARIM	203137	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5971	1	2025-04-08	3017755.00	159.00	SORTIE	MIT 11470A73	\N	436	f	35361.00	MOHAMED	203139	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5972	1	2025-04-08	3017870.00	115.00	SORTIE	MAN 4790B8	\N	403	f	957496.00	KARDODI	203140	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5974	1	2025-04-08	3017953.00	46.00	SORTIE	HYUNDAI 22368A73	\N	482	f	200283.00	IDRISS	203142	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5975	1	2025-04-08	3018001.00	48.00	SORTIE	LINDE	\N	472	f	1077.10	AZIZ	203143	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5976	1	2025-04-08	3018148.00	147.00	SORTIE	VOLVO 22300A73	\N	481	f	658428.00	MUSTAPHA	203144	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5977	1	2025-04-08	3018277.00	129.00	SORTIE	MIT 4969A73	\N	409	f	934741.00	CHOUAIB	203145	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5978	1	2025-04-08	3018470.00	193.00	SORTIE	CHARGEUSE G 938	\N	413	f	7148.70	HAMDANE	203146	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5979	1	2025-04-09	3018533.00	63.00	SORTIE	ISUZU 26128A8	\N	401	f	863194.00	TOUFIK	203147	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5980	1	2025-04-09	3018787.00	254.00	SORTIE	MAN 28659D1	\N	410	f	18163.00	CHOUAIB	203148	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5981	1	2025-04-09	3018913.00	126.00	SORTIE	MIT 11469A73	\N	435	f	900897.00	ABDELKHALEK	203149	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5982	1	2025-04-09	3019061.00	148.00	SORTIE	MIT 11470A73	\N	436	f	35900.00	MOHAMED	203150	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5983	1	2025-04-09	3019228.00	167.00	SORTIE	RENAULT 25636A13	\N	411	f	89766.00	YASSINE	203151	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5984	1	2025-04-09	3019290.00	62.00	SORTIE	BERLINGO 10591A73	\N	433	f	353019.00	ABDESLAM	203152	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5985	1	2025-04-09	3019315.00	25.00	SORTIE	LINDE	\N	434	f	7102.00	MILOUD	203153	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5987	1	2025-04-09	3019452.00	4.00	SORTIE	RENAULT 25636A13	\N	411	f	89787.00	YASSINE	203155	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5988	1	2025-04-09	3019637.00	185.00	SORTIE	VOLVO 22299A73	\N	480	f	567909.00	THAMI	203156	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5989	1	2025-04-09	3019674.00	37.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203157	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5990	1	2025-04-09	3019774.00	100.00	SORTIE	MAN 4790B8	\N	403	f	957944.00	KARDODI	203158	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5991	1	2025-04-10	3019821.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	234359.00	NOURDINE	203159	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5992	1	2025-04-10	3019987.00	167.00	SORTIE	VOLVO 22300A73	\N	481	f	659063.00	MUSTAPHA	203160	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5994	1	2025-04-10	3020200.00	168.00	SORTIE	MIT 11469A73	\N	435	f	901502.00	ABDELKHALEK	203162	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5995	1	2025-04-10	3020322.00	122.00	SORTIE	MIT 11470A73	\N	436	f	36325.00	MUSTAPHA	203163	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5996	1	2025-04-10	3020529.00	207.00	SORTIE	MAN 28659D1	\N	410	f	18872.00	CHOUAIB	203164	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5998	1	2025-04-10	3021770.00	478.00	SORTIE	VOLVO 17886A73	\N	439	f	628128.00	ABDELMAJID	203166	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
5999	1	2025-04-10	3021789.00	19.00	SORTIE	LINDE	\N	428	f	39962.00	HASSAN	203167	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6000	1	2025-04-10	3021919.00	130.00	SORTIE	RENAULT 25636A13	\N	411	f	90298.00	YASSINE	203168	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6001	1	2025-04-10	3021970.00	51.00	SORTIE	LINDE	\N	472	f	10795.40	AZIZ	203169	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6003	1	2025-04-10	3022514.00	147.00	SORTIE	VOLVO 22299A73	\N	480	f	568438.00	THAMI	203171	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6004	1	2025-04-10	3022559.00	45.00	SORTIE	VOLVO 22300A73	\N	481	f	659198.00	MUSTAPHA	203172	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6005	1	2025-04-10	3022628.00	69.00	SORTIE	ISUZU 26128A8	\N	401	f	863531.00	TOUFIK	203173	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6006	1	2025-04-11	3022710.00	82.00	SORTIE	MIT 4969A73	\N	409	f	934407.00	CHOUAIB	203174	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6007	1	2025-04-11	3022876.00	166.00	SORTIE	MIT 11469A73	\N	435	f	902114.00	ABDELKHALEK	203175	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6008	1	2025-04-11	3023043.00	167.00	SORTIE	CHARGEUSE G 938	\N	413	f	7161.90	ABDERAHIM	203176	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6009	1	2025-04-11	3023126.00	83.00	SORTIE	MANITOU	\N	484	f	4758.00	SAID	203177	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6010	1	2025-04-11	3023169.00	43.00	SORTIE	HYUNDAI 22368A73	\N	482	f	200780.00	IDRISS	203178	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6012	1	2025-04-11	3023248.00	29.00	SORTIE	LINDE	\N	427	f	30046.00	MILOUD	203180	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6014	1	2025-04-11	3023304.00	30.00	SORTIE	FENWICK	\N	430	f	27322.00	ABDELKHALEK	203182	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6015	1	2025-04-11	3023521.00	217.00	SORTIE	VOLVO 22299A73	\N	480	f	569210.00	THAMI	203183	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6016	1	2025-04-11	3023700.00	179.00	SORTIE	MIT 4703A73	\N	408	f	565364.00	MUSTAPHA	203184	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6017	1	2025-04-11	3023847.00	147.00	SORTIE	VOLVO 22300A73	\N	481	f	659731.00	MUSTAPHA	203185	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6018	1	2025-04-11	3023969.00	122.00	SORTIE	RENAULT 25636A13	\N	411	f	90781.00	YASSINE	203186	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6019	1	2025-04-11	3023984.00	15.00	SORTIE	KANGO 4812A73	\N	419	f	231643.00	TARMOUNIA	203187	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6020	1	2025-04-12	3024129.00	145.00	SORTIE	VOLVO 70352A2	\N	406	f	503913.00	MOHAMED	203188	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6021	1	2025-04-12	3024421.00	292.00	SORTIE	MAN 28659D1	\N	410	f	19755.00	CHOUAIB	203189	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6022	1	2025-04-12	3024566.00	145.00	SORTIE	MIT 11469A73	\N	435	f	902689.00	ABDELKHALEK	203190	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6023	1	2025-04-12	3025167.00	601.00	SORTIE	VOLVO 17885A73	\N	438	f	662611.00	ABDELKARIM	203191	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6024	1	2025-04-12	3025280.00	113.00	SORTIE	MAN 4790B8	\N	403	f	958335.00	KARDODI	203192	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6025	1	2025-04-12	3025389.00	109.00	SORTIE	RENAULT 25636A13	\N	411	f	91190.00	YASSINE	203193	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6026	1	2025-04-12	3025405.00	17.00	SORTIE	LINDE	\N	434	f	7109.10	MILOUD	203194	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6027	1	2025-04-12	3025562.00	157.00	SORTIE	CHARGEUSE G 938	\N	413	f	7174.50	ABDERRAHIM	203195	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6028	1	2025-04-12	3025593.00	30.00	SORTIE	MIT 11469A73	\N	435	f	902802.00	ABDELKHALEK	203196	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6029	1	2025-04-12	3025726.00	133.00	SORTIE	VOLVO 22299A73	\N	480	f	569705.00	THAMI	203197	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6030	1	2025-04-12	3025775.00	49.00	SORTIE	LINDE	\N	472	f	10815.80	AZIZ	203198	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6031	1	2025-04-12	3025811.00	36.00	SORTIE	LINDE	\N	428	f	3998.00	HASSAN	203199	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6032	1	2025-04-12	3025840.00	30.00	SORTIE	LINDE	\N	477	f	8412.10	CHAABI	203200	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6033	1	2025-04-14	3025882.00	42.00	SORTIE	MAN 4790B8	\N	403	f	958556.00	KARDODI	203201	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6034	1	2025-04-14	3026050.00	168.00	SORTIE	VOLVO 22300A73	\N	481	f	660423.00	MUSTAPHA	203202	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6035	1	2025-04-14	3026137.00	87.00	SORTIE	MIT 4969A73	\N	409	f	934682.00	CHOUAIB	203203	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6036	1	2025-04-14	3026272.00	135.00	SORTIE	MIT 11470A73	\N	436	f	36703.00	MOHAMED	203204	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6038	1	2025-04-14	3026356.00	50.00	SORTIE	HYUNDAI 18516A73	\N	471	f	306453.00	NOURDINE	203206	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6039	1	2025-04-14	3026406.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	234665.00	NOURDINE	203207	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6040	1	2025-04-14	3026443.00	38.00	SORTIE	VOLVO 22300A73	\N	481	f	660581.00	MUSTAPHA	203208	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6041	1	2025-04-14	3026493.00	50.00	SORTIE	MIT 11470A73	\N	436	f	36872.00	MOHAMED	203209	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6042	1	2025-04-14	3026532.00	39.00	SORTIE	LINDE	\N	472	f	10831.60	ABDELLAH	203210	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6043	1	2025-04-14	3026643.00	111.00	SORTIE	VOLVO 22299A73	\N	480	f	570130.00	THAMI	203211	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6044	1	2025-04-15	3026800.00	157.00	SORTIE	RENAULT 25636A13	\N	411	f	91822.00	YASSINE	203212	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6045	1	2025-04-15	3026975.00	175.00	SORTIE	CHARGEUSE G 938	\N	413	f	7187.30	ABDERRAHIM	203213	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6046	1	2025-04-15	3027177.00	202.00	SORTIE	MIT 11469A73	\N	435	f	903535.00	ABDELKHALEK	203214	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6047	1	2025-04-15	3027227.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	201324.00	IDRISS	203215	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6048	1	2025-04-15	3027243.00	16.00	SORTIE	LINDE	\N	427	f	30054.70	MILOUD	203216	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6049	1	2025-04-15	3027304.00	61.00	SORTIE	BERLINGO 10591A73	\N	433	f	354134.00	ABDESLAM	203217	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6051	1	2025-04-15	3027573.00	219.00	SORTIE	MAN 28659D1	\N	410	f	20451.00	CHOUAIB	203219	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6052	1	2025-04-15	3027933.00	360.00	SORTIE	VOLVO 17886A73	\N	439	f	629290.00	ABDELMAJID	203220	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6054	1	2025-04-15	3028120.00	36.00	SORTIE	LINDE	\N	428	f	3999.70	JAWAD	203222	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6055	1	2025-04-15	3028247.00	127.00	SORTIE	VOLVO 22299A73	\N	480	f	570559.00	THAMI	203223	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6056	1	2025-04-15	3028300.00	53.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203224	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6057	1	2025-04-15	3028358.00	58.00	SORTIE	RENAULT 25636A13	\N	411	f	91975.00	YASSINE	203225	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6058	1	2025-04-16	3028546.00	188.00	SORTIE	MIT 11470A73	\N	436	f	37516.00	MOHAMED	203226	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6059	1	2025-04-16	3028717.00	171.00	SORTIE	MIT 11469A73	\N	435	f	904172.00	ABDELKHALEK	203227	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6061	1	2025-04-16	3028895.00	133.00	SORTIE	VOLVO 22300A73	\N	481	f	661077.00	MUSTAPHA	203229	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6063	1	2025-04-16	3028965.00	21.00	SORTIE	LINDE	\N	434	f	7117.50	MILOUD	203231	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6064	1	2025-04-16	3029079.00	115.00	SORTIE	RENAULT 25636A13	\N	411	f	92404.00	YASSINE	203232	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6065	1	2025-04-16	3029101.00	22.00	SORTIE	LINDE	\N	428	f	4000.70	JAWAD	203233	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6066	1	2025-04-16	3029316.00	215.00	SORTIE	MAN 28659D1	\N	410	f	21109.00	CHOUAIB	203234	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6068	1	2025-04-16	3029677.00	53.00	SORTIE	MIT 11469A73	\N	435	f	904342.00	ABDELKHALEK	203236	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6070	1	2025-04-17	3030356.00	169.00	SORTIE	MIT 4969A73	\N	409	f	935174.00	CHOUAIB	203238	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6071	1	2025-04-17	3030518.00	162.00	SORTIE	CHARGEUSE G 938	\N	413	f	7199.60	ABDERRAHIM	203239	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6072	1	2025-04-17	3030738.00	220.00	SORTIE	VOLVO 22299A73	\N	480	f	571349.00	THAMI	203240	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6073	1	2025-04-17	3030815.00	77.00	SORTIE	MANITOU	\N	484	f	4789.00	SAID	203241	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6074	1	2025-04-17	3030952.00	137.00	SORTIE	VOLVO 22300A73	\N	481	f	661587.00	MUSTAPHA	203242	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6075	1	2025-04-17	3031104.00	152.00	SORTIE	MIT 11470A73	\N	436	f	38032.00	MOHAMED	203243	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6077	1	2025-04-17	3031662.00	59.00	SORTIE	VOLVO 22300A73	\N	481	f	661745.00	MUSTAPHA	203245	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6078	1	2025-04-17	3032223.00	561.00	SORTIE	VOLVO 17885A73	\N	438	f	663977.00	ABDELKARIM	203246	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6079	1	2025-04-17	3032263.00	40.00	SORTIE	LINDE	\N	472	f	10849.60	ABDELLAH	203247	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6080	1	2025-04-17	3032272.00	9.00	SORTIE	VOLVO 22299A73	\N	480	f	571382.00	THAMI	203248	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6081	1	2025-04-17	3032400.00	128.00	SORTIE	RENAULT 25636A13	\N	411	f	92897.00	YASSINE	203249	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6082	1	2025-04-17	3032536.00	136.00	SORTIE	MIT 11469A73	\N	435	f	904831.00	ABDELKHALEK	203250	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6083	1	2025-04-17	3032555.00	19.00	SORTIE	LINDE	\N	428	f	4001.70	JAWAD	203251	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6084	1	2025-04-17	3032596.00	41.00	SORTIE	LINDE	\N	477	f	8427.20	CHAABI	203252	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6085	1	2025-04-17	3032658.00	62.00	SORTIE	HYUNDAI 22772A73	\N	479	f	235083.00	HAMID	203253	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6086	1	2025-04-17	3033112.00	454.00	SORTIE	VOLVO 17886A73	\N	439	f	630743.00	ABDELMAJID	203254	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6088	1	2025-04-18	3033318.00	168.00	SORTIE	VOLVO 70352A2	\N	406	f	504366.00	MOHAMED	203256	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6089	1	2025-04-18	3033661.00	343.00	SORTIE	MAN 28659D1	\N	410	f	22212.00	CHOUAIB	203257	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6090	1	2025-04-18	3033709.00	48.00	SORTIE	HYUNDAI 22368A73	\N	482	f	201894.00	IDRISS	203258	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6092	1	2025-04-18	3033878.00	109.00	SORTIE	MIT 11470A73	\N	436	f	38427.00	MOHAMED	203260	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6094	1	2025-04-18	3033972.00	58.00	SORTIE	FENWICK	\N	430	f	2734.10	ABDELKHALEK	203262	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6096	1	2025-04-18	3034118.00	121.00	SORTIE	RENAULT 25636A13	\N	411	f	93371.00	YASSINE	203264	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6097	1	2025-04-19	3034251.00	133.00	SORTIE	MAN 4790B8	\N	403	f	959080.00	KARDODI	203265	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6098	1	2025-04-19	3034486.00	235.00	SORTIE	VOLVO 22299A73	\N	480	f	572265.00	THAMI	203266	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6099	1	2025-04-19	3034603.00	118.00	SORTIE	VOLVO 22300A73	\N	481	f	662270.00	MUSTAPHA	203267	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6100	1	2025-04-19	3034786.00	183.00	SORTIE	MIT 11469A73	\N	435	f	905517.00	ABDELKHALEK	203268	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6101	1	2025-04-19	3034973.00	187.00	SORTIE	MIT 4703A73	\N	408	f	566292.00	MUSTAPHA	203269	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6102	1	2025-04-19	3035069.00	96.00	SORTIE	MIT 11470A73	\N	436	f	38751.00	MOHAMED	203270	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6106	1	2025-04-19	3035857.00	33.00	SORTIE	VOLVO 22300A73	\N	481	f	662347.00	MUSTAPHA	203274	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6107	1	2025-04-19	3036055.00	198.00	SORTIE	CHARGEUSE G 938	\N	413	f	7214.20	ABDERRAHIM	203275	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6108	1	2025-04-19	3036081.00	27.00	SORTIE	LINDE	\N	434	f	7128.00	MILOUD	203276	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6109	1	2025-04-19	3036108.00	27.00	SORTIE	LINDE	\N	472	f	10861.70	ABDELLAH	203277	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6110	1	2025-04-19	3036143.00	35.00	SORTIE	LINDE	\N	428	f	4003.40	HASSAN	203278	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6111	1	2025-04-19	3036168.00	24.00	SORTIE	KANGO 4812A73	\N	419	f	232058.00	TARMOUNIA	203279	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6112	1	2025-04-19	3036209.00	41.00	SORTIE	HYUNDAI 22772A73	\N	479	f	235397.00	HAMID	203280	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6113	1	2025-04-21	3036344.00	135.00	SORTIE	MIT 4969A73	\N	409	f	935580.00	CHOUAIB	203281	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6114	1	2025-04-21	3036398.00	54.00	SORTIE	BERLINGO 10591A73	\N	433	f	355128.00	ABDESLAM	203282	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6115	1	2025-04-21	3036580.00	182.00	SORTIE	RENAULT 25636A13	\N	411	f	94127.00	YASSINE	203283	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6116	1	2025-04-21	3036750.00	170.00	SORTIE	MIT 11470A73	\N	436	f	39336.00	MOHAMED	203284	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6117	1	2025-04-21	3036814.00	64.00	SORTIE	MIT 11469A73	\N	435	f	905721.00	ABDELKHALEK	203285	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6118	1	2025-04-21	3036961.00	147.00	SORTIE	VOLVO 22299A73	\N	480	f	572791.00	THAMI	203286	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6120	1	2025-04-21	3037710.00	97.00	SORTIE	MAN 28659D1	\N	410	f	22454.00	CHOUAIB	203288	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6121	1	2025-04-21	3037863.00	153.00	SORTIE	MAN 706A73	\N	407	f	128045.00	HOUSSAM	203289	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6122	1	2025-04-21	3037915.00	52.00	SORTIE	RENAULT 25636A13	\N	411	f	94303.00	YASSINE	203290	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6124	1	2025-04-21	3037995.00	40.00	SORTIE	LINDE	\N	477	f	8443.30	ABDELKHALEK	203292	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6125	1	2025-04-21	3038062.00	67.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203293	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6126	1	2025-04-21	3038173.00	111.00	SORTIE	MIT 11470A73	\N	436	f	39718.00	MOHAMED	203294	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6127	1	2025-04-22	3038586.00	413.00	SORTIE	VOLVO 17886A73	\N	439	f	631990.00	ABDELMAJID	203295	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6128	1	2025-04-22	3038721.00	135.00	SORTIE	MIT 11469A73	\N	435	f	906263.00	ABDELKHALEK	203296	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6129	1	2025-04-22	3038780.00	59.00	SORTIE	HYUNDAI 22772A73	\N	479	f	235790.00	BOUJAIR	203297	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6130	1	2025-04-22	3038942.00	162.00	SORTIE	VOLVO 22300A73	\N	481	f	662965.00	MUSTAPHA	203298	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6131	1	2025-04-22	3039093.00	150.00	SORTIE	VOLVO 22299A73	\N	480	f	573342.00	THAMI	203299	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6132	1	2025-04-22	3039146.00	53.00	SORTIE	LINDE	\N	472	f	10883.20	ABDELLAH	203300	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6135	1	2025-04-22	3039637.00	166.00	SORTIE	CHARGEUSE G 938	\N	413	f	7226.30	ABDERRAHIM	203303	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6137	1	2025-04-22	3039794.00	16.00	SORTIE	LINDE	\N	428	f	4004.10	JAWAD	203305	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6138	1	2025-04-22	3039836.00	42.00	SORTIE	HYUNDAI 22368A73	\N	482	f	202438.00	IDRISS	203306	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6139	1	2025-04-22	3039871.00	35.00	SORTIE	VOLVO 22300A73	\N	481	f	663043.00	MUSTAPHA	203307	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6140	1	2025-04-22	3040086.00	215.00	SORTIE	MAN 28659D1	\N	410	f	23915.00	CHOUAIB	203308	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6141	1	2025-04-23	3040205.00	118.00	SORTIE	MIT 4969A73	\N	409	f	935968.00	CHOUAIB	203309	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6142	1	2025-04-23	3040412.00	207.00	SORTIE	MIT 11470A73	\N	436	f	40348.00	MOHAMED	203310	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6143	1	2025-04-23	3040547.00	135.00	SORTIE	MIT 11469A73	\N	435	f	906770.00	ABDELKHALEK	203311	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6144	1	2025-04-23	3040665.00	118.00	SORTIE	RENAULT 25636A13	\N	411	f	94739.00	YASSINE	203312	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6147	1	2025-04-23	3041544.00	89.00	SORTIE	VOLVO 22299A73	\N	480	f	573613.00	THAMI	203315	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6148	1	2025-04-23	3041587.00	43.00	SORTIE	FENWICK	\N	430	f	2735.70	ABDELKHALEK	203316	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6149	1	2025-04-23	3041669.00	82.00	SORTIE	MANITOU	\N	484	f	4827.00	SAID	203317	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6150	1	2025-04-23	3042200.00	531.00	SORTIE	VOLVO 17885A73	\N	438	f	665551.00	ABDELMAJID	203318	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6151	1	2025-04-23	3042230.00	30.00	SORTIE	LINDE	\N	434	f	7141.00	MILOUD	203319	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6153	1	2025-04-24	3042383.00	115.00	SORTIE	MIT 11469A73	\N	435	f	907183.00	ABDELKHALEK	203321	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6154	1	2025-04-24	3042481.00	98.00	SORTIE	VOLVO 70352A2	\N	406	f	504557.00	MOHAMED	203322	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6155	1	2025-04-24	3042540.00	59.00	SORTIE	MIT 11470A73	\N	436	f	40586.00	MOHAMED	203323	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6156	1	2025-04-24	3042663.00	123.00	SORTIE	MAN 4790B8	\N	403	f	959600.00	KARDODI	203324	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6157	1	2025-04-24	3042814.00	151.00	SORTIE	VOLVO 22300A73	\N	481	f	663620.00	MUSTAPHA	203325	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6159	1	2025-04-24	3043174.00	218.00	SORTIE	MAN 28659D1	\N	410	f	23870.00	CHOUAIB	203327	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6160	1	2025-04-24	3043227.00	53.00	SORTIE	LINDE	\N	472	f	10904.90	ABDELLAH	203328	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6161	1	2025-04-24	3043395.00	168.00	SORTIE	RENAULT 25636A13	\N	411	f	95385.00	YASSINE	203329	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6162	1	2025-04-24	3043431.00	36.00	SORTIE	LINDE	\N	477	f	8456.70	CHAABI	203330	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6163	1	2025-04-24	3043595.00	164.00	SORTIE	CHARGEUSE G 938	\N	413	f	7239.40	ABDERRAHIM	203331	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6164	1	2025-04-24	3043666.00	71.00	SORTIE	VOLVO 22299A73	\N	480	f	573931.00	THAMI	203332	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6165	1	2025-04-24	3043710.00	45.00	SORTIE	HYUNDAI 22368A73	\N	482	f	202914.00	IDRISS	203333	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6166	1	2025-04-24	3043756.00	46.00	SORTIE	VOLVO 22299A73	\N	480	f	573932.00	THAMI	203334	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6167	1	2025-04-25	3043901.00	145.00	SORTIE	MIT 11469A73	\N	435	f	907756.00	ABDELKHALEK	203335	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6168	1	2025-04-25	3044026.00	125.00	SORTIE	MIT 4969A73	\N	409	f	936390.00	CHOUAIB	203336	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6169	1	2025-04-25	3044083.00	57.00	SORTIE	HYUNDAI 22772A73	\N	479	f	236149.00	NOURDINE	203337	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6170	1	2025-04-25	3044156.00	73.00	SORTIE	MIT 11470A73	\N	436	f	40842.00	MOHAMED	203338	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6172	1	2025-04-25	3044685.00	202.00	SORTIE	VOLVO 17886A73	\N	439	f	632675.00	ABDELMAJID	203340	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6173	1	2025-04-25	3044711.00	26.00	SORTIE	KANGO 4812A73	\N	419	f	232440.00	TARMOUNIA	203341	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6175	1	2025-04-25	3044945.00	169.00	SORTIE	MIT 4703A73	\N	408	f	567093.00	MUSTAPHA	203343	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6176	1	2025-04-25	3045008.00	63.00	SORTIE	MIT 11469A73	\N	435	f	907975.00	ABDELKHALEK	203344	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6179	1	2025-04-26	3045219.00	166.00	SORTIE	VOLVO 22300A73	\N	481	f	664291.00	MUSTAPHA	203347	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6180	1	2025-04-26	3045424.00	205.00	SORTIE	MAN 28659D1	\N	410	f	24579.00	CHOUAIB	203348	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6181	1	2025-04-26	3045480.00	56.00	SORTIE	BERLINGO 10591A73	\N	433	f	356280.00	ABDESLAM	203349	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6182	1	2025-04-26	3045696.00	216.00	SORTIE	VOLVO 22299A73	\N	480	f	574882.00	THAMI	203350	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6184	1	2025-04-26	3046143.00	147.00	SORTIE	MIT 11470A73	\N	436	f	41372.00	MOHAMED	203352	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6187	1	2025-04-26	3046257.00	29.00	SORTIE	LINDE	\N	434	f	7150.60	MILOUD	203355	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6188	1	2025-04-26	3046307.00	50.00	SORTIE	LINDE	\N	472	f	1092.50	ABDELLAH	203356	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6190	1	2025-04-26	3046606.00	156.00	SORTIE	CHARGEUSE G 938	\N	413	f	7251.70	ABDERRAHIM	203358	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6192	1	2025-04-26	3046695.00	53.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203360	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6194	1	2025-04-26	3047189.00	186.00	SORTIE	RENAULT 25636A13	\N	411	f	96078.00	YASSINE	203362	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6195	1	2025-04-26	3047219.00	30.00	SORTIE	VOLVO 22300A73	\N	481	f	664385.00	MUSTAPHA	203363	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6196	1	2025-04-26	3047264.00	45.00	SORTIE	VOLVO 22299A73	\N	480	f	575010.00	THAMI	203364	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6197	1	2025-04-28	3047414.00	150.00	SORTIE	MIT 11470A73	\N	436	f	41900.00	MOHAMED	203365	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6198	1	2025-04-28	3047640.00	226.00	SORTIE	MAN 706A73	\N	407	f	128540.00	HOUSSAM	203366	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6199	1	2025-04-28	3047771.00	131.00	SORTIE	VOLVO 22299A73	\N	480	f	575538.00	THAMI	203367	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6200	1	2025-04-28	3047803.00	32.00	SORTIE	LINDE	\N	472	f	10938.50	AZIZ	203368	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6202	1	2025-04-28	3047876.00	35.00	SORTIE	FENWICK	\N	430	f	27368.00	ABDELKHALEK	203370	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6203	1	2025-04-28	3047926.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	203389.00	IDRISS	203371	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6204	1	2025-04-28	3047979.00	53.00	SORTIE	HYUNDAI 22772A73	\N	479	f	236497.00	HAMID	203372	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6205	1	2025-04-29	3048113.00	134.00	SORTIE	MIT 4969A73	\N	409	f	936822.00	CHOUAIB	203373	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6206	1	2025-04-29	3048268.00	155.00	SORTIE	MIT 11470A73	\N	436	f	42457.00	MOHAMED	203374	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6207	1	2025-04-29	3048358.00	90.00	SORTIE	MAN 4790B8	\N	403	f	960005.00	KARDODI	203375	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6208	1	2025-04-29	3048386.00	28.00	SORTIE	LINDE	\N	477	f	8467.50	CHAABI	203376	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6209	1	2025-04-29	3048422.00	36.00	SORTIE	LINDE	\N	427	f	30080.70	ABDERRAHIM	203377	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6210	1	2025-04-29	3048580.00	158.00	SORTIE	MIT 11469A73	\N	435	f	908461.00	ABDELKHALEK	203378	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6211	1	2025-04-29	3048719.00	139.00	SORTIE	VOLVO 22300A73	\N	481	f	664914.00	MUSTAPHA	203379	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6212	1	2025-04-29	3048873.00	154.00	SORTIE	RENAULT 25636A13	\N	411	f	96645.00	YASSINE	203380	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6213	1	2025-04-29	3048976.00	103.00	SORTIE	MAN 28659D1	\N	410	f	24874.00	CHOUAIB	203381	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6214	1	2025-04-29	3049418.00	442.00	SORTIE	VOLVO 17886A73	\N	439	f	634270.00	ABDELMAJID	203382	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6215	1	2025-04-29	3049488.00	70.00	SORTIE	VOLVO 22300A73	\N	481	f	665187.00	MUSTAPHA	203383	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6216	1	2025-04-29	3049597.00	109.00	SORTIE	VOLVO 22299A73	\N	480	f	575971.00	THAMI	203384	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6218	1	2025-04-30	3050964.00	700.00	SORTIE	VOLVO 17885A73	\N	438	f	667401.00	ABDELKARIM	203386	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6219	1	2025-04-30	3051094.00	130.00	SORTIE	MIT 11469A73	\N	435	f	908966.00	ABDELKHALEK	203387	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6221	1	2025-04-30	3051297.00	62.00	SORTIE	RENAULT 25636A13	\N	411	f	96878.00	YASSINE	203389	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6223	1	2025-04-30	3051674.00	90.00	SORTIE	MANITOU	\N	484	f	4867.00	SAID	203391	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6224	1	2025-04-30	3051705.00	31.00	SORTIE	LINDE	\N	434	f	7159.40	MILOUD	203392	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6225	1	2025-04-30	3051750.00	45.00	SORTIE	VOLVO 22299A73	\N	480	f	576130.00	THAMI	203393	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6226	1	2025-04-30	3051900.00	150.00	SORTIE	MIT 11470A73	\N	436	f	42958.00	MOHAMED	203394	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6227	1	2025-04-30	3052067.00	167.00	SORTIE	CHARGEUSE G 938	\N	413	f	7264.20	ABDERRAHIM	203395	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6228	1	2025-04-30	3052113.00	46.00	SORTIE	LINDE	\N	472	f	10956.90	AZIZ	203396	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6229	1	2025-04-30	3052171.00	58.00	SORTIE	HYUNDAI 22772A73	\N	479	f	236897.00	HAMID	203397	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6230	1	2025-04-30	3052211.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	203832.00	IDRISS	203398	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6234	1	2025-05-01	3052495.00	158.00	SORTIE	RENAULT 25636A13	\N	411	f	97506.00	YASSINE	203402	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6235	1	2025-05-01	3052766.00	271.00	SORTIE	MAN 28659D1	\N	410	f	25807.00	CHOUAIB	203403	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6236	1	2025-05-01	3052926.00	160.00	SORTIE	VOLVO 22300A73	\N	481	f	665840.00	MUSTAPHA	203404	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6237	1	2025-05-01	3052976.00	50.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203405	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6238	1	2025-05-01	3053026.00	50.00	SORTIE	VOLVO 22300A73	\N	481	f	665970.00	MUSTAPHA	203406	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6239	1	2025-05-02	3053190.00	164.00	SORTIE	RENAULT 25636A13	\N	411	f	98136.00	YASSINE	203407	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6240	1	2025-05-02	3053314.00	124.00	SORTIE	MIT 4969A73	\N	409	f	937229.00	CHOUAIB	203408	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6241	1	2025-05-02	3053374.00	60.00	SORTIE	ISUZU 26128A8	\N	401	f	863860.00	TOUFIK	203409	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6242	1	2025-05-02	3053513.00	139.00	SORTIE	MIT 11470A73	\N	436	f	43433.00	MOHAMED	203410	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6243	1	2025-05-02	3053645.00	132.00	SORTIE	MIT 11469A73	\N	435	f	909363.00	ABDELKHALEK	203411	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6244	1	2025-05-02	3053764.00	119.00	SORTIE	VOLVO 22299A73	\N	480	f	576555.00	THAMI	203412	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6245	1	2025-05-02	3053810.00	46.00	SORTIE	LINDE	\N	472	f	10975.80	AZIZ	203413	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6246	1	2025-05-02	3053860.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	237235.00	HAMID	203414	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6248	1	2025-05-03	3054011.00	134.00	SORTIE	VOLVO 70352A2	\N	406	f	504864.00	MOHAMED	203416	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6249	1	2025-05-03	3054133.00	122.00	SORTIE	MAN 4790B8	\N	403	f	960565.00	KARDODI	203417	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6250	1	2025-05-03	3054249.00	115.00	SORTIE	MIT 11469A73	\N	435	f	909785.00	ABDELKHALEK	203418	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6251	1	2025-05-03	3054359.00	110.00	SORTIE	VOLVO 22300A73	\N	481	f	666390.00	MUSTAPHA	203419	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6252	1	2025-05-03	3054438.00	79.00	SORTIE	RENAULT 25636A13	\N	411	f	98392.00	YASSINE	203420	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6253	1	2025-05-03	3054503.00	65.00	SORTIE	MIT 11470A73	\N	436	f	43639.00	MOHAMED	203421	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6255	1	2025-05-03	3054715.00	56.00	SORTIE	BERLINGO 10591A73	\N	433	f	357284.00	ABDESLAM	203423	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6256	1	2025-05-03	3055036.00	321.00	SORTIE	VOLVO 17886A73	\N	439	f	635315.00	ABDELMAJID	203424	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6257	1	2025-05-03	3055066.00	30.00	SORTIE	KANGO 4812A73	\N	419	f	232886.00	TARMOUNIA	203425	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6258	1	2025-05-03	3055092.00	26.00	SORTIE	LINDE	\N	434	f	7167.10	MILOUD	203426	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6259	1	2025-05-03	3055270.00	178.00	SORTIE	MIT 4703A73	\N	408	f	567958.00	MUSTAPHA	203427	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6260	1	2025-05-03	3055315.00	45.00	SORTIE	LINDE	\N	477	f	8484.90	CHAABI	203428	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6261	1	2025-05-03	3055338.00	23.00	SORTIE	LINDE	\N	472	f	10985.70	AZIZ	203429	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6262	1	2025-05-03	3055392.00	54.00	SORTIE	FENWICK	\N	430	f	27387.80	ABDELKHALEK	203430	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6264	1	2025-05-03	3055510.00	73.00	SORTIE	VOLVO 22300A73	\N	481	f	666643.00	MUSTAPHA	203432	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6265	1	2025-05-05	3055658.00	148.00	SORTIE	RENAULT 25636A13	\N	411	f	98954.00	YASSINE	203433	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6266	1	2025-05-05	3055720.00	62.00	SORTIE	ISUZU 26128A8	\N	401	f	864142.00	TOUFIK	203434	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6267	1	2025-05-05	3055885.00	165.00	SORTIE	MIT 11470A73	\N	436	f	44190.00	MOHAMED	203435	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6268	1	2025-05-05	3055925.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	204240.00	IDRISS	203436	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6269	1	2025-05-05	3056114.00	189.00	SORTIE	CHARGEUSE G 938	\N	413	f	7278.40	ABDERRAHIM	203437	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6270	1	2025-05-05	3056165.00	51.00	SORTIE	HYUNDAI 22772A73	\N	479	f	237613.00	NOURDINE	203438	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6271	1	2025-05-05	3056237.00	72.00	SORTIE	HYUNDAI 18516A73	\N	471	f	306838.00	NOURDINE	203439	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6272	1	2025-05-05	3056306.00	69.00	SORTIE	MIT 11469A73	\N	435	f	910031.00	ABDELKHALEK	203440	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6274	1	2025-05-05	3056548.00	188.00	SORTIE	VOLVO 22299A73	\N	480	f	577238.00	THAMI	203442	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6275	1	2025-05-05	3056722.00	174.00	SORTIE	MAN 28659D1	\N	410	f	26277.00	CHOUAIB	203443	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6276	1	2025-05-05	3056766.00	44.00	SORTIE	LINDE	\N	472	f	11004.10	AZIZ	203444	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6278	1	2025-05-05	3056835.00	31.00	SORTIE	RENAULT 25636A13	\N	411	f	99063.00	YASSINE	203446	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6279	1	2025-05-05	3056894.00	58.00	SORTIE	LINDE	\N	420	f	17805.70	ABDELKHALEK	203447	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6281	1	2025-05-06	3057345.00	143.00	SORTIE	MIT 4969A73	\N	409	f	937672.00	CHOUAIB	203449	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6282	1	2025-05-06	3057452.00	108.00	SORTIE	MIT 11469A73	\N	435	f	910434.00	ABDELKHALEK	203450	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6283	1	2025-05-06	3057622.00	170.00	SORTIE	VOLVO 22300A73	\N	481	f	667344.00	MUSTAPHA	203451	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6284	1	2025-05-06	3057701.00	79.00	SORTIE	MIT 11470A73	\N	436	f	44443.00	MOHAMED	203452	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6288	1	2025-05-06	3058704.00	387.00	SORTIE	VOLVO 17886A73	\N	439	f	636660.00	ABDELMAJID	203456	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6289	1	2025-05-06	3058757.00	53.00	SORTIE	HYUNDAI 18516A73	\N	471	f	307151.00	BOUJAIR	203457	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6290	1	2025-05-06	3059457.00	700.00	SORTIE	VOLVO 17885A73	\N	438	f	669238.00	ABDELKARIM	203458	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6291	1	2025-05-06	3059607.00	150.00	SORTIE	VOLVO 22299A73	\N	480	f	577749.00	THAMI	203459	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6292	1	2025-05-06	3059759.00	152.00	SORTIE	RENAULT 25636A13	\N	411	f	99635.00	YASSINE	203460	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6294	1	2025-05-06	3059852.00	43.00	SORTIE	VOLVO 22300A73	\N	481	f	667479.00	MUSTAPHA	203462	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6295	1	2025-05-07	3059920.00	68.00	SORTIE	ISUZU 26128A8	\N	401	f	864484.00	TOUFIK	203463	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6296	1	2025-05-07	3060183.00	263.00	SORTIE	MAN 706A73	\N	407	f	129168.00	HOUSSAM	203464	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6297	1	2025-05-07	3060421.00	238.00	SORTIE	MAN 28659D1	\N	410	f	27125.00	CHOUAIB	203465	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6298	1	2025-05-07	3060572.00	151.00	SORTIE	MIT 11470A73	\N	436	f	44990.00	MOHAMED	203466	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6299	1	2025-05-07	3060732.00	160.00	SORTIE	MIT 11469A73	\N	435	f	911062.00	ABDELKHALEK	203467	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6301	1	2025-05-07	3060937.00	48.00	SORTIE	HYUNDAI 18516A73	\N	471	f	307426.00	HAMZA	203469	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6302	1	2025-05-07	3060988.00	51.00	SORTIE	LINDE	\N	428	f	4006.60	JAWAD	203470	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6303	1	2025-05-07	3061087.00	99.00	SORTIE	MANITOU	\N	484	f	4912.00	SAID	203471	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6305	1	2025-05-07	3061267.00	138.00	SORTIE	MIT 4969A73	\N	409	f	938161.00	CHOUAIB	203473	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6306	1	2025-05-07	3061484.00	217.00	SORTIE	VOLVO 22299A73	\N	480	f	578612.00	THAMI	203474	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6307	1	2025-05-07	3061517.00	33.00	SORTIE	LINDE	\N	434	f	7180.70	MILOUD	203475	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6308	1	2025-05-07	3061664.00	147.00	SORTIE	MAN 4790B8	\N	403	f	961122.00	KARDODI	203476	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6309	1	2025-05-07	3061719.00	55.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203477	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6310	1	2025-05-07	3061750.00	31.00	SORTIE	FENWICK	\N	430	f	27398.60	ABDELKHALEK	203478	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6311	1	2025-05-07	3061790.00	40.00	SORTIE	LINDE	\N	472	f	11020.50	AZIZ	203479	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6312	1	2025-05-07	3061833.00	43.00	SORTIE	HYUNDAI 22368A73	\N	482	f	204499.00	IDRISS	203480	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6313	1	2025-05-08	3061943.00	110.00	SORTIE	VOLVO 70352A2	\N	406	f	505147.00	MOHAMED	203481	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6314	1	2025-05-08	3062122.00	179.00	SORTIE	MIT 11469A73	\N	435	f	911727.00	MUSTAPHA	203482	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6315	1	2025-05-08	3062305.00	183.00	SORTIE	VOLVO 22300A73	\N	481	f	668311.00	MUSTAPHA	203483	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6316	1	2025-05-08	3062398.00	93.00	SORTIE	MIT 11470A73	\N	436	f	45322.00	MOHAMED	203484	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6317	1	2025-05-08	3062436.00	39.00	SORTIE	LINDE	\N	477	f	8499.80	CHAABI	203485	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6318	1	2025-05-08	3062481.00	45.00	SORTIE	HYUNDAI 22772A73	\N	479	f	237891.00	BOUJAIR	203486	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6319	1	2025-05-08	3062528.00	48.00	SORTIE	HYUNDAI 18516A73	\N	471	f	307709.00	BOUJAIR	203487	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6320	1	2025-05-08	3062645.00	117.00	SORTIE	RENAULT 25636A13	\N	411	f	100083.00	YASSINE	203488	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6323	1	2025-05-08	3063664.00	240.00	SORTIE	MAN 28659D1	\N	410	f	27963.00	CHOUAIB	203491	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6324	1	2025-05-08	3063863.00	199.00	SORTIE	CHARGEUSE G 938	\N	413	f	7294.80	ABDERRAHIM	203492	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6325	1	2025-05-08	3063886.00	23.00	SORTIE	LINDE	\N	428	f	4007.90	HASSAN	203493	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6326	1	2025-05-08	3063936.00	49.00	SORTIE	MIT 11469A73	\N	435	f	911872.00	MUSTAPHA	203494	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6327	1	2025-05-09	3064077.00	141.00	SORTIE	VOLVO 22300A73	\N	481	f	668833.00	MUSTAPHA	203495	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6328	1	2025-05-09	3064140.00	63.00	SORTIE	ISUZU 26128A8	\N	401	f	864833.00	TOUFIK	203496	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6329	1	2025-05-09	3064250.00	110.00	SORTIE	MIT 11470A73	\N	436	f	45721.00	MOHAMED	203497	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6330	1	2025-05-09	3064900.00	650.00	SORTIE	VOLVO 17885A73	\N	438	f	671000.00	ABDELKARIM	203498	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6331	1	2025-05-09	3064947.00	47.00	SORTIE	VOLVO 22300A73	\N	481	f	668959.00	MUSTAPHA	203499	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6332	1	2025-05-09	3064997.00	50.00	SORTIE	HYUNDAI 18516A73	\N	471	f	307993.00	BOUJAIR	203500	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6333	1	2025-05-09	3065038.00	42.00	SORTIE	LINDE	\N	472	f	1138.50	AZIZ	203501	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6334	1	2025-05-09	3065321.00	283.00	SORTIE	VOLVO 17886A73	\N	439	f	637591.00	ABDELMAJID	203502	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6335	1	2025-05-09	3065523.00	202.00	SORTIE	RENAULT 25636A13	\N	411	f	100793.00	YASSINE	203503	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6336	1	2025-05-09	3065545.00	22.00	SORTIE	LINDE	\N	428	f	4009.10	HASSAN	203504	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6339	1	2025-05-09	3065726.00	29.00	SORTIE	KANGO 4812A73	\N	419	f	233313.00	TARMOUNIA	203507	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6341	1	2025-05-10	3065944.00	168.00	SORTIE	MIT 11470A73	\N	436	f	46311.00	MOHAMED	203509	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6342	1	2025-05-10	3065984.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	204921.00	IDRISS	203510	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6344	1	2025-05-10	3066074.00	61.00	SORTIE	MIT 11469A73	\N	435	f	912102.00	ABDELKHALEK	203512	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6345	1	2025-05-10	3066272.00	198.00	SORTIE	VOLVO 22299A73	\N	480	f	579323.00	THAMI	203513	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6346	1	2025-05-10	3066294.00	22.00	SORTIE	LINDE	\N	472	f	11048.10	AZIZ	203514	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6347	1	2025-05-10	3066344.00	50.00	SORTIE	HYUNDAI 18516A73	\N	471	f	308251.00	BOUJAIR	203515	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6348	1	2025-05-10	3066375.00	31.00	SORTIE	LINDE	\N	434	f	7193.40	MILOUD	203516	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6349	1	2025-05-10	3066410.00	35.00	SORTIE	MIT 11470A73	\N	436	f	46425.00	MOHAMED	203517	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6350	1	2025-05-10	3066433.00	23.00	SORTIE	LINDE	\N	428	f	4010.30	HASSAN	203518	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6352	1	2025-05-12	3066550.00	66.00	SORTIE	ISUZU 26128A8	\N	401	f	865142.00	TOUFIK	203520	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6353	1	2025-05-12	3066689.00	139.00	SORTIE	MIT 11469A73	\N	435	f	912640.00	ABDELKHALEK	203521	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6354	1	2025-05-12	3066870.00	181.00	SORTIE	CHARGEUSE G 938	\N	413	f	7308.80	ABDERRAHIM	203522	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6355	1	2025-05-12	3066968.00	98.00	SORTIE	VOLVO 22300A73	\N	481	f	669353.00	MUSTAPHA	203523	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6356	1	2025-05-12	3067151.00	184.00	SORTIE	RENAULT 25636A13	\N	411	f	101492.00	YASSINE	203524	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6357	1	2025-05-12	3067210.00	59.00	SORTIE	HYUNDAI 18516A73	\N	471	f	380561.00	HAMZA	203525	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6358	1	2025-05-12	3067477.00	267.00	SORTIE	VOLVO 17886A73	\N	439	f	638491.00	ABDELMAJID	203526	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6359	1	2025-05-12	3067610.00	133.00	SORTIE	VOLVO 22299A73	\N	480	f	579828.00	THAMI	203527	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6360	1	2025-05-12	3067642.00	32.00	SORTIE	VOLVO 22300A73	\N	481	f	669434.00	MUSTAPHA	203528	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6361	1	2025-05-12	3067691.00	49.00	SORTIE	LINDE	\N	472	f	11066.70	ABDELLAH	203529	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6362	1	2025-05-12	3067737.00	46.00	SORTIE	FENWICK	\N	430	f	27414.40	ABDELKHALEK	203530	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6363	1	2025-05-13	3067877.00	140.00	SORTIE	MAN 4790B8	\N	403	f	961689.00	KARDODI	203531	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6364	1	2025-05-13	3068047.00	170.00	SORTIE	MIT 11469A73	\N	435	f	913307.00	ABDELKHALEK	203532	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6365	1	2025-05-13	3068083.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	308712.00	HAMZA	203533	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6367	1	2025-05-13	3068411.00	174.00	SORTIE	MIT 11470A73	\N	436	f	47011.00	MOHAMED	203535	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6369	1	2025-05-13	3068899.00	183.00	SORTIE	RENAULT 25636A13	\N	411	f	102247.00	YASSINE	203537	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6370	1	2025-05-13	3068949.00	50.00	SORTIE	MIT 11469A73	\N	435	f	913526.00	ABDELKHALEK	203538	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6371	1	2025-05-13	3069066.00	117.00	SORTIE	VOLVO 22299A73	\N	480	f	580255.00	THAMI	203539	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6373	1	2025-05-13	3069153.00	44.00	SORTIE	LINDE	\N	477	f	8816.90	CHAABI	203541	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6374	1	2025-05-13	3069272.00	119.00	SORTIE	MAN 28659D1	\N	410	f	28208.00	CHOUAIB	203542	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6375	1	2025-05-13	3069319.00	47.00	SORTIE	LINDE	\N	428	f	4012.80	JAWAD	203543	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6376	1	2025-05-13	3069526.00	207.00	SORTIE	MIT 4969A73	\N	409	f	938764.00	CHOUAIB	203544	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6377	1	2025-05-14	3069576.00	50.00	SORTIE	ISUZU 26128A8	\N	401	f	865396.00	TOUFIK	203545	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6378	1	2025-05-14	3069599.00	23.00	SORTIE	HYUNDAI 18516A73	\N	471	f	308854.00	HAMZA	203546	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6379	1	2025-05-14	3069695.00	96.00	SORTIE	MIT 11470A73	\N	436	f	47377.00	MOHAMED	203547	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6381	1	2025-05-14	3071718.00	23.00	SORTIE	LINDE	\N	434	f	7204.00	MILOUD	203549	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6382	1	2025-05-14	3071899.00	182.00	SORTIE	CHARGEUSE G 938	\N	413	f	7323.60	ABDERRAHIM	203550	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6383	1	2025-05-14	3072046.00	147.00	SORTIE	MIT 4703A73	\N	408	f	568666.00	MUSTAPHA	203551	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6385	1	2025-05-14	3072131.00	38.00	SORTIE	LINDE	\N	472	f	11083.10	ABDELLAH	203553	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6386	1	2025-05-14	3072198.00	67.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203554	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6388	1	2025-05-14	3072475.00	224.00	SORTIE	VOLVO 22300A73	\N	481	f	670271.00	MUSTAPHA	203556	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6389	1	2025-05-14	3072524.00	49.00	SORTIE	HYUNDAI 22368A73	\N	482	f	205412.00	IDRISS	203557	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6390	1	2025-05-15	3072767.00	243.00	SORTIE	MAN 706A73	\N	407	f	129683.00	HOUSSAM	203558	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6391	1	2025-05-15	3072947.00	180.00	SORTIE	MIT 11469A73	\N	435	f	914196.00	ABDELKHALEK	203559	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6392	1	2025-05-15	3073465.00	518.00	SORTIE	VOLVO 17885A73	\N	438	f	672336.00	ABDELKARIM	203560	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6394	1	2025-05-15	3073607.00	34.00	SORTIE	HYUNDAI 18516A73	\N	471	f	309015.00	HAMZA	203562	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6395	1	2025-05-15	3073667.00	60.00	SORTIE	MIT 11470A73	\N	436	f	47591.00	MOHAMED	203563	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6396	1	2025-05-15	3073842.00	175.00	SORTIE	RENAULT 25636A13	\N	411	f	102924.00	YASSINE	203564	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6399	1	2025-05-15	3074940.00	112.00	SORTIE	VOLVO 17886A73	\N	439	f	638737.00	ABDELMAJID	203567	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6400	1	2025-05-15	3075028.00	88.00	SORTIE	MANITOU	\N	484	f	4959.00	SAID	203568	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6401	1	2025-05-15	3075081.00	53.00	SORTIE	MIT 11469A73	\N	435	f	914385.00	ABDELKHALEK	203569	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6402	1	2025-05-15	3075148.00	67.00	SORTIE	RENAULT 25636A13	\N	411	f	103186.00	YASSINE	203570	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6403	1	2025-05-15	3075495.00	347.00	SORTIE	MAN 28659D1	\N	410	f	29236.00	CHOUAIB	203571	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6404	1	2025-05-15	3075530.00	35.00	SORTIE	LINDE	\N	428	f	4014.70	JAWAD	203572	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6405	1	2025-05-15	3075703.00	173.00	SORTIE	MIT 4969A73	\N	409	f	939381.00	CHOUAIB	203573	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6406	1	2025-05-16	3075898.00	195.00	SORTIE	VOLVO 70352A2	\N	406	f	505644.00	MOHAMED	203574	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6407	1	2025-05-16	3075953.00	55.00	SORTIE	ISUZU 26128A8	\N	401	f	865648.00	TOUFIK	203575	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6408	1	2025-05-16	3076136.00	183.00	SORTIE	VOLVO 22300A73	\N	481	f	670952.00	MUSTAPHA	203576	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6409	1	2025-05-16	3076261.00	125.00	SORTIE	MIT 11470A73	\N	436	f	48049.00	MUSTAPHA	203577	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6410	1	2025-05-16	3076378.00	117.00	SORTIE	MAN 4790B8	\N	403	f	962145.00	KARDODI	203578	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6412	1	2025-05-16	3076745.00	63.00	SORTIE	HYUNDAI 18516A73	\N	471	f	309349.00	HAMZA	203580	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6415	1	2025-05-16	3077104.00	47.00	SORTIE	LINDE	\N	472	f	11102.90	MILOUD	203583	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6416	1	2025-05-16	3077148.00	44.00	SORTIE	FENWICK	\N	430	f	27430.00	ABDELKHALEK	203584	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6417	1	2025-05-16	3077183.00	35.00	SORTIE	VOLVO 22300A73	\N	481	f	671083.00	MUSTAPHA	203585	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6418	1	2025-05-16	3077319.00	136.00	SORTIE	VOLVO 22299A73	\N	480	f	580701.00	THAMI	203586	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6419	1	2025-05-17	3077498.00	178.00	SORTIE	RENAULT 25636A13	\N	411	f	103872.00	YASSINE	203587	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6420	1	2025-05-17	3077638.00	140.00	SORTIE	MIT 11469A73	\N	435	f	914889.00	ABDELKHALEK	203588	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6423	1	2025-05-17	3077776.00	76.00	SORTIE	MIT 11470A73	\N	436	f	48275.00	MOHAMED	203591	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6424	1	2025-05-17	3078147.00	371.00	SORTIE	VOLVO 17886A73	\N	439	f	640018.00	ABDELMAJID	203592	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6425	1	2025-05-17	3078201.00	54.00	SORTIE	RENAULT 25636A13	\N	411	f	104088.00	YASSINE	203593	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6426	1	2025-05-17	3078227.00	26.00	SORTIE	LINDE	\N	434	f	7215.20	MILOUD	203594	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6427	1	2025-05-17	3078271.00	44.00	SORTIE	MIT 11469A73	\N	435	f	915045.00	ABDELKHALEK	203595	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6428	1	2025-05-17	3078581.00	310.00	SORTIE	VOLVO 17885A73	\N	438	f	673183.00	ABDELKARIM	203596	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6429	1	2025-05-17	3078628.00	47.00	SORTIE	HYUNDAI 18516A73	\N	471	f	309588.00	HAMZA	203597	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6430	1	2025-05-17	3078664.00	36.00	SORTIE	LINDE	\N	428	f	4016.60	HASSAN	203598	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6431	1	2025-05-17	3078685.00	22.00	SORTIE	LINDE	\N	472	f	11112.30	ABDELLAH	203599	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6432	1	2025-05-17	3078730.00	45.00	SORTIE	LINDE	\N	477	f	8534.20	CHAABI	203600	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6433	1	2025-05-17	3078757.00	28.00	SORTIE	KANGO 4812A73	\N	419	f	233729.00	TARMOUNIA	203601	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6434	1	2025-05-19	3078822.00	65.00	SORTIE	ISUZU 26128A8	\N	401	f	866003.00	TOUFIK	203602	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6435	1	2025-05-19	3078980.00	158.00	SORTIE	VOLVO 22300A73	\N	481	f	671725.00	MUSTAPHA	203603	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6436	1	2025-05-19	3079218.00	238.00	SORTIE	VOLVO 22299A73	\N	480	f	581528.00	THAMI	203604	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6437	1	2025-05-19	3079598.00	380.00	SORTIE	MAN 28659D1	\N	410	f	30401.00	CHOUAIB	203605	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6438	1	2025-05-19	3079636.00	38.00	SORTIE	HYUNDAI 22368A73	\N	482	f	205878.00	IDRISS	203606	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6439	1	2025-05-19	3079792.00	156.00	SORTIE	CHARGEUSE G 938	\N	413	f	7334.50	ABDERRAHIM	203607	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6440	1	2025-05-19	3079854.00	62.00	SORTIE	HYUNDAI 18516A73	\N	471	f	309977.00	HAMZA	203608	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6442	1	2025-05-19	3080169.00	178.00	SORTIE	MIT 11470A73	\N	436	f	48901.00	MOHAMED	203610	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6443	1	2025-05-19	3080195.00	26.00	SORTIE	VOLVO 22300A73	\N	481	f	671784.00	MUSTAPHA	203611	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6444	1	2025-05-19	3080225.00	30.00	SORTIE	LINDE	\N	472	f	11124.90	ABDELLAH	203612	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6445	1	2025-05-19	3080329.00	105.00	SORTIE	MAN 4790B8	\N	403	f	962573.00	KARDODI	203613	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6446	1	2025-05-19	3080354.00	25.00	SORTIE	LINDE	\N	428	f	4017.80	JAWAD	203614	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6447	1	2025-05-19	3080480.00	126.00	SORTIE	MIT 4969A73	\N	409	f	939752.00	CHOUAIB	203615	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6448	1	2025-05-19	3080757.00	277.00	SORTIE	VOLVO 17886A73	\N	439	f	640998.00	ABDELMAJID	203616	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6450	1	2025-05-20	3081005.00	198.00	SORTIE	RENAULT 25636A13	\N	411	f	104809.00	YASSINE	203618	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6451	1	2025-05-20	3081107.00	102.00	SORTIE	VOLVO 22299A73	\N	480	f	581864.00	THAMI	203619	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6452	1	2025-05-20	3081266.00	159.00	SORTIE	MIT 11469A73	\N	435	f	915641.00	ABDELKHALEK	203620	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6454	1	2025-05-20	3081429.00	105.00	SORTIE	MIT 11470A73	\N	436	f	49255.00	MOHAMED	203622	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6455	1	2025-05-20	3081626.00	197.00	SORTIE	MAN 28659D1	\N	410	f	31045.00	CHOUAIB	203623	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6456	1	2025-05-20	3081665.00	39.00	SORTIE	HYUNDAI 18516A73	\N	471	f	310770.00	BOUJAIR	203624	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6457	1	2025-05-20	3081794.00	129.00	SORTIE	VOLVO 22300A73	\N	481	f	672225.00	MUSTAPHA	203625	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6458	1	2025-05-20	3081850.00	56.00	SORTIE	LINDE	\N	431	f	8674.00	SAID	203626	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6459	1	2025-05-20	3082264.00	414.00	SORTIE	VOLVO 17885A73	\N	438	f	674267.00	ABDELKARIM	203627	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6460	1	2025-05-21	3082284.00	20.00	SORTIE	ISUZU 26128A8	\N	401	f	866257.00	TOUFIK	203628	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6461	1	2025-05-21	3082343.00	59.00	SORTIE	MIT 11469A73	\N	435	f	915839.00	ABDELKHALEK	203629	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6462	1	2025-05-21	3082409.00	66.00	SORTIE	MIT 11470A73	\N	436	f	49487.00	MOHAMED	203630	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6466	1	2025-05-21	3083184.00	272.00	SORTIE	VOLVO 17886A73	\N	439	f	641912.00	ABDELMAJID	203634	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6468	1	2025-05-21	3083390.00	158.00	SORTIE	CHARGEUSE G 938	\N	413	f	7347.00	ABDERRAHIM	203636	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6469	1	2025-05-21	3083409.00	19.00	SORTIE	LINDE	\N	434	f	7223.10	MILOUD	203637	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6470	1	2025-05-21	3083445.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	310391.00	BOUJAIR	203638	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6471	1	2025-05-21	3083492.00	47.00	SORTIE	HYUNDAI 22772A73	\N	479	f	238191.00	BOUJAIR	203639	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6472	1	2025-05-21	3083531.00	39.00	SORTIE	FENWICK	\N	430	f	27444.50	ABDELKHALEK	203640	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6473	1	2025-05-21	3083577.00	46.00	SORTIE	LINDE	\N	472	f	11144.70	SEKOURI	203641	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6474	1	2025-05-21	3083727.00	150.00	SORTIE	VOLVO 22300A73	\N	481	f	672813.00	MUSTAPHA	203642	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6475	1	2025-05-21	3083770.00	43.00	SORTIE	LINDE	\N	428	f	4020.30	JAWAD	203643	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6476	1	2025-05-21	3083974.00	204.00	SORTIE	VOLVO 22299A73	\N	480	f	582636.00	THAMI	203644	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6477	1	2025-05-22	3084046.00	72.00	SORTIE	ISUZU 26128A8	\N	401	f	866453.00	TOUFIK	203645	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6478	1	2025-05-22	3084190.00	144.00	SORTIE	MIT 11469A73	\N	435	f	916399.00	ABDELKHALEK	203646	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6479	1	2025-05-22	3084333.00	143.00	SORTIE	VOLVO 70352A2	\N	406	f	506016.00	MOHAMED	203647	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6480	1	2025-05-22	3084386.00	53.00	SORTIE	HYUNDAI 22368A73	\N	482	f	206435.00	IDRISS	203648	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6481	1	2025-05-22	3084568.00	182.00	SORTIE	MIT 11470A73	\N	436	f	50140.00	MOHAMED	203649	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6482	1	2025-05-22	3084600.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	310567.00	HAMZA	203650	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6483	1	2025-05-22	3084847.00	247.00	SORTIE	MAN 28659D1	\N	410	f	31874.00	CHOUAIB	203651	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6484	1	2025-05-22	3084883.00	36.00	SORTIE	LINDE	\N	477	f	8548.10	CHAABI	203652	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6486	1	2025-05-23	3085064.00	130.00	SORTIE	MAN 4790B8	\N	403	f	963051.00	KARDODI	203654	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6487	1	2025-05-23	3085219.00	154.00	SORTIE	MIT 11470A73	\N	436	f	50675.00	MOHAMED	203655	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6488	1	2025-05-23	3085342.00	123.00	SORTIE	MIT 11469A73	\N	435	f	916859.00	ABDELKHALEK	203656	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6489	1	2025-05-23	3085557.00	215.00	SORTIE	MAN 706A73	\N	407	f	130149.00	HOUSSAM	203657	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6490	1	2025-05-23	3085742.00	185.00	SORTIE	RENAULT 25636A13	\N	411	f	105510.00	YASSINE	203658	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6493	1	2025-05-23	3086338.00	160.00	SORTIE	MIT 4703A73	\N	408	f	569514.00	MUSTAPHA	203661	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6494	1	2025-05-23	3086373.00	35.00	SORTIE	HYUNDAI 18516A73	\N	471	f	310776.00	HAMZA	203662	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6496	1	2025-05-23	3086499.00	88.00	SORTIE	LINDE	\N	484	f	5000.00	SAID	203664	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6497	1	2025-05-23	3086545.00	46.00	SORTIE	LINDE	\N	472	f	11164.30	ABDELLAH	203665	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6498	1	2025-05-23	3086576.00	31.00	SORTIE	MIT 11469A73	\N	435	f	916968.00	ABDELKHALEK	203666	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6500	1	2025-05-23	3087078.00	180.00	SORTIE	VOLVO 22300A73	\N	481	f	673526.00	MUSTAPHA	203668	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6502	1	2025-05-23	3087133.00	38.00	SORTIE	LINDE	\N	428	f	4022.00	JAWAD	203670	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6503	1	2025-05-23	3087302.00	169.00	SORTIE	VOLVO 22299A73	\N	480	f	583246.00	THAMI	203671	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6504	1	2025-05-23	3087327.00	25.00	SORTIE	KANGO 4812A73	\N	419	f	234108.00	TARMOUNIA	203672	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6505	1	2025-05-24	3087388.00	61.00	SORTIE	ISUZU 26128A8	\N	401	f	856790.00	TOUFIK	203673	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6506	1	2025-05-24	3087583.00	195.00	SORTIE	MIT 4969A73	\N	409	f	940420.00	CHOUAIB	203674	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6507	1	2025-05-24	3087683.00	100.00	SORTIE	MIT 11470A73	\N	436	f	51005.00	MOHAMED	203675	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6509	1	2025-05-24	3087783.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	238541.00	BOUJAIR	203677	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6510	1	2025-05-24	3087911.00	128.00	SORTIE	RENAULT 25636A13	\N	411	f	105986.00	YASSINE	203678	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6512	1	2025-05-24	3088262.00	37.00	SORTIE	BERLINGO 981A73	\N	417	f	296422.00	MAGHNIA	203680	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6514	1	2025-05-24	3088937.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	310949.00	HAMZA	203682	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6515	1	2025-05-24	3089138.00	201.00	SORTIE	VOLVO 22299A73	\N	480	f	584054.00	THAMI	203683	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6516	1	2025-05-24	3089155.00	17.00	SORTIE	LINDE	\N	428	f	4022.00	KAMAL	203684	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6517	1	2025-05-24	3089185.00	30.00	SORTIE	LINDE	\N	434	f	7236.00	MILOUD	203685	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6518	1	2025-05-24	3089212.00	27.00	SORTIE	LINDE	\N	472	f	11175.90	SKOURI	203686	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6519	1	2025-05-26	3089241.00	29.00	SORTIE	LINDE	\N	477	f	8559.00	CHAABI	203687	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6520	1	2025-05-26	3089386.00	145.00	SORTIE	MIT 11469A73	\N	435	f	917493.00	ABDELKHALEK	203688	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6522	1	2025-05-26	3090137.00	24.00	SORTIE	HYUNDAI 18516A73	\N	471	f	311110.00	HAMZA	203690	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6523	1	2025-05-26	3090279.00	142.00	SORTIE	MIT 11470A73	\N	436	f	51507.00	MOHAMED	203691	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6525	1	2025-05-26	3090572.00	164.00	SORTIE	RENAULT 25636A13	\N	411	f	106597.00	YASSINE	203693	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6526	1	2025-05-26	3091203.00	631.00	SORTIE	VOLVO 17886A73	\N	439	f	675862.00	ABDELKARIM	203694	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6527	1	2025-05-26	3091386.00	183.00	SORTIE	VOLVO 22300A73	\N	481	f	674262.00	MUSTAPHA	203695	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6528	1	2025-05-26	3091612.00	226.00	SORTIE	VOLVO 17886A73	\N	439	f	642724.00	ABDELMAJID	203696	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6529	1	2025-05-26	3091641.00	29.00	SORTIE	LINDE	\N	472	f	11138.00	ABDELAZIZ	203697	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6530	1	2025-05-26	3091694.00	53.00	SORTIE	FENWICK	\N	430	f	27463.00	ABDELKHALEK	203698	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6532	1	2025-05-26	3091753.00	21.00	SORTIE	LINDE	\N	428	f	4023.00	MOHAMED	203700	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6533	1	2025-05-26	3091795.00	42.00	SORTIE	VOLVO 22300A73	\N	481	f	674317.00	MUSTAPHA	203701	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6534	1	2025-05-26	3092188.00	393.00	SORTIE	MAN 28659D1	\N	410	f	33184.00	CHOUAIB	203702	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6535	1	2025-05-27	3092254.00	66.00	SORTIE	ISUZU 26128A8	\N	401	f	867111.00	TOUFIK	203703	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6536	1	2025-05-27	3092299.00	45.00	SORTIE	HYUNDAI 22368A73	\N	482	f	207020.00	IDRISS	203704	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6537	1	2025-05-27	3092505.00	206.00	SORTIE	VOLVO 22299A73	\N	480	f	584768.00	THAMI	203705	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6538	1	2025-05-27	3092650.00	145.00	SORTIE	MIT 11469A73	\N	435	f	918068.00	ABDELKHALEK	203706	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6539	1	2025-05-27	3092681.00	31.00	SORTIE	HYUNDAI 18516A73	\N	471	f	311301.00	HAMZA	203707	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6540	1	2025-05-27	3092815.00	134.00	SORTIE	RENAULT 25636A13	\N	411	f	107173.00	YASSINE	203708	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6541	1	2025-05-27	3092959.00	144.00	SORTIE	MIT 11470A73	\N	436	f	52004.00	MOHAMED	203709	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6542	1	2025-05-27	3093009.00	50.00	SORTIE	LINDE	\N	427	f	30107.80	HASSAN	203710	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6543	1	2025-05-27	3093027.00	18.00	SORTIE	LINDE	\N	428	f	4023.90	HASSAN	203711	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6544	1	2025-05-27	3093203.00	176.00	SORTIE	MAN 28659D1	\N	410	f	33733.00	CHOUAIB	203712	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6545	1	2025-05-27	3093342.00	139.00	SORTIE	MAN 4790B8	\N	403	f	963584.00	KARDODI	203713	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6547	1	2025-05-27	3093437.00	47.00	SORTIE	HYUNDAI 22772A73	\N	479	f	238850.00	HAMID	203715	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6549	1	2025-05-28	3093649.00	172.00	SORTIE	MIT 11470A73	\N	436	f	52632.00	MOHAMED	203717	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6551	1	2025-05-28	3093865.00	175.00	SORTIE	CHARGEUSE G 938	\N	413	f	7361.30	ABDERRAHIM	203719	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6552	1	2025-05-28	3093983.00	118.00	SORTIE	MIT 11469A73	\N	435	f	918546.00	ABDELKHALEK	203720	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6553	1	2025-05-28	3094013.00	30.00	SORTIE	HYUNDAI 18516A73	\N	471	f	311475.00	HAMZA	203721	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6554	1	2025-05-28	3094177.00	165.00	SORTIE	RENAULT 25636A13	\N	411	f	107829.00	YASSINE	203722	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6557	1	2025-05-28	3094665.00	28.00	SORTIE	LINDE	\N	434	f	7249.30	MILOUD	203725	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6558	1	2025-05-28	3094740.00	75.00	SORTIE	MANITOU	\N	431	f	8674.00	JAWAD	203726	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6559	1	2025-05-28	3094789.00	49.00	SORTIE	LINDE	\N	472	f	11207.50	AZIZ	203727	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6560	1	2025-05-28	3094823.00	34.00	SORTIE	MIT 11469A73	\N	435	f	918661.00	ABDELKHALEK	203728	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6561	1	2025-05-28	3094976.00	153.00	SORTIE	MIT 4969A73	\N	409	f	940825.00	CHOUAIB	203729	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6562	1	2025-05-28	3094992.00	16.00	SORTIE	LINDE	\N	428	f	4024.80	HASSAN	203730	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6563	1	2025-05-28	3095098.00	106.00	SORTIE	VOLVO 22299A73	\N	480	f	585080.00	THAMI	203731	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6564	1	2025-05-28	3095550.00	452.00	SORTIE	VOLVO 17885A73	\N	438	f	677195.00	ABDELKARIM	203732	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6565	1	2025-05-28	3095585.00	35.00	SORTIE	MIT 11470A73	\N	436	f	52751.00	MOHAMED	203733	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6566	1	2025-05-29	3095708.00	123.00	SORTIE	VOLVO 70352A2	\N	406	f	506322.00	MOHAMED	203734	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6567	1	2025-05-29	3095766.00	58.00	SORTIE	ISUZU 26128A8	\N	401	f	867437.00	TOUFIK	203735	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6568	1	2025-05-29	3095899.00	133.00	SORTIE	VOLVO 22300A73	\N	481	f	674824.00	MUSTAPHA	203736	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6571	1	2025-05-29	3096418.00	163.00	SORTIE	RENAULT 25636A13	\N	411	f	108477.00	YASSINE	203739	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6574	1	2025-05-29	3097492.00	491.00	SORTIE	VOLVO 17886A73	\N	439	f	644511.00	ABDELMAJID	203742	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6575	1	2025-05-29	3097529.00	37.00	SORTIE	HYUNDAI 18516A73	\N	471	f	311683.00	HAMZA	203743	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6576	1	2025-05-29	3097561.00	32.00	SORTIE	VOLVO 22300A73	\N	481	f	674896.00	MUSTAPHA	203744	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6579	1	2025-05-29	3098180.00	50.00	SORTIE	LINDE	\N	477	f	8576.90	CHAABI	203747	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6580	1	2025-05-29	3098215.00	35.00	SORTIE	FENWICK	\N	430	f	27475.30	SAID	203748	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6581	1	2025-05-29	3098257.00	43.00	SORTIE	HYUNDAI 22772A73	\N	479	f	239174.00	HAMZA	203749	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6583	1	2025-05-30	3098467.00	176.00	SORTIE	MIT 11470A73	\N	436	f	53352.00	MOHAMED	203751	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6584	1	2025-05-30	3098644.00	177.00	SORTIE	MIT 11469A73	\N	435	f	919327.00	ABDELKHALEK	203752	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6585	1	2025-05-30	3098688.00	43.00	SORTIE	HYUNDAI 22368A73	\N	482	f	207448.00	IDRISS	203753	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6586	1	2025-05-30	3098754.00	66.00	SORTIE	RENAULT 25636A13	\N	411	f	108745.00	YASSINE	203754	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6588	1	2025-05-30	3098932.00	28.00	SORTIE	HYUNDAI 18516A73	\N	471	f	311834.00	HAMZA	203756	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6589	1	2025-05-30	3099133.00	201.00	SORTIE	VOLVO 22299A73	\N	480	f	585790.00	THAMI	203757	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6590	1	2025-05-30	3099190.00	57.00	SORTIE	BERLINGO 10591A73	\N	433	f	358481.00	ABDESLAM	203758	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6591	1	2025-05-30	3099347.00	157.00	SORTIE	MIT 4703A73	\N	408	f	570307.00	MUSTAPHA	203759	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6592	1	2025-05-30	3099606.00	259.00	SORTIE	MAN 28659D1	\N	410	f	34630.00	CHOUAIB	203760	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6594	1	2025-05-30	3099652.00	33.00	SORTIE	LINDE	\N	472	f	11221.50	AZIZ	203762	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6595	1	2025-05-30	3099747.00	95.00	SORTIE	MAN 4790B8	\N	403	f	963984.00	KARDODI	203763	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6597	1	2025-05-30	3099835.00	40.00	SORTIE	MIT 11469A73	\N	435	f	919469.00	ABDELKHALEK	203765	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6598	1	2025-05-31	3099889.00	54.00	SORTIE	ISUZU 26128A8	\N	401	f	867736.00	TOUFIK	203766	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6599	1	2025-05-31	3099998.00	109.00	SORTIE	VOLVO 22299A73	\N	480	f	586179.00	THAMI	203767	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6600	1	2025-05-31	3100159.00	161.00	SORTIE	VOLVO 22300A73	\N	481	f	675500.00	MUSTAPHA	203768	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6601	1	2025-05-31	3100339.00	180.00	SORTIE	RENAULT 25636A13	\N	411	f	109461.00	YASSINE	203769	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6602	1	2025-05-31	3100400.00	61.00	SORTIE	MIT 11470A73	\N	436	f	53541.00	MOHAMED	203770	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6603	1	2025-05-31	3100493.00	93.00	SORTIE	MANITOU	\N	484	f	543.00	SAID	203771	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6604	1	2025-05-31	3100747.00	254.00	SORTIE	MAN 706A73	\N	407	f	130747.00	HOUSSAM	203772	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6605	1	2025-05-31	3100972.00	225.00	SORTIE	CHARGEUSE G 938	\N	413	f	7379.10	ABDERRAHIM	203773	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6606	1	2025-05-31	3101026.00	54.00	SORTIE	RENAULT 25636A13	\N	411	f	109676.00	YASSINE	203774	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6607	1	2025-05-31	3101062.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	312073.00	HAMZA	203775	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6608	1	2025-05-31	3101090.00	28.00	SORTIE	LINDE	\N	434	f	7262.20	MILOUD	203776	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6609	1	2025-05-31	3101117.00	27.00	SORTIE	LINDE	\N	472	f	11232.00	AZIZ	203777	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6610	1	2025-05-31	3101171.00	54.00	SORTIE	HYUNDAI 22772A73	\N	479	f	239585.00	HAMID	203778	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6612	1	2025-05-31	3101295.00	85.00	SORTIE	VOLVO 22300A73	\N	481	f	675757.00	MUSTAPHA	203780	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6613	1	2025-06-02	3101347.00	52.00	SORTIE	HYUNDAI 18516A73	\N	471	f	312374.00	HAMZA	203781	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6615	1	2025-06-02	3101606.00	94.00	SORTIE	MIT 11470A73	\N	436	f	53876.00	MOHAMED	203783	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6617	1	2025-06-02	3102336.00	413.00	SORTIE	VOLVO 17886A73	\N	439	f	645828.00	ABDELMAJID	203785	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6618	1	2025-06-02	3102502.00	166.00	SORTIE	VOLVO 22300A73	\N	481	f	676392.00	MUSTAPHA	203786	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6619	1	2025-06-02	3102546.00	44.00	SORTIE	LINDE	\N	472	f	11250.10	ABDELALI	203787	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6620	1	2025-06-02	3102730.00	184.00	SORTIE	VOLVO 22299A73	\N	480	f	586673.00	THAMI	203788	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6621	1	2025-06-02	3102837.00	107.00	SORTIE	MIT 11469A73	\N	435	f	919845.00	ABDELKHALEK	203789	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6624	1	2025-06-03	3103261.00	142.00	SORTIE	RENAULT 25636A13	\N	411	f	110258.00	YASSINE	203792	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6625	1	2025-06-03	3103311.00	50.00	SORTIE	HYUNDAI 18516A73	\N	471	f	312664.00	HAMZA	203793	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6626	1	2025-06-03	3103372.00	61.00	SORTIE	ISUZU 26128A8	\N	401	f	868057.00	TOUFIK	203794	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6627	1	2025-06-03	3103418.00	46.00	SORTIE	HYUNDAI 22368A73	\N	482	f	207911.00	IDRISS	203795	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6628	1	2025-06-03	3103570.00	152.00	SORTIE	MIT 4969A73	\N	409	f	941281.00	CHOUAIB	203796	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6629	1	2025-06-03	3103590.00	20.00	SORTIE	BERLINGO 981A73	\N	417	f	296719.00	MAGHNIA	203797	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6630	1	2025-06-03	3103841.00	251.00	SORTIE	MAN 28659D1	\N	410	f	35490.00	CHOUAIB	203798	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6631	1	2025-06-03	3104421.00	580.00	SORTIE	VOLVO 17885A73	\N	438	f	678774.00	ABDELKARIM	203799	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6632	1	2025-06-03	3104475.00	54.00	SORTIE	RENAULT 25636A13	\N	411	f	110421.00	YASSINE	203800	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6633	1	2025-06-03	3104507.00	32.00	SORTIE	FENWICK	\N	430	f	27486.00	SAID	203801	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6634	1	2025-06-03	3104541.00	34.00	SORTIE	LINDE	\N	477	f	8590.00	CHAABI	203802	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6635	1	2025-06-03	3104646.00	106.00	SORTIE	VOLVO 22300A73	\N	481	f	676777.00	MUSTAPHA	203803	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6637	1	2025-06-03	3104753.00	53.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203805	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6638	1	2025-06-04	3104919.00	166.00	SORTIE	MAN 28659D1	\N	410	f	35979.00	CHOUAIB	203806	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6639	1	2025-06-04	3105048.00	129.00	SORTIE	MIT 11469A73	\N	435	f	920355.00	ABDELKHALEK	203807	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6640	1	2025-06-04	3105283.00	234.00	SORTIE	VOLVO 22299A73	\N	480	f	587731.00	THAMI	203808	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6641	1	2025-06-04	3105405.00	122.00	SORTIE	MIT 11470A73	\N	436	f	54285.00	MUSTAPHA	203809	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6642	1	2025-06-04	3105565.00	160.00	SORTIE	CHARGEUSE G 938	\N	413	f	7391.30	ABDERRAHIM	203810	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6643	1	2025-06-04	3105619.00	54.00	SORTIE	HYUNDAI 22772A73	\N	479	f	239933.00	BOUJAIR	203811	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6645	1	2025-06-04	3105844.00	58.00	SORTIE	HYUNDAI 18516A73	\N	471	f	312992.00	BOUJAIR	203813	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6648	1	2025-06-04	3106835.00	370.00	SORTIE	VOLVO 17886A73	\N	439	f	647008.00	ABDELMAJID	203816	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6650	1	2025-06-04	3107197.00	45.00	SORTIE	LINDE	\N	472	f	11269.30	ABDELLAH	203818	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6651	1	2025-06-04	3107217.00	19.00	SORTIE	LINDE	\N	434	f	7270.00	MILOUD	203819	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6655	1	2025-06-04	3107443.00	127.00	SORTIE	VOLVO 22300A73	\N	481	f	677237.00	MUSTAPHA	203823	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6656	1	2025-06-05	3107557.00	114.00	SORTIE	MAN 4790B8	\N	403	f	964445.00	KARDODI	203824	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6657	1	2025-06-05	3107622.00	65.00	SORTIE	ISUZU 26128A8	\N	401	f	868386.00	TOUFIK	203825	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6658	1	2025-06-05	3107749.00	127.00	SORTIE	VOLVO 22299A73	\N	480	f	588211.00	THAMI	203826	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6660	1	2025-06-05	3107880.00	46.00	SORTIE	HYUNDAI 18516A73	\N	417	f	313252.00	BOUJAIR	203828	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6661	1	2025-06-05	3107938.00	58.00	SORTIE	BERLINGO 10591A73	\N	433	f	359502.00	ABDESLAM	203829	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6662	1	2025-06-05	3107968.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	208288.00	IDRISS	203830	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6665	1	2025-06-12	3108073.00	29.00	SORTIE	BERLINGO 981A73	\N	417	f	297117.00	MAGHNIA	203833	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6668	1	2025-06-12	3108918.00	51.00	SORTIE	HYUNDAI 18516A73	\N	471	f	313603.00	HAMZA	203836	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6669	1	2025-06-12	3108962.00	44.00	SORTIE	LINDE	\N	472	f	11290.40	SKOURI	203837	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6670	1	2025-06-12	3109008.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	240199.00	HAMZA	203838	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6671	1	2025-06-13	3109036.00	28.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203839	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6672	1	2025-06-14	3109200.00	164.00	SORTIE	VOLVO 22300A73	\N	481	f	677907.00	MUSTAPHA	203840	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6673	1	2025-06-14	3109247.00	47.00	SORTIE	HYUNDAI 22368A73	\N	482	f	208767.00	IDRISS	203841	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6674	1	2025-06-14	3109272.00	25.00	SORTIE	FENWICK	\N	429	f	\N	HAKIM	203842	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6676	1	2025-06-14	3109348.00	51.00	SORTIE	HYUNDAI 18516A73	\N	471	f	313940.00	HAMZA	203844	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6677	1	2025-06-16	3109393.00	45.00	SORTIE	MIT 11470A73	\N	436	f	54383.00	MOHAMED	203845	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6678	1	2025-06-16	3109543.00	150.00	SORTIE	VOLVO 22299A73	\N	480	f	588651.00	THAMI	203846	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6680	1	2025-06-16	3109770.00	166.00	SORTIE	CHARGEUSE G 938	\N	413	f	7405.70	ABDERRAHIM	203848	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6681	1	2025-06-16	3109795.00	25.00	SORTIE	VOLVO 22300A73	\N	481	f	677966.00	MUSTAPHA	203849	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6682	1	2025-06-16	3109862.00	67.00	SORTIE	MIT 4969A73	\N	409	f	941489.00	CHOUAIB	203850	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6683	1	2025-06-16	3109922.00	60.00	SORTIE	HYUNDAI 22772A73	\N	479	f	240647.00	NOURDINE	203851	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6684	1	2025-06-16	3109983.00	61.00	SORTIE	HYUNDAI 18516A73	\N	471	f	314359.00	NOURDINE	203852	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6685	1	2025-06-16	3110037.00	54.00	SORTIE	LINDE	\N	472	f	113134.00	SKOURI	203853	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6686	1	2025-06-16	3110075.00	38.00	SORTIE	KANGO 4812A73	\N	419	f	234847.00	TARMOUNIA	203854	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6689	1	2025-06-16	3110172.00	20.00	SORTIE	FENWICK	\N	430	f	27493.00	ABDELKHALEK	203857	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6690	1	2025-06-17	3110264.00	92.00	SORTIE	MANITOU	\N	484	f	5090.00	SAID	203858	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6691	1	2025-06-17	3110444.00	180.00	SORTIE	MIT 11470A73	\N	436	f	55014.00	MOHAMED	203859	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6692	1	2025-06-17	3110590.00	146.00	SORTIE	RENAULT 25636A13	\N	411	f	110997.00	YASSINE	203860	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6693	1	2025-06-17	3110612.00	22.00	SORTIE	LINDE	\N	434	f	7283.00	MILOUD	203861	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6695	1	2025-06-17	3110714.00	54.00	SORTIE	HYUNDAI 18516A73	\N	471	f	314677.00	NOURDINE	203863	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6696	1	2025-06-17	3110870.00	156.00	SORTIE	VOLVO 22300A73	\N	481	f	678283.00	MUSTAPHA	203864	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6697	1	2025-06-18	3110980.00	110.00	SORTIE	MAN 4790B8	\N	403	f	964851.00	KARDODI	203865	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6698	1	2025-06-18	3111084.00	104.00	SORTIE	RENAULT 25636A13	\N	411	f	111360.00	YASSINE	203866	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6699	1	2025-06-18	3111125.00	41.00	SORTIE	BERLINGO 981A73	\N	417	f	297739.00	MAGHNIA	203867	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6700	1	2025-06-18	3111252.00	127.00	SORTIE	MIT 11470A73	\N	436	f	55487.00	MOHAMED	203868	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6701	1	2025-06-18	3111746.00	494.00	SORTIE	VOLVO 17886A73	\N	439	f	648761.00	ABDELMAJID	203869	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6704	1	2025-06-18	3112435.00	47.00	SORTIE	LINDE	\N	472	f	11334.40	SEKOURI	203872	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6705	1	2025-06-18	3112496.00	61.00	SORTIE	BERLINGO 10591A73	\N	433	f	361494.00	ABDESLAM	203873	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6706	1	2025-06-18	3112522.00	26.00	SORTIE	HYUNDAI 18516A73	\N	471	f	314826.00	NOURDINE	203874	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6707	1	2025-06-18	3113107.00	585.00	SORTIE	VOLVO 17885A73	\N	438	f	680416.00	ABDELKARIM	203875	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6708	1	2025-06-19	3113275.00	168.00	SORTIE	VOLVO 22300A73	\N	481	f	678959.00	MUSTAPHA	203876	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6709	1	2025-06-19	3113442.00	167.00	SORTIE	RENAULT 25636A13	\N	411	f	112055.00	YASSINE	203877	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6710	1	2025-06-19	3113564.00	122.00	SORTIE	MIT 11470A73	\N	436	f	55953.00	MOHAMED	203878	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6711	1	2025-06-19	3113756.00	192.00	SORTIE	VOLVO 22299A73	\N	480	f	589312.00	THAMI	203879	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6712	1	2025-06-19	3113804.00	48.00	SORTIE	HYUNDAI 22368A73	\N	482	f	209273.00	IDRISS	203880	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6714	1	2025-06-19	3114016.00	176.00	SORTIE	CHARGEUSE G 938	\N	413	f	7421.20	ABDERRAHIM	203882	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6717	1	2025-06-19	3114152.00	48.00	SORTIE	VOLVO 22299A73	\N	480	f	589466.00	THAMI	203885	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6718	1	2025-06-19	3114258.00	106.00	SORTIE	VOLVO 22300A73	\N	481	f	679349.00	MUSTAPHA	203886	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6719	1	2025-06-19	3114308.00	50.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	203887	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6720	1	2025-06-20	3114457.00	149.00	SORTIE	RENAULT 25636A13	\N	411	f	112595.00	YASSINE	203888	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6721	1	2025-06-20	3114500.00	43.00	SORTIE	HYUNDAI 18516A73	\N	471	f	318005.00	BOUJAIR	203889	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6722	1	2025-06-20	3114646.00	146.00	SORTIE	MIT 11470A73	\N	436	f	56508.00	MOHAMED	203890	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6723	1	2025-06-20	3114850.00	204.00	SORTIE	MAN 706A73	\N	407	f	131215.00	HOUSSAM	203891	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6725	1	2025-06-20	3115285.00	181.00	SORTIE	MIT 4703A73	\N	408	f	571272.00	MUSTAPHA	203893	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6726	1	2025-06-20	3115416.00	131.00	SORTIE	VOLVO 22299A73	\N	480	f	589953.00	THAMI	203894	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6727	1	2025-06-21	3115476.00	59.00	SORTIE	ISUZU 26128A8	\N	401	f	868665.00	TOUFIK	203895	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6728	1	2025-06-21	3115657.00	181.00	SORTIE	MIT 4969A73	\N	409	f	942059.00	CHOUAIB	203896	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6729	1	2025-06-21	3115745.00	88.00	SORTIE	MIT 11470A73	\N	436	f	56819.00	MOHAMED	203897	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6730	1	2025-06-21	3115925.00	180.00	SORTIE	RENAULT 25636A13	\N	411	f	113262.00	YASSINE	203898	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6731	1	2025-06-21	3116029.00	104.00	SORTIE	VOLVO 70352A2	\N	406	f	506578.00	KARMY	203899	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6732	1	2025-06-21	3116277.00	248.00	SORTIE	VOLVO 17886A73	\N	439	f	649531.00	ABDELMAJID	203900	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6736	1	2025-06-21	3116523.00	49.00	SORTIE	LINDE	\N	430	f	2751.00	SAID	203904	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6737	1	2025-06-21	3116561.00	38.00	SORTIE	LINDE	\N	477	f	8604.00	CHAABI	203905	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6738	1	2025-06-21	3116602.00	40.00	SORTIE	LINDE	\N	434	f	73027.00	SKOURI	203906	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6739	1	2025-06-23	3116740.00	138.00	SORTIE	RENAULT 25636A13	\N	411	f	113837.00	YASSINE	203907	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6740	1	2025-06-23	3116892.00	152.00	SORTIE	MIT 11470A73	\N	436	f	57322.00	MOHAMED	203908	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6741	1	2025-06-23	3117022.00	130.00	SORTIE	MAN 4790B8	\N	403	f	965398.00	KARDODI	203909	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6742	1	2025-06-23	3117182.00	160.00	SORTIE	MAN 28659D1	\N	410	f	36400.00	CHOUAIB	203910	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6743	1	2025-06-23	3117362.00	180.00	SORTIE	VOLVO 22300A73	\N	481	f	680003.00	MUSTAPHA	203911	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6744	1	2025-06-23	3117382.00	20.00	SORTIE	LINDE	\N	434	f	7312.00	AZIZ	203912	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6745	1	2025-06-23	3117573.00	191.00	SORTIE	CHARGEUSE G 938	\N	413	f	7437.40	ABDERRAHIM	203913	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6747	1	2025-06-23	3117616.00	22.00	SORTIE	MIT 11470A73	\N	436	f	57384.00	MOHAMED	203915	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6748	1	2025-06-24	3117683.00	67.00	SORTIE	ISUZU 26128A8	\N	401	f	869042.00	TOUFIK	203916	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6749	1	2025-06-24	3118417.00	734.00	SORTIE	VOLVO 17885A73	\N	438	f	682317.00	ABDELKARIM	203917	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6750	1	2025-06-24	3118592.00	175.00	SORTIE	VOLVO 22300A73	\N	481	f	680653.00	MUSTAPHA	203918	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6751	1	2025-06-24	3118670.00	78.00	SORTIE	MANITOU	\N	484	f	5126.00	SAID	203919	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6752	1	2025-06-24	3118714.00	44.00	SORTIE	HYUNDAI 22368A73	\N	482	f	209822.00	IDRISS	203920	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6753	1	2025-06-24	3118761.00	47.00	SORTIE	HYUNDAI	\N	479	f	240930.00	NOURDINE	203921	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6755	1	2025-06-24	3119801.00	230.00	SORTIE	VOLVO 22299A73	\N	480	f	590696.00	THAMI	203923	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6756	1	2025-06-24	3120017.00	216.00	SORTIE	RENAULT 25636A13	\N	411	f	114609.00	YASSINE	203924	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6758	1	2025-06-24	3120100.00	28.00	SORTIE	LINDE	\N	428	f	4026.00	HASSAN	203926	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6759	1	2025-06-24	3120440.00	340.00	SORTIE	VOLVO 17886A73	\N	439	f	650534.00	ABDELMAJID	203927	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6760	1	2025-06-24	3120464.00	24.00	SORTIE	VOLVO 22300A73	\N	481	f	680738.00	MUSTAPHA	203928	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6762	1	2025-06-25	3120815.00	192.00	SORTIE	VOLVO 22299A73	\N	480	f	591411.00	THAMI	203930	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6763	1	2025-06-25	3121018.00	203.00	SORTIE	RENAULT 25636A13	\N	411	f	115374.00	YASSINE	203931	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6765	1	2025-06-25	3121114.00	41.00	SORTIE	LINDE	\N	427	f	30130.00	SAID	203933	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6767	1	2025-06-25	3121519.00	95.00	SORTIE	MIT 11470A73	\N	436	f	57700.00	MOHAMED	203935	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6770	1	2025-06-25	3122070.00	195.00	SORTIE	MAN 28659D1	\N	410	f	37013.00	CHOUAIB	203938	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6771	1	2025-06-25	3122090.00	20.00	SORTIE	LINDE	\N	428	f	4027.50	HASSAN	203939	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6772	1	2025-06-25	3122121.00	31.00	SORTIE	FENWICK	\N	430	f	27523.00	ABDELKHALEK	203940	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6773	1	2025-06-25	3122156.00	35.00	SORTIE	LINDE	\N	434	f	7329.50	AZIZ	203941	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6774	1	2025-06-25	3122184.00	28.00	SORTIE	VOLVO 22299A73	\N	480	f	591497.00	THAMI	203942	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6775	1	2025-06-25	3122253.00	68.00	SORTIE	ISUZU 26128A8	\N	401	f	869414.00	TOUFIK	203943	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6776	1	2025-06-26	3122383.00	130.00	SORTIE	VOLVO 22300A73	\N	481	f	681228.00	MUSTAPHA	203944	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6778	1	2025-06-26	3122588.00	171.00	SORTIE	CHARGEUSE G 938	\N	413	f	7450.70	ABDERRAHIM	203946	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6779	1	2025-06-26	3122648.00	61.00	SORTIE	BERLINGO 10591A73	\N	433	f	362505.00	ABDESLAM	203947	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6780	1	2025-06-26	3122759.00	111.00	SORTIE	RENAULT 25636A13	\N	411	f	115793.00	YASSINE	203948	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6782	1	2025-06-26	3123932.00	173.00	SORTIE	MIT 11470A73	\N	436	f	58316.00	MOHAMED	203950	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6783	1	2025-06-26	3123952.00	20.00	SORTIE	FENWICK	\N	429	f	\N	MILOUD	203951	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6785	1	2025-06-26	3124247.00	36.00	SORTIE	LINDE	\N	477	f	8618.50	CHAABI	203953	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6786	1	2025-06-26	3124289.00	42.00	SORTIE	VOLVO 22300A73	\N	481	f	681333.00	MUSTAPHA	203954	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6787	1	2025-06-27	3124412.00	123.00	SORTIE	MIT 11470A73	\N	436	f	58771.00	MOHAMED	203955	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6788	1	2025-06-27	3124447.00	35.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	203956	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6789	1	2025-06-27	3124658.00	211.00	SORTIE	VOLVO 22299A73	\N	480	f	592212.00	THAMI	203957	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6791	1	2025-06-27	3125404.00	246.00	SORTIE	MAN 706A73	\N	407	f	131827.00	HOUSSAM	203959	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6792	1	2025-06-27	3125442.00	38.00	SORTIE	LINDE	\N	434	f	7347.90	AZIZ	203960	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6793	1	2025-06-27	3125467.00	25.00	SORTIE	LINDE	\N	428	f	4028.00	HASSAN	203961	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6794	1	2025-06-27	3125700.00	233.00	SORTIE	RENAULT 25636A13	\N	411	f	116726.00	YASSINE	203962	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6795	1	2025-06-27	3125882.00	182.00	SORTIE	VOLVO 22300A73	\N	481	f	682063.00	MUSTAPHA	203963	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6796	1	2025-06-28	3125942.00	60.00	SORTIE	ISUZU 26128A8	\N	401	f	869742.00	TOUFIK	203964	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6797	1	2025-06-28	3126077.00	135.00	SORTIE	MIT 11470A73	\N	436	f	59295.00	MOHAMED	203965	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6798	1	2025-06-28	3126193.00	116.00	SORTIE	MAN 4790B8	\N	403	f	965845.00	KARDODI	203966	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6799	1	2025-06-28	3126364.00	171.00	SORTIE	MIT 4703A73	\N	408	f	572115.00	MUSTAPHA	203967	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6800	1	2025-06-28	3126414.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	241227.00	NOURDINE	203968	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6801	1	2025-06-28	3126464.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	210344.00	IDRISS	203969	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6802	1	2025-06-28	3126591.00	127.00	SORTIE	VOLVO 70352A2	\N	406	f	506952.00	MOHAMED	203970	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6803	1	2025-06-28	3126735.00	144.00	SORTIE	VOLVO 22299A73	\N	480	f	592749.00	THAMI	203971	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6805	1	2025-06-28	3126886.00	21.00	SORTIE	FENWICK	\N	429	f	\N	MILOUD	203973	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6806	1	2025-06-28	3127315.00	429.00	SORTIE	MAN 28659D1	\N	410	f	37537.00	CHOUAIB	203974	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6807	1	2025-06-28	3127387.00	72.00	SORTIE	MIT 11470A73	\N	436	f	59555.00	MOHAMED	203975	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6808	1	2025-06-30	3127556.00	169.00	SORTIE	RENAULT 25636A13	\N	411	f	117395.00	YASSINE	203976	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6810	1	2025-06-30	3127892.00	136.00	SORTIE	VOLVO 22300A73	\N	481	f	682594.00	MUSTAPHA	203978	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6811	1	2025-06-30	3127910.00	18.00	SORTIE	LINDE	\N	434	f	7357.00	MILOUD	203979	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6812	1	2025-06-30	3127968.00	58.00	SORTIE	ISUZU 26128A8	\N	401	f	870060.00	TOUFIK	203980	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6813	1	2025-06-30	3128001.00	33.00	SORTIE	KANGO 4812A73	\N	419	f	235329.00	TARMOUNIA	203981	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6814	1	2025-06-30	3128031.00	30.00	SORTIE	LINDE	\N	472	f	11347.70	ABDELAZIZ	203982	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6815	1	2025-06-30	3128202.00	171.00	SORTIE	CHARGEUSE G 938	\N	413	f	7464.80	ABDERRAHIM	203983	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6817	1	2025-06-30	3128250.00	31.00	SORTIE	FENWICK	\N	430	f	27534.00	ABDELKHALEK	203985	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6818	1	2025-06-30	3128263.00	13.00	SORTIE	LINDE	\N	428	f	4029.00	HASSAN	203986	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6820	1	2025-06-30	3128501.00	184.00	SORTIE	VOLVO 22299A73	\N	480	f	593442.00	THAMI	203988	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6821	1	2025-06-30	3128527.00	26.00	SORTIE	HYUNDAI 18516A73	\N	471	f	315235.00	ABDERRAZAK	203989	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6822	1	2025-07-01	3128687.00	160.00	SORTIE	VOLVO 22300A73	\N	481	f	683216.00	MUSTAPHA	203990	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6823	1	2025-07-01	3128868.00	181.00	SORTIE	MIT 11470A73	\N	436	f	60218.00	MOHAMED	203991	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6824	1	2025-07-01	3129038.00	170.00	SORTIE	RENAULT 25636A13	\N	411	f	118059.00	YASSINE	203992	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6825	1	2025-07-01	3129125.00	88.00	SORTIE	MANITOU	\N	484	f	5169.00	SAID	203993	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6826	1	2025-07-01	3129384.00	259.00	SORTIE	MAN 28659D1	\N	410	f	39116.00	CHOUAIB	203994	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6828	1	2025-07-01	3129431.00	17.00	SORTIE	LINDE	\N	428	f	4029.50	HASSAN	203996	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6829	1	2025-07-01	3129467.00	36.00	SORTIE	HYUNDAI 22772A73	\N	479	f	241467.00	ABDERRAZAK	203997	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6830	1	2025-07-01	3129494.00	27.00	SORTIE	LINDE	\N	477	f	8629.80	CHAABI	203998	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6831	1	2025-07-01	3129621.00	127.00	SORTIE	VOLVO 22299A73	\N	480	f	593889.00	THAMI	203999	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6832	1	2025-07-01	3129645.00	24.00	SORTIE	MIT 11470A73	\N	436	f	60308.00	MOHAMED	204000	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6834	1	2025-07-02	3129810.00	124.00	SORTIE	VOLVO 22300A73	\N	481	f	683633.00	MUSTAPHA	204002	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6835	1	2025-07-02	3129894.00	84.00	SORTIE	MAN 4790B8	\N	403	f	966168.00	KARDODI	204003	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6836	1	2025-07-02	3129906.00	13.00	SORTIE	LINDE	\N	428	f	40302.00	HASSAN	204004	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6837	1	2025-07-02	3129932.00	26.00	SORTIE	HYUNDAI 18516A73	\N	471	f	315369.00	ABDERRAZAK	204005	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6838	1	2025-07-02	3129978.00	46.00	SORTIE	HYUNDAI 22368A73	\N	482	f	210977.00	IDRISS	204006	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6840	1	2025-07-03	3130881.00	200.00	SORTIE	MIT 11470A73	\N	436	f	61035.00	MOHAMED	204008	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6841	1	2025-07-03	3131193.00	312.00	SORTIE	MAN 28659D1	\N	410	f	40088.00	CHOUAIB	204009	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6843	1	2025-07-03	3132050.00	140.00	SORTIE	VOLVO 22300A73	\N	481	f	684189.00	MUSTAPHA	204011	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6844	1	2025-07-03	3132082.00	32.00	SORTIE	BERLINGO 981A73	\N	417	f	298190.00	MAGHNIA	204012	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6845	1	2025-07-03	3132137.00	55.00	SORTIE	BERLINGO 10591A73	\N	433	f	363487.00	ABDESLAM	204013	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6848	1	2025-07-03	3132729.00	121.00	SORTIE	MIT 4969A73	\N	409	f	942396.00	CHOUAIB	204016	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6849	1	2025-07-03	3132925.00	197.00	SORTIE	VOLVO 22299A73	\N	480	f	594581.00	THAMI	204017	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6851	1	2025-07-03	3133042.00	71.00	SORTIE	ISUZU 26128A8	\N	401	f	870424.00	TOUFIK	204019	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6852	1	2025-07-03	3133444.00	402.00	SORTIE	VOLVO 17886A73	\N	439	f	651769.00	MJID	204020	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6853	1	2025-07-03	3133461.00	17.00	SORTIE	LINDE	\N	428	f	4031.20	HASSAN	204021	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6854	1	2025-07-03	3133498.00	37.00	SORTIE	LINDE	\N	434	f	7375.40	AZIZ	204022	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6856	1	2025-07-03	3133599.00	41.00	SORTIE	FENWICK	\N	430	f	27550.00	SAID	204024	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6857	1	2025-07-04	3133658.00	59.00	SORTIE	HYUNDAI 22772A73	\N	479	f	241878.00	ABDERAZZAK	204025	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6858	1	2025-07-04	3133887.00	229.00	SORTIE	MAN 28659D1	\N	410	f	40849.00	CHOUAIB	204026	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6859	1	2025-07-04	3134065.00	178.00	SORTIE	CHARGEUSE G 938	\N	413	f	7478.80	ABDERRAHIM	204027	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6860	1	2025-07-04	3134238.00	173.00	SORTIE	MIT 11470A73	\N	436	f	61644.00	MOHAMED	204028	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6861	1	2025-07-04	3134351.00	113.00	SORTIE	VOLVO 22300A73	\N	481	f	684643.00	MUSTAPHA	204029	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6862	1	2025-07-04	3134410.00	59.00	SORTIE	MIT 4969A73	\N	409	f	942589.00	CHOUAIB	204030	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6863	1	2025-07-04	3134623.00	213.00	SORTIE	VOLVO 22299A73	\N	480	f	595355.00	THAMI	204031	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6866	1	2025-07-04	3135201.00	16.00	SORTIE	LINDE	\N	428	f	4032.00	HASSAN	204034	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6867	1	2025-07-05	3135285.00	84.00	SORTIE	MIT 4969A73	\N	409	f	942914.00	CHOUAIB	204035	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6869	1	2025-07-05	3135522.00	204.00	SORTIE	MAN 706A73	\N	407	f	132296.00	HOUSSAM	204037	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6870	1	2025-07-05	3135660.00	138.00	SORTIE	VOLVO 22300A73	\N	481	f	685186.00	MUSTAPHA	204038	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6871	1	2025-07-05	3135831.00	171.00	SORTIE	MIT 11470A73	\N	436	f	62224.00	MOHAMED	204039	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6875	1	2025-07-05	3136345.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	211479.00	IDRISS	204043	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6876	1	2025-07-05	3136382.00	37.00	SORTIE	LINDE	\N	434	f	7391.90	MILOUD	204044	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6877	1	2025-07-05	3136442.00	60.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	204045	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6878	1	2025-07-05	3136486.00	44.00	SORTIE	LINDE	\N	472	f	11365.30	AZIZ	204046	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6879	1	2025-07-05	3136499.00	13.00	SORTIE	LINDE	\N	428	f	4032.60	HASSAN	204047	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6880	1	2025-07-05	3136538.00	39.00	SORTIE	LINDE	\N	477	f	8645.20	CHAABI	204048	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6881	1	2025-07-07	3136691.00	153.00	SORTIE	VOLVO 22299A73	\N	480	f	595866.00	THAMI	204049	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6882	1	2025-07-07	3136744.00	53.00	SORTIE	ISUZU 26128A8	\N	401	f	870675.00	TOUFIK	204050	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6884	1	2025-07-07	3137538.00	307.00	SORTIE	MAN 28659D1	\N	410	f	41943.00	CHOUAIB	204052	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6885	1	2025-07-07	3137592.00	54.00	SORTIE	HYUNDAI 22772A73	\N	479	f	242245.00	NOURDINE	204053	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6886	1	2025-07-07	3137655.00	63.00	SORTIE	HYUNDAI 18516A73	\N	471	f	315732.00	NOURDINE	204054	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6887	1	2025-07-07	3137791.00	136.00	SORTIE	VOLVO 22300A73	\N	481	f	685708.00	MUSTAPHA	204055	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6888	1	2025-07-07	3137911.00	120.00	SORTIE	MAN 4790B8	\N	403	f	966600.00	KARDODI	204056	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6889	1	2025-07-07	3138026.00	115.00	SORTIE	MIT 11470A73	\N	436	f	62606.00	MOHAMED	204057	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6890	1	2025-07-07	3138499.00	473.00	SORTIE	VOLVO 17886A73	\N	439	f	653390.00	MJID	204058	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6891	1	2025-07-07	3138562.00	63.00	SORTIE	VOLVO 22299A73	\N	480	f	596103.00	THAMI	204059	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6892	1	2025-07-07	3138596.00	34.00	SORTIE	LINDE	\N	472	f	11378.50	SKOURI	204060	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6893	1	2025-07-07	3138756.00	160.00	SORTIE	MIT 4703A73	\N	408	f	572953.00	MUSTAPHA	204061	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6894	1	2025-07-07	3138865.00	109.00	SORTIE	MIT 4969A73	\N	409	f	943274.00	CHOUAIB	204062	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6897	1	2025-07-08	3139459.00	161.00	SORTIE	MAN 28659D1	\N	410	f	42434.00	CHOUAIB	204065	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6898	1	2025-07-08	3139664.00	205.00	SORTIE	CHARGEUSE G 938	\N	413	f	7495.50	ABDERRAHIM	204066	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6899	1	2025-07-08	3139803.00	139.00	SORTIE	MIT 11470A73	\N	436	f	63125.00	MOHAMED	204067	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6900	1	2025-07-08	3139828.00	25.00	SORTIE	HYUNDAI 18516A73	\N	471	f	315902.00	NOURDINE	204068	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6901	1	2025-07-08	3139988.00	160.00	SORTIE	VOLVO 22300A73	\N	481	f	686324.00	MUSTAPHA	204069	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6902	1	2025-07-08	3140064.00	76.00	SORTIE	VOLVO 22300A73	\N	481	f	686623.00	MUSTAPHA	204070	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6904	1	2025-07-08	3140313.00	87.00	SORTIE	MANITOU	\N	484	f	5213.00	SAID	204072	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6905	1	2025-07-08	3140346.00	33.00	SORTIE	LINDE	\N	428	f	4034.30	JAWAD	204073	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6906	1	2025-07-08	3140378.00	32.00	SORTIE	LINDE	\N	429	f	\N	SAID	204074	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6908	1	2025-07-08	3140530.00	101.00	SORTIE	VOLVO 22299A73	\N	480	f	596490.00	THAMI	204076	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6909	1	2025-07-09	3140579.00	49.00	SORTIE	ISUZU 26128A8	\N	401	f	870900.00	TOUFIK	204077	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6910	1	2025-07-09	3141120.00	541.00	SORTIE	VOLVO 17885A73	\N	438	f	683737.00	ABDELKARIM	204078	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6911	1	2025-07-09	3141236.00	116.00	SORTIE	MIT 11469A73	\N	435	f	920813.00	ABDELKHALEK	204079	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6912	1	2025-07-09	3141386.00	150.00	SORTIE	MIT 11470A73	\N	436	f	63638.00	MOHAMED	204080	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6913	1	2025-07-09	3141519.00	133.00	SORTIE	VOLVO 22299A73	\N	480	f	596949.00	THAMI	204081	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6914	1	2025-07-09	3141554.00	35.00	SORTIE	HYUNDAI 18516A73	\N	471	f	316135.00	NOURDINE	204082	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6915	1	2025-07-09	3141635.00	81.00	SORTIE	VOLVO 22300A73	\N	481	f	686939.00	MUSTAPHA	204083	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6916	1	2025-07-09	3141701.00	66.00	SORTIE	BERLINGO 10591A73	\N	433	f	364629.00	ABDESSLAM	204084	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6917	1	2025-07-09	3141721.00	20.00	SORTIE	LINDE	\N	428	f	4035.70	HASSAN	204085	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6918	1	2025-07-09	3141765.00	44.00	SORTIE	LINDE	\N	472	f	11396.80	ABDELLAH	204086	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6919	1	2025-07-09	3141791.00	26.00	SORTIE	LINDE	\N	434	f	7404.40	MILOUD	204087	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6921	1	2025-07-10	3142005.00	117.00	SORTIE	MAN 4790B8	\N	403	f	967078.00	KARDODI	204089	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6922	1	2025-07-10	3142453.00	448.00	SORTIE	VOLVO 17886A73	\N	439	f	654863.00	MJID	204090	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6923	1	2025-07-10	3142653.00	200.00	SORTIE	MAN 28659D1	\N	410	f	43150.00	CHOUAIB	204091	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6924	1	2025-07-10	3142699.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	242522.00	NOURDINE	204092	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6925	1	2025-07-10	3142726.00	27.00	SORTIE	HYUNDAI 18516A73	\N	471	f	316347.00	NOURDINE	204093	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6926	1	2025-07-10	3142766.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	212020.00	IDRISS	204094	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6928	1	2025-07-10	3142929.00	126.00	SORTIE	MIT 11469A73	\N	435	f	921283.00	ABDELKHALEK	204096	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6929	1	2025-07-10	3143097.00	168.00	SORTIE	MIT 11470A73	\N	436	f	64219.00	MOHAMED	204097	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6930	1	2025-07-10	3143109.00	12.00	SORTIE	LINDE	\N	428	f	4035.80	HASSAN	204098	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6931	1	2025-07-10	3143149.00	40.00	SORTIE	LINDE	\N	427	f	30152.80	HASSAN	204099	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6933	1	2025-07-10	3143598.00	148.00	SORTIE	VOLVO 22299A73	\N	480	f	597471.00	THAMI	204101	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6935	1	2025-07-10	3143670.00	41.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	204103	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6936	1	2025-07-10	3143711.00	41.00	SORTIE	LINDE	\N	477	f	8661.20	CHAABI	204104	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6938	1	2025-07-11	3143811.00	59.00	SORTIE	ISUZU 26128A8	\N	401	f	871210.00	TOUFIK	204106	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6939	1	2025-07-11	3143958.00	147.00	SORTIE	MIT 11469A73	\N	435	f	921878.00	ABDELKHALEK	204107	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6941	1	2025-07-11	3144146.00	155.00	SORTIE	MAN 28659D1	\N	410	f	43581.00	CHOUAIB	204109	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6942	1	2025-07-11	3144177.00	31.00	SORTIE	HYUNDAI 18516A73	\N	471	f	316576.00	NOURDINE	204110	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6944	1	2025-07-11	3144917.00	115.00	SORTIE	MIT 11470A73	\N	436	f	64644.00	MOHAMED	204112	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6946	1	2025-07-11	3145404.00	186.00	SORTIE	VOLVO 22299A73	\N	480	f	595177.00	THAMI	204114	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6947	1	2025-07-11	3145441.00	37.00	SORTIE	LINDE	\N	472	f	11413.00	ABDELLAH	204115	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6948	1	2025-07-11	3145463.00	22.00	SORTIE	FENWICK	\N	429	f	\N	ABDELKHALEK	204116	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6949	1	2025-07-11	3145506.00	43.00	SORTIE	KANGO 4812A73	\N	419	f	235924.00	TARMOUNIA	204117	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6951	1	2025-07-11	3146015.00	461.00	SORTIE	VOLVO 17885A73	\N	438	f	684927.00	ABDELKARIM	204119	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6952	1	2025-07-12	3146112.00	97.00	SORTIE	MIT 11469A73	\N	435	f	922244.00	ABDELKHALEK	204120	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6953	1	2025-07-12	3146357.00	245.00	SORTIE	MAN 706A73	\N	407	f	182880.00	HOUSSAM	204121	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6954	1	2025-07-12	3146543.00	186.00	SORTIE	MIT 4969A73	\N	409	f	943782.00	CHOUAIB	204122	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6956	1	2025-07-12	3146914.00	29.00	SORTIE	HYUNDAI 18516A73	\N	471	f	316779.00	NOURDINE	204124	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6957	1	2025-07-12	3146947.00	33.00	SORTIE	HYUNDAI 22772A73	\N	479	f	242712.00	NOURDINE	204125	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6958	1	2025-07-12	3147061.00	114.00	SORTIE	MIT 11470A73	\N	436	f	65059.00	MOHAMED	204126	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6960	1	2025-07-12	3147615.00	415.00	SORTIE	VOLVO 17886A73	\N	439	f	656318.00	MJID	204128	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6961	1	2025-07-12	3147800.00	185.00	SORTIE	VOLVO 22299A73	\N	480	f	598881.00	THAMI	204129	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6963	1	2025-07-12	3147862.00	33.00	SORTIE	LINDE	\N	472	f	11427.80	ABDELLAH	204131	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6964	1	2025-07-14	3147922.00	60.00	SORTIE	ISUZU 26128A8	\N	401	f	871515.00	TOUFIK	204132	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6965	1	2025-07-14	3148059.00	137.00	SORTIE	MAN 4790B8	\N	403	f	967610.00	KARDODI	204133	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6966	1	2025-07-14	3148374.00	315.00	SORTIE	MAN 28659D1	\N	410	f	44710.00	CHOUAIB	204134	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6967	1	2025-07-14	3148425.00	51.00	SORTIE	HYUNDAI 22368A73	\N	482	f	212511.00	IDRISS	204135	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6968	1	2025-07-14	3148440.00	15.00	SORTIE	MIT 11469A73	\N	435	f	922274.00	ABDELKHALEK	204136	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6969	1	2025-07-14	3148589.00	149.00	SORTIE	MIT 11470A73	\N	436	f	65580.00	MOHAMED	204137	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6970	1	2025-07-14	3148629.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	313079.00	ABDERRAZAK	204138	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6972	1	2025-07-14	3149410.00	131.00	SORTIE	VOLVO 22299A73	\N	480	f	599382.00	THAMI	204140	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6973	1	2025-07-14	3149449.00	39.00	SORTIE	LINDE	\N	434	f	7419.20	MILOUD	204141	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6974	1	2025-07-14	3149488.00	39.00	SORTIE	LINDE	\N	472	f	11442.90	ABDELLAH	204142	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6975	1	2025-07-14	3149693.00	205.00	SORTIE	VOLVO 17886A73	\N	439	f	657027.00	MJID	204143	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6976	1	2025-07-15	3149842.00	149.00	SORTIE	VOLVO 70352A2	\N	406	f	507332.00	MOHAMED	204144	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6977	1	2025-07-15	3150024.00	182.00	SORTIE	MAN 28659D1	\N	410	f	45306.00	CHOUAIB	204145	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6978	1	2025-07-15	3150062.00	38.00	SORTIE	BERLINGO 981A73	\N	417	f	298694.00	MAGHNIA	204146	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6979	1	2025-07-15	3150199.00	137.00	SORTIE	MIT 11469A73	\N	435	f	922830.00	ABDELKHALEK	204147	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6980	1	2025-07-15	3150304.00	105.00	SORTIE	MIT 11470A73	\N	436	f	65971.00	MOHAMED	204148	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6983	1	2025-07-15	3150881.00	103.00	SORTIE	RENAULT 25636A13	\N	411	f	118382.00	YASSINE	204151	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6984	1	2025-07-15	3150943.00	62.00	SORTIE	FENWICK	\N	430	f	27573.00	ABDELKHALEK	204152	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6985	1	2025-07-15	3150990.00	47.00	SORTIE	LINDE	\N	477	f	8679.80	CHAABI	204153	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6986	1	2025-07-15	3151515.00	525.00	SORTIE	VOLVO 17886A73	\N	439	f	686128.00	ABDELKARIM	204154	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6987	1	2025-07-15	3151667.00	152.00	SORTIE	MIT 4703A73	\N	408	f	573747.00	MUSTAPHA	204155	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6988	1	2025-07-16	3151717.00	50.00	SORTIE	ISUZU 26128A8	\N	401	f	871766.00	TOUFIK	204156	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6989	1	2025-07-16	3151877.00	160.00	SORTIE	MAN 28659D1	\N	410	f	45857.00	CHOUAIB	204157	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6991	1	2025-07-16	3152094.00	161.00	SORTIE	MIT 11469A73	\N	435	f	923464.00	ABDELKHALEK	204159	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6992	1	2025-07-16	3152244.00	150.00	SORTIE	MIT 11470A73	\N	436	f	66518.00	MOHAMED	204160	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6993	1	2025-07-16	3152294.00	50.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	204161	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6994	1	2025-07-16	3152446.00	152.00	SORTIE	CHARGEUSE G 938	\N	413	f	7508.30	ABDERRAHIM	204162	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6995	1	2025-07-16	3152485.00	39.00	SORTIE	HYUNDAI 18516A73	\N	471	f	317320.00	NOURDINE	204163	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6997	1	2025-07-17	3152640.00	116.00	SORTIE	MAN 4790B8	\N	403	f	968038.00	KARDODI	204165	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6998	1	2025-07-17	3152705.00	65.00	SORTIE	MIT 11469A73	\N	435	f	923717.00	ABDELKHALEK	204166	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
6999	1	2025-07-17	3152899.00	194.00	SORTIE	VOLVO 22300A73	\N	481	f	687670.00	MUSTAPHA	204167	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7000	1	2025-07-17	3152952.00	53.00	SORTIE	BERLINGO 10591A73	\N	433	f	365955.00	ABDESSLAM	204168	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7001	1	2025-07-17	3153118.00	166.00	SORTIE	VOLVO 22299A73	\N	480	f	599995.00	THAMI	204169	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7002	1	2025-07-17	3153287.00	169.00	SORTIE	MIT 11470A73	\N	436	f	67100.00	MOHAMED	204170	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7004	1	2025-07-17	3153787.00	180.00	SORTIE	MIT 4969A73	\N	409	f	944346.00	CHOUAIB	204172	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7008	1	2025-07-17	3154497.00	495.00	SORTIE	VOLVO 17885A73	\N	438	f	687399.00	ABDELKARIM	204176	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7011	1	2025-07-17	3154685.00	130.00	SORTIE	RENAULT 25636A13	\N	411	f	118911.00	YASSINE	204179	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7012	1	2025-07-17	3154735.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	213110.00	IDRISS	204180	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7013	1	2025-07-17	3154765.00	30.00	SORTIE	VOLVO 22300A73	\N	481	f	687739.00	MUSTAPHA	204181	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7014	1	2025-07-18	3155213.00	448.00	SORTIE	VOLVO 17886A73	\N	439	f	658558.00	MJID	204182	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7015	1	2025-07-18	3155280.00	67.00	SORTIE	ISUZU 26128A8	\N	401	f	872110.00	TOUFIK	204183	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7016	1	2025-07-18	3155374.00	94.00	SORTIE	MANITOU	\N	484	f	5257.00	SAID	204184	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7017	1	2025-07-18	3155543.00	169.00	SORTIE	MIT 11469A73	\N	435	f	924389.00	ABDELKHALEK	204185	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7020	1	2025-07-18	3157194.00	31.00	SORTIE	LINDE	\N	434	f	7433.10	MILOUD	204188	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7023	1	2025-07-18	3157897.00	49.00	SORTIE	LINDE	\N	472	f	11464.50	ABDELAH	204191	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7024	1	2025-07-18	3158255.00	358.00	SORTIE	MAN 28659D1	\N	410	f	47011.00	CHOUAIB	204192	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7025	1	2025-07-19	3158358.00	103.00	SORTIE	MIT 4969A73	\N	409	f	944739.00	CHOUAIB	204193	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7026	1	2025-07-19	3158518.00	160.00	SORTIE	VOLVO 22300A73	\N	481	f	688367.00	MUSTAPHA	204194	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7027	1	2025-07-19	3158650.00	132.00	SORTIE	CHARGEUSE G 938	\N	413	f	7519.60	ABDERRAHIM	204195	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7028	1	2025-07-19	3158847.00	197.00	SORTIE	VOLVO 22299A73	\N	480	f	600724.00	THAMI	204196	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7029	1	2025-07-19	3158868.00	22.00	SORTIE	LINDE	\N	427	f	30164.00	HASSAN	204197	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7031	1	2025-07-19	3159328.00	117.00	SORTIE	RENAULT 25636A13	\N	411	f	119330.00	YASSINE	204199	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7034	1	2025-07-19	3159629.00	137.00	SORTIE	MIT 11469A73	\N	435	f	924908.00	ABDELKHALEK	204202	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7036	1	2025-07-19	3159972.00	31.00	SORTIE	KANGO 4812A73	\N	419	f	236410.00	TARMOUNIA	204204	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7037	1	2025-07-19	3160010.00	38.00	SORTIE	HYUNDAI 18516A73	\N	471	f	317543.00	NOURDINE	204205	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7038	1	2025-07-19	3160045.00	34.00	SORTIE	HYUNDAI 22772A73	\N	479	f	242917.00	NOURDINE	204206	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7039	1	2025-07-19	3160069.00	25.00	SORTIE	LINDE	\N	472	f	11475.40	ABDELLAH	204207	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7040	1	2025-07-19	3160349.00	280.00	SORTIE	VOLVO 17886A73	\N	439	f	659589.00	MJID	204208	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7041	1	2025-07-19	3160392.00	42.00	SORTIE	FENWICK	\N	430	f	27589.00	SAID	204209	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7042	1	2025-07-19	3160434.00	42.00	SORTIE	LINDE	\N	477	f	8696.00	CHAABI	204210	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7043	1	2025-07-21	3160511.00	77.00	SORTIE	ISUZU 26128A8	\N	401	f	872522.00	TOUFIK	204211	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7044	1	2025-07-21	3160649.00	138.00	SORTIE	RENAULT 25636A13	\N	411	f	119866.00	YASSINE	204212	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7045	1	2025-07-21	3160774.00	125.00	SORTIE	MAN 4790B8	\N	403	f	968557.00	KARDODI	204213	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7046	1	2025-07-21	3160917.00	143.00	SORTIE	MIT 11469A73	\N	435	f	925484.00	ABDELKHALEK	204214	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7047	1	2025-07-21	3160988.00	71.00	SORTIE	VOLVO 22299A73	\N	480	f	600987.00	THAMI	204215	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7048	1	2025-07-21	3161264.00	276.00	SORTIE	MAN 28659D1	\N	410	f	47983.00	CHOUAIB	204216	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7050	1	2025-07-21	3161449.00	144.00	SORTIE	MIT 4703A73	\N	408	f	574406.00	MUSTAPHA	204218	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7051	1	2025-07-21	3161584.00	134.00	SORTIE	VOLVO 22300A73	\N	481	f	688842.00	MUSTAPHA	204219	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7052	1	2025-07-21	3161631.00	47.00	SORTIE	LINDE	\N	472	f	11494.00	AZIZ	204220	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7054	1	2025-07-21	3162243.00	570.00	SORTIE	VOLVO 17886A73	\N	439	f	688622.00	ABDELKARIM	204222	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7055	1	2025-07-22	3162343.00	100.00	SORTIE	VOLVO 70352A2	\N	406	f	507788.00	MOHAMED	204223	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7056	1	2025-07-22	3162447.00	104.00	SORTIE	MIT 11469A73	\N	435	f	925884.00	ABDELKHALEK	204224	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7057	1	2025-07-22	3162500.00	53.00	SORTIE	HYUNDAI 22368A73	\N	482	f	213721.00	IDRISS	204225	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7058	1	2025-07-22	3162658.00	158.00	SORTIE	RENAULT 25636A13	\N	411	f	120509.00	YASSINE	204226	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7060	1	2025-07-23	3163150.00	460.00	SORTIE	VOLVO 17886A73	\N	439	f	661209.00	MJID	204228	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7062	1	2025-07-23	3163420.00	236.00	SORTIE	VOLVO 22299A73	\N	480	f	601826.00	THAMI	204230	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7063	1	2025-07-23	3163607.00	187.00	SORTIE	CHARGEUSE G 938	\N	413	f	7536.50	ABDERRAHIM	204231	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7064	1	2025-07-23	3163713.00	106.00	SORTIE	RENAULT 25636A13	\N	411	f	120920.00	YASSINE	204232	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7066	1	2025-07-23	3164034.00	161.00	SORTIE	MIT 11469A73	\N	435	f	926520.00	ABDELKHALEK	204234	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7067	1	2025-07-23	3164191.00	157.00	SORTIE	MIT 11470A73	\N	436	f	67632.00	MOHAMED	204235	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7069	1	2025-07-23	3164523.00	37.00	SORTIE	LINDE	\N	434	f	7450.90	MILOUD	204237	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7070	1	2025-07-23	3164727.00	204.00	SORTIE	MIT 4969A73	\N	409	f	945449.00	CHOUAIB	204238	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7071	1	2025-07-23	3165072.00	345.00	SORTIE	MAN 28659D1	\N	410	f	49206.00	CHOUAIB	204239	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7072	1	2025-07-23	3165175.00	103.00	SORTIE	MAN 4790B8	\N	403	f	968925.00	KARDODI	204240	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7074	1	2025-07-23	3165245.00	36.00	SORTIE	LINDE	\N	472	f	11507.70	AZIZ	204242	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7075	1	2025-07-23	3165320.00	75.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	204243	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7076	1	2025-07-23	3165360.00	40.00	SORTIE	FENWICK	\N	430	f	27603.00	ABDELKHALEK	204244	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7077	1	2025-07-24	3165508.00	148.00	SORTIE	RENAULT 25636A13	\N	411	f	121532.00	YASSINE	204245	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7078	1	2025-07-24	3165584.00	76.00	SORTIE	ISUZU 26128A8	\N	401	f	872922.00	TOUFIK	204246	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7079	1	2025-07-24	3165629.00	45.00	SORTIE	MIT 11470A73	\N	436	f	67786.00	MOHAMED	204247	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7080	1	2025-07-24	3165734.00	105.00	SORTIE	MIT 11469A73	\N	435	f	926892.00	ABDELKHALEK	204248	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7081	1	2025-07-24	3165738.00	4.00	SORTIE	LINDE	\N	429	f	\N	ABDERRAHIM	204249	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7083	1	2025-07-24	3166109.00	63.00	SORTIE	BERLINGO 10591A73	\N	433	f	367069.00	ABDESSLAM	204251	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7084	1	2025-07-24	3166155.00	46.00	SORTIE	HYUNDAI 18516A73	\N	471	f	318102.00	HAMID	204252	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7085	1	2025-07-24	3166169.00	14.00	SORTIE	LINDE	\N	427	f	30169.00	HASSAN	204253	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7086	1	2025-07-24	3166211.00	43.00	SORTIE	LINDE	\N	477	f	8713.20	CHAABI	204254	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7087	1	2025-07-24	3166614.00	403.00	SORTIE	VOLVO 17885A73	\N	438	f	689581.00	JAWAD	204255	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7089	1	2025-07-25	3166874.00	127.00	SORTIE	RENAULT 25636A13	\N	411	f	122052.00	YASSINE	204257	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7090	1	2025-07-25	3167023.00	149.00	SORTIE	MIT 11470A73	\N	436	f	68369.00	MOHAMED	204258	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7091	1	2025-07-25	3167331.00	308.00	SORTIE	MAN 28659D1	\N	410	f	50180.00	CHOUAIB	204259	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7093	1	2025-07-25	3167586.00	194.00	SORTIE	VOLVO 22299A73	\N	480	f	602550.00	THAMI	204261	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7094	1	2025-07-25	3167720.00	134.00	SORTIE	VOLVO 22300A73	\N	481	f	689353.00	MUSTAPHA	204262	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7095	1	2025-07-25	3167818.00	98.00	SORTIE	MIT 11469A73	\N	435	f	927241.00	ABDELKHALEK	204263	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7096	1	2025-07-25	3168181.00	363.00	SORTIE	VOLVO 17886A73	\N	439	f	662357.00	MJID	204264	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7097	1	2025-07-25	3168195.00	15.00	SORTIE	LINDE	\N	429	f	\N	ABDELKHALEK	204265	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7098	1	2025-07-25	3168240.00	45.00	SORTIE	LINDE	\N	472	f	11524.80	AZIZ	204266	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7100	1	2025-07-25	3168320.00	42.00	SORTIE	HYUNDAI 22368A73	\N	482	f	214301.00	IDRISS	204268	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7102	1	2025-07-25	3169157.00	37.00	SORTIE	KANGO 4812A73	\N	419	f	236929.00	TARMOUNIA	204270	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7103	1	2025-07-25	3169187.00	30.00	SORTIE	RENAULT 25636A13	\N	411	f	122143.00	YASSINE	204271	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7104	1	2025-07-25	3169274.00	87.00	SORTIE	MANITOU	\N	484	f	5299.00	SAID	204272	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7105	1	2025-07-26	3169332.00	58.00	SORTIE	ISUZU 26128A8	\N	401	f	873218.00	TOUFIK	204273	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7106	1	2025-07-26	3169476.00	144.00	SORTIE	MIT 11469A73	\N	435	f	927807.00	ABDELKHALEK	204274	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7107	1	2025-07-26	3169589.00	113.00	SORTIE	MIT 11470A73	\N	436	f	68784.00	MOHAMED	204275	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7109	1	2025-07-26	3169806.00	163.00	SORTIE	VOLVO 22299A73	\N	480	f	603139.00	THAMI	204276	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7110	1	2025-07-26	3170028.00	222.00	SORTIE	MAN 706A73	\N	407	f	133394.00	HOUSSAM	204278	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7111	1	2025-07-26	3170207.00	179.00	SORTIE	CHARGEUSE G 938	\N	413	f	7552.70	ABDERRAHIM	204279	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7113	1	2025-07-26	3170267.00	22.00	SORTIE	LINDE	\N	472	f	11533.70	AZIZ	204281	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7114	1	2025-07-26	3170291.00	24.00	SORTIE	LINDE	\N	434	f	7463.10	MILOUD	204282	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7116	1	2025-07-26	3170470.00	153.00	SORTIE	MAN 28659D1	\N	410	f	50673.00	CHOUAIB	204284	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7117	1	2025-07-26	3170841.00	371.00	SORTIE	VOLVO 17885A73	\N	438	f	690724.00	ABDELKARIM	204285	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7118	1	2025-07-26	3170882.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	318337.00	NOURDINE	204286	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7119	1	2025-07-28	3171099.00	217.00	SORTIE	MIT 11470A73	\N	436	f	69604.00	MOHAMED	204287	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7121	1	2025-07-28	3171339.00	201.00	SORTIE	VOLVO 70352A2	\N	406	f	508162.00	MOHAMED	204289	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7122	1	2025-07-28	3171718.00	379.00	SORTIE	VOLVO 17886A73	\N	439	f	663661.00	MJID	204290	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7123	1	2025-07-28	3171848.00	130.00	SORTIE	MAN 28659D1	\N	410	f	51105.00	CHOUAIB	204291	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7124	1	2025-07-28	3172024.00	176.00	SORTIE	RENAULT 25636A13	\N	411	f	122839.00	YASSINE	204292	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7125	1	2025-07-28	3172189.00	165.00	SORTIE	MIT 11469A73	\N	435	f	928408.00	ABDELKHALEK	204293	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7128	1	2025-07-28	3172658.00	78.00	SORTIE	VOLVO 22299A73	\N	480	f	603625.00	THAMI	204296	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7129	1	2025-07-29	3172735.00	77.00	SORTIE	ISUZU 26128A8	\N	401	f	873605.00	TOUFIK	204303	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7130	1	2025-07-29	3172908.00	173.00	SORTIE	RENAULT 25636A13	\N	411	f	123526.00	YASSINE	204304	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7131	1	2025-07-29	3172938.00	30.00	SORTIE	LINDE	\N	434	f	7476.80	MILOUD	204305	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7132	1	2025-07-29	3173144.00	206.00	SORTIE	MIT 4703A73	\N	408	f	575379.00	MUSTAPHA	204306	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7133	1	2025-07-29	3173187.00	43.00	SORTIE	LINDE	\N	477	f	8730.70	CHAABI	204307	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7134	1	2025-07-29	3173358.00	171.00	SORTIE	CHARGEUSE G 938	\N	413	f	7567.20	ABDERRAHIM	204308	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7135	1	2025-07-29	3173377.00	19.00	SORTIE	FENWICK	\N	430	f	27610.00	SAID	204309	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7138	1	2025-07-29	3173594.00	51.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	204312	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7139	1	2025-07-29	3173784.00	190.00	SORTIE	VOLVO 22300A73	\N	481	f	690104.00	MUSTAPHA	204313	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7140	1	2025-07-29	3173826.00	42.00	SORTIE	HYUNDAI 22368A73	\N	482	f	214831.00	IDRISS	204314	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7141	1	2025-07-29	3173965.00	139.00	SORTIE	MAN 4790B8	\N	403	f	969431.00	KARDODI	204315	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7142	1	2025-07-29	3173992.00	27.00	SORTIE	LINDE	\N	472	f	1155.30	AZIZ	204316	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7143	1	2025-07-30	3174620.00	628.00	SORTIE	VOLVO 17885A73	\N	438	f	692363.00	ABDELKARIM	204317	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7144	1	2025-07-30	3174946.00	326.00	SORTIE	MAN 28659D1	\N	410	f	52163.00	CHOUAIB	204318	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7145	1	2025-07-30	3175109.00	163.00	SORTIE	MIT 11469A73	\N	435	f	929693.00	CHOUAIB	204319	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7148	1	2025-07-31	3176041.00	192.00	SORTIE	RENAULT 25636A13	\N	411	f	124273.00	YASSINE	204322	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7149	1	2025-07-31	3176215.00	174.00	SORTIE	MIT 11470A73	\N	436	f	70825.00	MOHAMED	204323	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7150	1	2025-07-31	3176410.00	195.00	SORTIE	MIT 4969A73	\N	409	f	946080.00	CHOUAIB	204324	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7152	1	2025-07-31	3176601.00	145.00	SORTIE	VOLVO 22300A73	\N	481	f	690633.00	MUSTAPHA	204326	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7153	1	2025-07-31	3176802.00	201.00	SORTIE	VOLVO 22299A73	\N	480	f	604180.00	THAMI	204327	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7154	1	2025-07-31	3176824.00	22.00	SORTIE	MIT 11469A73	\N	435	f	929737.00	ABDELKHALEK	204328	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7155	1	2025-07-31	3176896.00	72.00	SORTIE	VOLVO 22300A73	\N	481	f	690884.00	MUSTAPHA	204329	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7156	1	2025-07-31	3176952.00	56.00	SORTIE	HYUNDAI 18516A73	\N	471	f	318913.00	NOURDINE	204330	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7157	1	2025-07-31	3176991.00	39.00	SORTIE	RENAULT 25636A13	\N	411	f	124365.00	YASSINE	204331	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7158	1	2025-07-31	3177038.00	47.00	SORTIE	LINDE	\N	472	f	11571.30	AZIZ	204332	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7159	1	2025-07-31	3177099.00	61.00	SORTIE	BERLINGO 10591A73	\N	433	f	368507.00	ABDESSLAM	204333	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7161	1	2025-08-01	3177210.00	68.00	SORTIE	ISUZU 26128A8	\N	401	f	873961.00	TOUFIK	204335	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7162	1	2025-08-01	3177396.00	186.00	SORTIE	MAN 28659D1	\N	410	f	52797.00	CHOUAIB	204336	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7165	1	2025-08-01	3177724.00	140.00	SORTIE	MIT 11470A73	\N	436	f	71327.00	MOHAMED	204339	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7166	1	2025-08-01	3177954.00	230.00	SORTIE	MAN 706A73	\N	407	f	133894.00	HOUSSAM	204340	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7168	1	2025-08-01	3178670.00	394.00	SORTIE	VOLVO 17886A73	\N	439	f	664929.00	MJID	204342	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7170	1	2025-08-01	3178997.00	13.00	SORTIE	LINDE	\N	427	f	30174.80	HASSAN	204344	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7171	1	2025-08-01	3179097.00	100.00	SORTIE	MAN 4790B8	\N	403	f	969844.00	KARDODI	204345	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7172	1	2025-08-01	3179133.00	37.00	SORTIE	FENWICK	\N	430	f	27623.00	ABDELKHALEK	204346	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7173	1	2025-08-01	3179287.00	154.00	SORTIE	VOLVO 22299A73	\N	480	f	604734.00	THAMI	204347	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7174	1	2025-08-01	3179312.00	25.00	SORTIE	MIT 11470A73	\N	436	f	71416.00	MOHAMED	204348	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7175	1	2025-08-02	3179499.00	187.00	SORTIE	CHARGEUSE G 938	\N	413	f	7583.30	ABDERRAHIM	204349	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7176	1	2025-08-02	3179547.00	48.00	SORTIE	HYUNDAI 22368A73	\N	482	f	215327.00	IDRISS	204350	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7177	1	2025-08-02	3179724.00	177.00	SORTIE	VOLVO 22300A73	\N	481	f	691597.00	MUSTAPHA	204351	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7178	1	2025-08-02	3179759.00	35.00	SORTIE	LINDE	\N	434	f	7493.40	MILOUD	204352	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7179	1	2025-08-02	3179794.00	35.00	SORTIE	HYUNDAI 18516A73	\N	471	f	319115.00	NOURDINE	204353	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7182	1	2025-08-02	3180603.00	45.00	SORTIE	LINDE	\N	477	f	8748.70	CHAABI	204356	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7183	1	2025-08-02	3180753.00	150.00	SORTIE	VOLVO 22299A73	\N	480	f	605265.00	THAMI	204357	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7185	1	2025-08-02	3180820.00	29.00	SORTIE	LINDE	\N	472	f	11582.30	AZIZ	204359	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7187	1	2025-08-04	3180933.00	58.00	SORTIE	ISUZU 26128A8	\N	401	f	874295.00	TOUFIK	204361	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7188	1	2025-08-04	3181036.00	103.00	SORTIE	MIT 4969A73	\N	409	f	946411.00	CHOUAIB	204362	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7189	1	2025-08-04	3181205.00	169.00	SORTIE	RENAULT 25636A13	\N	411	f	125039.00	YASSINE	204363	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7190	1	2025-08-04	3181361.00	156.00	SORTIE	VOLVO 22300A73	\N	481	f	692140.00	MUSTAPHA	204364	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7192	1	2025-08-04	3181683.00	180.00	SORTIE	MIT 11470A73	\N	436	f	72036.00	MOHAMED	204366	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7193	1	2025-08-04	3181772.00	89.00	SORTIE	MANITOU	\N	484	f	5341.00	SAID	204367	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7197	1	2025-08-04	3182297.00	44.00	SORTIE	LINDE	\N	472	f	11600.70	ABDELAH	204371	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7198	1	2025-08-04	3182437.00	140.00	SORTIE	VOLVO 22299A73	\N	480	f	605763.00	THAMI	204372	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7200	1	2025-08-04	3183092.00	619.00	SORTIE	VOLVO 17885A73	\N	438	f	694058.00	ABDELKARIM	204374	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7202	1	2025-08-04	3183177.00	38.00	SORTIE	HYUNDAI 18516A73	\N	471	f	319345.00	HAMID	204376	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7203	1	2025-08-04	3183277.00	100.00	SORTIE	RENAULT 25636A13	\N	411	f	125418.00	YASSINE	204377	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7204	1	2025-08-05	3183388.00	111.00	SORTIE	MIT 11470A73	\N	436	f	72445.00	MOHAMED	204378	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7205	1	2025-08-05	3183541.00	153.00	SORTIE	VOLVO 22300A73	\N	481	f	692740.00	MUSTAPHA	204379	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7206	1	2025-08-05	3183592.00	51.00	SORTIE	HYUNDAI 22368A73	\N	482	f	215784.00	IDRISS	204380	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7207	1	2025-08-05	3183641.00	49.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	204381	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7209	1	2025-08-05	3183975.00	24.00	SORTIE	HYUNDAI 18516A73	\N	471	f	319502.00	NOURDINE	204383	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7210	1	2025-08-05	3184191.00	216.00	SORTIE	CHARGEUSE G 938	\N	413	f	7601.90	ABDERRAHIM	204384	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7211	1	2025-08-05	3184368.00	177.00	SORTIE	VOLVO 22299A73	\N	480	f	606450.00	THAMI	204385	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7213	1	2025-08-05	3184596.00	194.00	SORTIE	RENAULT 25636A13	\N	411	f	126149.00	YASSINE	204387	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7215	1	2025-08-05	3184701.00	84.00	SORTIE	MIT 4969A73	\N	409	f	946695.00	SALAH	204389	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7216	1	2025-08-06	3184765.00	64.00	SORTIE	ISUZU 26128A8	\N	401	f	874617.00	TOUFIK	204390	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7217	1	2025-08-06	3184794.00	29.00	SORTIE	HYUNDAI 18516A73	\N	471	f	319694.00	NOURDINE	204391	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7218	1	2025-08-06	3184934.00	140.00	SORTIE	VOLVO 22300A73	\N	481	f	693301.00	MUSTAPHA	204392	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7219	1	2025-08-06	3185074.00	140.00	SORTIE	MIT 11470A73	\N	436	f	72962.00	MOHAMED	204393	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7220	1	2025-08-06	3185164.00	90.00	SORTIE	MIT 11469A73	\N	435	f	930065.00	ABDELKHALEK	204394	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7221	1	2025-08-06	3185194.00	30.00	SORTIE	KANGO 4812A73	\N	419	f	237602.00	TARMOUNIA	204395	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7222	1	2025-08-06	3185547.00	353.00	SORTIE	VOLVO 17886A73	\N	439	f	665974.00	MJID	204396	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7223	1	2025-08-06	3185708.00	161.00	SORTIE	RENAULT 25636A13	\N	411	f	126793.00	YASSINE	204397	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7225	1	2025-08-06	3185861.00	28.00	SORTIE	LINDE	\N	434	f	7507.50	MILOUD	204399	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7226	1	2025-08-06	3186045.00	184.00	SORTIE	MIT 4703A73	\N	408	f	576227.00	MUSTAPHA	204400	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7227	1	2025-08-06	3186087.00	43.00	SORTIE	LINDE	\N	472	f	11618.90	AZIZ	204401	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7228	1	2025-08-06	3186140.00	53.00	SORTIE	FENWICK	\N	430	f	27642.60	ABDELKHALEK	204402	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7229	1	2025-08-06	3186166.00	26.00	SORTIE	MIT 11469A73	\N	435	f	930173.00	ABDELKHALEK	204403	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7230	1	2025-08-07	3186266.00	100.00	SORTIE	MIT 4969A73	\N	409	f	947054.00	CHOUAIB	204404	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7231	1	2025-08-07	3186422.00	156.00	SORTIE	MIT 11470A73	\N	436	f	73487.00	MOHAMED	204405	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7232	1	2025-08-07	3186558.00	136.00	SORTIE	MAN 4790B8	\N	403	f	970388.00	KARDODI	204406	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7233	1	2025-08-07	3186909.00	351.00	SORTIE	MAN 28659D1	\N	410	f	53673.00	CHOUAIB	204407	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7235	1	2025-08-07	3187017.00	48.00	SORTIE	LINDE	\N	477	f	8767.60	CHAABI	204409	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7236	1	2025-08-07	3187161.00	144.00	SORTIE	VOLVO 22299A73	\N	480	f	606936.00	THAMI	204410	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7237	1	2025-08-07	3187205.00	44.00	SORTIE	HYUNDAI 18516A73	\N	471	f	319953.00	HAMID	204411	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7238	1	2025-08-07	3187321.00	116.00	SORTIE	VOLVO 22300A73	\N	481	f	693749.00	MUSTAPHA	204412	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7240	1	2025-08-08	3188015.00	655.00	SORTIE	VOLVO 17885A73	\N	438	f	695759.00	ABDELKARIM	204414	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7241	1	2025-08-08	3188104.00	89.00	SORTIE	MIT 11470A73	\N	436	f	73777.00	MOHAMED	204415	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7242	1	2025-08-08	3188297.00	193.00	SORTIE	RENAULT 25636A13	\N	411	f	127523.00	YASSINE	204416	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7244	1	2025-08-08	3189002.00	90.00	SORTIE	MIT 11469A73	\N	435	f	930487.00	ABDELKHALEK	204418	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7246	1	2025-08-08	3189401.00	69.00	SORTIE	ISUZU 26128A8	\N	401	f	874984.00	TOUFIK	204420	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7247	1	2025-08-08	3189460.00	59.00	SORTIE	BERLINGO 10591A73	\N	433	f	369532.00	ABDESSLAM	204421	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7248	1	2025-08-08	3189620.00	160.00	SORTIE	VOLVO 17886A73	\N	439	f	666464.00	MJID	204422	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7249	1	2025-08-08	3189672.00	52.00	SORTIE	VOLVO 22300A73	\N	481	f	693958.00	MUSTAPHA	204423	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7250	1	2025-08-08	3189720.00	48.00	SORTIE	LINDE	\N	472	f	11637.30	ABDELLAH	204424	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7251	1	2025-08-08	3189799.00	80.00	SORTIE	RENAULT 25636A13	\N	411	f	127845.00	YASSINE	204425	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7252	1	2025-08-08	3190008.00	209.00	SORTIE	MAN 28659D1	\N	410	f	54329.00	CHOUAIB	204426	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7253	1	2025-08-08	3190042.00	34.00	SORTIE	HYUNDAI 18516A73	\N	471	f	320153.00	ABDELMALEK	204427	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7254	1	2025-08-08	3190161.00	119.00	SORTIE	MIT 4969A73	\N	409	f	947451.00	CHOUAIB	204428	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7255	1	2025-08-08	3190209.00	48.00	SORTIE	HYUNDAI 22368A73	\N	482	f	216327.00	IDRISS	204429	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7256	1	2025-08-09	3190298.00	89.00	SORTIE	MIT 11469A73	\N	435	f	930820.00	ABDELKHALEK	204430	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7257	1	2025-08-09	3190534.00	235.00	SORTIE	VOLVO 22299A73	\N	480	f	607827.00	THAMI	204431	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7258	1	2025-08-09	3190753.00	219.00	SORTIE	CHARGEUSE G 938	\N	413	f	7621.30	ABDERRAHIM	204432	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7259	1	2025-08-09	3190919.00	166.00	SORTIE	MIT 11470A73	\N	436	f	74378.00	MOHAMED	204433	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7260	1	2025-08-09	3191131.00	212.00	SORTIE	MAN 706A73	\N	407	f	134338.00	HOUSSAM	204434	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7263	1	2025-08-09	3191393.00	129.00	SORTIE	MAN 28659D1	\N	410	f	54801.00	CHOUAIB	204437	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7264	1	2025-08-09	3191522.00	128.00	SORTIE	VOLVO 22300A73	\N	481	f	694475.00	MUSTAPHA	204438	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7265	1	2025-08-09	3191545.00	23.00	SORTIE	LINDE	\N	434	f	7518.40	MILOUD	204439	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7267	1	2025-08-09	3191603.00	22.00	SORTIE	LINDE	\N	472	f	11647.00	ABDELLAH	204441	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7269	1	2025-08-11	3192264.00	112.00	SORTIE	VOLVO 22300A73	\N	481	f	694936.00	MUSTAPHA	204443	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7270	1	2025-08-11	3192465.00	201.00	SORTIE	MIT 11469A73	\N	435	f	931639.00	ABDELKHALEK	204444	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7272	1	2025-08-11	3192641.00	117.00	SORTIE	RENAULT 25636A13	\N	411	f	128321.00	YASSINE	204446	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7273	1	2025-08-11	3192780.00	139.00	SORTIE	MIT 11470A73	\N	436	f	74902.00	MOHAMED	204447	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7275	1	2025-08-11	3193154.00	62.00	SORTIE	HYUNDAI 22772A73	\N	479	f	243273.00	NOURDINE	204449	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7278	1	2025-08-11	3193383.00	158.00	SORTIE	CHARGEUSE G 938	\N	413	f	7635.40	ABDERRAHIM	204452	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7279	1	2025-08-11	3193422.00	39.00	SORTIE	HYUNDAI 18516A73	\N	471	f	320392.00	ABDELMALEK	204453	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7281	1	2025-08-11	3193514.00	58.00	SORTIE	FENWICK	\N	430	f	27664.40	ABDELKHALEK	204455	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7282	1	2025-08-11	3193603.00	89.00	SORTIE	MANITOU	\N	484	f	5391.00	SAID	204456	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7283	1	2025-08-11	3193643.00	40.00	SORTIE	LINDE	\N	472	f	11664.00	ABDELLAH	204457	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7284	1	2025-08-11	3193752.00	109.00	SORTIE	MIT 4969A73	\N	409	f	947831.00	CHOUAIB	204458	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7285	1	2025-08-11	3193793.00	41.00	SORTIE	VOLVO 22300A73	\N	481	f	695044.00	MUSTAPHA	204459	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7286	1	2025-08-11	3193928.00	135.00	SORTIE	MAN 4790B8	\N	403	f	970911.00	KARDODI	204460	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7287	1	2025-08-12	3194004.00	76.00	SORTIE	ISUZU 26128A8	\N	401	f	875370.00	TOUFIK	204461	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7288	1	2025-08-12	3194312.00	308.00	SORTIE	MAN 28659D1	\N	410	f	55771.00	CHOUAIB	204462	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7289	1	2025-08-12	3194452.00	140.00	SORTIE	MIT 11469A73	\N	435	f	932148.00	ABDELKHALEK	204463	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7290	1	2025-08-12	3194492.00	40.00	SORTIE	KANGO 4812A73	\N	419	f	237979.00	TARMOUNIA	204464	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7291	1	2025-08-12	3194655.00	163.00	SORTIE	MIT 11470A73	\N	436	f	75496.00	MOHAMED	204465	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7293	1	2025-08-12	3194979.00	24.00	SORTIE	HYUNDAI 18516A73	\N	471	f	320568.00	ABDELMALEK	204467	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7294	1	2025-08-12	3195028.00	49.00	SORTIE	MIT 11470A73	\N	436	f	75684.00	MOHAMED	204468	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7295	1	2025-08-12	3195415.00	387.00	SORTIE	VOLVO 17886A73	\N	439	f	667904.00	MJID	204469	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7296	1	2025-08-12	3195468.00	53.00	SORTIE	LINDE	\N	477	f	8789.10	CHAABI	204470	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7297	1	2025-08-12	3195545.00	77.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	204471	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7299	1	2025-08-12	3195749.00	182.00	SORTIE	RENAULT 25636A13	\N	411	f	129042.00	YASSINE	204473	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7301	1	2025-08-13	3195940.00	154.00	SORTIE	MIT 11469A73	\N	435	f	932746.00	ABDELKHALEK	204475	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7305	1	2025-08-13	3196931.00	149.00	SORTIE	VOLVO 22299A73	\N	480	f	608335.00	THAMI	204479	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7308	1	2025-08-13	3197284.00	46.00	SORTIE	LINDE	\N	472	f	11684.30	ABDELLAH	204482	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7309	1	2025-08-13	3197314.00	30.00	SORTIE	LINDE	\N	434	f	7533.10	MILOUD	204483	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7310	1	2025-08-13	3197482.00	168.00	SORTIE	VOLVO 22300A73	\N	481	f	695675.00	MUSTAPHA	204484	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7312	1	2025-08-14	3197661.00	157.00	SORTIE	MIT 11469A73	\N	435	f	933372.00	ABDELKHALEK	204486	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7313	1	2025-08-14	3197845.00	184.00	SORTIE	MIT 11470A73	\N	436	f	76345.00	MOHAMED	204487	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7314	1	2025-08-14	3197880.00	35.00	SORTIE	HYUNDAI 18516A73	\N	471	f	320833.00	ABDELMALEK	204488	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7316	1	2025-08-14	3199939.00	59.00	SORTIE	BERLINGO 10591A73	\N	433	f	370566.00	ABDESSLAM	204490	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7317	1	2025-08-14	3200312.00	373.00	SORTIE	VOLVO 17886A73	\N	439	f	669197.00	MJID	204491	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7318	1	2025-08-14	3200391.00	79.00	SORTIE	VOLVO 22299A73	\N	480	f	608590.00	THAMI	204492	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7319	1	2025-08-15	3200470.00	79.00	SORTIE	ISUZU 26128A8	\N	401	f	875753.00	TOUFIK	204493	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7320	1	2025-08-15	3200565.00	95.00	SORTIE	MIT 11469A73	\N	435	f	933714.00	ABDELKHALEK	204494	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7321	1	2025-08-15	3200620.00	55.00	SORTIE	HYUNDAI 22772A73	\N	479	f	243612.00	NOURDINE	204495	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7322	1	2025-08-15	3200831.00	211.00	SORTIE	RENAULT 25636A13	\N	411	f	129850.00	YASSINE	204496	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7323	1	2025-08-15	3200871.00	40.00	SORTIE	MIT 11470A73	\N	436	f	76459.00	MOHAMED	204497	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7324	1	2025-08-15	3201011.00	140.00	SORTIE	MAN 4790B8	\N	403	f	971440.00	KARDODI	204498	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7325	1	2025-08-15	3201052.00	41.00	SORTIE	LINDE	\N	472	f	11702.30	ABDELLAH	204499	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7326	1	2025-08-15	3201104.00	52.00	SORTIE	FENWICK	\N	430	f	27682.00	ABDELKHALEK	204500	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7327	1	2025-08-15	3201129.00	25.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321010.00	ABDELMALEK	205001	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7328	1	2025-08-15	3201832.00	703.00	SORTIE	VOLVO 17885A73	\N	438	f	697520.00	ABDELKARIM	205002	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7330	1	2025-08-15	3202006.00	132.00	SORTIE	VOLVO 22299A73	\N	480	f	609094.00	THAMI	205004	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7331	1	2025-08-16	3202173.00	168.00	SORTIE	VOLVO 22300A73	\N	481	f	696293.00	MUSTAPHA	205005	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7332	1	2025-08-16	3202235.00	62.00	SORTIE	HYUNDAI 22368A73	\N	482	f	216830.00	IDRISS	205006	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7333	1	2025-08-16	3202404.00	169.00	SORTIE	MIT 4969A73	\N	409	f	948307.00	MUSTAPHA	205007	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7334	1	2025-08-16	3202450.00	46.00	SORTIE	MIT 11469A73	\N	435	f	933844.00	ABDELKHALEK	205008	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7335	1	2025-08-16	3202593.00	143.00	SORTIE	RENAULT 25636A13	\N	411	f	130420.00	YASSINE	205009	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7339	1	2025-08-16	3203099.00	27.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321220.00	ABDELMALEK	205013	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7340	1	2025-08-16	3203497.00	398.00	SORTIE	VOLVO 17886A73	\N	439	f	670627.00	MJID	205014	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7341	1	2025-08-16	3203520.00	23.00	SORTIE	LINDE	\N	434	f	7543.60	MILOUD	205015	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7342	1	2025-08-16	3203569.00	49.00	SORTIE	LINDE	\N	477	f	8809.70	CHAABI	205016	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7344	1	2025-08-16	3203610.00	19.00	SORTIE	LINDE	\N	472	f	11710.90	ABDELLAH	205018	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7345	1	2025-08-16	3203675.00	65.00	SORTIE	VOLVO 22300A73	\N	481	f	696564.00	MUSTAPHA	205019	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7346	1	2025-08-16	3203818.00	143.00	SORTIE	RENAULT 25636A13	\N	411	f	131013.00	YASSINE	205020	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7347	1	2025-08-18	3204074.00	256.00	SORTIE	MAN 706A73	\N	407	f	134965.00	HOUSSAM	205021	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7348	1	2025-08-18	3204254.00	180.00	SORTIE	MIT 11469A73	\N	435	f	934525.00	ABDELKHALEK	205022	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7350	1	2025-08-18	3204637.00	32.00	SORTIE	LINDE	\N	427	f	30192.20	HASSAN	205024	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7352	1	2025-08-18	3204913.00	26.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321408.00	ABDELMALEK	205026	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7354	1	2025-08-18	3205000.00	51.00	SORTIE	MIT 11469A73	\N	435	f	934682.00	ABDELKHALEK	205028	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7355	1	2025-08-18	3205033.00	33.00	SORTIE	FENWICK	\N	430	f	27695.50	ABDELKHALEK	205029	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7356	1	2025-08-18	3205080.00	47.00	SORTIE	LINDE	\N	472	f	11731.90	AZIZ	205030	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7357	1	2025-08-18	3205215.00	135.00	SORTIE	RENAULT 25636A13	\N	411	f	131549.00	YASSINE	205031	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7358	1	2025-08-18	3205264.00	49.00	SORTIE	HYUNDAI 22772A73	\N	479	f	243902.00	ABDELMALEK	205032	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7361	1	2025-08-19	3205439.00	90.00	SORTIE	ISUZU 26128A8	\N	401	f	876230.00	TOUFIK	205035	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7362	1	2025-08-19	3205464.00	25.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321596.00	ABDELMALEK	205036	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7365	1	2025-08-19	3206025.00	52.00	SORTIE	MANITOU	\N	431	f	8476.00	SAID	205039	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7366	1	2025-08-19	3206240.00	215.00	SORTIE	VOLVO 22300A73	\N	481	f	697363.00	MUSTAPHA	205040	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7367	1	2025-08-19	3206330.00	90.00	SORTIE	MANITOU	\N	484	f	5435.00	SAID	205041	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7368	1	2025-08-19	3206382.00	52.00	SORTIE	BERLINGO 10591A73	\N	433	f	371822.00	ABDESSLAM	205042	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7369	1	2025-08-19	3206414.00	32.00	SORTIE	LINDE	\N	477	f	8822.80	CHAABI	205043	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7370	1	2025-08-19	3206437.00	23.00	SORTIE	LINDE	\N	472	f	11741.40	AZIZ	205044	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7371	1	2025-08-19	3206792.00	355.00	SORTIE	VOLVO 17886A73	\N	439	f	671781.00	MJID	205045	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7373	1	2025-08-20	3207383.00	41.00	SORTIE	HYUNDAI 22772A73	\N	479	f	244194.00	NOURDINE	205047	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7375	1	2025-08-20	3208418.00	211.00	SORTIE	MIT 11469A73	\N	435	f	935449.00	ABDELKHALEK	205049	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7376	1	2025-08-20	3208618.00	200.00	SORTIE	VOLVO 22299A73	\N	480	f	609718.00	THAMI	205050	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7377	1	2025-08-20	3208646.00	29.00	SORTIE	LINDE	\N	434	f	7556.30	MILOUD	205051	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7378	1	2025-08-20	3208864.00	218.00	SORTIE	RENAULT 25636A13	\N	411	f	122203.00	YASSINE	205052	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7379	1	2025-08-20	3208982.00	117.00	SORTIE	VOLVO 22300A73	\N	481	f	697812.00	MUSTAPHA	205053	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7380	1	2025-08-20	3209005.00	23.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321705.00	ABDELMALEK	205054	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7381	1	2025-08-21	3209138.00	133.00	SORTIE	MAN 4790B8	\N	403	f	971960.00	KARDODI	205055	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7382	1	2025-08-21	3209268.00	130.00	SORTIE	MIT 11469A73	\N	435	f	935917.00	ABDELKHALEK	205056	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7383	1	2025-08-21	3209548.00	280.00	SORTIE	VOLVO 17886A73	\N	439	f	672818.00	MJID	205057	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7384	1	2025-08-21	3209563.00	15.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321706.00	ABDELMALEK	205058	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7385	1	2025-08-21	3209599.00	37.00	SORTIE	LINDE	\N	472	f	11756.60	AZIZ	205059	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7387	1	2025-08-21	3209829.00	193.00	SORTIE	RENAULT 25636A13	\N	411	f	133139.00	YASSINE	205061	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7388	1	2025-08-22	3209881.00	52.00	SORTIE	HYUNDAI 22772A73	\N	479	f	244534.00	NOURDINE	205062	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7389	1	2025-08-22	3210055.00	174.00	SORTIE	MIT 4969A73	\N	409	f	948740.00	CHOUAIB	205063	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7390	1	2025-08-22	3210208.00	153.00	SORTIE	MIT 11469A73	\N	435	f	936496.00	ABDELKHALEK	205064	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7392	1	2025-08-22	3210557.00	56.00	SORTIE	FENWICK	\N	430	f	27715.50	ABDELKHALEK	205066	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7393	1	2025-08-22	3210580.00	23.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321708.00	ABDELMALEK	205067	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7394	1	2025-08-22	3211076.00	496.00	SORTIE	VOLVO 17885A73	\N	438	f	698601.00	CHOUAIB	205068	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7395	1	2025-08-22	3211106.00	29.00	SORTIE	KANGO 4812A73	\N	419	f	238742.00	TARMOUNIA	205069	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7396	1	2025-08-22	3211296.00	190.00	SORTIE	VOLVO 22300A73	\N	481	f	698521.00	MUSTAPHA	205070	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7397	1	2025-08-22	3211339.00	43.00	SORTIE	LINDE	\N	477	f	8840.90	ABDELKHALEK	205071	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7398	1	2025-08-22	3211380.00	41.00	SORTIE	HYUNDAI 22368A73	\N	482	f	\N	IDRISS	205072	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7399	1	2025-08-22	3211471.00	91.00	SORTIE	ISUZU 26128A8	\N	401	f	876690.00	TOUFIK	205073	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7400	1	2025-08-23	3211575.00	104.00	SORTIE	MIT 11469A73	\N	435	f	936897.00	ABDELKHALEK	205074	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7402	1	2025-08-23	3211781.00	180.00	SORTIE	RENAULT 25636A13	\N	411	f	133826.00	YASSINE	205076	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7405	1	2025-08-23	3211954.00	31.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321709.00	ABDELMALEK	205079	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7408	1	2025-08-23	3212045.00	35.00	SORTIE	LINDE	\N	434	f	7573.20	AZIZ	205082	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7410	1	2025-08-25	3212469.00	151.00	SORTIE	VOLVO 22300A73	\N	481	f	699043.00	MUSTAPHA	205084	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7411	1	2025-08-25	3212629.00	160.00	SORTIE	MIT 11469A73	\N	435	f	937461.00	ABDELKHALEK	205085	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7412	1	2025-08-25	3212665.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321710.00	ABDELMALEK	205086	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7413	1	2025-08-25	3212850.00	185.00	SORTIE	CHARGEUSE G 938	\N	413	f	7651.90	ABDERRAHIM	205087	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7414	1	2025-08-25	3212910.00	60.00	SORTIE	HYUNDAI 22772A73	\N	479	f	244918.00	NOURDINE	205088	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7415	1	2025-08-25	3213070.00	160.00	SORTIE	RENAULT 25636A13	\N	411	f	134463.00	YASSINE	205089	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7418	1	2025-08-25	3214034.00	30.00	SORTIE	LINDE	\N	434	f	7588.30	AZIZ	205092	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7420	1	2025-08-25	3214409.00	337.00	SORTIE	VOLVO 17886A73	\N	439	f	674006.00	MJID	205094	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7422	1	2025-08-25	3214466.00	33.00	SORTIE	FENWICK	\N	430	f	27726.00	ABDELKHALEK	205096	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7423	1	2025-08-26	3214543.00	77.00	SORTIE	ISUZU 26128A8	\N	401	f	877102.00	TOUFIK	205097	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7424	1	2025-08-26	3214566.00	23.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321710.00	ABDELMALEK	205098	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7425	1	2025-08-26	3214732.00	166.00	SORTIE	RENAULT 25636A13	\N	411	f	135104.00	YASSINE	205099	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7426	1	2025-08-26	3214874.00	142.00	SORTIE	MIT 11469A73	\N	435	f	938009.00	ABDELKHALEK	205100	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7428	1	2025-08-26	3215232.00	220.00	SORTIE	MAN 706A73	\N	407	f	135457.00	HOUSSAM	205102	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7430	1	2025-08-26	3215584.00	45.00	SORTIE	LINDE	\N	477	f	8859.50	CHAABI	205104	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7431	1	2025-08-26	3215623.00	39.00	SORTIE	LINDE	\N	472	f	11773.00	AZIZ	205105	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7432	1	2025-08-26	3215697.00	74.00	SORTIE	RENAULT 25636A13	\N	411	f	135408.00	YASSINE	205106	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7433	1	2025-08-26	3215899.00	202.00	SORTIE	VOLVO 22299A73	\N	480	f	610291.00	THAMI	205107	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7434	1	2025-08-26	3215964.00	65.00	SORTIE	VOLVO 22300A73	\N	481	f	699233.00	MUSTAPHA	205108	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7435	1	2025-08-26	3216402.00	438.00	SORTIE	VOLVO 17885A73	\N	438	f	699621.00	ABDELKARIM	205109	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7436	1	2025-08-27	3216522.00	120.00	SORTIE	MAN 4790B8	\N	403	f	972417.00	KARDODI	205110	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7437	1	2025-08-27	3216563.00	41.00	SORTIE	HYUNDAI 22368A73	\N	482	f	217938.00	IDRISS	205111	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7438	1	2025-08-27	3216763.00	200.00	SORTIE	MIT 4969A73	\N	409	f	949337.00	CHOUAIB	205112	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7439	1	2025-08-27	3216796.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321711.00	ABDELMALEK	205113	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7440	1	2025-08-27	3216823.00	27.00	SORTIE	BERLINGO 981A73	\N	417	f	299327.00	MAGHNIA	205114	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7441	1	2025-08-27	3216945.00	122.00	SORTIE	MIT 11469A73	\N	435	f	938432.00	ABDELKHALEK	205115	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7442	1	2025-08-27	3217021.00	76.00	SORTIE	VOLVO 22300A73	\N	481	f	699493.00	MUSTAPHA	205116	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7443	1	2025-08-27	3217104.00	83.00	SORTIE	MANITOU	\N	484	f	5472.00	SAID	205117	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7445	1	2025-08-27	3217887.00	104.00	SORTIE	MAN 28659D1	\N	410	f	56061.00	CHOUAIB	205119	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7446	1	2025-08-27	3217954.00	67.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	205120	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7447	1	2025-08-27	3217974.00	20.00	SORTIE	LINDE	\N	434	f	7598.30	MILOUD	205121	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7448	1	2025-08-27	3218005.00	31.00	SORTIE	FENWICK	\N	430	f	27738.00	ABDELKHALEK	205122	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7449	1	2025-08-28	3218033.00	28.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321711.00	ABDELMALEK	205123	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7450	1	2025-08-28	3218124.00	91.00	SORTIE	MIT 11469A73	\N	435	f	938769.00	ABDELKHALEK	205124	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7451	1	2025-08-28	3218299.00	175.00	SORTIE	CHARGEUSE G 938	\N	413	f	7666.10	ABDERRAHIM	205125	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7452	1	2025-08-28	3218465.00	166.00	SORTIE	RENAULT 25636A13	\N	411	f	136047.00	YASSINE	205126	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7453	1	2025-08-28	3218521.00	56.00	SORTIE	HYUNDAI 22772A73	\N	479	f	245237.00	NOURDINE	205127	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7454	1	2025-08-28	3218554.00	33.00	SORTIE	MIT 11469A73	\N	435	f	938871.00	ABDELKHALEK	205128	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7455	1	2025-08-28	3218997.00	443.00	SORTIE	VOLVO 17886A73	\N	439	f	675577.00	MJID	205129	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7457	1	2025-08-28	3219081.00	46.00	SORTIE	LINDE	\N	472	f	11793.00	AZIZ	205131	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7458	1	2025-08-28	3219299.00	219.00	SORTIE	MAN 28659D1	\N	410	f	56752.00	CHOUAIB	205132	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7459	1	2025-08-29	3219375.00	76.00	SORTIE	ISUZU 26128A8	\N	401	f	877341.00	TOUFIK	205133	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7460	1	2025-08-29	3219545.00	170.00	SORTIE	VOLVO 22300A73	\N	481	f	700133.00	MUSTAPHA	205134	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7462	1	2025-08-29	3219614.00	28.00	SORTIE	HYUNDAI 18516A73	\N	471	f	321896.00	ABDELMALEK	205136	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7463	1	2025-08-29	3219794.00	180.00	SORTIE	VOLVO 22299A73	\N	480	f	610896.00	THAMI	205137	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7464	1	2025-08-29	3219910.00	116.00	SORTIE	RENAULT 25636A13	\N	411	f	136473.00	YASSINE	205138	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7466	1	2025-08-29	3220123.00	76.00	SORTIE	MAN 4790B8	\N	403	f	972717.00	KARDODI	205140	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7468	1	2025-08-29	3220188.00	62.00	SORTIE	BERLINGO 10591A73	\N	433	f	373366.00	ABDESSLAM	205142	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7469	1	2025-08-29	3220262.00	74.00	SORTIE	MIT 4969A73	\N	409	f	949555.00	CHOUAIB	205143	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7470	1	2025-08-29	3220432.00	170.00	SORTIE	MAN 28659D1	\N	410	f	57355.00	CHOUAIB	205144	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7471	1	2025-08-30	3220613.00	181.00	SORTIE	MIT 11469A73	\N	435	f	939506.00	ABDELKHALEK	205145	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7472	1	2025-08-30	3220778.00	165.00	SORTIE	MIT 11470A73	\N	436	f	77040.00	MOHAMED	205146	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7474	1	2025-08-30	3221231.00	41.00	SORTIE	LINDE	\N	477	f	8876.20	CHAABI	205148	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7475	1	2025-08-30	3221271.00	40.00	SORTIE	HYUNDAI 22772A73	\N	479	f	245465.00	NOURDINE	205149	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7476	1	2025-08-30	3221435.00	164.00	SORTIE	CHARGEUSE G 938	\N	413	f	7680.00	ABDERRAHIM	205150	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7478	1	2025-08-30	3221930.00	191.00	SORTIE	VOLVO 22299A73	\N	480	f	611615.00	THAMI	205152	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7479	1	2025-08-30	3222081.00	151.00	SORTIE	RENAULT 25636A13	\N	411	f	137094.00	YASSINE	205153	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7480	1	2025-08-30	3222754.00	673.00	SORTIE	VOLVO 17885A73	\N	438	f	701267.00	ABDELKARIM	205154	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7481	1	2025-08-30	3222775.00	21.00	SORTIE	LINDE	\N	434	f	7609.70	MILOUD	205155	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7482	1	2025-08-30	3222814.00	39.00	SORTIE	HYUNDAI 18516A73	\N	471	f	322163.00	ABDELMALEK	205156	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7483	1	2025-08-30	3222857.00	43.00	SORTIE	LINDE	\N	472	f	11811.50	AZIZ	205157	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7485	1	2025-08-30	3222968.00	79.00	SORTIE	RENAULT 25636A13	\N	411	f	137388.00	YASSINE	205159	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7486	1	2025-09-01	3223086.00	118.00	SORTIE	MIT 4969A73	\N	409	f	949961.00	CHOUAIB	205160	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7487	1	2025-09-01	3223233.00	146.00	SORTIE	MAN 4790B8	\N	403	f	973282.00	KARDODI	205161	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7488	1	2025-09-01	3223377.00	144.00	SORTIE	MIT 11470A73	\N	436	f	77543.00	MOHAMED	205162	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7490	1	2025-09-01	3223822.00	135.00	SORTIE	VOLVO 22300A73	\N	481	f	700626.00	MUSTAPHA	205164	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7491	1	2025-09-01	3224040.00	218.00	SORTIE	VOLVO 22299A73	\N	480	f	612424.00	THAMI	205165	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7492	1	2025-09-01	3224078.00	37.00	SORTIE	LINDE	\N	472	f	118269.00	SKOURI	205166	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7494	1	2025-09-01	3224157.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	322395.00	ABDELMALEK	205168	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7495	1	2025-09-01	3224402.00	245.00	SORTIE	VOLVO 17886A73	\N	439	f	676364.00	MJID	205169	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7497	1	2025-09-01	3224492.00	51.00	SORTIE	FENWICK	\N	430	f	27756.00	ABDELKHALEK	205171	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7498	1	2025-09-01	3224548.00	56.00	SORTIE	MIT 11469A73	\N	435	f	939697.00	ABDELKHALEK	205172	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7499	1	2025-09-01	3224631.00	83.00	SORTIE	VOLVO 22300A73	\N	481	f	700932.00	MUSTAPHA	205173	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7500	1	2025-09-02	3224716.00	85.00	SORTIE	ISUZU 26128A8	\N	401	f	877958.00	TOUFIK	205174	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7503	1	2025-09-02	3225073.00	167.00	SORTIE	CHARGEUSE G 938	\N	413	f	7693.20	ABDERRAHIM	205177	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7504	1	2025-09-02	3225233.00	160.00	SORTIE	MIT 11470A73	\N	436	f	78098.00	MOHAMED	205178	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7505	1	2025-09-02	3225307.00	74.00	SORTIE	VOLVO 22299A73	\N	480	f	612640.00	THAMI	205179	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7506	1	2025-09-02	3225559.00	252.00	SORTIE	MAN 28659D1	\N	410	f	58184.00	CHOUAIB	205180	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7507	1	2025-09-02	3225589.00	30.00	SORTIE	HYUNDAI 18516A73	\N	471	f	322584.00	ABDELMALEK	205181	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7508	1	2025-09-02	3225790.00	201.00	SORTIE	RENAULT 25636A13	\N	411	f	138112.00	YASSINE	205182	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7510	1	2025-09-02	3226149.00	45.00	SORTIE	HYUNDAI 22772A73	\N	479	f	245780.00	ABDELMALEK	205184	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7511	1	2025-09-02	3226185.00	36.00	SORTIE	LINDE	\N	477	f	8891.10	CHAABI	205185	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7512	1	2025-09-02	3226296.00	111.00	SORTIE	VOLVO 22299A73	\N	480	f	613040.00	THAMI	205186	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7513	1	2025-09-03	3226339.00	43.00	SORTIE	KANGO 4812A73	\N	419	f	239486.00	TARMOUNIA	205187	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7514	1	2025-09-03	3226503.00	164.00	SORTIE	MIT 11469A73	\N	435	f	940302.00	ABDELKHALEK	205188	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7516	1	2025-09-03	3227060.00	246.00	SORTIE	MIT 11470A73	\N	436	f	78985.00	MOHAMED	205190	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7517	1	2025-09-03	3227116.00	56.00	SORTIE	VOLVO 22299A73	\N	480	f	613326.00	THAMI	205191	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7518	1	2025-09-03	3227148.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	322786.00	ABDELMALEK	205192	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7519	1	2025-09-03	3227329.00	181.00	SORTIE	VOLVO 22300A73	\N	481	f	701563.00	MUSTAPHA	205193	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7520	1	2025-09-03	3227429.00	100.00	SORTIE	MAN 4790B8	\N	403	f	973637.00	KARDODI	205194	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7525	1	2025-09-04	3228487.00	170.00	SORTIE	MIT 11470A73	\N	436	f	79603.00	MOHAMED	205199	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7526	1	2025-09-04	3228551.00	64.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	205200	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7527	1	2025-09-04	3228636.00	85.00	SORTIE	MANITOU	\N	484	f	5512.00	SAID	205201	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7530	1	2025-09-04	3228838.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	322984.00	ABDELMALEK	205204	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7531	1	2025-09-04	3228887.00	49.00	SORTIE	HYUNDAI 22772A73	\N	479	f	246133.00	ABDELMALEK	205205	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7532	1	2025-09-04	3229104.00	217.00	SORTIE	VOLVO 17886A73	\N	439	f	677117.00	MJID	205206	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7533	1	2025-09-04	3229164.00	60.00	SORTIE	BERLINGO 10591A73	\N	433	f	374430.00	ABDESSLAM	205207	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7537	1	2025-09-04	3229382.00	145.00	SORTIE	CHARGEUSE G 938	\N	413	f	7704.90	ABDERRAHIM	205211	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7538	1	2025-09-08	3229442.00	60.00	SORTIE	FENWICK	\N	430	f	\N	ABDELKHALEK	205212	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7539	1	2025-09-08	3230114.00	671.00	SORTIE	VOLVO 17885A73	\N	438	f	702881.00	HOUSSAM	205213	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7540	1	2025-09-08	3230301.00	187.00	SORTIE	RENAULT 25636A13	\N	411	f	138806.00	YASSINE	205214	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7541	1	2025-09-08	3230473.00	172.00	SORTIE	MIT 4969A73	\N	409	f	950482.00	MUSTAPHA	205215	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7542	1	2025-09-08	3230533.00	60.00	SORTIE	HYUNDAI 22772A73	\N	479	f	246525.00	NOURDINE	205216	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7543	1	2025-09-08	3230663.00	130.00	SORTIE	VOLVO 22300A73	\N	481	f	702065.00	MUSTAPHA	205217	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7544	1	2025-09-08	3230710.00	47.00	SORTIE	LINDE	\N	434	f	7626.60	MILOUD	205218	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7545	1	2025-09-08	3230891.00	181.00	SORTIE	VOLVO 22299A73	\N	480	f	613919.00	THAMI	205219	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7546	1	2025-09-08	3231040.00	149.00	SORTIE	MIT 11470A73	\N	436	f	80124.00	MOHAMED	205220	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7547	1	2025-09-08	3231083.00	42.00	SORTIE	RENAULT 25636A13	\N	411	f	138936.00	YASSINE	205221	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7548	1	2025-09-08	3231126.00	43.00	SORTIE	LINDE	\N	472	f	11847.90	ABDELAH	205222	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7549	1	2025-09-08	3231162.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	323234.00	NOURDINE	205223	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7550	1	2025-09-09	3231240.00	78.00	SORTIE	VOLVO 22299A73	\N	480	f	614192.00	THAMI	205224	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7551	1	2025-09-09	3231378.00	138.00	SORTIE	MIT 11469A73	\N	435	f	940806.00	ABDELKHALEK	205225	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7552	1	2025-09-09	3231573.00	195.00	SORTIE	MIT 11470A73	\N	436	f	80787.00	MOHAMED	205226	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7553	1	2025-09-09	3231738.00	165.00	SORTIE	VOLVO 22300A73	\N	481	f	702685.00	MUSTAPHA	205227	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7554	1	2025-09-09	3231798.00	60.00	SORTIE	VOLVO 22300A73	\N	481	f	702936.00	MUSTAPHA	205228	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7555	1	2025-09-09	3231878.00	80.00	SORTIE	ISUZU 26128A8	\N	401	f	878343.00	TOUFIK	205229	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7556	1	2025-09-09	3231927.00	49.00	SORTIE	HYUNDAI 18516A73	\N	471	f	323580.00	NOURDINE	205230	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7557	1	2025-09-09	3232142.00	215.00	SORTIE	VOLVO 17885A73	\N	438	f	703542.00	HOUSSAM	205231	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7559	1	2025-09-09	3232246.00	70.00	SORTIE	MIT 11470A73	\N	436	f	81025.00	MOHAMED	205233	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7560	1	2025-09-10	3232364.00	118.00	SORTIE	MAN 4790B8	\N	403	f	974088.00	KARDODI	205234	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7562	1	2025-09-10	3232505.00	111.00	SORTIE	MIT 4969A73	\N	409	f	950774.00	CHOUAIB	205236	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7563	1	2025-09-10	3232949.00	444.00	SORTIE	VOLVO 17886A73	\N	439	f	678731.00	MJID	205237	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7564	1	2025-09-10	3233207.00	258.00	SORTIE	MAN 28659D1	\N	410	f	59076.00	CHOUAIB	205238	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7565	1	2025-09-10	3233406.00	199.00	SORTIE	CHARGEUSE G 938	\N	413	f	7721.10	ABDERRAHIM	205239	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7566	1	2025-09-10	3233454.00	49.00	SORTIE	LINDE	\N	472	f	11867.80	ABDELLAH	205240	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7567	1	2025-09-10	3233494.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	323877.00	NOURDINE	205241	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7568	1	2025-09-10	3233539.00	45.00	SORTIE	LINDE	\N	477	f	8909.40	ABDELKHALEK	205242	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7569	1	2025-09-10	3233667.00	128.00	SORTIE	VOLVO 22300A73	\N	481	f	703432.00	MUSTAPHA	205243	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7570	1	2025-09-11	3233704.00	37.00	SORTIE	HYUNDAI 18516A73	\N	471	f	324160.00	ABDELMALEK	205244	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7571	1	2025-09-11	3233871.00	167.00	SORTIE	MIT 11470A73	\N	436	f	81551.00	MOHAMED	205245	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7574	1	2025-09-11	3234757.00	198.00	SORTIE	VOLVO 22299A73	\N	480	f	614901.00	THAMI	205248	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7575	1	2025-09-11	3234876.00	119.00	SORTIE	MIT 4969A73	\N	409	f	951205.00	CHOUAIB	205249	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7576	1	2025-09-11	3234899.00	23.00	SORTIE	LINDE	\N	434	f	7637.70	MILOUD	205250	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7577	1	2025-09-11	3234942.00	43.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	205251	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7579	1	2025-09-12	3235165.00	186.00	SORTIE	MIT 11470A73	\N	436	f	82188.00	MOHAMED	205253	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7580	1	2025-09-12	3235338.00	173.00	SORTIE	VOLVO 22300A73	\N	481	f	704125.00	MUSTAPHA	205254	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7581	1	2025-09-12	3235368.00	30.00	SORTIE	BERLINGO 981A73	\N	417	f	299734.00	MAGHNIA	205255	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7584	1	2025-09-12	3236150.00	37.00	SORTIE	VOLVO 22299A73	\N	480	f	614993.00	THAMI	205258	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7586	1	2025-09-12	3236339.00	54.00	SORTIE	HYUNDAI 22368A73	\N	482	f	218578.00	AHMED	205260	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7587	1	2025-09-12	3236714.00	375.00	SORTIE	VOLVO 17885A73	\N	438	f	704637.00	HOUSSAM	205261	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7589	1	2025-09-12	3236793.00	37.00	SORTIE	LINDE	\N	472	f	11883.70	ABDELLAH	205263	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7590	1	2025-09-12	3236820.00	27.00	SORTIE	VOLVO 22300A73	\N	481	f	704207.00	MUSTAPHA	205264	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7591	1	2025-09-12	3236873.00	53.00	SORTIE	HYUNDAI 18516A73	\N	471	f	324525.00	NOURDINE	205265	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7592	1	2025-09-12	3236933.00	60.00	SORTIE	HYUNDAI 22772A73	\N	479	f	246890.00	NOURDINE	205266	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7594	1	2025-09-12	3236999.00	44.00	SORTIE	KANGO 4812A73	\N	419	f	240041.00	TARMOUNIA	205268	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7596	1	2025-09-12	3237074.00	44.00	SORTIE	FENWICK	\N	430	f	27793.00	ABDELKHALEK	205270	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7597	1	2025-09-13	3237223.00	150.00	SORTIE	MIT 11470A73	\N	436	f	82715.00	MOHAMED	205271	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7598	1	2025-09-13	3237432.00	209.00	SORTIE	VOLVO 22299A73	\N	480	f	615781.00	THAMI	205272	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7599	1	2025-09-13	3237606.00	174.00	SORTIE	RENAULT 25636A13	\N	411	f	139609.00	YASSINE	205273	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7600	1	2025-09-13	3237664.00	58.00	SORTIE	BERLINGO 10591A73	\N	433	f	375466.00	ABDESSLAM	205274	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7602	1	2025-09-13	3238080.00	88.00	SORTIE	MANITOU	\N	484	f	5552.00	SAID	205276	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7603	1	2025-09-13	3238242.00	162.00	SORTIE	MAN 28659D1	\N	410	f	59483.00	CHOUAIB	205277	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7604	1	2025-09-13	3238284.00	42.00	SORTIE	HYUNDAI 18516A73	\N	471	f	324821.00	NOURDINE	205278	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7605	1	2025-09-13	3238476.00	192.00	SORTIE	CHARGEUSE G 938	\N	413	f	7737.40	ABDERRAHIM	205279	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7607	1	2025-09-13	3238687.00	160.00	SORTIE	VOLVO 22300A73	\N	481	f	704817.00	MUSTAPHA	205281	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7608	1	2025-09-13	3238709.00	22.00	SORTIE	LINDE	\N	472	f	11893.20	ABDELLAH	205282	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7609	1	2025-09-13	3238737.00	28.00	SORTIE	LINDE	\N	477	f	8920.80	CHAABI	205283	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7611	1	2025-09-15	3238888.00	130.00	SORTIE	MAN 4790B8	\N	403	f	974535.00	KARDODI	205285	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7612	1	2025-09-15	3239010.00	122.00	SORTIE	ISUZU 26128A8	\N	401	f	878896.00	TOUFIK	205286	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7613	1	2025-09-15	3239056.00	46.00	SORTIE	HYUNDAI 18516A73	\N	471	f	325184.00	ABDELMALEK	205287	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7614	1	2025-09-15	3239173.00	117.00	SORTIE	MIT 11470A73	\N	436	f	83110.00	MOHAMED	205288	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7615	1	2025-09-15	3239300.00	127.00	SORTIE	VOLVO 22299A73	\N	480	f	616280.00	THAMI	205289	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7616	1	2025-09-15	3239348.00	48.00	SORTIE	LINDE	\N	472	f	11913.90	AZIZ	205290	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7617	1	2025-09-15	3239446.00	98.00	SORTIE	VOLVO 22300A73	\N	481	f	705211.00	MUSTAPHA	205291	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7618	1	2025-09-15	3239476.00	30.00	SORTIE	LINDE	\N	434	f	7651.20	MILOUD	205292	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7619	1	2025-09-16	3239744.00	268.00	SORTIE	MAN 28659D1	\N	410	f	60353.00	CHOUAIB	205293	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7620	1	2025-09-16	3239794.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	247195.00	NOURDINE	205294	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7621	1	2025-09-16	3239894.00	100.00	SORTIE	MIT 11470A73	\N	436	f	83471.00	MOHAMED	205295	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7624	1	2025-09-16	3240702.00	185.00	SORTIE	MIT 4969A73	\N	409	f	951791.00	ABDELKHALEK	205298	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7626	1	2025-09-16	3240777.00	34.00	SORTIE	HYUNDAI 18516A73	\N	471	f	325429.00	ABDELMALEK	205300	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7627	1	2025-09-16	3240938.00	161.00	SORTIE	CHARGEUSE G 938	\N	413	f	7751.90	ABDERRAHIM	205301	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7628	1	2025-09-16	3240984.00	46.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	205302	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7629	1	2025-09-16	3241125.00	141.00	SORTIE	VOLVO 22300A73	\N	481	f	705810.00	MUSTAPHA	205303	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7630	1	2025-09-16	3241315.00	190.00	SORTIE	VOLVO 22299A73	\N	480	f	617030.00	THAMI	205304	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7631	1	2025-09-17	3241410.00	95.00	SORTIE	MIT 11470A73	\N	436	f	83825.00	MOHAMED	205305	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7633	1	2025-09-17	3241670.00	207.00	SORTIE	MIT 4703A73	\N	408	f	577138.00	MUSTAPHA	205307	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7634	1	2025-09-17	3241935.00	265.00	SORTIE	VOLVO 17886A73	\N	439	f	679639.00	MJID	205308	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7635	1	2025-09-17	3241966.00	31.00	SORTIE	HYUNDAI 18516A73	\N	471	f	325636.00	NOURDINE	205309	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7636	1	2025-09-17	3242010.00	44.00	SORTIE	LINDE	\N	472	f	11932.80	AZIZ	205310	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7637	1	2025-09-17	3242272.00	262.00	SORTIE	MAN 706A73	\N	407	f	136059.00	SOUFIANE	205311	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7638	1	2025-09-17	3242324.00	52.00	SORTIE	FENWICK	\N	430	f	27813.70	ABDELKHALEK	205312	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7639	1	2025-09-17	3242362.00	38.00	SORTIE	LINDE	\N	477	f	8936.40	ABDELKHALEK	205313	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7641	1	2025-09-18	3242467.00	82.00	SORTIE	ISUZU 26128A8	\N	401	f	879353.00	TOUFIK	205315	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7642	1	2025-09-18	3242609.00	142.00	SORTIE	VOLVO 22300A73	\N	481	f	706379.00	MUSTAPHA	205316	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7643	1	2025-09-18	3242752.00	143.00	SORTIE	MIT 11470A73	\N	436	f	84332.00	MOHAMED	205317	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7645	1	2025-09-18	3243043.00	259.00	SORTIE	MAN 28659D1	\N	410	f	61212.00	CHOUAIB	205319	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7646	1	2025-09-18	3243156.00	113.00	SORTIE	MAN 4790B8	\N	403	f	974944.00	KARDODI	205320	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7648	1	2025-09-18	3243427.00	108.00	SORTIE	MIT 4969A73	\N	409	f	952143.00	CHOUAIB	205322	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7651	1	2025-09-18	3244704.00	446.00	SORTIE	VOLVO 17885A73	\N	438	f	705901.00	HOUSSAM	205325	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7652	1	2025-09-18	\N	73.00	SORTIE	MIT 4969A73	\N	409	f	952433.00	CHOUAIB	205326	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7653	1	2025-09-18	3244855.00	78.00	SORTIE	VOLVO 22299A73	\N	480	f	617289.00	THAMI	205327	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7654	1	2025-09-19	3244998.00	143.00	SORTIE	MIT 11470A73	\N	436	f	84821.00	MOHAMED	205328	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7655	1	2025-09-19	3245148.00	150.00	SORTIE	MAN 28659D1	\N	410	f	61746.00	CHOUAIB	205329	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7656	1	2025-09-19	3245190.00	42.00	SORTIE	HYUNDAI 18516A73	\N	471	f	525927.00	ABDELMALEK	205330	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7657	1	2025-09-19	3245236.00	46.00	SORTIE	LINDE	\N	472	f	11951.70	AZIZ	205331	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7658	1	2025-09-19	3245287.00	51.00	SORTIE	HYUNDAI 22772A73	\N	479	f	247549.00	NOURDINE	205332	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7660	1	2025-09-19	3245518.00	188.00	SORTIE	CHARGEUSE G 938	\N	413	f	7768.70	ABDERRAHIM	205334	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7661	1	2025-09-19	3245639.00	121.00	SORTIE	VOLVO 22299A73	\N	480	f	617734.00	THAMI	205335	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7662	1	2025-09-19	3245671.00	32.00	SORTIE	LINDE	\N	434	f	7666.90	MILOUD	205336	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7663	1	2025-09-19	3245724.00	53.00	SORTIE	ISUZU 26128A8	\N	401	f	879610.00	TOUFIK	205337	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7664	1	2025-09-20	3245780.00	56.00	SORTIE	HYUNDAI 22368A73	\N	482	f	219243.00	BADER	205338	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7665	1	2025-09-20	3245952.00	172.00	SORTIE	MIT 11470A73	\N	436	f	85409.00	MOHAMED	205339	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7666	1	2025-09-20	3246085.00	133.00	SORTIE	MIT 4969A73	\N	409	f	952944.00	CHOUAIB	205340	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7667	1	2025-09-20	3246447.00	362.00	SORTIE	VOLVO 17886A73	\N	439	f	681008.00	MJID	205341	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7668	1	2025-09-20	3246467.00	20.00	SORTIE	HYUNDAI 18516A73	\N	471	f	326059.00	ABDELMALEK	205342	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7669	1	2025-09-20	3246521.00	54.00	SORTIE	BERLINGO 10591A73	\N	433	f	376678.00	ABDESSLAM	205343	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7670	1	2025-09-20	3246676.00	155.00	SORTIE	MAN 28659D1	\N	410	f	62296.00	CHOUAIB	205344	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7671	1	2025-09-20	3246765.00	89.00	SORTIE	MANITOU	\N	484	f	5594.00	SAID	205345	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7672	1	2025-09-20	3246878.00	113.00	SORTIE	MAN 4790B8	\N	403	f	975307.00	KARDODI	205346	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7674	1	2025-09-20	3247288.00	369.00	SORTIE	VOLVO 17885A73	\N	438	f	706811.00	HOUSSAM	205348	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7675	1	2025-09-20	3247312.00	24.00	SORTIE	LINDE	\N	472	f	11961.50	AZIZ	205349	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7676	1	2025-09-20	3247354.00	42.00	SORTIE	FENWICK	\N	430	f	27829.00	SAID	205350	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7677	1	2025-09-20	3247385.00	31.00	SORTIE	LINDE	\N	477	f	8949.40	CHAABI	205351	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7678	1	2025-09-22	3247540.00	155.00	SORTIE	MIT 11470A73	\N	436	f	85960.00	MOHAMED	205352	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7680	1	2025-09-22	3247759.00	106.00	SORTIE	MIT 4969A73	\N	409	f	953127.00	CHOUAIB	205354	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7683	1	2025-09-22	3248670.00	51.00	SORTIE	HYUNDAI 18516A73	\N	471	f	326476.00	ABDELMALEK	205357	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7684	1	2025-09-22	3248704.00	34.00	SORTIE	LINDE	\N	472	f	11975.50	AZIZ	205358	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7686	1	2025-09-22	3248773.00	20.00	SORTIE	KANGO 4812A73	\N	419	f	240701.00	TARMOUNIA	205360	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7687	1	2025-09-22	3248947.00	174.00	SORTIE	RENAULT 25636A13	\N	411	f	140251.00	YASSINE	205361	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7688	1	2025-09-22	3249270.00	323.00	SORTIE	MAN 28659D1	\N	410	f	63376.00	CHOUAIB	205362	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7689	1	2025-09-23	3249403.00	133.00	SORTIE	MIT 4969A73	\N	409	f	953130.00	CHOUAIB	205363	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7690	1	2025-09-23	3249570.00	167.00	SORTIE	MIT 11470A73	\N	436	f	86542.00	MOHAMED	205364	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7692	1	2025-09-23	3249685.00	58.00	SORTIE	HYUNDAI 22772A73	\N	479	f	247932.00	ABDELMALEK	205366	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7693	1	2025-09-23	3250145.00	460.00	SORTIE	VOLVO 17885A73	\N	438	f	708056.00	HOUSSAM	205367	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7694	1	2025-09-23	3250173.00	28.00	SORTIE	HYUNDAI 18516A73	\N	471	f	326651.00	ABDELMALEK	205368	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7696	1	2025-09-23	3250225.00	29.00	SORTIE	LINDE	\N	434	f	7681.80	MILOUD	205370	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7697	1	2025-09-23	3250286.00	61.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	205371	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7698	1	2025-09-23	3250453.00	167.00	SORTIE	CHARGEUSE G 938	\N	413	f	7783.40	ABDERRAHIM	205372	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7699	1	2025-09-23	3250613.00	160.00	SORTIE	RENAULT 25636A13	\N	411	f	140867.00	YASSINE	205373	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7700	1	2025-09-23	3250784.00	171.00	SORTIE	MIT 4703A73	\N	408	f	577944.00	MUSTAPHA	205374	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7702	1	2025-09-24	3251735.00	426.00	SORTIE	VOLVO 17886A73	\N	439	f	682560.00	MJID	205376	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7703	1	2025-09-24	3251779.00	44.00	SORTIE	HYUNDAI 22368A73	\N	482	f	219736.00	BADER	205377	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7705	1	2025-09-24	3252135.00	206.00	SORTIE	MIT 11469A73	\N	435	f	941538.00	ABDELKHALEK	205379	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7706	1	2025-09-24	3252277.00	142.00	SORTIE	MIT 11470A73	\N	436	f	86996.00	MOHAMED	205380	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7707	1	2025-09-24	3252402.00	125.00	SORTIE	MIT 4969A73	\N	409	f	\N	CHOUAIB	205381	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7708	1	2025-09-24	3252444.00	42.00	SORTIE	LINDE	\N	472	f	11993.40	AZIZ	205382	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7709	1	2025-09-24	3252475.00	31.00	SORTIE	FENWICK	\N	430	f	27840.00	ABDELKHALEK	205383	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7710	1	2025-09-24	3252820.00	345.00	SORTIE	MAN 28659D1	\N	410	f	64362.00	CHOUAIB	205384	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7711	1	2025-09-24	3252938.00	118.00	SORTIE	MAN 4790B8	\N	403	f	975670.00	KARDODI	205385	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7712	1	2025-09-24	3252977.00	39.00	SORTIE	VOLVO 22300A73	\N	481	f	706464.00	MUSTAPHA	205386	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7713	1	2025-09-25	3253066.00	89.00	SORTIE	ISUZU 26128A8	\N	401	f	880042.00	TOUFIK	205387	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7715	1	2025-09-25	3253201.00	99.00	SORTIE	MIT 11469A73	\N	435	f	941907.00	ABDELKHALEK	205389	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7716	1	2025-09-25	3253361.00	160.00	SORTIE	MIT 11470A73	\N	436	f	87530.00	MOHAMED	205390	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7718	1	2025-09-25	3253856.00	186.00	SORTIE	RENAULT 25636A13	\N	411	f	141585.00	YASSINE	205392	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7719	1	2025-09-25	3253901.00	45.00	SORTIE	HYUNDAI 18516A73	\N	471	f	326938.00	ABDELMALEK	205393	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7721	1	2025-09-25	3254264.00	54.00	SORTIE	HYUNDAI 22772A73	\N	479	f	248313.00	ABDELMALEK	205395	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7723	1	2025-09-25	3254667.00	82.00	SORTIE	VOLVO 22300A73	\N	481	f	706776.00	MUSTAPHA	205397	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7724	1	2025-09-25	3254718.00	51.00	SORTIE	LINDE	\N	472	f	8970.30	CHAABI	205398	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7727	1	2025-09-26	3254926.00	25.00	SORTIE	BERLINGO 981A73	\N	417	f	300069.00	MAGHNIA	205401	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7728	1	2025-09-26	3254946.00	20.00	SORTIE	LINDE	\N	420	f	17831.00	ABDELKHALEK	205402	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7730	1	2025-09-26	3255219.00	216.00	SORTIE	MAN 28659D1	\N	410	f	64978.00	CHOUAIB	205404	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7731	1	2025-09-26	3255399.00	180.00	SORTIE	MIT 11469A73	\N	435	f	942546.00	ABDELKHALEK	205405	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7732	1	2025-09-26	3255445.00	46.00	SORTIE	LINDE	\N	472	f	11201.80	ABDELLAH	205406	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7733	1	2025-09-26	3255468.00	23.00	SORTIE	HYUNDAI 18516A73	\N	471	f	327099.00	ABDELMALEK	205407	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7736	1	2025-09-26	3255825.00	15.00	SORTIE	LINDE	\N	429	f	\N	MILOUD	205410	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7737	1	2025-09-26	3256427.00	602.00	SORTIE	VOLVO 17885A73	\N	438	f	709795.00	HOUSSAM	205411	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7739	1	2025-09-26	3256939.00	79.00	SORTIE	RENAULT 25636A13	\N	411	f	141840.00	YASSINE	205413	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7740	1	2025-09-26	3257265.00	325.00	SORTIE	VOLVO 17886A73	\N	439	f	683635.00	MJID	205414	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7741	1	2025-09-27	3257541.00	276.00	SORTIE	MAN 706A73	\N	407	f	136679.00	SOUFIANE	205415	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7742	1	2025-09-27	3257575.00	34.00	SORTIE	HYUNDAI 22368A73	\N	482	f	220178.00	BADER	205416	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7743	1	2025-09-27	3257635.00	60.00	SORTIE	MIT 11469A73	\N	435	f	942760.00	ABDELKHALEK	205417	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7744	1	2025-09-27	3257791.00	156.00	SORTIE	MIT 11470A73	\N	436	f	88049.00	MOHAMED	205418	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7746	1	2025-09-27	3257917.00	93.00	SORTIE	MANITOU	\N	484	f	5635.00	SAID	205420	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7747	1	2025-09-27	3257972.00	55.00	SORTIE	BERLINGO 10591A73	\N	433	f	377670.00	ABDESSLAM	205421	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7748	1	2025-09-27	3257991.00	19.00	SORTIE	HYUNDAI 18516A73	\N	471	f	327235.00	ABDELMALEK	205422	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7749	1	2025-09-27	3258191.00	200.00	SORTIE	VOLVO 22300A73	\N	481	f	707560.00	MUSTAPHA	205423	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7750	1	2025-09-27	3258233.00	42.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	205424	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7751	1	2025-09-27	3258421.00	188.00	SORTIE	CHARGEUSE G 938	\N	413	f	7799.70	ABDERRAHIM	205425	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7753	1	2025-09-27	3258480.00	36.00	SORTIE	LINDE	\N	472	f	12025.90	AZIZ	205427	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7754	1	2025-09-27	3258529.00	49.00	SORTIE	HYUNDAI 22772A73	\N	479	f	248656.00	ABDELMALEK	205428	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7755	1	2025-09-27	3258570.00	42.00	SORTIE	FENWICK	\N	430	f	2785.60	SAID	205429	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7756	1	2025-09-27	3258604.00	34.00	SORTIE	LINDE	\N	477	f	8984.30	CHAABI	205430	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7758	1	2025-09-29	3258682.00	41.00	SORTIE	HYUNDAI 18516A73	\N	471	f	327516.00	ABDELMALEK	205432	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7759	1	2025-09-29	3258884.00	202.00	SORTIE	MAN 28659D1	\N	410	f	65592.00	CHOUAIB	205433	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7761	1	2025-09-29	3259029.00	27.00	SORTIE	MIT 11470A73	\N	436	f	88129.00	MOHAMED	205435	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7762	1	2025-09-29	3259140.00	111.00	SORTIE	MIT 4969A73	\N	409	f	953130.00	THAMI	205436	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7763	1	2025-09-29	3259407.00	267.00	SORTIE	VOLVO 17886A73	\N	439	f	684448.00	MJID	205437	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7764	1	2025-09-29	3259431.00	24.00	SORTIE	LINDE	\N	429	f	\N	MILOUD	205438	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7765	1	2025-09-29	3259627.00	196.00	SORTIE	RENAULT 25636A13	\N	411	f	142566.00	YASSINE	205439	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7766	1	2025-09-29	3259796.00	169.00	SORTIE	MIT 4703A73	\N	408	f	578783.00	MUSTAPHA	205440	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7767	1	2025-09-29	3259839.00	44.00	SORTIE	LINDE	\N	472	f	12044.50	ABDELLAH	205441	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7769	1	2025-09-29	3260003.00	133.00	SORTIE	MAN 4790B8	\N	403	f	976169.00	KARDODI	205443	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7770	1	2025-09-29	3260088.00	85.00	SORTIE	ISUZU 26128A8	\N	401	f	880426.00	TOUFIK	205444	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7771	1	2025-09-29	3260235.00	147.00	SORTIE	VOLVO 22300A73	\N	481	f	708126.00	MUSTAPHA	205445	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7772	1	2025-09-30	3260280.00	45.00	SORTIE	HYUNDAI 18516A73	\N	471	f	327846.00	ABDELMALEK	205446	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7773	1	2025-09-30	3260337.00	57.00	SORTIE	HYUNDAI 22772A73	\N	479	f	249019.00	NOURDINE	205447	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7774	1	2025-09-30	3260482.00	145.00	SORTIE	MIT 4969A73	\N	409	f	\N	CHOUAIB	205448	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7775	1	2025-09-30	3260601.00	119.00	SORTIE	MIT 11470A73	\N	436	f	88558.00	MOHAMED	205449	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7776	1	2025-09-30	3260782.00	181.00	SORTIE	MIT 11469A73	\N	435	f	943417.00	ABDELKHALEK	205450	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7777	1	2025-09-30	3260819.00	37.00	SORTIE	LINDE	\N	477	f	8999.70	CHAABI	205451	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7778	1	2025-09-30	3260855.00	36.00	SORTIE	FENWICK	\N	430	f	27870.00	SAID	205452	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7779	1	2025-09-30	3261037.00	182.00	SORTIE	CHARGEUSE G 938	\N	413	f	7815.20	ABDERRAHIM	205453	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7781	1	2025-09-30	3261480.00	43.00	SORTIE	HYUNDAI 22368A73	\N	482	f	220686.00	BADER	205455	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7782	1	2025-09-30	3261639.00	159.00	SORTIE	VOLVO 22300A73	\N	481	f	708808.00	MUSTAPHA	205456	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7783	1	2025-10-01	3262214.00	575.00	SORTIE	VOLVO 17885A73	\N	438	f	711405.00	HOUSSAM	205457	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7784	1	2025-10-01	3262296.00	82.00	SORTIE	RENAULT 25636A13	\N	411	f	142867.00	YASSINE	205458	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7785	1	2025-10-01	3262317.00	21.00	SORTIE	LINDE	\N	434	f	7691.40	MILOUD	205459	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7787	1	2025-10-01	3262518.00	170.00	SORTIE	MIT 11470A73	\N	436	f	89147.00	MOHAMED	205461	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7790	1	2025-10-01	3263435.00	43.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	205464	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7791	1	2025-10-01	3263495.00	60.00	SORTIE	MIT 11470A73	\N	436	f	89359.00	MOHAMED	205465	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7792	1	2025-10-01	3263536.00	41.00	SORTIE	LINDE	\N	472	f	12062.00	ABDELLAH	205466	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7793	1	2025-10-01	3263581.00	45.00	SORTIE	HYUNDAI 18516A73	\N	471	f	328132.00	NOURDINE	205467	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7794	1	2025-10-02	3263670.00	88.00	SORTIE	VOLVO 70352A2	\N	406	f	508332.00	CHOUAIB	205468	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7795	1	2025-10-02	3263978.00	308.00	SORTIE	VOLVO 17886A73	\N	439	f	685571.00	MJID	205469	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7796	1	2025-10-02	3264008.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	220945.00	BADER	205470	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7798	1	2025-10-02	3264250.00	186.00	SORTIE	VOLVO 22300A73	\N	481	f	709473.00	MUSTAPHA	205472	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7800	1	2025-10-02	3264447.00	137.00	SORTIE	RENAULT 25636A13	\N	411	f	143419.00	YASSINE	205474	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7802	1	2025-10-02	3264816.00	74.00	SORTIE	MAN 4790B8	\N	403	f	976415.00	KARDODI	205476	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7803	1	2025-10-02	3264856.00	40.00	SORTIE	KANGO 4812A73	\N	419	f	241179.00	TARMOUNIA	205477	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7805	1	2025-10-02	3265224.00	321.00	SORTIE	MAN 28659D1	\N	410	f	66494.00	CHOUAIB	205479	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7806	1	2025-10-02	3265259.00	35.00	SORTIE	HYUNDAI 18516A73	\N	471	f	328386.00	NOURDINE	205480	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7808	1	2025-10-02	3265445.00	39.00	SORTIE	LINDE	\N	427	f	30207.00	JAWAD	205482	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7810	1	2025-10-03	3265978.00	221.00	SORTIE	MIT 11470A73	\N	436	f	90120.00	MOHAMED	205484	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7811	1	2025-10-03	3266097.00	119.00	SORTIE	MIT 11469A73	\N	435	f	943830.00	ABDELKHALEK	205485	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7813	1	2025-10-03	3266897.00	445.00	SORTIE	VOLVO 17885A73	\N	438	f	712715.00	HOUSSAM	205487	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7814	1	2025-10-03	3266929.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	328613.00	NOURDINE	205488	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7815	1	2025-10-03	3266979.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	249325.00	NOURDINE	205489	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7818	1	2025-10-03	3267080.00	38.00	SORTIE	LINDE	\N	472	f	12077.30	ABDELLAH	205492	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7819	1	2025-10-03	3267105.00	25.00	SORTIE	VOLVO 22300A73	\N	481	f	709501.00	MUSTAPHA	205493	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7820	1	2025-10-03	3267148.00	43.00	SORTIE	LINDE	\N	477	f	9018.00	ABDELKHALEK	205494	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7822	1	2025-10-03	3267803.00	42.00	SORTIE	FENWICK	\N	430	f	27886.00	ABDELKHALEK	205496	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7823	1	2025-10-03	3267967.00	164.00	SORTIE	VOLVO 17886A73	\N	439	f	686129.00	MJID	205497	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7824	1	2025-10-04	3268083.00	116.00	SORTIE	MAN 4790B8	\N	403	f	976874.00	KARDODI	205498	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7825	1	2025-10-04	3268116.00	33.00	SORTIE	HYUNDAI 22368A73	\N	482	f	221362.00	BADER	205499	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7826	1	2025-10-04	3268238.00	122.00	SORTIE	MIT 11469A73	\N	435	f	944263.00	ABDELKHALEK	205500	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7827	1	2025-10-04	3268424.00	186.00	SORTIE	CHARGEUSE G 938	\N	413	f	7831.20	ABDERRAHIM	207001	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7828	1	2025-10-04	3268708.00	284.00	SORTIE	MAN 28659D1	\N	410	f	67445.00	CHOUAIB	207002	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7829	1	2025-10-04	3268798.00	90.00	SORTIE	MANITOU	\N	484	f	5676.00	SAID	207003	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7832	1	2025-10-04	3269548.00	13.00	SORTIE	LINDE	\N	434	f	7697.80	MILOUD	207006	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7833	1	2025-10-04	3269588.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	328884.00	NOURDINE	207007	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7834	1	2025-10-04	3269763.00	175.00	SORTIE	VOLVO 22300A73	\N	481	f	710164.00	MUSTAPHA	207008	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7835	1	2025-10-06	3269905.00	142.00	SORTIE	MIT 11469A73	\N	435	f	944718.00	ABDELKHALEK	207009	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7836	1	2025-10-06	3270088.00	183.00	SORTIE	MAN 28659D1	\N	410	f	67991.00	CHOUAIB	207010	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7837	1	2025-10-06	3270212.00	124.00	SORTIE	MIT 11470A73	\N	436	f	90549.00	MOHAMED	207011	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7838	1	2025-10-06	3270258.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	249591.00	NOURDINE	207012	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7840	1	2025-10-06	3270475.00	49.00	SORTIE	VOLVO 70352A2	\N	406	f	508397.00	CHOUAIB	207014	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7841	1	2025-10-06	3270569.00	94.00	SORTIE	VOLVO 22300A73	\N	481	f	710494.00	MUSTAPHA	207015	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7842	1	2025-10-06	3270613.00	44.00	SORTIE	HYUNDAI 18516A73	\N	471	f	329221.00	ABDELMALEK	207016	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7843	1	2025-10-06	3270646.00	33.00	SORTIE	FENWICK	\N	430	f	27899.00	ABDELKHALEK	207017	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7845	1	2025-10-06	3271893.00	246.00	SORTIE	MAN 706A73	\N	407	f	137350.00	SOUFIANE	207019	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7846	1	2025-10-07	3272286.00	393.00	SORTIE	VOLVO 17885A73	\N	438	f	713796.00	HOUSSAM	207020	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7847	1	2025-10-07	3272505.00	219.00	SORTIE	MIT 11470A73	\N	436	f	91326.00	MOHAMED	207021	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7848	1	2025-10-07	3272596.00	91.00	SORTIE	ISUZU 26128A8	\N	401	f	880884.00	TOUFIK	207022	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7849	1	2025-10-07	3272626.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	221720.00	BADER	207023	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7850	1	2025-10-07	3272665.00	39.00	SORTIE	LINDE	\N	477	f	9033.70	CHAABI	207024	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7851	1	2025-10-07	3272717.00	52.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	207025	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7852	1	2025-10-07	3272848.00	131.00	SORTIE	MIT 11469A73	\N	435	f	945188.00	ABDELKHALEK	207026	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7854	1	2025-10-07	3273016.00	128.00	SORTIE	VOLVO 22300A73	\N	481	f	710996.00	MUSTAPHA	207028	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7855	1	2025-10-07	3273036.00	20.00	SORTIE	HYUNDAI 18516A73	\N	471	f	329349.00	ABDELMALEK	207029	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7856	1	2025-10-07	3273084.00	48.00	SORTIE	LINDE	\N	472	f	12097.10	ABDELLAH	207030	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7857	1	2025-10-07	3273508.00	424.00	SORTIE	VOLVO 17886A73	\N	439	f	687457.00	MJID	207031	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7858	1	2025-10-07	3273720.00	212.00	SORTIE	CHARGEUSE G 938	\N	413	f	7848.50	ABDERRAHIM	207032	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7859	1	2025-10-07	3273832.00	112.00	SORTIE	MAN 4790B8	\N	403	f	977288.00	KARDODI	207033	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7860	1	2025-10-07	3274003.00	171.00	SORTIE	MAN 28659D1	\N	410	f	68576.00	CHOUAIB	207034	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7863	1	2025-10-07	3274470.00	83.00	SORTIE	VOLVO 22300A73	\N	481	f	711283.00	MUSTAPHA	207037	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7864	1	2025-10-08	3274636.00	166.00	SORTIE	MIT 11470A73	\N	436	f	91877.00	MOHAMED	207038	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7865	1	2025-10-08	3274823.00	187.00	SORTIE	MIT 11469A73	\N	435	f	945874.00	ABDELKHALEK	207039	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7866	1	2025-10-08	3274843.00	20.00	SORTIE	HYUNDAI 22368A73	\N	482	f	221993.00	BADER	207040	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7867	1	2025-10-08	3274862.00	19.00	SORTIE	HYUNDAI 18516A73	\N	471	f	329483.00	ABDELMALEK	207041	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7870	1	2025-10-08	3275265.00	230.00	SORTIE	VOLVO 22299A73	\N	480	f	618542.00	THAMI	207044	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7872	1	2025-10-08	3275973.00	208.00	SORTIE	VOLVO 17885A73	\N	438	f	714180.00	HOUSSAM	207046	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7873	1	2025-10-08	3275992.00	19.00	SORTIE	LINDE	\N	434	f	7706.70	MILOUD	207047	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7874	1	2025-10-08	3276053.00	61.00	SORTIE	BERLINGO 10591A73	\N	433	f	379175.00	ABDESSLAM	207048	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7876	1	2025-10-09	3276535.00	168.00	SORTIE	MIT 11470A73	\N	436	f	92453.00	MOHAMED	207050	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7877	1	2025-10-09	3276719.00	184.00	SORTIE	VOLVO 22300A73	\N	481	f	712000.00	MUSTAPHA	207051	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7878	1	2025-10-09	3276830.00	111.00	SORTIE	MIT 11469A73	\N	435	f	946268.00	ABDELKHALEK	207052	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7879	1	2025-10-09	3277021.00	191.00	SORTIE	RENAULT 25636A13	\N	411	f	144171.00	YASSINE	207053	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7881	1	2025-10-09	3277172.00	111.00	SORTIE	MAN 28659D1	\N	410	f	68893.00	CHOUAIB	207055	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7882	1	2025-10-09	3277522.00	350.00	SORTIE	VOLVO 17886A73	\N	439	f	688648.00	MJID	207056	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7883	1	2025-10-09	3277573.00	51.00	SORTIE	HYUNDAI 22772A73	\N	479	f	249946.00	NOURDINE	207057	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7884	1	2025-10-09	3277611.00	38.00	SORTIE	LINDE	\N	477	f	9049.00	CHAABI	207058	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7885	1	2025-10-09	3277655.00	44.00	SORTIE	FENWICK	\N	430	f	27915.00	SAID	207059	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7887	1	2025-10-10	3277740.00	48.00	SORTIE	VOLVO 22300A73	\N	481	f	712133.00	MUSTAPHA	207061	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7888	1	2025-10-10	3277782.00	42.00	SORTIE	HYUNDAI 18516A73	\N	471	f	329787.00	ABDELMALEK	207062	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7889	1	2025-10-10	3277934.00	152.00	SORTIE	MIT 11469A73	\N	435	f	946821.00	ABDELKHALEK	207063	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7891	1	2025-10-10	3278484.00	411.00	SORTIE	VOLVO 17885A73	\N	438	f	715492.00	HOUSSAM	207065	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7894	1	2025-10-10	3279176.00	58.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	207068	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7895	1	2025-10-10	3279377.00	201.00	SORTIE	CHARGEUSE G 938	\N	413	f	7865.80	ABDERRAHIM	207069	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7896	1	2025-10-10	3279458.00	81.00	SORTIE	MANITOU	\N	484	f	5715.00	SAID	207070	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7897	1	2025-10-10	3279479.00	21.00	SORTIE	KANGO 4812A73	\N	419	f	241733.00	TARMOUNIA	207071	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7898	1	2025-10-10	3279661.00	182.00	SORTIE	VOLVO 22299A73	\N	480	f	619146.00	THAMI	207072	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7899	1	2025-10-10	3279701.00	40.00	SORTIE	LINDE	\N	472	f	12115.90	ABDELLAH	207073	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7900	1	2025-10-11	3279791.00	90.00	SORTIE	ISUZU 26128A8	\N	401	f	881381.00	TOUFIK	207074	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7901	1	2025-10-11	3279928.00	137.00	SORTIE	VOLVO 22300A73	\N	481	f	712682.00	MUSTAPHA	207075	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7902	1	2025-10-11	3280188.00	260.00	SORTIE	MAN 28659D1	\N	410	f	69752.00	CHOUAIB	207076	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7903	1	2025-10-11	3280229.00	41.00	SORTIE	HYUNDAI 22368A73	\N	482	f	222396.00	BADER	207077	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7905	1	2025-10-11	3280416.00	127.00	SORTIE	VOLVO 70352A2	\N	406	f	508660.00	CHOUAIB	207079	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7906	1	2025-10-11	3280541.00	125.00	SORTIE	MIT 11470A73	\N	436	f	92865.00	MOHAMED	207080	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7908	1	2025-10-11	3280596.00	28.00	SORTIE	HYUNDAI 18516A73	\N	471	f	329959.00	ABDELMALEK	207082	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7909	1	2025-10-11	3280713.00	117.00	SORTIE	MIT 11469A73	\N	435	f	947250.00	CHOUAIB	207083	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7911	1	2025-10-11	3280977.00	221.00	SORTIE	MIT 4703A73	\N	408	f	579744.00	MUSTAPHA	207085	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7913	1	2025-10-11	3281024.00	30.00	SORTIE	LINDE	\N	427	f	30214.00	MILOUD	207087	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7914	1	2025-10-11	3281057.00	33.00	SORTIE	LINDE	\N	477	f	9062.80	CHAABI	207088	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7915	1	2025-10-11	3281187.00	130.00	SORTIE	MAN 4790B8	\N	403	f	977748.00	KARDODI	207089	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7916	1	2025-10-11	3281208.00	21.00	SORTIE	LINDE	\N	472	f	12124.10	ABDELLAH	207090	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7917	1	2025-10-13	3281416.00	208.00	SORTIE	VOLVO 22300A73	\N	481	f	713463.00	MUSTAPHA	207091	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7919	1	2025-10-13	3282403.00	284.00	SORTIE	VOLVO 17886A73	\N	439	f	689638.00	MJID	207093	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7920	1	2025-10-13	3282427.00	24.00	SORTIE	RENAULT 25636A13	\N	411	f	144221.00	YASSINE	207094	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7921	1	2025-10-13	3282472.00	45.00	SORTIE	MIT 11469A73	\N	435	f	947409.00	ABDELKHALEK	207095	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7922	1	2025-10-13	3282645.00	173.00	SORTIE	VOLVO 22299A73	\N	480	f	619760.00	THAMI	207096	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7924	1	2025-10-13	3282979.00	45.00	SORTIE	LINDE	\N	472	f	12136.90	ABDELLAH	207098	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7925	1	2025-10-13	3283278.00	299.00	SORTIE	VOLVO 17885A73	\N	438	f	716384.00	HOUSSAM	207099	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7927	1	2025-10-13	3283466.00	49.00	SORTIE	FENWICK	\N	430	f	27935.00	ABDELKHALEK	207101	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7928	1	2025-10-13	3283631.00	165.00	SORTIE	MIT 11470A73	\N	436	f	93414.00	MOHAMED	207102	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7929	1	2025-10-13	3283679.00	48.00	SORTIE	HYUNDAI 22772A73	\N	479	f	250229.00	NOURDINE	207103	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7930	1	2025-10-13	3283719.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	330245.00	ABDELMALEK	207104	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7931	1	2025-10-14	3283894.00	175.00	SORTIE	RENAULT 25636A13	\N	411	f	144909.00	YASSINE	207105	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7933	1	2025-10-14	3284002.00	60.00	SORTIE	VOLVO 22300A73	\N	481	f	713579.00	MUSTAPHA	207107	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7935	1	2025-10-14	3284888.00	185.00	SORTIE	CHARGEUSE G 938	\N	413	f	7882.20	ABDERRAHIM	207109	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7937	1	2025-10-14	3284983.00	34.00	SORTIE	LINDE	\N	472	f	12151.10	AZIZ	207111	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7938	1	2025-10-14	3285014.00	31.00	SORTIE	HYUNDAI 18516A73	\N	471	f	330442.00	ABDELMALEK	207112	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7939	1	2025-10-14	3285073.00	59.00	SORTIE	RENAULT 25636A13	\N	411	f	145140.00	YASSINE	207113	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7940	1	2025-10-14	3285106.00	33.00	SORTIE	HYUNDAI 22368A73	\N	482	f	222833.00	BADER	207114	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7941	1	2025-10-14	3285364.00	258.00	SORTIE	MAN 28659D1	\N	410	f	70522.00	CHOUAIB	207115	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7942	1	2025-10-14	3285404.00	40.00	SORTIE	LINDE	\N	477	f	9080.00	CHAABI	207116	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7945	1	2025-10-14	3285577.00	121.00	SORTIE	VOLVO 22299A73	\N	480	f	620190.00	THAMI	207119	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7946	1	2025-10-14	3285838.00	261.00	SORTIE	MAN 706A73	\N	407	f	137971.00	SOUFIANE	207120	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7947	1	2025-10-15	3285917.00	78.00	SORTIE	VOLVO 22300A73	\N	481	f	713930.00	MUSTAPHA	207121	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7948	1	2025-10-15	3286005.00	88.00	SORTIE	MIT 11470A73	\N	436	f	93717.00	MOHAMED	207122	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7949	1	2025-10-15	3286134.00	129.00	SORTIE	MIT 11469A73	\N	435	f	947835.00	ABDELKHALEK	207123	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7950	1	2025-10-15	3286164.00	30.00	SORTIE	HYUNDAI 18516A73	\N	471	f	330630.00	ABDELMALEK	207124	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7951	1	2025-10-15	3286206.00	42.00	SORTIE	HYUNDAI 22772A73	\N	479	f	250522.00	ABDELMALEK	207125	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7952	1	2025-10-15	3286241.00	35.00	SORTIE	VOLVO 22300A73	\N	481	f	713996.00	MUSTAPHA	207126	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7954	1	2025-10-15	3286367.00	80.00	SORTIE	ISUZU 26128A8	\N	401	f	881791.00	TOUFIK	207128	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7955	1	2025-10-16	3286593.00	226.00	SORTIE	MAN 28659D1	\N	410	f	71138.00	CHOUAIB	207129	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7956	1	2025-10-16	3286754.00	161.00	SORTIE	MIT 11469A73	\N	435	f	948406.00	ABDELKHALEK	207130	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7957	1	2025-10-16	3286932.00	178.00	SORTIE	RENAULT 25636A13	\N	411	f	145763.00	YASSINE	207131	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7959	1	2025-10-16	3287515.00	73.00	SORTIE	MANITOU	\N	484	f	5748.00	SAID	207133	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7960	1	2025-10-16	3287651.00	136.00	SORTIE	MIT 11470A73	\N	436	f	94226.00	MOHAMED	207134	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7961	1	2025-10-16	3287813.00	162.00	SORTIE	VOLVO 22299A73	\N	480	f	620731.00	THAMI	207135	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7964	1	2025-10-16	3288459.00	147.00	SORTIE	MAN 4790B8	\N	403	f	978286.00	KARDODI	207138	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7965	1	2025-10-16	3288486.00	27.00	SORTIE	HYUNDAI 18516A73	\N	471	f	330808.00	ABDELMALEK	207139	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7966	1	2025-10-16	3288545.00	58.00	SORTIE	BERLINGO 10591A73	\N	433	f	380671.00	ABDESSLAM	207140	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7967	1	2025-10-16	3288621.00	76.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	207141	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7968	1	2025-10-16	3288674.00	53.00	SORTIE	MIT 11469A73	\N	435	f	948587.00	ABDELKHALEK	207142	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7969	1	2025-10-16	3288728.00	54.00	SORTIE	FENWICK	\N	430	f	27955.00	CHAABI	207143	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7970	1	2025-10-16	3288759.00	31.00	SORTIE	LINDE	\N	477	f	9093.30	CHAABI	207144	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7971	1	2025-10-16	3288802.00	43.00	SORTIE	LINDE	\N	472	f	12168.50	AZIZ	207145	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7972	1	2025-10-16	3288877.00	75.00	SORTIE	VOLVO 22300A73	\N	481	f	714299.00	MUSTAPHA	207146	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7974	1	2025-10-16	3288941.00	32.00	SORTIE	HYUNDAI 2238	\N	482	f	223123.00	BADER	207148	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7975	1	2025-10-16	3289512.00	571.00	SORTIE	VOLVO 17885A73	\N	438	f	718059.00	HOUSSAM	207149	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7976	1	2025-10-17	3289682.00	170.00	SORTIE	RENAULT 25636A13	\N	411	f	146468.00	YASSINE	207150	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7977	1	2025-10-17	3289870.00	188.00	SORTIE	MIT 11470A73	\N	436	f	94882.00	MOHAMED	207151	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7978	1	2025-10-17	3289882.00	12.00	SORTIE	KANGO 4812A73	\N	419	f	242069.00	TARMOUNIA	207152	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7980	1	2025-10-17	3290347.00	159.00	SORTIE	MAN 28659D1	\N	410	f	71687.00	CHOUAIB	207154	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7982	1	2025-10-17	3290564.00	42.00	SORTIE	HYUNDAI 22772A73	\N	479	f	2508111.00	ABDELMALEK	207156	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7983	1	2025-10-17	3290589.00	25.00	SORTIE	HYUNDAI 18516A73	\N	471	f	331002.00	ABDELMALEK	207157	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7984	1	2025-10-17	3290711.00	122.00	SORTIE	MIT 4703A73	\N	408	f	580339.00	MUSTAPHA	207158	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7986	1	2025-10-18	3290867.00	141.00	SORTIE	MIT 11469A73	\N	435	f	949102.00	ABDELKHALEK	207160	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7987	1	2025-10-18	3290896.00	29.00	SORTIE	BERLINGO 981A73	\N	417	f	300428.00	MAGHNIA	207161	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7988	1	2025-10-18	3291109.00	213.00	SORTIE	VOLVO 22299A73	\N	480	f	621527.00	THAMI	207162	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7989	1	2025-10-18	3291136.00	27.00	SORTIE	HYUNDAI 22368A73	\N	482	f	223452.00	BADER	207163	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7991	1	2025-10-18	3291244.00	76.00	SORTIE	MIT 11470A73	\N	436	f	95123.00	MOHAMED	207165	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7993	1	2025-10-18	3291528.00	134.00	SORTIE	VOLVO 22300A73	\N	481	f	714910.00	MUSTAPHA	207167	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7995	1	2025-10-18	3291630.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	331207.00	ABDELMALEK	207169	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7996	1	2025-10-18	3291656.00	26.00	SORTIE	LINDE	\N	477	f	9104.00	CHAABI	207170	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7997	1	2025-10-18	3291702.00	45.00	SORTIE	LINDE	\N	472	f	12186.90	AZIZ	207171	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
7998	1	2025-10-18	3291792.00	90.00	SORTIE	ISUZU 26128A8	\N	401	f	882292.00	TOUFIK	207172	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8000	1	2025-10-20	3291946.00	116.00	SORTIE	MIT 11470A73	\N	436	f	95543.00	MOHAMED	207174	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8001	1	2025-10-20	3292210.00	264.00	SORTIE	MAN 28659D1	\N	410	f	72157.00	CHOUAIB	207175	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8002	1	2025-10-20	3292403.00	193.00	SORTIE	CHARGEUSE G 938	\N	413	f	\N	ABDERRAHIM	207176	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8003	1	2025-10-20	3292600.00	197.00	SORTIE	VOLVO 70352A2	\N	406	f	509006.00	KARMY	207177	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8004	1	2025-10-20	3292780.00	180.00	SORTIE	VOLVO 22299A73	\N	480	f	622224.00	THAMI	207178	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8005	1	2025-10-20	3292849.00	69.00	SORTIE	MIT 11469A73	\N	435	f	949329.00	ABDELKHALEK	207179	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8007	1	2025-10-20	3292990.00	83.00	SORTIE	RENAULT 25636A13	\N	411	f	146777.00	YASSINE	207181	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8008	1	2025-10-20	3293435.00	445.00	SORTIE	VOLVO 17885A73	\N	438	f	719324.00	HOUSSAM	207182	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8009	1	2025-10-20	3293491.00	56.00	SORTIE	HYUNDAI 22772A73	\N	479	f	251181.00	NOURDINE	207183	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8010	1	2025-10-20	3293521.00	30.00	SORTIE	HYUNDAI 18516A73	\N	471	f	331422.00	NOURDINE	207184	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8012	1	2025-10-20	3293609.00	45.00	SORTIE	FENWICK	\N	430	f	\N	ABDELKHALEK	207186	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8014	1	2025-10-20	3293668.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	223752.00	BADER	207188	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8015	1	2025-10-21	3293841.00	173.00	SORTIE	MIT 11469A73	\N	435	f	949983.00	ABDELKHALEK	207189	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8016	1	2025-10-21	3293956.00	115.00	SORTIE	RENAULT 25636A13	\N	411	f	147809.00	YASSINE	207190	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8017	1	2025-10-21	3294156.00	200.00	SORTIE	VOLVO 22300A73	\N	481	f	715532.00	MUSTAPHA	207191	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8018	1	2025-10-21	3294210.00	54.00	SORTIE	MIT 11470A73	\N	436	f	95789.00	MOHAMED	207192	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8019	1	2025-10-22	3294448.00	238.00	SORTIE	VOLVO 17885A73	\N	438	f	720008.00	HOUSSAM	207196	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8020	1	2025-10-22	3294591.00	143.00	SORTIE	MIT 11470A73	\N	436	f	96202.00	MOHAMED	207197	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8021	1	2025-10-22	3294628.00	37.00	SORTIE	HYUNDAI 18516A73	\N	471	f	331907.00	NOURDINE	207198	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8022	1	2025-10-22	3294815.00	187.00	SORTIE	RENAULT 25636A13	\N	411	f	147916.00	YASSINE	207199	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8023	1	2025-10-22	3294889.00	74.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	207200	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8024	1	2025-10-22	3295145.00	256.00	SORTIE	MAN 28659D1	\N	410	f	73384.00	CHOUAIB	207201	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8026	1	2025-10-22	3295304.00	122.00	SORTIE	MAN 4790B8	\N	403	f	978713.00	KARDODI	207203	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8027	1	2025-10-22	3295396.00	92.00	SORTIE	MANITOU	\N	484	f	5792.00	SAID	207204	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8029	1	2025-10-23	3295813.00	89.00	SORTIE	MIT 11469A73	\N	435	f	950287.00	ABDELKHALEK	207206	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8030	1	2025-10-23	3296012.00	198.00	SORTIE	VOLVO 22300A73	\N	481	f	716228.00	MUSTAPHA	207207	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8032	1	2025-10-23	3296932.00	245.00	SORTIE	VOLVO 22299A73	\N	480	f	623123.00	THAMI	207209	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8034	1	2025-10-23	3297110.00	63.00	SORTIE	BERLINGO 10591A73	\N	433	f	381831.00	ABDESSLAM	207211	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8035	1	2025-10-23	3297596.00	486.00	SORTIE	VOLVO 17886A73	\N	439	f	691382.00	MJID	207212	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8038	1	2025-10-23	3298227.00	35.00	SORTIE	HYUNDAI 22368A73	\N	482	f	224184.00	BADER	207215	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8039	1	2025-10-23	3298274.00	47.00	SORTIE	VOLVO 22300A73	\N	481	f	716430.00	MUSTAPHA	207216	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8040	1	2025-10-23	3298312.00	38.00	SORTIE	LINDE	\N	472	f	12218.20	AZIZ	207217	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8041	1	2025-10-23	3298352.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	332171.00	NOURDINE	207218	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8043	1	2025-10-24	3299249.00	47.00	SORTIE	HYUNDAI 22772A73	\N	479	f	251471.00	NOURDINE	207220	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8045	1	2025-10-24	3299326.00	41.00	SORTIE	MIT 11469A73	\N	435	f	950410.00	ABDELKHALEK	207222	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8046	1	2025-10-24	3299523.00	197.00	SORTIE	MIT 11470A73	\N	436	f	96847.00	MOHAMED	207223	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8047	1	2025-10-24	3299623.00	100.00	SORTIE	ISUZU 26128A8	\N	401	f	882810.00	TOUFIK	207224	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8051	1	2025-10-24	3300204.00	220.00	SORTIE	VOLVO 22299A73	\N	480	f	623908.00	THAMI	207228	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8052	1	2025-10-24	3300500.00	296.00	SORTIE	MAN 706A73	\N	407	f	138711.00	SOUFIANE	207229	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8053	1	2025-10-24	3300909.00	409.00	SORTIE	VOLVO 17885A73	\N	438	f	721227.00	HASSAN	207230	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8054	1	2025-10-24	3301113.00	204.00	SORTIE	CHARGEUSE G 938	\N	413	f	7932.70	ABDERRAHIM	207231	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8055	1	2025-10-24	3301165.00	52.00	SORTIE	FENWICK	\N	430	f	27991.70	ABDELKHALEK	207232	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8056	1	2025-10-24	3301185.00	20.00	SORTIE	KANGO 4812A73	\N	419	f	242436.00	TARMOUNIA	207233	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8058	1	2025-10-24	3301270.00	46.00	SORTIE	LINDE	\N	477	f	9138.70	ABDELKHALEK	207235	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8059	1	2025-10-24	3301312.00	42.00	SORTIE	LINDE	\N	428	f	4059.30	HASSAN	207236	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8061	1	2025-10-24	3301685.00	27.00	SORTIE	HYUNDAI 18516A73	\N	471	f	332339.00	NOURDINE	207238	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8062	1	2025-10-25	3302001.00	316.00	SORTIE	MAN 28659D1	\N	410	f	74451.00	CHOUAIB	207239	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8063	1	2025-10-25	3302161.00	160.00	SORTIE	MIT 4703A73	\N	408	f	581061.00	MUSTAPHA	207240	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8064	1	2025-10-25	3302183.00	22.00	SORTIE	HYUNDAI 22368A73	\N	482	f	224462.00	BADER	207241	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8065	1	2025-10-25	3302382.00	199.00	SORTIE	RENAULT 25636A13	\N	411	f	148711.00	YASSINE	207242	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8067	1	2025-10-25	3302557.00	120.00	SORTIE	MIT 11469A73	\N	435	f	950853.00	ABDELKHALEK	207244	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8068	1	2025-10-25	3302681.00	124.00	SORTIE	VOLVO 22300A73	\N	481	f	716912.00	MUSTAPHA	207245	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8069	1	2025-10-25	3302828.00	147.00	SORTIE	VOLVO 22299A73	\N	480	f	624436.00	THAMI	207246	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8070	1	2025-10-25	3302891.00	63.00	SORTIE	VOLVO 22300A73	\N	481	f	717155.00	MUSTAPHA	207247	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8071	1	2025-10-25	3302936.00	45.00	SORTIE	VOLVO 70352A2	\N	406	f	509435.00	HAKIM	207248	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8073	1	2025-10-25	3303351.00	400.00	SORTIE	VOLVO 17886A73	\N	439	f	692614.00	MJID	207250	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8074	1	2025-10-25	3303395.00	44.00	SORTIE	LINDE	\N	472	f	12235.90	AZIZ	207251	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8076	1	2025-10-25	3303447.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	332560.00	HAMID	207253	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8077	1	2025-10-27	3303867.00	420.00	SORTIE	VOLVO 17885A73	\N	438	f	722300.00	HOUSSAM	207254	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8078	1	2025-10-27	3304017.00	150.00	SORTIE	MIT 11470A73	\N	436	f	97352.00	KARDODI	207255	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8079	1	2025-10-27	3304184.00	167.00	SORTIE	MAN 28659D1	\N	410	f	74998.00	CHOUAIB	207256	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8080	1	2025-10-27	3304272.00	88.00	SORTIE	MIT 11469A73	\N	435	f	951147.00	ABDELKHALEK	207257	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8081	1	2025-10-27	3304294.00	22.00	SORTIE	VOLVO 22300A73	\N	481	f	717230.00	MUSTAPHA	207258	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8082	1	2025-10-27	3304494.00	200.00	SORTIE	VOLVO 70352A2	\N	406	f	509486.00	CHOUAIB	207259	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8084	1	2025-10-27	3304748.00	104.00	SORTIE	RENAULT 25636A13	\N	411	f	149095.00	YASSINE	207261	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8085	1	2025-10-27	3304759.00	11.00	SORTIE	LINDE	\N	434	f	\N	MILOUD	207262	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8086	1	2025-10-27	3304799.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	332847.00	ABDELMALEK	207263	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8087	1	2025-10-27	3304832.00	33.00	SORTIE	FENWICK	\N	430	f	28003.00	HASSAN	207264	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8088	1	2025-10-27	3304877.00	45.00	SORTIE	LINDE	\N	472	f	\N	ABDELLAH	207265	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8091	1	2025-10-27	3305094.00	143.00	SORTIE	VOLVO 22299A73	\N	480	f	624936.00	THAMI	207268	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8092	1	2025-10-27	3305143.00	49.00	SORTIE	HYUNDAI 22368A73	\N	482	f	225011.00	BADER	207269	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8093	1	2025-10-28	3305281.00	138.00	SORTIE	RENAULT 25636A13	\N	411	f	149657.00	YASSINE	207270	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8094	1	2025-10-28	3305330.00	49.00	SORTIE	MIT 11470A73	\N	436	f	97489.00	MOHAMED	207271	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8096	1	2025-10-28	3305903.00	143.00	SORTIE	VOLVO 22300A73	\N	481	f	717770.00	MUSTAPHA	207273	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8097	1	2025-10-28	3306176.00	273.00	SORTIE	VOLVO 17886A73	\N	439	f	693623.00	MJID	207274	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8098	1	2025-10-28	3306195.00	19.00	SORTIE	HYUNDAI 18516A73	\N	471	f	332991.00	ABDELMALEK	207275	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8099	1	2025-10-28	3306442.00	247.00	SORTIE	MAN 28659D1	\N	410	f	75791.00	CHOUAIB	207276	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8100	1	2025-10-28	3306487.00	45.00	SORTIE	LINDE	\N	472	f	9156.70	CHAABI	207277	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8101	1	2025-10-28	3306688.00	201.00	SORTIE	CHARGEUSE G 938	\N	413	f	7949.80	ABDERRAHIM	207278	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8102	1	2025-10-28	3306973.00	285.00	SORTIE	VOLVO 17885A73	\N	438	f	723163.00	HOUSSAM	207279	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8103	1	2025-10-29	3307060.00	87.00	SORTIE	ISUZU 26128A8	\N	401	f	883261.00	TOUFIK	207280	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8104	1	2025-10-29	3307150.00	90.00	SORTIE	VOLVO 22300A73	\N	481	f	718119.00	MUSTAPHA	207281	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8105	1	2025-10-29	3307247.00	97.00	SORTIE	VOLVO 70352A2	\N	406	f	509697.00	CHOUAIB	207282	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8106	1	2025-10-29	3307270.00	23.00	SORTIE	BERLINGO 981A73	\N	417	f	300686.00	MAGHNIA	207283	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8107	1	2025-10-29	3307338.00	68.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	207284	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8109	1	2025-10-29	3308063.00	150.00	SORTIE	MIT 11470A73	\N	436	f	98022.00	MOHAMED	207286	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8110	1	2025-10-29	3308180.00	117.00	SORTIE	MIT 11469A73	\N	435	f	951627.00	ABDELKHALEK	207287	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8112	1	2025-10-29	3308489.00	190.00	SORTIE	VOLVO 22299A73	\N	480	f	625625.00	THAMI	207289	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8113	1	2025-10-29	3308532.00	43.00	SORTIE	LINDE	\N	472	f	122711.30	ABDELLAH	207290	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8114	1	2025-10-29	3308689.00	157.00	SORTIE	MIT 4969A73	\N	409	f	953292.00	CHOUAIB	207291	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8116	1	2025-10-29	3310776.00	87.00	SORTIE	MANITOU	\N	484	f	5832.00	SAID	207293	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8118	1	2025-10-29	3310873.00	58.00	SORTIE	HYUNDAI 22772A73	\N	479	f	251810.00	NOURDINE	207295	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8119	1	2025-10-29	3310901.00	28.00	SORTIE	HYUNDAI 18516A73	\N	471	f	333169.00	ABDELMALEK	207296	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8120	1	2025-10-30	3311079.00	175.00	SORTIE	MIT 11470A73	\N	436	f	98648.00	MOHAMED	207297	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8121	1	2025-10-30	3311289.00	210.00	SORTIE	MIT 11469A73	\N	435	f	952309.00	ABDELKHALEK	207298	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8122	1	2025-10-30	3311321.00	32.00	SORTIE	HYUNDAI 22368A73	\N	482	f	225432.00	BADR	207299	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8123	1	2025-10-30	3311516.00	195.00	SORTIE	RENAULT 25636A13	\N	411	f	150403.00	YASSINE	207300	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8124	1	2025-10-30	3311643.00	127.00	SORTIE	VOLVO 22300A73	\N	481	f	718559.00	MUSTAPHA	207301	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8127	1	2025-10-30	3312308.00	364.00	SORTIE	VOLVO 17886A73	\N	439	f	694827.00	ABDELMJID	207304	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8128	1	2025-10-30	3312357.00	49.00	SORTIE	FENWICK	\N	430	f	38021.00	SAID	207305	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8129	1	2025-10-30	3312387.00	30.00	SORTIE	LINDE	\N	477	f	9169.50	CHAABI	207306	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8130	1	2025-10-30	3312472.00	84.00	SORTIE	VOLVO 22300A73	\N	481	f	718853.00	MUSTAPHA	207307	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8132	1	2025-10-31	3312730.00	222.00	SORTIE	VOLVO 22299A73	\N	480	f	626431.00	THAMI	207309	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8133	1	2025-10-31	3312805.00	75.00	SORTIE	MIT 11469A73	\N	435	f	952551.00	ABDELKHALEK	207310	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8134	1	2025-10-31	3312865.00	60.00	SORTIE	MIT 11470A73	\N	436	f	98828.00	MOHAMED	207311	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8135	1	2025-10-31	3312898.00	34.00	SORTIE	LINDE	\N	434	f	7730.00	MILOUD	207312	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8136	1	2025-10-31	3313076.00	178.00	SORTIE	CHARGEUSE G 938	\N	413	f	7964.50	ABDERRAHIM	207313	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8137	1	2025-10-31	3313100.00	24.00	SORTIE	LINDE	\N	428	f	4059.00	HASSAN	207314	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8138	1	2025-10-31	3313151.00	51.00	SORTIE	HYUNDAI 18516A73	\N	471	f	333499.00	ABDELMALEK	207315	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8141	1	2025-10-31	3313544.00	50.00	SORTIE	LINDE	\N	472	f	12292.40	ABDELLAH	207318	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8143	1	2025-10-31	3313665.00	84.00	SORTIE	ISUZU 26128A8	\N	401	f	883725.00	TOUFK	207320	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8144	1	2025-10-31	3313695.00	30.00	SORTIE	VOLVO 22299A73	\N	480	f	626507.00	THAMI	207321	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8145	1	2025-10-31	3313902.00	207.00	SORTIE	VOLVO 22300A73	\N	481	f	716765.00	MUSTAPHA	207322	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8146	1	2025-11-01	3313932.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	225753.00	BADR	208323	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8148	1	2025-11-01	3314374.00	134.00	SORTIE	MIT 11470A73	\N	436	f	99328.00	MOHAMED	208325	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8149	1	2025-11-01	3314554.00	180.00	SORTIE	MIT 11469A73	\N	435	f	953203.00	ABDELKHALEK	208326	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8152	1	2025-11-01	3315133.00	110.00	SORTIE	MIT 4969A73	\N	409	f	953576.00	CHOUAIB	208329	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8154	1	2025-11-01	3315225.00	30.00	SORTIE	KANGO 4812A73	\N	419	f	242814.00	TARMONIA	208331	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8156	1	2025-11-01	3315866.00	156.00	SORTIE	MIT 4703A73	\N	408	f	581753.00	MUSTAPHA	208333	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8158	1	2025-11-01	3315916.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	333723.00	ABDELMALEK	208335	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8159	1	2025-11-01	3315939.00	23.00	SORTIE	LINDE	\N	472	f	12302.30	ABDELLAH	208336	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8160	1	2025-11-01	3315951.00	12.00	SORTIE	LINDE	\N	434	f	7736.00	MILOUD	208337	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8161	1	2025-11-01	3315994.00	43.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	208338	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8162	1	2025-11-01	3316034.00	40.00	SORTIE	HYUNDAI 22772A73	\N	479	f	252044.00	NOURDINE	208339	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8163	1	2025-11-01	3316174.00	140.00	SORTIE	VOLVO 22299A73	\N	480	f	627052.00	THAMI	208340	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8164	1	2025-11-01	3316279.00	105.00	SORTIE	VOLVO 22300A73	\N	481	f	720168.00	MUSTAPHA	208341	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8165	1	2025-11-03	3316384.00	105.00	SORTIE	VOLVO 22300A73	\N	481	f	720775.00	MUSTAPHA	208342	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8166	1	2025-11-03	3316454.00	70.00	SORTIE	CHARGEUSE G 938	\N	413	f	7979.40	ABDERRAHIM	208343	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8167	1	2025-11-03	3316535.00	81.00	SORTIE	MIT 11469A73	\N	435	f	953450.00	ABDELKHALEK	208344	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8168	1	2025-11-03	3316682.00	147.00	SORTIE	MIT 11470A73	\N	436	f	99842.00	MOHAMED	208345	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8169	1	2025-11-03	3316825.00	143.00	SORTIE	MIT 4969A73	\N	409	f	954035.00	CHOUAIB	208346	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8170	1	2025-11-03	3316850.00	25.00	SORTIE	HYUNDAI 18516A73	\N	471	f	333887.00	ABDELMALEK	208347	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8173	1	2025-11-03	3317287.00	41.00	SORTIE	LINDE	\N	477	f	\N	YOUSSEF	208350	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8174	1	2025-11-03	3317332.00	45.00	SORTIE	FENWICK	\N	430	f	\N	ABDELKHALEK	208351	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8175	1	2025-11-03	3317376.00	44.00	SORTIE	LINDE	\N	472	f	12321.10	SEKOURI	208352	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8176	1	2025-11-03	3317563.00	187.00	SORTIE	VOLVO 22299A73	\N	480	f	627741.00	THAMI	208353	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8177	1	2025-11-04	3317733.00	170.00	SORTIE	MIT 11470A73	\N	436	f	100492.00	MOHAMED	208354	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8180	1	2025-11-04	3318075.00	130.00	SORTIE	MIT 11469A73	\N	435	f	953905.00	ABDELKHALEK	208357	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8182	1	2025-11-04	3318404.00	281.00	SORTIE	MAN 706A73	\N	407	f	139391.00	SOUFIANE	208359	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8183	1	2025-11-04	3319040.00	636.00	SORTIE	VOLVO 17885A73	\N	438	f	724809.00	HOUSSAM	208360	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8184	1	2025-11-04	3319316.00	276.00	SORTIE	MAN 28659D1	\N	410	f	76634.00	CHOUAIB	208361	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8185	1	2025-11-04	3319477.00	161.00	SORTIE	MIT 4969A73	\N	409	f	954597.00	CHOUAIB	208362	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8186	1	2025-11-04	3319640.00	163.00	SORTIE	CHARGEUSE G 938	\N	413	f	7988.00	ABDERRAHIM	208363	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8188	1	2025-11-05	3319795.00	109.00	SORTIE	MIT 11470A73	\N	436	f	100907.00	MOHAMED	208365	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8189	1	2025-11-05	3319873.00	78.00	SORTIE	VOLVO 70352A2	\N	406	f	509840.00	CHOUAIB	208366	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8190	1	2025-11-05	3319906.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	334124.00	ABDELMALEK	208367	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8191	1	2025-11-05	3319972.00	66.00	SORTIE	ISUZU 26128A8	\N	401	f	884075.00	TOUFIK	208368	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8192	1	2025-11-05	3320031.00	59.00	SORTIE	HYUNDAI 22772A73	\N	479	f	252448.00	ABDELMALEK	208369	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8193	1	2025-11-05	3320196.00	165.00	SORTIE	MIT 11469A73	\N	435	f	954494.00	ABDELKHALEK	208370	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8194	1	2025-11-05	3320410.00	214.00	SORTIE	VOLVO 22299A73	\N	480	f	628543.00	THAMI	208371	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8196	1	2025-11-05	3321015.00	330.00	SORTIE	VOLVO 17886A73	\N	439	f	695900.00	MJID	208373	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8197	1	2025-11-05	3321054.00	39.00	SORTIE	KANGO 4812A73	\N	419	f	243193.00	TARMONIA	208374	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8198	1	2025-11-05	3321082.00	28.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	208375	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8199	1	2025-11-05	3321106.00	24.00	SORTIE	LINDE	\N	434	f	7747.00	MILOUD	208376	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8200	1	2025-11-05	3321142.00	36.00	SORTIE	LINDE	\N	477	f	9208.70	CHAABI	208377	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8201	1	2025-11-05	3321171.00	29.00	SORTIE	FENWICK	\N	430	f	28047.00	ABDELKHALEK	208378	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8202	1	2025-11-05	3321219.00	48.00	SORTIE	LINDE	\N	472	f	12341.30	SEKOURI	208379	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8204	1	2025-11-06	3321333.00	78.00	SORTIE	MIT 11470A73	\N	436	f	101183.00	MOHAMED	208381	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8205	1	2025-11-06	3321543.00	210.00	SORTIE	MIT 11469A73	\N	435	f	955277.00	ABDELKHALEK	208382	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8206	1	2025-11-06	3321617.00	74.00	SORTIE	VOLVO 22300A73	\N	481	f	720851.00	MUSTAPHA	208383	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8207	1	2025-11-06	3321699.00	82.00	SORTIE	MANITOU	\N	484	f	5869.70	SAID	208384	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8210	1	2025-11-06	3322168.00	19.00	SORTIE	HYUNDAI 18516A73	\N	471	f	325240.00	ABDELMALEK	208387	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8211	1	2025-11-06	3322333.00	165.00	SORTIE	CHARGEUSE G 938	\N	413	f	7997.40	ABDERRAHIM	208388	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8213	1	2025-11-07	3322460.00	92.00	SORTIE	MIT 11470A73	\N	436	f	101491.00	MOHAMED	208390	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8214	1	2025-11-07	3322756.00	296.00	SORTIE	MAN 28659D1	\N	410	f	77586.00	CHOUAIB	208391	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8215	1	2025-11-07	3322887.00	131.00	SORTIE	VOLVO 22300A73	\N	481	f	721373.00	MUSTAPHA	208392	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8216	1	2025-11-07	3322917.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	226049.00	BADER	208393	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8217	1	2025-11-07	3323376.00	459.00	SORTIE	VOLVO 17885A73	\N	438	f	726119.00	HOUSSAM	208394	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8218	1	2025-11-07	3323600.00	224.00	SORTIE	VOLVO 22299A73	\N	480	f	629314.00	THAMI	208395	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8221	1	2025-11-07	3323969.00	22.00	SORTIE	HYUNDAI 18516A73	\N	471	f	334391.00	ABDELMALEK	208398	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8222	1	2025-11-07	3324163.00	194.00	SORTIE	RENAULT 25636A13	\N	411	f	151072.00	YASSINE	208399	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8223	1	2025-11-07	3324285.00	122.00	SORTIE	MIT 4703A73	\N	408	f	582327.00	MUSTAPHA	208400	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8224	1	2025-11-07	3324330.00	45.00	SORTIE	LINDE	\N	472	f	12359.60	ABDELLAH	208401	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8225	1	2025-11-08	3324510.00	180.00	SORTIE	MIT 11470A73	\N	436	f	102113.00	MOHAMED	208402	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8226	1	2025-11-08	3324643.00	133.00	SORTIE	VOLVO 22299A73	\N	480	f	629828.00	THAMI	208403	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8227	1	2025-11-08	3324740.00	97.00	SORTIE	MIT 11469A73	\N	435	f	955564.00	ABDELKHALEK	208404	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8230	1	2025-11-08	3325379.00	190.00	SORTIE	MAN 28659D1	\N	410	f	78142.00	CHOUAIB	208407	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8232	1	2025-11-08	3325972.00	153.00	SORTIE	VOLVO 22300A73	\N	481	f	721888.00	MUSTAPHA	208409	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8233	1	2025-11-08	3325994.00	22.00	SORTIE	HYUNDAI 18516A73	\N	471	f	334550.00	ABDELMALEK	208410	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8235	1	2025-11-08	3326033.00	24.00	SORTIE	LINDE	\N	472	f	12369.90	ABDELLAH	208412	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8236	1	2025-11-08	3326081.00	48.00	SORTIE	FENWICK	\N	430	f	28064.00	SAID	208413	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8237	1	2025-11-08	3326116.00	35.00	SORTIE	LINDE	\N	477	f	9223.80	CHAABI	208414	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8238	1	2025-11-08	3326143.00	27.00	SORTIE	VOLVO 22299A73	\N	480	f	629920.00	THAMI	208415	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8240	1	2025-11-10	3326299.00	113.00	SORTIE	MIT 11469A73	\N	435	f	955941.00	ABDELKHALEK	208417	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8241	1	2025-11-10	3326321.00	22.00	SORTIE	HYUNDAI 18516A73	\N	471	f	334710.00	ABDELMALEK	208418	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8242	1	2025-11-10	3326353.00	32.00	SORTIE	HYUNDAI 22368A73	\N	482	f	226351.00	BADER	208419	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8243	1	2025-11-10	3326502.00	149.00	SORTIE	MIT 11470A73	\N	436	f	102625.00	MOHAMED	208420	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8244	1	2025-11-10	3326967.00	465.00	SORTIE	VOLVO 17886A73	\N	439	f	697437.00	MJID	208421	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8246	1	2025-11-10	3327522.00	497.00	SORTIE	VOLVO 17885A73	\N	438	f	727574.00	HOUSSAM	208423	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8247	1	2025-11-10	3327717.00	195.00	SORTIE	CHARGEUSE G 938	\N	413	f	8013.70	ABDERRAHIM	208424	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8248	1	2025-11-10	3327765.00	48.00	SORTIE	LINDE	\N	472	f	12389.60	AZIZ	208425	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8252	1	2025-11-10	3328719.00	180.00	SORTIE	VOLVO 22299A73	\N	480	f	630613.00	THAMI	208429	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8253	1	2025-11-11	3328863.00	144.00	SORTIE	MIT 11469A73	\N	435	f	956465.00	ABDELKHALEK	208430	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8254	1	2025-11-11	3329042.00	179.00	SORTIE	MAN 28659D1	\N	410	f	78704.00	CHOUAIB	208431	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8255	1	2025-11-11	3329218.00	176.00	SORTIE	MIT 11470A73	\N	436	f	103252.00	MOHAMED	208432	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8256	1	2025-11-11	3329245.00	27.00	SORTIE	HYUNDAI 18516A73	\N	471	f	334908.00	ABDELMALEK	208433	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8257	1	2025-11-11	3329339.00	94.00	SORTIE	ISUZU 26128A8	\N	401	f	884580.00	TOUFIK	208434	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8258	1	2025-11-11	3329493.00	154.00	SORTIE	VOLVO 22300A73	\N	481	f	722530.00	MUSTAPHA	208435	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8261	1	2025-11-11	3329772.00	100.00	SORTIE	MAN 4790B8	\N	403	f	979058.00	KARDODI	208438	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8262	1	2025-11-11	3329811.00	39.00	SORTIE	FENWICK	\N	430	f	28077.00	SAID	208439	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8263	1	2025-11-11	3329848.00	37.00	SORTIE	LINDE	\N	477	f	9239.60	CHAABI	208440	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8264	1	2025-11-11	3329870.00	22.00	SORTIE	LINDE	\N	472	f	12399.00	AZIZ	208441	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8265	1	2025-11-11	3329910.00	40.00	SORTIE	LINDE	\N	428	f	4061.30	HASSAN	208442	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8266	1	2025-11-11	3329961.00	51.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	208443	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8267	1	2025-11-12	3329995.00	34.00	SORTIE	HYUNDAI 18516A73	\N	471	f	335133.00	ABDELMALEK	208444	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8268	1	2025-11-12	3330117.00	122.00	SORTIE	VOLVO 22300A73	\N	481	f	723049.00	MUSTAPHA	208445	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8269	1	2025-11-12	3330228.00	111.00	SORTIE	VOLVO 70352A2	\N	406	f	510033.00	CHOUAIB	208446	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8270	1	2025-11-12	3330407.00	179.00	SORTIE	MIT 11470A73	\N	436	f	103861.00	MOHAMED	208447	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8272	1	2025-11-12	3330785.00	73.00	SORTIE	MAN 28659D1	\N	410	f	78889.00	CHOUAIB	208449	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8273	1	2025-11-12	3331189.00	404.00	SORTIE	VOLVO 17885A73	\N	438	f	728766.00	HOUSSAM	208450	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8276	1	2025-11-12	3331574.00	214.00	SORTIE	VOLVO 22299A73	\N	480	f	631283.00	THAMI	208453	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8277	1	2025-11-12	3331607.00	33.00	SORTIE	HYUNDAI 22368A73	\N	482	f	226758.00	BADER	208454	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8278	1	2025-11-13	3331791.00	184.00	SORTIE	MIT 11470A73	\N	436	f	104504.00	MOHAMED	208455	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8280	1	2025-11-14	3332162.00	328.00	SORTIE	VOLVO 17885A73	\N	438	f	729674.00	HOUSSAM	208461	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8281	1	2025-11-14	3332208.00	46.00	SORTIE	HYUNDAI 18516A73	\N	471	f	335473.00	ABDELMALEK	208462	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8282	1	2025-11-14	3332326.00	118.00	SORTIE	MIT 11470A73	\N	436	f	104908.00	MOHAMED	208463	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8283	1	2025-11-14	3332459.00	132.00	SORTIE	MIT 4703A73	\N	408	f	582911.00	MUSTAPHA	208464	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8284	1	2025-11-14	3332648.00	190.00	SORTIE	VOLVO 22300A73	\N	481	f	723710.00	MUSTAPHA	208465	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8286	1	2025-11-14	3332822.00	119.00	SORTIE	MAN 4790B8	\N	403	f	979553.00	KARDODI	208467	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8288	1	2025-11-14	3333193.00	223.00	SORTIE	VOLVO 22299A73	\N	480	f	632171.00	THAMI	208469	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8291	1	2025-11-14	3333346.00	106.00	SORTIE	ISUZU 26128A8	\N	401	f	885117.00	TOUFIK	208472	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8292	1	2025-11-14	3333925.00	579.00	SORTIE	VOLVO 17886A73	\N	439	f	699267.00	MJID	208473	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8293	1	2025-11-15	3334151.00	226.00	SORTIE	MIT 11470A73	\N	436	f	105679.00	MOHAMED	208474	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8294	1	2025-11-15	3334299.00	148.00	SORTIE	VOLVO 22300A73	\N	481	f	724259.00	MUSTAPHA	208475	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8295	1	2025-11-15	3334322.00	23.00	SORTIE	HYUNDAI 22368A73	\N	482	f	227025.00	BADER	208476	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8296	1	2025-11-15	3334520.00	198.00	SORTIE	MIT 11469A73	\N	435	f	957315.00	ABDELKHALEK	208477	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8299	1	2025-11-15	3335492.00	386.00	SORTIE	VOLVO 17885A73	\N	438	f	730707.00	HOUSSAM	208480	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8302	1	2025-11-15	3335863.00	23.00	SORTIE	LINDE	\N	428	f	4062.00	JAWAD	208483	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8303	1	2025-11-15	3335913.00	50.00	SORTIE	LINDE	\N	472	f	12436.40	AZIZ	208484	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8304	1	2025-11-15	3335963.00	50.00	SORTIE	FENWICK	\N	430	f	28095.00	SAID	208485	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8305	1	2025-11-15	3335981.00	18.00	SORTIE	LINDE	\N	434	f	7756.40	MILOUD	208486	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8306	1	2025-11-15	3336030.00	50.00	SORTIE	LINDE	\N	477	f	9260.00	CHAABI	208487	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8307	1	2025-11-15	3336192.00	162.00	SORTIE	CHARGEUSE G 938	\N	413	f	8040.50	ABDERRAHIM	208488	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8308	1	2025-11-15	3336232.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	335731.00	ABDELMALEK	208489	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8309	1	2025-11-17	3336406.00	174.00	SORTIE	MIT 11469A73	\N	435	f	957886.00	ABDELKHALEK	208490	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8310	1	2025-11-17	3336598.00	192.00	SORTIE	RENAULT 25636A13	\N	411	f	151821.00	YASSINE	208491	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8311	1	2025-11-17	3336787.00	189.00	SORTIE	MIT 11470A73	\N	436	f	160297.00	MOHAMED	208492	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8312	1	2025-11-17	3336852.00	65.00	SORTIE	VOLVO 22299A73	\N	480	f	632386.00	THAMI	208493	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8315	1	2025-11-17	3337359.00	300.00	SORTIE	VOLVO 17886A73	\N	439	f	700338.00	MJID	208496	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8316	1	2025-11-17	3337392.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	335961.00	ABDELMALEK	208497	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8317	1	2025-11-17	3337438.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	252698.00	NOURDINE	208498	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8318	1	2025-11-17	3337598.00	160.00	SORTIE	VOLVO 22300A73	\N	481	f	724902.00	MUSTAPHA	208499	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8319	1	2025-11-17	3337647.00	49.00	SORTIE	LINDE	\N	472	f	12455.80	AZIZ	208500	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8322	1	2025-11-17	3337789.00	71.00	SORTIE	RENAULT 25636A13	\N	411	f	152085.00	YASSINE	208503	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8323	1	2025-11-17	3337846.00	57.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	208504	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8324	1	2025-11-17	3337966.00	120.00	SORTIE	MAN 4790B8	\N	403	f	980033.00	KARDODI	208505	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8326	1	2025-11-18	3338373.00	357.00	SORTIE	VOLVO 17885A73	\N	438	f	731752.00	HOUSSAM	208507	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8327	1	2025-11-18	3338451.00	78.00	SORTIE	VOLVO 70352A2	\N	406	f	510143.00	CHOUAIB	208508	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8328	1	2025-11-18	3338486.00	35.00	SORTIE	HYUNDAI 22368A73	\N	482	f	227393.00	BADER	208509	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8329	1	2025-11-18	3338673.00	187.00	SORTIE	MIT 11469A73	\N	435	f	958529.00	ABDELKHALEK	208510	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8330	1	2025-11-18	3338777.00	104.00	SORTIE	MIT 11470A73	\N	436	f	106681.00	MOHAMED	208511	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8331	1	2025-11-18	3339010.00	233.00	SORTIE	MAN 28659D1	\N	410	f	79636.00	CHOUAIB	208512	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8333	1	2025-11-18	3339914.00	183.00	SORTIE	CHARGEUSE G 938	\N	413	f	8055.70	ABDERRAHIM	208514	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8334	1	2025-11-19	3340105.00	191.00	SORTIE	RENAULT 25636A13	\N	411	f	152805.00	YASSINE	208515	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8335	1	2025-11-19	3340271.00	166.00	SORTIE	MIT 11470A73	\N	436	f	107275.00	MOHAMED	208516	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8336	1	2025-11-19	3340436.00	165.00	SORTIE	VOLVO 22300A73	\N	481	f	725514.00	MUSTAPHA	208517	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8337	1	2025-11-19	3340619.00	183.00	SORTIE	MIT 11469A73	\N	435	f	959207.00	ABDELKHALEK	208518	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8339	1	2025-11-19	3340768.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	336228.00	ABDELMALEK	208520	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8341	1	2025-11-19	3340850.00	45.00	SORTIE	LINDE	\N	472	f	12473.40	AZIZ	208522	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8342	1	2025-11-19	3340889.00	39.00	SORTIE	LINDE	\N	477	f	9276.30	CHAABI	208523	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8343	1	2025-11-19	3340935.00	46.00	SORTIE	FENWICK	\N	430	f	28112.00	ABDELKHALEK	208524	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8344	1	2025-11-20	3341022.00	87.00	SORTIE	MIT 11470A73	\N	436	f	107545.00	MOHAMED	208525	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8345	1	2025-11-20	3341180.00	158.00	SORTIE	MIT 11469A73	\N	435	f	959766.00	ABDELKHALEK	208526	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8346	1	2025-11-20	3341362.00	182.00	SORTIE	MAN 28659D1	\N	410	f	80242.00	CHOUAIB	208527	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8347	1	2025-11-20	3341478.00	116.00	SORTIE	VOLVO 22299A73	\N	480	f	632778.00	THAMI	208528	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8348	1	2025-11-20	3341557.00	79.00	SORTIE	RENAULT 25636A13	\N	411	f	153048.00	YASSINE	208529	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8349	1	2025-11-20	3341848.00	291.00	SORTIE	MAN 706A73	\N	407	f	139973.00	SOUFIANE	208530	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8350	1	2025-11-20	3342252.00	404.00	SORTIE	VOLVO 17885A73	\N	438	f	732895.00	HOUSSAM	208531	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8351	1	2025-11-20	3342304.00	52.00	SORTIE	HYUNDAI 22772A73	\N	479	f	252992.00	NOURDINE	208532	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8354	1	2025-11-20	3343301.00	39.00	SORTIE	BERLINGO 981A73	\N	417	f	301252.00	MAGHNIA	208535	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8355	1	2025-11-20	3343378.00	77.00	SORTIE	VOLVO 22299A73	\N	480	f	633040.00	THAMI	208536	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8357	1	2025-11-20	3343834.00	165.00	SORTIE	MIT 4703A73	\N	408	f	583632.00	MUSTAPHA	208538	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8358	1	2025-11-20	3343868.00	35.00	SORTIE	LINDE	\N	434	f	7770.90	MILOUD	208539	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8359	1	2025-11-21	3343998.00	130.00	SORTIE	MIT 11470A73	\N	436	f	108021.00	MOHAMED	208540	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8360	1	2025-11-21	3344040.00	42.00	SORTIE	HYUNDAI 22368A73	\N	482	f	227872.00	BADER	208541	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8361	1	2025-11-21	3344195.00	155.00	SORTIE	MAN 28659D1	\N	410	f	80759.00	CHOUAIB	208542	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8362	1	2025-11-21	3344265.00	70.00	SORTIE	MIT 11469A73	\N	435	f	959986.00	ABDELKHALEK	208543	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8363	1	2025-11-21	3344343.00	78.00	SORTIE	MANITOU	\N	484	f	5946.00	SAID	208544	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8364	1	2025-11-21	3344526.00	183.00	SORTIE	RENAULT 25636A13	\N	411	f	153771.00	YASSINE	208545	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8365	1	2025-11-21	3344659.00	133.00	SORTIE	VOLVO 22300A73	\N	481	f	725939.00	MUSTAPHA	208546	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8367	1	2025-11-21	3344831.00	122.00	SORTIE	VOLVO 22299A73	\N	480	f	633480.00	THAMI	208548	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8369	1	2025-11-21	3344908.00	38.00	SORTIE	HYUNDAI 18516A73	\N	471	f	336488.00	ABDELMALEK	208550	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8370	1	2025-11-21	3345428.00	520.00	SORTIE	VOLVO 17886A73	\N	439	f	702054.00	MJID	208551	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8371	1	2025-11-21	3345452.00	23.00	SORTIE	KANGO 4812A73	\N	419	f	243712.00	TARMONIA	208552	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8372	1	2025-11-21	3345499.00	47.00	SORTIE	RENAULT 25636A13	\N	411	f	154017.00	YASSINE	208553	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8374	1	2025-11-21	3345581.00	47.00	SORTIE	LINDE	\N	472	f	12492.00	AZIZ	208555	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8376	1	2025-11-21	3345771.00	151.00	SORTIE	CHARGEUSE G 938	\N	413	f	8068.70	ABDERRAHIM	208557	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8377	1	2025-11-21	3345896.00	125.00	SORTIE	MAN 4790B8	\N	403	f	980511.00	KARDODI	208558	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8378	1	2025-11-22	3346059.00	162.00	SORTIE	MIT 11469A73	\N	435	f	960524.00	ABDELKHALEK	208559	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8379	1	2025-11-22	3346241.00	182.00	SORTIE	MAN 28659D1	\N	410	f	81313.00	CHOUAIB	208560	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8381	1	2025-11-22	3346384.00	110.00	SORTIE	VOLVO 22300A73	\N	481	f	726360.00	MUSTAPHA	208562	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8387	1	2025-11-22	3347446.00	20.00	SORTIE	HYUNDAI 22368A73	\N	482	f	228105.00	BADER	208568	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8388	1	2025-11-22	3347465.00	19.00	SORTIE	LINDE	\N	428	f	4062.90	HASSAN	208569	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8389	1	2025-11-22	3347518.00	53.00	SORTIE	HYUNDAI 22772A73	\N	479	f	253292.00	NOURDINE	208570	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8390	1	2025-11-22	3347564.00	46.00	SORTIE	FENWICK	\N	430	f	28128.60	HASSAN	208571	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8391	1	2025-11-22	3347582.00	18.00	SORTIE	HYUNDAI 18516A73	\N	471	f	336607.00	ABDELMALEK	208572	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8392	1	2025-11-22	3347602.00	20.00	SORTIE	LINDE	\N	434	f	7783.30	MILOUD	208573	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8393	1	2025-11-22	3347645.00	42.00	SORTIE	LINDE	\N	477	f	9295.10	CHAABI	208574	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8394	1	2025-11-24	3347891.00	246.00	SORTIE	MIT 11470A73	\N	436	f	108879.00	MOHAMED	208575	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8395	1	2025-11-24	3348028.00	137.00	SORTIE	MIT 11469A73	\N	435	f	960966.00	ABDELKHALEK	208576	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8396	1	2025-11-24	3348180.00	152.00	SORTIE	VOLVO 22300A73	\N	481	f	726943.00	MUSTAPHA	208577	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8397	1	2025-11-24	3348261.00	81.00	SORTIE	RENAULT 25636A13	\N	411	f	154337.00	YASSINE	208578	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8398	1	2025-11-24	3348335.00	74.00	SORTIE	VOLVO 70352A2	\N	406	f	510249.00	CHOUAIB	208579	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8400	1	2025-11-24	3349277.00	571.00	SORTIE	VOLVO 17885A73	\N	438	f	734708.00	HOUSSAM	208581	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8402	1	2025-11-24	3349460.00	151.00	SORTIE	CHARGEUSE G 938	\N	413	f	8080.10	ABDERRAHIM	208583	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8404	1	2025-11-24	3349724.00	127.00	SORTIE	VOLVO 22299A73	\N	480	f	633889.00	THAMI	208585	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8405	1	2025-11-24	3349964.00	240.00	SORTIE	MAN 28659D1	\N	410	f	82088.00	CHOUAIB	208586	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8406	1	2025-11-24	3350042.00	78.00	SORTIE	VOLVO 22300A73	\N	481	f	727244.00	MUSTAPHA	208587	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8407	1	2025-11-25	3350223.00	181.00	SORTIE	MIT 11470A73	\N	436	f	109494.00	MOHAMED	208588	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8408	1	2025-11-25	3350341.00	117.00	SORTIE	MIT 11469A73	\N	435	f	961405.00	ABDELKHALEK	208589	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8409	1	2025-11-25	3350494.00	154.00	SORTIE	RENAULT 25636A13	\N	411	f	154963.00	YASSINE	208590	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8411	1	2025-11-25	3350590.00	40.00	SORTIE	HYUNDAI 22772A73	\N	479	f	253578.00	ABDELMALEK	208592	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8412	1	2025-11-25	3350702.00	112.00	SORTIE	VOLVO 22299A73	\N	480	f	634279.00	THAMI	208593	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8413	1	2025-11-25	3350773.00	71.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	208594	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8415	1	2025-11-25	3350868.00	40.00	SORTIE	LINDE	\N	472	f	12509.30	ABDELLAH	208596	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8416	1	2025-11-25	3350921.00	53.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	208597	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8417	1	2025-11-26	3350961.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	228553.00	BADER	208598	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8418	1	2025-11-26	3351079.00	118.00	SORTIE	MIT 11469A73	\N	435	f	961847.00	ABDELKHALEK	208599	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8419	1	2025-11-26	3351237.00	158.00	SORTIE	MIT 11470A73	\N	436	f	110051.00	MOHAMED	208600	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8421	1	2025-11-26	3351445.00	148.00	SORTIE	RENAULT 25636A13	\N	411	f	155505.00	YASSINE	208602	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8422	1	2025-11-26	3351565.00	120.00	SORTIE	VOLVO 22300A73	\N	481	f	727733.00	MUSTAPHA	208603	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8424	1	2025-11-26	3351897.00	61.00	SORTIE	VOLVO 22300A73	\N	481	f	727987.00	MUSTAPHA	208605	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8425	1	2025-11-26	3351957.00	60.00	SORTIE	FENWICK	\N	430	f	28149.00	ABDELKHALEK	208606	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8426	1	2025-11-26	3352032.00	75.00	SORTIE	MANITOU	\N	484	f	5979.00	SAID	208607	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8427	1	2025-11-26	3352051.00	19.00	SORTIE	LINDE	\N	434	f	7792.70	MILOUD	208608	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8431	1	2025-11-27	3353087.00	126.00	SORTIE	MAN 4790B8	\N	403	f	980986.00	KARDODI	208612	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8432	1	2025-11-27	3353257.00	169.00	SORTIE	MIT 11470A73	\N	436	f	110620.00	MOHAMED	208613	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8433	1	2025-11-27	3353384.00	127.00	SORTIE	RENAULT 25636A13	\N	411	f	156018.00	YASSINE	208614	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8436	1	2025-11-27	3354220.00	71.00	SORTIE	MIT 11469A73	\N	435	f	962081.00	ABDELKHALEK	208617	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8437	1	2025-11-27	3354420.00	200.00	SORTIE	MAN 706A73	\N	407	f	148452.00	SOUFIANE	208618	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8439	1	2025-11-27	3354740.00	34.00	SORTIE	LINDE	\N	477	f	9309.80	CHAABI	208620	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8440	1	2025-11-27	3354775.00	35.00	SORTIE	LINDE	\N	472	f	12552.50	ABDELLAH	208621	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8441	1	2025-11-27	3354823.00	49.00	SORTIE	HYUNDAI 22772A73	\N	479	f	253931.00	ABDELMALEK	208622	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8442	1	2025-11-27	3355220.00	396.00	SORTIE	VOLVO 17886A73	\N	439	f	703363.00	MJID	208623	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8443	1	2025-11-27	3355248.00	28.00	SORTIE	LINDE	\N	428	f	4064.00	JAWAD	208624	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8444	1	2025-11-28	3355276.00	28.00	SORTIE	HYUNDAI 22368A73	\N	482	f	228935.00	BADER	208625	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8445	1	2025-11-28	3355435.00	159.00	SORTIE	MIT 11469A73	\N	435	f	962648.00	ABDELMALEK	208626	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8446	1	2025-11-28	3355599.00	164.00	SORTIE	MIT 11470A73	\N	436	f	111186.00	MOHAMED	208627	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8448	1	2025-11-28	3355863.00	229.00	SORTIE	VOLVO 22299A73	\N	480	f	635110.00	THAMI	208629	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8450	1	2025-11-28	3356369.00	184.00	SORTIE	RENAULT 25636A13	\N	411	f	156834.00	YASSINE	208631	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8453	1	2025-11-28	3356889.00	206.00	SORTIE	CHARGEUSE G 938	\N	413	f	8096.20	ABDERRAHIM	208634	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8454	1	2025-11-28	3356917.00	28.00	SORTIE	LINDE	\N	472	f	12539.20	ABDELLAH	208635	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8455	1	2025-11-28	3357123.00	206.00	SORTIE	VOLVO 22300A73	\N	481	f	728777.00	MUSTAPHA	208636	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8456	1	2025-11-28	3357171.00	48.00	SORTIE	VOLVO 22299A73	\N	480	f	635248.00	THAMI	208637	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8457	1	2025-11-29	3357313.00	142.00	SORTIE	MAN 4790B8	\N	403	f	981597.00	KARDODI	208638	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8458	1	2025-11-29	3357336.00	23.00	SORTIE	HYUNDAI 22368A73	\N	482	f	229182.00	BADER	208639	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8459	1	2025-11-29	3357576.00	240.00	SORTIE	MAN 28659D1	\N	410	f	82774.00	CHOUAIB	208640	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8460	1	2025-11-29	3357649.00	73.00	SORTIE	MIT 11470A73	\N	436	f	111420.00	MOHAMED	208641	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8461	1	2025-11-29	3357760.00	111.00	SORTIE	MIT 11469A73	\N	435	f	963019.00	ABDELKHALEK	208642	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8462	1	2025-11-29	3357935.00	175.00	SORTIE	RENAULT 25636A13	\N	410	f	157497.00	YASSINE	208643	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8464	1	2025-11-29	3358129.00	56.00	SORTIE	HYUNDAI 22772A73	\N	479	f	254307.00	ABDELMALEK	208645	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8466	1	2025-11-29	3358226.00	55.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	208647	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8467	1	2025-11-29	3358247.00	21.00	SORTIE	LINDE	\N	434	f	7803.20	MILOUD	208648	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8468	1	2025-11-29	3358794.00	547.00	SORTIE	VOLVO 17885A73	\N	438	f	736264.00	HOUSSAM	208649	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8469	1	2025-11-29	3358827.00	33.00	SORTIE	LINDE	\N	428	f	4064.00	JAWAD	208650	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8470	1	2025-11-29	3358961.00	134.00	SORTIE	VOLVO 22300A73	\N	481	f	729288.00	MUSTAPHA	208651	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8471	1	2025-12-01	3359171.00	210.00	SORTIE	VOLVO 22299A73	\N	480	f	636026.00	THAMI	208652	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8472	1	2025-12-01	3359197.00	26.00	SORTIE	HYUNDAI 22368A73	\N	482	f	229394.00	BADER	208653	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8473	1	2025-12-01	3359413.00	215.00	SORTIE	VOLVO 17886A73	\N	439	f	703971.00	MJID	208654	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8474	1	2025-12-01	3359543.00	130.00	SORTIE	VOLVO 22300A73	\N	481	f	729823.00	MUSTAPHA	208655	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8475	1	2025-12-01	3359665.00	122.00	SORTIE	MIT 11469A73	\N	435	f	963447.00	ABDELKHALEK	208656	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8476	1	2025-12-01	3359739.00	74.00	SORTIE	MIT 11470A73	\N	436	f	111684.00	MOHAMED	208657	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8477	1	2025-12-01	3359818.00	79.00	SORTIE	RENAULT 25636A13	\N	411	f	157821.00	YASSINE	208658	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8478	1	2025-12-01	3359869.00	51.00	SORTIE	LINDE	\N	472	f	12561.40	AZIZ	208659	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8479	1	2025-12-01	3360100.00	231.00	SORTIE	MAN 28659D1	\N	410	f	83483.00	CHOUAIB	208660	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8480	1	2025-12-01	3360146.00	46.00	SORTIE	FENWICK	\N	430	f	28165.00	ABDELKHALEK	208661	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8481	1	2025-12-01	3360192.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	254605.00	NOURDINE	208662	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8482	1	2025-12-01	3360245.00	53.00	SORTIE	KANGO 4812A73	\N	419	f	244310.00	TARMONIA	208663	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8483	1	2025-12-01	3360317.00	72.00	SORTIE	MANITOU	\N	484	f	6011.00	SAID	208664	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8484	1	2025-12-01	3360368.00	51.00	SORTIE	LINDE	\N	477	f	9330.40	ABDELKHALEK	208665	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8485	1	2025-12-02	3360487.00	119.00	SORTIE	MIT 11470A73	\N	436	f	112119.00	MOHAMED	208666	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8486	1	2025-12-02	3360665.00	178.00	SORTIE	MAN 28659D1	\N	410	f	84079.00	CHOUAIB	208667	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8487	1	2025-12-02	3360762.00	97.00	SORTIE	VOLVO 22300A73	\N	481	f	730204.00	MUSTAPHA	208668	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8488	1	2025-12-02	3360914.00	152.00	SORTIE	VOLVO 70352A2	\N	406	f	510537.00	CHOUAIB	208669	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8489	1	2025-12-02	3360984.00	70.00	SORTIE	MIT 11469A73	\N	435	f	963648.00	ABDELKHALEK	208670	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8493	1	2025-12-02	3362335.00	166.00	SORTIE	RENAULT 25636A13	\N	411	f	158446.00	YASSINE	208674	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8494	1	2025-12-02	3362365.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	229700.00	BADR	208675	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8495	1	2025-12-02	3362404.00	39.00	SORTIE	LINDE	\N	472	f	12578.70	AZIZ	208676	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8496	1	2025-12-02	3362454.00	50.00	SORTIE	LINDE	\N	428	f	4066.50	JAWAD	208677	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8497	1	2025-12-03	3362969.00	515.00	SORTIE	VOLVO 17885A73	\N	438	f	737820.00	HOUSSAM	208678	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8498	1	2025-12-03	3363117.00	148.00	SORTIE	MIT 11469A73	\N	435	f	964177.00	ABDELKHALEK	208679	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8499	1	2025-12-03	3363268.00	151.00	SORTIE	MAN 4790B8	\N	403	f	982186.00	KARDODI	208680	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8500	1	2025-12-03	3363385.00	117.00	SORTIE	MIT 11470A73	\N	436	f	112513.00	MOHAMED	208681	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8503	1	2025-12-03	3363765.00	29.00	SORTIE	LINDE	\N	434	f	7817.30	MILOUD	208684	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8504	1	2025-12-03	3363834.00	69.00	SORTIE	MIT 11469A73	\N	435	f	964428.00	ABDELKHALEK	208685	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8505	1	2025-12-03	3363858.00	24.00	SORTIE	LINDE	\N	428	f	4067.50	HASSAN	208686	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8507	1	2025-12-03	3363943.00	43.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	208688	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8508	1	2025-12-03	3364106.00	163.00	SORTIE	CHARGEUSE G 938	\N	413	f	8109.60	ABDERRAHIM	208689	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8509	1	2025-12-03	3364132.00	26.00	SORTIE	LINDE	\N	472	f	12589.00	ABDELLAH	208690	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8512	1	2025-12-03	3364512.00	17.00	SORTIE	HYUNDAI 18516A73	\N	471	f	336969.00	ABDELMALEK	208693	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8513	1	2025-12-04	3364596.00	84.00	SORTIE	ISUZU 26128A8	\N	401	f	885535.00	TOUFIK	208694	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8514	1	2025-12-04	3364751.00	155.00	SORTIE	MIT 11470A73	\N	436	f	113023.00	MOHAMED	208695	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8516	1	2025-12-04	3364988.00	203.00	SORTIE	MIT 4703A73	\N	408	f	584537.00	MUSTAPHA	208697	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8519	1	2025-12-04	3365531.00	148.00	SORTIE	VOLVO 22299A73	\N	480	f	636486.00	THAMI	208700	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8520	1	2025-12-04	3366025.00	494.00	SORTIE	VOLVO 17886A73	\N	439	f	705593.00	MJID	208701	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8521	1	2025-12-04	3366051.00	26.00	SORTIE	LINDE	\N	472	f	12599.30	ABDELLAH	208702	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8522	1	2025-12-04	3366083.00	32.00	SORTIE	HYUNDAI 18516A73	\N	471	f	336909.00	NOURDINE	208703	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8523	1	2025-12-04	3366119.00	36.00	SORTIE	FENWICK	\N	430	f	28177.00	SAID	208704	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8524	1	2025-12-04	3366157.00	38.00	SORTIE	LINDE	\N	477	f	9344.00	CHAABI	208705	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8525	1	2025-12-04	3366231.00	74.00	SORTIE	MIT 11470A73	\N	436	f	113303.00	MOHAMED	208706	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8526	1	2025-12-05	3366328.00	97.00	SORTIE	MIT 11469A73	\N	435	f	964748.00	ABDELKHALEK	208707	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8527	1	2025-12-05	3366352.00	24.00	SORTIE	HYUNDAI 22368A73	\N	482	f	230028.00	BADER	208708	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8529	1	2025-12-05	3366443.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	337144.00	NOURDINE	208710	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8530	1	2025-12-05	3366504.00	61.00	SORTIE	HYUNDAI 22772A73	\N	479	f	254950.00	NOURDINE	208711	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8533	1	2025-12-05	3366983.00	157.00	SORTIE	CHARGEUSE G 938	\N	413	f	8121.60	ABDERRAHIM	208714	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8535	1	2025-12-05	3367139.00	115.00	SORTIE	VOLVO 22299A73	\N	480	f	636904.00	THAMI	208716	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8536	1	2025-12-06	3367257.00	118.00	SORTIE	MAN 4790B8	\N	403	f	982629.00	KARDODI	208717	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8537	1	2025-12-06	3367421.00	164.00	SORTIE	MIT 11469A73	\N	435	f	965323.00	ABDELKHALEK	208718	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8538	1	2025-12-06	3367569.00	148.00	SORTIE	MIT 11470A73	\N	436	f	113799.00	MOHAMED	208719	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8540	1	2025-12-06	3367824.00	129.00	SORTIE	MIT 4969A73	\N	409	f	954918.00	MUSTAPHA	208721	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8541	1	2025-12-06	3367987.00	163.00	SORTIE	VOLVO 22300A73	\N	481	f	730732.00	MUSTAPHA	208722	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8542	1	2025-12-06	3368497.00	510.00	SORTIE	VOLVO 17885A73	\N	438	f	739316.00	HOUSSAM	208723	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8543	1	2025-12-06	3368560.00	63.00	SORTIE	VOLVO 22300A73	\N	481	f	630992.00	MUSTAPHA	208724	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8544	1	2025-12-06	3368597.00	37.00	SORTIE	LINDE	\N	472	f	12613.30	ABDELLAH	208725	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8545	1	2025-12-06	3368619.00	22.00	SORTIE	LINDE	\N	434	f	7827.00	MILOUD	208726	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8547	1	2025-12-06	3368711.00	75.00	SORTIE	MANITOU	\N	484	f	6046.00	SAID	208728	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8548	1	2025-12-06	3368752.00	41.00	SORTIE	HYUNDAI 18516A73	\N	471	f	337430.00	ABDELMALEK	208729	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8549	1	2025-12-06	3368777.00	25.00	SORTIE	LINDE	\N	477	f	9354.70	CHAABI	208730	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8550	1	2025-12-06	3368911.00	134.00	SORTIE	VOLVO 22299A73	\N	480	f	637421.00	THAMI	208731	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8551	1	2025-12-08	3369076.00	165.00	SORTIE	MIT 11469A73	\N	435	f	965894.00	ABDELKHALEK	208732	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8552	1	2025-12-08	3369138.00	481.00	SORTIE	VOLVO 22300A73	\N	481	f	731202.00	MUSTAPHA	208733	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8553	1	2025-12-08	3369162.00	25.00	SORTIE	HYUNDAI 22368A73	\N	482	f	230376.00	BADER	208734	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8554	1	2025-12-08	3369206.00	42.00	SORTIE	HYUNDAI 18516A73	\N	471	f	337737.00	ABDELMALEK	208735	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8555	1	2025-12-08	3369340.00	134.00	SORTIE	VOLVO 70352A2	\N	406	f	510812.00	CHOUAIB	208736	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8556	1	2025-12-08	3369432.00	92.00	SORTIE	MIT 11470A73	\N	436	f	114120.00	MOHAMED	208737	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8557	1	2025-12-08	3369685.00	253.00	SORTIE	MAN 28659D1	\N	410	f	84875.00	CHOUAIB	208738	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8559	1	2025-12-08	3369908.00	194.00	SORTIE	CHARGEUSE G 938	\N	413	f	\N	ABDERRAHIM	208740	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8560	1	2025-12-08	3369945.00	37.00	SORTIE	FENWICK	\N	430	f	\N	ABDELKHALEK	208741	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8561	1	2025-12-08	3370009.00	64.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	208742	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8562	1	2025-12-09	3370115.00	106.00	SORTIE	MIT 11470A73	\N	436	f	114495.00	MOHAMED	208743	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8563	1	2025-12-09	3370256.00	141.00	SORTIE	VOLVO 22299A73	\N	480	f	637928.00	THAMI	208744	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8564	1	2025-12-09	3370277.00	21.00	SORTIE	HYUNDAI 22368A73	\N	482	f	230565.00	BADER	208745	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8565	1	2025-12-09	3370352.00	75.00	SORTIE	MIT 11469A73	\N	435	f	966123.00	ABDELKHALEK	208746	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8567	1	2025-12-09	3370572.00	87.00	SORTIE	VOLVO 22300A73	\N	481	f	731533.00	MUSTAPHA	208748	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8569	1	2025-12-09	3370662.00	31.00	SORTIE	LINDE	\N	472	f	12627.50	AZIZ	208750	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8570	1	2025-12-09	3370697.00	34.00	SORTIE	LINDE	\N	428	f	40869.00	MILOUD	208751	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8572	1	2025-12-09	3370755.00	20.00	SORTIE	HYUNDAI 18516A73	\N	471	f	337852.00	NOURDINE	208753	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8573	1	2025-12-10	3370829.00	74.00	SORTIE	MIT 11469A73	\N	435	f	966404.00	ABDELKHALEK	208754	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8574	1	2025-12-10	3370915.00	86.00	SORTIE	MIT 11470A73	\N	436	f	114814.00	MOHAMED	208755	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8575	1	2025-12-10	3371086.00	171.00	SORTIE	VOLVO 22300A73	\N	481	f	732246.00	MUSTAPHA	208756	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8576	1	2025-12-10	3371183.00	97.00	SORTIE	MIT 4969A73	\N	409	f	955144.00	CHOUAIB	208757	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8581	1	2025-12-10	3372488.00	319.00	SORTIE	VOLVO 17886A73	\N	439	f	706499.00	MJID	208762	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8584	1	2025-12-11	3373100.00	43.00	SORTIE	MIT 4969A73	\N	409	f	955300.00	CHOUAIB	208765	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8585	1	2025-12-11	3373230.00	130.00	SORTIE	MAN 4790B8	\N	403	f	983112.00	KARDODI	208766	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8586	1	2025-12-11	3373447.00	217.00	SORTIE	MIT 11470A73	\N	436	f	115509.00	MOHAMED	208767	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8587	1	2025-12-11	3373478.00	31.00	SORTIE	HYUNDAI 22368A73	\N	482	f	230911.00	BADER	208768	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8588	1	2025-12-11	3373635.00	157.00	SORTIE	MIT 11469A73	\N	435	f	966870.00	ABDELKHALEK	208769	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8589	1	2025-12-11	3373779.00	144.00	SORTIE	VOLVO 22300A73	\N	481	f	732759.00	MUSTAPHA	208770	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8590	1	2025-12-11	3373824.00	45.00	SORTIE	RENAULT 25636A13	\N	411	f	159147.00	YASSINE	208771	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8592	1	2025-12-11	3373979.00	35.00	SORTIE	FENWICK	\N	430	f	28203.00	SAID	208773	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8593	1	2025-12-11	3374023.00	44.00	SORTIE	LINDE	\N	477	f	9371.60	CHAABI	208774	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8595	1	2025-12-11	3374137.00	68.00	SORTIE	MANITOU	\N	484	f	6076.00	SAID	208776	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8596	1	2025-12-11	3374160.00	23.00	SORTIE	LINDE	\N	434	f	7837.70	MILOUD	208777	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8597	1	2025-12-11	3374204.00	44.00	SORTIE	LINDE	\N	472	f	12643.60	AZIZ	208778	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8598	1	2025-12-11	3374423.00	219.00	SORTIE	CHARGEUSE G 938	\N	413	f	8154.30	ABDERRAHIM	208779	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8599	1	2025-12-12	3374446.00	23.00	SORTIE	HYUNDAI 22368A73	\N	482	f	231132.00	BADR	208780	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8600	1	2025-12-12	3374619.00	173.00	SORTIE	MIT 11469A73	\N	435	f	967459.00	ABDELKHALEK	208781	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8601	1	2025-12-12	3374679.00	60.00	SORTIE	HYUNDAI 18516A73	\N	471	f	338182.00	NOURDINE	208782	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8602	1	2025-12-12	3374716.00	37.00	SORTIE	BERLINGO 981A73	\N	417	f	301753.00	MAGHNIA	208783	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8603	1	2025-12-12	3374823.00	107.00	SORTIE	VOLVO 22300A73	\N	481	f	733212.00	MUSTAPHA	208784	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8604	1	2025-12-12	3374973.00	150.00	SORTIE	MIT 11470A73	\N	436	f	116013.00	MOHAMED	208785	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8608	1	2025-12-12	3376178.00	459.00	SORTIE	VOLVO 17885A73	\N	438	f	740619.00	HOUSSAM	208789	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8609	1	2025-12-12	3376249.00	71.00	SORTIE	VOLVO 22300A73	\N	481	f	733503.00	MUSTAPHA	208790	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8611	1	2025-12-12	3376296.00	30.00	SORTIE	LINDE	\N	428	f	40697.00	HASSAN	208792	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8612	1	2025-12-12	3376342.00	46.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	208793	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8613	1	2025-12-12	3376710.00	368.00	SORTIE	MAN 28659D1	\N	410	f	85960.00	CHOUAIB	208794	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8614	1	2025-12-13	3376794.00	84.00	SORTIE	MAN 4790B8	\N	403	f	983505.00	KARDODI	208795	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8615	1	2025-12-13	3376977.00	183.00	SORTIE	MIT 11470A73	\N	436	f	116644.00	MOHAMED	208796	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8616	1	2025-12-13	3377093.00	116.00	SORTIE	MIT 11469A73	\N	435	f	967832.00	ABDELKHALEK	208797	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8617	1	2025-12-13	3377107.00	14.00	SORTIE	KANGO 4812A73	\N	419	f	244808.00	TARMONIA	208798	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8618	1	2025-12-13	3377156.00	49.00	SORTIE	LINDE	\N	472	f	12662.00	ABDELLAH	208799	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8619	1	2025-12-13	3377217.00	61.00	SORTIE	VOLVO 22300A73	\N	481	f	733747.00	MUSTAPHA	208800	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8620	1	2025-12-13	3377246.00	29.00	SORTIE	HYUNDAI 22368A73	\N	482	f	231430.00	BADER	208801	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8622	1	2025-12-13	3377312.00	42.00	SORTIE	LINDE	\N	427	f	30225.00	MILOUD	208803	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8623	1	2025-12-13	3377801.00	489.00	SORTIE	VOLVO 17886A73	\N	439	f	708176.00	MJID	208804	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8624	1	2025-12-13	3377819.00	18.00	SORTIE	LINDE	\N	477	f	9378.90	CHAABI	208805	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8626	1	2025-12-15	3378147.00	187.00	SORTIE	RENAULT 25636A13	\N	411	f	159255.00	YASSINE	208807	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8628	1	2025-12-15	3378317.00	116.00	SORTIE	MIT 11470A73	\N	436	f	117034.00	MOHAMED	208809	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8629	1	2025-12-15	3378513.00	196.00	SORTIE	MIT 4703A73	\N	408	f	585379.00	MUSTAPHA	208810	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8630	1	2025-12-15	3378650.00	137.00	SORTIE	MIT 11469A73	\N	435	f	968343.00	ABDELKHALEK	208811	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8631	1	2025-12-15	3378706.00	56.00	SORTIE	HYUNDAI 18516A73	\N	471	f	338498.00	NOURDINE	208812	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8632	1	2025-12-15	3378977.00	271.00	SORTIE	MAN 28659D1	\N	410	f	86862.00	MJID	208813	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8635	1	2025-12-15	3379083.00	42.00	SORTIE	LINDE	\N	472	f	12678.80	AZIZ	208816	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8636	1	2025-12-16	3379221.00	138.00	SORTIE	MIT 11470A73	\N	436	f	117489.00	MOHAMED	208817	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8639	1	2025-12-16	3380086.00	196.00	SORTIE	VOLVO 22300A73	\N	481	f	734540.00	MUSTAPHA	208820	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8640	1	2025-12-17	3380321.00	235.00	SORTIE	MAN 28659D1	\N	410	f	87633.00	CHOUAIB	208821	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8642	1	2025-12-17	3380584.00	34.00	SORTIE	HYUNDAI 22368A73	\N	482	f	231852.00	BADER	208823	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8643	1	2025-12-17	3380707.00	122.00	SORTIE	VOLVO 70352A2	\N	406	f	511043.00	CHOUAIB	208824	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8644	1	2025-12-17	3380853.00	146.00	SORTIE	MIT 11470A73	\N	436	f	117950.00	MOHAMED	208825	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8645	1	2025-12-17	\N	309.00	SORTIE	VOLVO 17886A73	\N	439	f	709119.00	MJID	208826	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8646	1	2025-12-17	3381574.00	412.00	SORTIE	VOLVO 17885A73	\N	438	f	741707.00	HOUSSAM	208827	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8647	1	2025-12-17	3381700.00	126.00	SORTIE	MAN 4790B8	\N	403	f	984049.00	KARDODI	208828	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8648	1	2025-12-17	3381746.00	46.00	SORTIE	FENWICK	\N	430	f	28218.00	ABDELKHALEK	208829	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8649	1	2025-12-17	3381794.00	48.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	208830	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8650	1	2025-12-17	3381833.00	39.00	SORTIE	LINDE	\N	472	f	12693.50	AZIZ	208831	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8652	1	2025-12-17	3381948.00	87.00	SORTIE	MANITOU	\N	484	f	6116.00	SAID	208833	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8653	1	2025-12-18	3382096.00	148.00	SORTIE	MIT 11470A73	\N	436	f	118490.00	MOHAMED	208834	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8654	1	2025-12-18	3382115.00	19.00	SORTIE	HYUNDAI 22368A73	\N	482	f	232022.00	BADER	208835	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8655	1	2025-12-18	3382189.00	74.00	SORTIE	MIT 11469A73	\N	435	f	969302.00	ABDELKHALEK	208836	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8657	1	2025-12-18	3382313.00	61.00	SORTIE	BERLINGO 10591A73	\N	433	f	390469.00	ABDESSLAM	208838	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8659	1	2025-12-18	3382419.00	67.00	SORTIE	HYUNDAI 18516A73	\N	471	f	338858.00	NOURDINE	208840	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8660	1	2025-12-18	3382439.00	20.00	SORTIE	KANGO 4812A73	\N	419	f	245116.00	TARMONIA	208841	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8661	1	2025-12-18	3382476.00	37.00	SORTIE	LINDE	\N	472	f	9393.30	CHAABI	208842	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8662	1	2025-12-18	3382507.00	31.00	SORTIE	LINDE	\N	434	f	7253.10	MILOUD	208843	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8663	1	2025-12-18	3382550.00	43.00	SORTIE	LINDE	\N	428	f	4071.10	HASSAN	208844	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8664	1	2025-12-19	3382719.00	169.00	SORTIE	MIT 11470A73	\N	436	f	119033.00	MOHAMED	208845	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8665	1	2025-12-19	3382819.00	100.00	SORTIE	MIT 11469A73	\N	435	f	969638.00	ABDELKHALEK	208846	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8669	1	2025-12-20	3383066.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	339079.00	NOURDINE	208850	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8671	1	2025-12-20	3385200.00	134.00	SORTIE	MIT 11469A73	\N	435	f	970099.00	ABDELKHALEK	208852	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8673	1	2025-12-20	3385492.00	32.00	SORTIE	HYUNDAI 22368A73	\N	482	f	232429.00	BADER	208854	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8675	1	2025-12-20	3385569.00	60.00	SORTIE	MIT 11470A73	\N	436	f	119227.00	YASSINE	208856	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8677	1	2025-12-22	3385961.00	359.00	SORTIE	VOLVO 17886A73	\N	439	f	710277.00	MJID	208858	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8678	1	2025-12-22	3386071.00	110.00	SORTIE	MAN 4790B8	\N	403	f	984474.00	KARDODI	208859	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8679	1	2025-12-22	3386183.00	112.00	SORTIE	MIT 4969A73	\N	409	f	955612.00	CHOUAIB	208860	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8680	1	2025-12-22	3386284.00	101.00	SORTIE	MIT 4703A73	\N	408	f	585800.00	MUSTAPHA	208861	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8681	1	2025-12-22	3386440.00	156.00	SORTIE	MIT 11469A73	\N	435	f	970620.00	ABDELKHALEK	208862	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8687	1	2025-12-22	3387599.00	39.00	SORTIE	LINDE	\N	472	f	12728.80	ABDELLAH	208868	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8688	1	2025-12-22	3387623.00	24.00	SORTIE	HYUNDAI 22368A73	\N	482	f	232636.00	BADER	208869	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8689	1	2025-12-22	3387662.00	39.00	SORTIE	HYUNDAI 18516A73	\N	471	f	339310.00	HAMID	208870	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8690	1	2025-12-23	3387806.00	144.00	SORTIE	RENAULT 25636A13	\N	411	f	159785.00	YASSINE	208871	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8691	1	2025-12-23	3387974.00	168.00	SORTIE	MIT 11469A73	\N	435	f	971185.00	ABDELKHALEK	208872	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8692	1	2025-12-23	3388177.00	203.00	SORTIE	MIT 11470A73	\N	436	f	119896.00	MOHAMED	208873	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8693	1	2025-12-23	3388260.00	83.00	SORTIE	VOLVO 70352A2	\N	406	f	511235.00	CHOUAIB	208874	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8695	1	2025-12-23	3389511.00	400.00	SORTIE	VOLVO 17885A73	\N	438	f	724834.00	HOUSSAM	208876	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8696	1	2025-12-23	3389912.00	401.00	SORTIE	MAN 28659D1	\N	410	f	88729.00	CHOUAIB	208877	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8697	1	2025-12-23	3389952.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	339561.00	HAMID	208878	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8698	1	2025-12-23	3390001.00	49.00	SORTIE	FENWICK	\N	430	f	28235.00	SAID	208879	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8699	1	2025-12-23	3390035.00	34.00	SORTIE	LINDE	\N	477	f	9406.60	CHAABI	208880	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8700	1	2025-12-23	3390064.00	29.00	SORTIE	LINDE	\N	472	f	12740.80	ABDELLAH	208881	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8701	1	2025-12-23	3390120.00	56.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	208882	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8703	1	2025-12-23	3390342.00	195.00	SORTIE	CHARGEUSE G 938	\N	413	f	8169.70	ABDERRAHIM	208884	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8704	1	2025-12-23	3390404.00	62.00	SORTIE	HYUNDAI 22772A73	\N	479	f	255308.00	CHAKIB	208885	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8705	1	2025-12-24	3390571.00	167.00	SORTIE	MIT 11470A73	\N	436	f	120478.00	MOHAMED	208886	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8706	1	2025-12-24	3390643.00	72.00	SORTIE	MIT 11469A73	\N	435	f	971384.00	ABDELKHALEK	208887	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8709	1	2025-12-24	3390850.00	90.00	SORTIE	VOLVO 17886A73	\N	439	f	710565.00	MJID	208890	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8711	1	2025-12-24	3391059.00	74.00	SORTIE	MANITOU	\N	484	f	6149.00	SAID	208892	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8712	1	2025-12-24	3391311.00	252.00	SORTIE	VOLVO 17885A73	\N	438	f	743634.00	HOUSSAM	208893	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8713	1	2025-12-24	3391342.00	31.00	SORTIE	HYUNDAI 22368A73	\N	482	f	232930.00	BADER	208894	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8714	1	2025-12-25	3391489.00	147.00	SORTIE	MAN 4790B8	\N	403	f	985084.00	KARDODI	208895	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8715	1	2025-12-25	3391704.00	215.00	SORTIE	MIT 11469A73	\N	435	f	972101.00	ABDELKHALEK	208896	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8717	1	2025-12-25	3391794.00	49.00	SORTIE	HYUNDAI 22772A73	\N	479	f	255624.00	CHAKIB	208898	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8718	1	2025-12-25	3391982.00	188.00	SORTIE	RENAULT 25636A13	\N	411	f	160532.00	YASSINE	208899	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8720	1	2025-12-25	3392154.00	141.00	SORTIE	MIT 4969A73	\N	409	f	956045.00	CHOUAIB	208901	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8721	1	2025-12-25	3392312.00	158.00	SORTIE	CHARGEUSE G 938	\N	413	f	8182.70	ABDERRAHIM	208902	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8722	1	2025-12-26	3392581.00	269.00	SORTIE	MAN 706A73	\N	407	f	140959.00	SOUFIANE	208903	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8723	1	2025-12-26	3392734.00	153.00	SORTIE	MIT 11469A73	\N	435	f	972595.00	ABDELKHALEK	208904	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8724	1	2025-12-26	3392833.00	99.00	SORTIE	VOLVO 70352A2	\N	406	f	511395.00	CHOUAIB	208905	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8727	1	2025-12-26	3393148.00	220.00	SORTIE	MAN 28659D1	\N	410	f	89406.00	CHOUAIB	208908	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8728	1	2025-12-26	3393444.00	296.00	SORTIE	VOLVO 17886A73	\N	439	f	711602.00	MJID	208909	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8731	1	2025-12-26	3393540.00	45.00	SORTIE	LINDE	\N	428	f	40728.00	JAWAD	208912	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8732	1	2025-12-27	3393697.00	157.00	SORTIE	MIT 4969A73	\N	409	f	956552.00	CHOUAIB	208913	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8733	1	2025-12-27	3393828.00	131.00	SORTIE	MIT 11469A73	\N	435	f	973045.00	ABDELKHALEK	208914	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8734	1	2025-12-27	3393945.00	117.00	SORTIE	RENAULT 25636A13	\N	411	f	160955.00	YASSINE	208915	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8735	1	2025-12-27	3393993.00	48.00	SORTIE	HYUNDAI 22772A73	\N	479	f	255912.00	CHAKIB	208916	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8737	1	2025-12-27	3394168.00	39.00	SORTIE	LINDE	\N	472	f	\N	ABDELLAH	208918	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8738	1	2025-12-27	3394202.00	34.00	SORTIE	LINDE	\N	477	f	9419.90	CHAABI	208919	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8739	1	2025-12-27	3394247.00	45.00	SORTIE	FENWICK	\N	430	f	2825.20	ABDELKHALEK	208920	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8741	1	2025-12-29	3394356.00	63.00	SORTIE	MIT 4969A73	\N	409	f	956725.00	MUSTAPHA	208922	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8742	1	2025-12-29	3394584.00	227.00	SORTIE	CHARGEUSE G 938	\N	413	f	8600.80	ABDERRAHIM	208923	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8743	1	2025-12-29	3394675.00	91.00	SORTIE	MAN 4790B8	\N	403	f	985424.00	KARDODI	208924	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8744	1	2025-12-29	3394817.00	142.00	SORTIE	RENAULT 25636A13	\N	411	f	161488.00	YASSINE	208925	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8745	1	2025-12-29	3394844.00	27.00	SORTIE	HYUNDAI 22368A73	\N	482	f	233199.00	BADER	208926	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8746	1	2025-12-29	3394878.00	34.00	SORTIE	HYUNDAI 18516A73	\N	471	f	339775.00	NOURDINE	208927	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8747	1	2025-12-29	3394930.00	52.00	SORTIE	LINDE	\N	472	f	12788.30	ABDELLAH	208928	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8748	1	2025-12-29	3395004.00	74.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	208929	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8750	1	2025-12-30	3395234.00	195.00	SORTIE	MIT 11469A73	\N	435	f	973661.00	ABDELKHALEK	208931	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8751	1	2025-12-30	3395265.00	31.00	SORTIE	BERLINGO 981A73	\N	417	f	302167.00	MAGHNIA	208932	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8752	1	2025-12-30	3395384.00	119.00	SORTIE	RENAULT 25636A13	\N	411	f	161937.00	YASSINE	208933	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8754	1	2025-12-30	3395620.00	173.00	SORTIE	VOLVO 17886A73	\N	439	f	712106.00	MJID	208935	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8755	1	2025-12-30	3395668.00	48.00	SORTIE	HYUNDAI 22772A73	\N	479	f	256212.00	NOURDINE	208936	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8756	1	2025-12-30	3395702.00	34.00	SORTIE	HYUNDAI 18516A73	\N	471	f	339978.00	NOURDINE	208937	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8757	1	2025-12-31	3395737.00	35.00	SORTIE	HYUNDAI 22368A73	\N	482	f	233527.00	BADER	208938	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8758	1	2025-12-31	3395801.00	64.00	SORTIE	MIT 11470A73	\N	436	f	120666.00	MOHAMED	208939	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8760	1	2025-12-31	3396553.00	628.00	SORTIE	VOLVO 17885A73	\N	438	f	745417.00	HOUSSAM	208941	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8761	1	2025-12-31	3396597.00	44.00	SORTIE	HYUNDAI 18516A73	\N	471	f	340255.00	CHAKIB	208942	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8762	1	2025-12-31	3396784.00	187.00	SORTIE	CHARGEUSE G 938	\N	413	f	8215.90	ABDERRAHIM	208943	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8764	1	2025-12-31	3396978.00	181.00	SORTIE	VOLVO 22300A73	\N	481	f	735058.00	MUSTAPHA	208945	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8765	1	2025-12-31	3397061.00	83.00	SORTIE	MANITOU	\N	484	f	6191.00	SAID	208946	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8766	1	2025-12-31	3397111.00	50.00	SORTIE	LINDE	\N	472	f	12807.00	\N	208947	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8767	1	2025-12-31	3397137.00	26.00	SORTIE	FENWICK	\N	430	f	28260.00	ABDELKHALEK	208948	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8770	1	2026-01-01	3397355.00	151.00	SORTIE	RENAULT 25636A13	\N	411	f	162560.00	YASSINE	208951	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8771	1	2026-01-01	3397476.00	121.00	SORTIE	MIT 4969A73	\N	409	f	957023.00	CHOUAIB	208952	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8772	1	2026-01-01	3397577.00	101.00	SORTIE	MIT 11469A73	\N	435	f	973975.00	ABDELKHALEK	208953	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8773	1	2026-01-01	3397760.00	183.00	SORTIE	MIT 11470A73	\N	436	f	121290.00	MOHAMED	208954	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8776	1	2026-01-01	3398694.00	80.00	SORTIE	VOLVO 17886A73	\N	439	f	712341.00	MJID	208957	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8777	1	2026-01-01	3399064.00	370.00	SORTIE	MAN 28659D1	\N	410	f	90537.00	CHOUAIB	208958	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8778	1	2026-01-01	3399076.00	12.00	SORTIE	HYUNDAI 22368A73	\N	482	f	233706.00	BADER	208959	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8779	1	2026-01-01	3399111.00	35.00	SORTIE	LINDE	\N	428	f	40743.00	JAWAD	208960	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8780	1	2026-01-01	3399151.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	340522.00	HAMID	208961	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8781	1	2026-01-02	3399260.00	109.00	SORTIE	VOLVO 70352A2	\N	406	f	511607.00	CHOUAIB	208962	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8782	1	2026-01-02	3399416.00	156.00	SORTIE	RENAULT 25636A13	\N	411	f	163130.00	YASSINE	208963	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8784	1	2026-01-02	3399503.00	47.00	SORTIE	HYUNDAI 22772A73	\N	479	f	256475.00	NOURDINE	208965	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8785	1	2026-01-02	3399594.00	91.00	SORTIE	MIT 11470A73	\N	436	f	121585.00	MOHAMED	208966	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8786	1	2026-01-02	3399634.00	40.00	SORTIE	MIT 11469A73	\N	435	f	974095.00	ABDELKHALEK	208967	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8787	1	2026-01-02	3399678.00	44.00	SORTIE	LINDE	\N	477	f	9437.20	CHAABI	208968	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8791	1	2026-01-02	3400407.00	47.00	SORTIE	HYUNDAI 18516A73	\N	471	f	340821.00	NOURDINE	208972	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8792	1	2026-01-02	3400437.00	30.00	SORTIE	KANGO 4812A73	\N	419	f	245770.00	TARMONIA	208973	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8793	1	2026-01-02	3400487.00	50.00	SORTIE	LINDE	\N	472	f	12827.10	ABDELLAH	208974	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8794	1	2026-01-02	3400662.00	175.00	SORTIE	CHARGEUSE G 938	\N	413	f	8230.60	ABDERRAHIM	208975	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8795	1	2026-01-02	3400846.00	184.00	SORTIE	VOLVO 22300A73	\N	481	f	735695.00	MUSTAPHA	208976	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8796	1	2026-01-03	3401005.00	159.00	SORTIE	MAN 4790B8	\N	403	f	986069.00	KARDODI	208977	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8797	1	2026-01-03	3401138.00	133.00	SORTIE	MIT 11469A73	\N	435	f	974569.00	ABDELKHALEK	208978	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8798	1	2026-01-03	3401276.00	138.00	SORTIE	MIT 11470A73	\N	436	f	122087.00	MOHAMED	208979	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8801	1	2026-01-03	3401927.00	204.00	SORTIE	MIT 4703A73	\N	408	f	586630.00	MUSTAPHA	208982	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8802	1	2026-01-03	3401954.00	27.00	SORTIE	HYUNDAI 22368A73	\N	482	f	234003.00	BADER	208983	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8803	1	2026-01-03	3402068.00	114.00	SORTIE	RENAULT 25636A13	\N	411	f	163535.00	YASSINE	208984	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8804	1	2026-01-03	3402125.00	57.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	208985	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8805	1	2026-01-03	3402235.00	110.00	SORTIE	MAN 28659D1	\N	410	f	90866.00	CHOUAIB	208986	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8806	1	2026-01-03	3402280.00	45.00	SORTIE	HYUNDAI 18516A73	\N	471	f	341113.00	CHAKIB	208987	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8808	1	2026-01-03	3402331.00	29.00	SORTIE	FENWICK	\N	430	f	2826.90	SAID	208989	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8809	1	2026-01-03	3402351.00	20.00	SORTIE	LINDE	\N	477	f	9444.50	CHAABI	208990	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8810	1	2026-01-03	3402382.00	31.00	SORTIE	LINDE	\N	472	f	12840.10	ABDELLAH	208991	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8812	1	2026-01-03	3402735.00	305.00	SORTIE	VOLVO 17886A73	\N	439	f	713396.00	MJID	208993	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8813	1	2026-01-05	3402893.00	157.00	SORTIE	MIT 11470A73	\N	436	f	122597.00	MOHAMED	208994	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8814	1	2026-01-05	3402971.00	78.00	SORTIE	VOLVO 70352A2	\N	406	f	511768.00	CHOUAIB	208995	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8815	1	2026-01-05	3403046.00	76.00	SORTIE	MIT 11469A73	\N	435	f	974787.00	ABDELKHALEK	208996	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8818	1	2026-01-05	3403461.00	54.00	SORTIE	HYUNDAI 22772A73	\N	479	f	256792.00	NOURDINE	208999	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8819	1	2026-01-05	\N	45.00	SORTIE	HYUNDAI 18516A73	\N	471	f	341431.00	NOURDINE	209000	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8820	1	2026-01-05	3403695.00	189.00	SORTIE	VOLVO 22300A73	\N	481	f	736413.00	MUSTAPHA	205501	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8821	1	2026-01-05	3404012.00	317.00	SORTIE	VOLVO 17885A73	\N	438	f	746251.00	HOUSSAM	205502	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8822	1	2026-01-05	3404061.00	50.00	SORTIE	LINDE	\N	472	f	12860.60	AZIZ	205503	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8823	1	2026-01-05	3404089.00	28.00	SORTIE	LINDE	\N	428	f	4075.00	HASSAN	205504	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8824	1	2026-01-06	3404260.00	171.00	SORTIE	RENAULT 25636A13	\N	411	f	164180.00	YASSINE	205505	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8825	1	2026-01-06	3404325.00	65.00	SORTIE	MIT 11470A73	\N	436	f	122795.00	MOHAMED	205506	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8826	1	2026-01-06	3404672.00	347.00	SORTIE	MAN 28659D1	\N	410	f	91874.00	CHOUAIB	205507	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8827	1	2026-01-06	3404825.00	153.00	SORTIE	MIT 11469A73	\N	435	f	975282.00	ABDELKHALEK	205508	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8828	1	2026-01-06	3405164.00	339.00	SORTIE	VOLVO 17886A73	\N	439	f	714412.00	MJID	205509	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8829	1	2026-01-06	3405245.00	81.00	SORTIE	MIT 11470A73	\N	436	f	123069.00	MOHAMED	205510	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8830	1	2026-01-06	3405349.00	104.00	SORTIE	VOLVO 22300A73	\N	481	f	736767.00	MUSTAPHA	205511	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8832	1	2026-01-07	3405575.00	189.00	SORTIE	MIT 4969A73	\N	409	f	957499.00	CHOUAIB	205514	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8833	1	2026-01-07	3405736.00	161.00	SORTIE	MIT 11469A73	\N	435	f	975843.00	ABDELKHALEK	205515	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8834	1	2026-01-07	3405770.00	34.00	SORTIE	HYUNDAI 22368A73	\N	482	f	234339.00	BADER	205516	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8836	1	2026-01-07	3405937.00	43.00	SORTIE	LINDE	\N	472	f	12877.10	AZIZ	205518	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8837	1	2026-01-07	3406022.00	84.00	SORTIE	MANITOU	\N	484	f	6229.00	SAID	205519	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8839	1	2026-01-07	3406062.00	21.00	SORTIE	LINDE	\N	428	f	4076.00	HASSAN	205521	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8841	1	2026-01-07	3406276.00	171.00	SORTIE	CHARGEUSE G 938	\N	413	f	8257.80	ABDERRAHIM	205523	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8842	1	2026-01-08	3406442.00	166.00	SORTIE	MIT 11470A73	\N	436	f	123641.00	MOHAMED	205524	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8843	1	2026-01-08	3406530.00	88.00	SORTIE	VOLVO 70352A2	\N	406	f	511985.00	CHOUAIB	205525	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8844	1	2026-01-08	3406684.00	154.00	SORTIE	RENAULT 25636A13	\N	411	f	164634.00	YASSINE	205526	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8845	1	2026-01-08	3406736.00	52.00	SORTIE	HYUNDAI 22772A73	\N	479	f	257084.00	NOURDINE	205527	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8846	1	2026-01-08	3406803.00	67.00	SORTIE	HYUNDAI 18516A73	\N	471	f	341825.00	HAMID	205528	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8848	1	2026-01-08	3406962.00	130.00	SORTIE	MAN 4790B8	\N	403	f	986551.00	KARDODI	205530	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8849	1	2026-01-08	3407008.00	46.00	SORTIE	LINDE	\N	477	f	9460.90	CHAABI	205531	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8850	1	2026-01-08	3407040.00	32.00	SORTIE	LINDE	\N	472	f	12888.90	AZIZ	205532	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8851	1	2026-01-08	3407088.00	48.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	205533	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8852	1	2026-01-08	3407120.00	32.00	SORTIE	FENWICK	\N	430	f	2828.00	HASSAN	205534	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8853	1	2026-01-09	3407267.00	147.00	SORTIE	RENAULT 25636A13	\N	411	f	165230.00	YASSINE	205535	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8854	1	2026-01-09	3407496.00	228.00	SORTIE	VOLVO 22300A73	\N	481	f	737640.00	MUSTAPHA	205536	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8856	1	2026-01-09	3407627.00	65.00	SORTIE	VOLVO 17886A73	\N	439	f	714521.00	MJID	205538	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8857	1	2026-01-09	3407977.00	350.00	SORTIE	VOLVO 17885A73	\N	438	f	747228.00	HOUSSAM	205539	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8859	1	2026-01-09	3408075.00	75.00	SORTIE	RENAULT 25636A13	\N	411	f	165538.00	YASSINE	205541	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8861	1	2026-01-09	3408168.00	30.00	SORTIE	KANGO 4812A73	\N	419	f	246165.00	TARMONIA	205543	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8862	1	2026-01-09	3408255.00	87.00	SORTIE	MIT 11470A73	\N	436	f	123896.00	MOHAMED	205544	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8863	1	2026-01-10	3408355.00	100.00	SORTIE	MIT 4969A73	\N	409	f	957879.00	CHOUAIB	205545	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8864	1	2026-01-10	3408388.00	33.00	SORTIE	HYUNDAI 22368A73	\N	482	f	234603.00	BADER	205546	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8866	1	2026-01-10	3408451.00	42.00	SORTIE	LINDE	\N	472	f	12905.00	ABDELLAH	205548	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8867	1	2026-01-10	3408489.00	38.00	SORTIE	HYUNDAI 22772A73	\N	479	f	257290.00	NOURDINE	205549	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8868	1	2026-01-10	3408532.00	43.00	SORTIE	HYUNDAI 18516A73	\N	471	f	342088.00	NOURDINE	205550	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8869	1	2026-01-12	3408727.00	195.00	SORTIE	MIT 11470A73	\N	436	f	124560.00	MOHAMED	205551	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8870	1	2026-01-12	3408897.00	170.00	SORTIE	RENAULT 25636A13	\N	411	f	166199.00	YASSINE	205552	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8872	1	2026-01-12	3408968.00	39.00	SORTIE	FENWICK	\N	430	f	28293.00	ABDELKHALEK	205558	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8874	1	2026-01-12	3409177.00	157.00	SORTIE	MIT 4969A73	\N	409	f	958211.00	CHOUAIB	205560	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8875	1	2026-01-12	3409203.00	26.00	SORTIE	HYUNDAI 22368A73	\N	482	f	234863.00	BADER	205561	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8876	1	2026-01-13	3409549.00	346.00	SORTIE	MAN 28659D1	\N	410	f	92880.00	CHOUAIB	205562	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8877	1	2026-01-13	3409719.00	170.00	SORTIE	ISUZU 26128A8	\N	401	f	886258.00	TOUFIK	205563	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8879	1	2026-01-13	3410013.00	256.00	SORTIE	VOLVO 22299A73	\N	480	f	638663.00	THAMI	205565	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8880	1	2026-01-13	3410084.00	71.00	SORTIE	MIT 11470A73	\N	436	f	124756.00	MOHAMED	205566	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8881	1	2026-01-13	3410226.00	142.00	SORTIE	VOLVO 22300A73	\N	481	f	738567.00	MUSTAPHA	205567	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8883	1	2026-01-13	3410508.00	156.00	SORTIE	VOLVO 17886A73	\N	439	f	714957.00	MJID	205569	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8886	1	2026-01-13	3411497.00	361.00	SORTIE	VOLVO 17885A73	\N	438	f	748284.00	HOUSSAM	205572	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8888	1	2026-01-13	3411842.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	342516.00	HAMID	205574	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8891	1	2026-01-13	3412199.00	24.00	SORTIE	LINDE	\N	472	f	12914.40	AZIZ	205577	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8892	1	2026-01-13	3412255.00	56.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	205578	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8893	1	2026-01-13	3412305.00	50.00	SORTIE	HYUNDAI 22772A73	\N	479	f	257606.00	CHAKIB	205579	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8896	1	2026-01-14	3412514.00	124.00	SORTIE	RENAULT 25636A13	\N	411	f	166643.00	YASSINE	205582	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8897	1	2026-01-14	3412672.00	157.00	SORTIE	MIT 11470A73	\N	436	f	125276.00	MOHAMED	205583	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8898	1	2026-01-14	3412797.00	125.00	SORTIE	VOLVO 22300A73	\N	481	f	739080.00	MUSTAPHA	205584	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8900	1	2026-01-14	3413566.00	65.00	SORTIE	MIT 11469A73	\N	435	f	975999.00	ABDELKHALEK	205586	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8902	1	2026-01-14	3413736.00	127.00	SORTIE	MAN 4790B8	\N	403	f	987032.00	KARDODI	205588	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8903	1	2026-01-14	3413763.00	27.00	SORTIE	LINDE	\N	472	f	12924.70	AZIZ	205589	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8904	1	2026-01-14	3413829.00	66.00	SORTIE	VOLVO 22300A73	\N	481	f	739359.00	MUSTAPHA	205590	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8905	1	2026-01-15	3413963.00	134.00	SORTIE	MIT 11469A73	\N	435	f	976469.00	ABDELKHALEK	205591	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8906	1	2026-01-15	3414107.00	144.00	SORTIE	MIT 11470A73	\N	436	f	125726.00	MOHAMED	205592	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8907	1	2026-01-15	3414237.00	130.00	SORTIE	RENAULT 25636A13	\N	411	f	167122.00	YASSINE	205593	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8909	1	2026-01-15	3414622.00	341.00	SORTIE	VOLVO 17885A73	\N	438	f	749210.00	HOUSSAM	205595	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8910	1	2026-01-15	3414663.00	41.00	SORTIE	HYUNDAI 18516A73	\N	471	f	342749.00	HAMID	205596	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8911	1	2026-01-15	3414724.00	61.00	SORTIE	HYUNDAI 22772A73	\N	479	f	258006.00	CHAKIB	205597	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8912	1	2026-01-15	3414903.00	179.00	SORTIE	CHARGEUSE G 938	\N	413	f	\N	ABDERRAHIM	205598	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8913	1	2026-01-15	3414988.00	85.00	SORTIE	RENAULT 25636A13	\N	411	f	167484.00	YASSINE	205599	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8914	1	2026-01-16	3415109.00	121.00	SORTIE	MIT 4969A73	\N	409	f	958562.00	CHOUAIB	205600	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8915	1	2026-01-16	3415242.00	133.00	SORTIE	MIT 11469A73	\N	435	f	976924.00	ABDELKHALEK	205601	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8916	1	2026-01-16	3415286.00	44.00	SORTIE	HYUNDAI 22368A73	\N	482	f	235282.00	BADER	205602	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8918	1	2026-01-16	3415430.00	88.00	SORTIE	VOLVO 22300A73	\N	481	f	739645.00	MUSTAPHA	205604	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8920	1	2026-01-16	3415979.00	367.00	SORTIE	VOLVO 17886A73	\N	439	f	716129.00	MJID	205606	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8924	1	2026-01-16	3416146.00	74.00	SORTIE	MANITOU	\N	484	f	6267.00	SAID	205610	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8925	1	2026-01-16	3416176.00	30.00	SORTIE	LINDE	\N	472	f	9485.60	ABDELKHALEK	205611	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8926	1	2026-01-16	3416224.00	48.00	SORTIE	LINDE	\N	472	f	12944.20	AZIZ	205612	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8927	1	2026-01-16	3416259.00	35.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	205613	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8928	1	2026-01-16	3416271.00	12.00	SORTIE	KANGO 4812A73	\N	419	f	246535.00	TARMONIA	205614	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8929	1	2026-01-17	3416429.00	158.00	SORTIE	RENAULT 25636A13	\N	411	f	168140.00	YASSINE	205615	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8930	1	2026-01-17	3416529.00	100.00	SORTIE	ISUZU 26128A8	\N	401	f	886768.00	TOUFIK	205616	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8931	1	2026-01-17	3416636.00	106.00	SORTIE	MIT 11469A73	\N	435	f	977265.00	ABDELKHALEK	205617	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8932	1	2026-01-17	3417030.00	394.00	SORTIE	MAN 28659D1	\N	410	f	94048.00	CHOUAIB	205618	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8933	1	2026-01-17	3417182.00	152.00	SORTIE	VOLVO 22300A73	\N	481	f	740195.00	MUSTAPHA	205619	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8934	1	2026-01-17	3417338.00	156.00	SORTIE	MIT 11470A73	\N	436	f	126229.00	MOHAMED	205620	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8936	1	2026-01-17	3417490.00	92.00	SORTIE	MIT 11469A73	\N	435	f	977566.00	ABDELKHALEK	205622	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8937	1	2026-01-17	3417511.00	21.00	SORTIE	LINDE	\N	472	f	12952.20	AZIZ	205623	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8938	1	2026-01-17	3417604.00	93.00	SORTIE	VOLVO 22299A73	\N	480	f	638925.00	THAMI	205624	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8939	1	2026-01-17	3417665.00	61.00	SORTIE	FENWICK	\N	430	f	28315.00	MILOUD	205625	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8941	1	2026-01-17	3417738.00	49.00	SORTIE	HYUNDAI 22772A73	\N	479	f	258341.00	CHAKIB	205627	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8942	1	2026-01-17	3417784.00	45.00	SORTIE	RENAULT 25636A13	\N	411	f	168305.00	YASSINE	205628	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8943	1	2026-01-19	3417862.00	78.00	SORTIE	MAN 4790B8	\N	403	f	987312.00	KARDODI	205629	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8944	1	2026-01-19	3417984.00	122.00	SORTIE	MIT 11470A73	\N	436	f	126621.00	MOHAMED	205630	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8945	1	2026-01-19	3418009.00	25.00	SORTIE	HYUNDAI 22368A73	\N	482	f	235575.00	BADER	205631	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8947	1	2026-01-19	3418324.00	160.00	SORTIE	VOLVO 22299A73	\N	480	f	639587.00	THAMI	205633	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8948	1	2026-01-19	3418360.00	36.00	SORTIE	LINDE	\N	472	f	12967.00	ABDELLAH	205634	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8950	1	2026-01-19	3418419.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	342968.00	NOURDINE	205636	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8951	1	2026-01-19	3418609.00	190.00	SORTIE	CHARGEUSE G 938	\N	413	f	8303.40	ABDERRAHIM	205637	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8953	1	2026-01-19	3418665.00	24.00	SORTIE	LINDE	\N	428	f	4077.30	JAWAD	205639	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8954	1	2026-01-20	3418809.00	144.00	SORTIE	RENAULT 25636A13	\N	411	f	168902.00	YASSINE	205640	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8955	1	2026-01-20	3418985.00	176.00	SORTIE	MIT 11469A73	\N	435	f	978044.00	ABDELKHALEK	205641	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8956	1	2026-01-20	3419140.00	155.00	SORTIE	MIT 4703A73	\N	408	f	587926.00	MUSTAPHA	205642	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8958	1	2026-01-20	3419241.00	64.00	SORTIE	MIT 11470A73	\N	436	f	126824.00	MOHAMED	205644	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8959	1	2026-01-20	3419492.00	251.00	SORTIE	VOLVO 17886A73	\N	439	f	716891.00	MJID	205645	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8960	1	2026-01-20	3419524.00	32.00	SORTIE	LINDE	\N	472	f	12979.40	ABDELLAH	205646	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8961	1	2026-01-20	3419561.00	37.00	SORTIE	LINDE	\N	477	f	9499.20	CHAABI	205647	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8962	1	2026-01-20	3419776.00	215.00	SORTIE	MIT 4969A73	\N	409	f	959178.00	CHOUAIB	205648	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8963	1	2026-01-20	3419962.00	186.00	SORTIE	VOLVO 22299A73	\N	480	f	640268.00	THAMI	205649	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8964	1	2026-01-21	3420155.00	193.00	SORTIE	MIT 11470A73	\N	436	f	127469.00	MOHAMED	205650	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8965	1	2026-01-21	3420185.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	235912.00	BADER	205651	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8968	1	2026-01-21	3421423.00	427.00	SORTIE	VOLVO 17885A73	\N	438	f	750398.00	HOUSSAM	205654	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8970	1	2026-01-21	3421817.00	77.00	SORTIE	MANITOU	\N	484	f	6298.80	SAID	205656	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8971	1	2026-01-21	3421860.00	43.00	SORTIE	FENWICK	\N	430	f	28330.00	ABDELKHALEK	205657	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8972	1	2026-01-21	3421961.00	100.00	SORTIE	ISUZU 26128A8	\N	401	f	887204.00	TOUFIK	205658	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8974	1	2026-01-21	3422139.00	141.00	SORTIE	VOLVO 22299A73	\N	480	f	640786.00	THAMI	205660	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8975	1	2026-01-22	3422270.00	131.00	SORTIE	RENAULT 25636A13	\N	411	f	169391.00	YASSINE	205661	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8976	1	2026-01-22	3422669.00	399.00	SORTIE	MAN 28659D1	\N	410	f	95298.00	CHOUAIB	205662	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8977	1	2026-01-22	3422737.00	68.00	SORTIE	HYUNDAI 18516A73	\N	471	f	343350.00	NOURDINE	205663	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8980	1	2026-01-22	3423159.00	26.00	SORTIE	LINDE	\N	477	f	9508.90	CHAABI	205666	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8981	1	2026-01-22	3423211.00	52.00	SORTIE	LINDE	\N	472	f	13000.50	AZIZ	205667	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8982	1	2026-01-22	3423429.00	218.00	SORTIE	CHARGEUSE G 938	\N	413	f	8220.50	ABDERRAHIM	205668	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8985	1	2026-01-23	3423868.00	357.00	SORTIE	VOLVO 17886A73	\N	439	f	718003.00	MJID	205671	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8986	1	2026-01-23	3424004.00	136.00	SORTIE	MIT 11470A73	\N	436	f	127896.00	MOHAMED	205672	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8987	1	2026-01-23	3424171.00	167.00	SORTIE	MIT 11469A73	\N	435	f	978708.00	ABDELKHALEK	205673	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8988	1	2026-01-23	3424201.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	236282.00	BADER	205674	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8990	1	2026-01-23	3424676.00	156.00	SORTIE	RENAULT 25636A13	\N	411	f	170000.00	YASSINE	205676	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8994	1	2026-01-24	3425072.00	148.00	SORTIE	RENAULT 25636A13	\N	411	f	170647.00	YASSINE	205680	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8995	1	2026-01-24	3425208.00	136.00	SORTIE	MAN 4790B8	\N	403	f	987801.00	KARDODI	205681	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8996	1	2026-01-24	3425610.00	402.00	SORTIE	MAN 28659D1	\N	410	f	96554.00	CHOUAIB	205682	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8997	1	2026-01-24	3425665.00	55.00	SORTIE	HYUNDAI 18516A73	\N	471	f	343651.00	NOURDINE	205683	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
8998	1	2026-01-24	3425862.00	197.00	SORTIE	VOLVO 22299A73	\N	480	f	641578.00	THAMI	205684	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9000	1	2026-01-24	3425924.00	30.00	SORTIE	KANGO 4812A73	\N	419	f	246770.00	TARMONIA	205686	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9001	1	2026-01-24	3426055.00	131.00	SORTIE	MIT 11470A73	\N	436	f	128138.00	MOHAMED	205687	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9002	1	2026-01-24	3426081.00	26.00	SORTIE	VOLVO 22299A73	\N	480	f	641658.00	THAMI	205688	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9003	1	2026-01-24	3426103.00	22.00	SORTIE	MIT 11470A73	\N	436	f	\N	-	205689	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9005	1	2026-01-24	3426264.00	145.00	SORTIE	CHARGEUSE G 938	\N	413	f	8331.70	ABDERRAHIM	205691	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9006	1	2026-01-24	3426301.00	37.00	SORTIE	FENWICK	\N	430	f	28344.00	SAID	205692	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9007	1	2026-01-24	3426314.00	13.00	SORTIE	LINDE	\N	477	f	9513.80	CHAABI	205693	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9008	1	2026-01-26	3426446.00	132.00	SORTIE	MIT 11469A73	\N	435	f	979105.00	MUSTAPHA	205694	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9009	1	2026-01-26	3426513.00	67.00	SORTIE	HYUNDAI 18516A73	\N	471	f	344053.00	HAMZA	205695	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9010	1	2026-01-26	3426551.00	38.00	SORTIE	HYUNDAI 22368A73	\N	482	f	236619.00	BADER	205696	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9011	1	2026-01-26	3426589.00	38.00	SORTIE	BERLINGO 981A73	\N	417	f	302668.00	MAGHNIA	205697	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9012	1	2026-01-26	3426678.00	89.00	SORTIE	VOLVO 70352A2	\N	406	f	512127.00	CHOUAIB	205698	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9013	1	2026-01-26	3426736.00	58.00	SORTIE	RENAULT 25636A13	\N	411	f	170854.00	YASSINE	205699	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9014	1	2026-01-26	3427202.00	466.00	SORTIE	VOLVO 17885A73	\N	438	f	751696.00	HOUSSAM	205700	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9015	1	2026-01-26	3427213.00	11.00	SORTIE	LINDE	\N	427	f	3023.00	MILOUD	205701	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9017	1	2026-01-26	3427333.00	60.00	SORTIE	LINDE	\N	472	f	13024.10	ABDELLAH	205703	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9018	1	2026-01-27	3427503.00	170.00	SORTIE	MIT 4969A73	\N	409	f	959630.00	CHOUAIB	205704	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9019	1	2026-01-27	3427536.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	344271.00	NOURDINE	205705	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9020	1	2026-01-27	3427792.00	256.00	SORTIE	VOLVO 17886A73	\N	439	f	718710.00	MJID	205706	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9021	1	2026-01-27	3427993.00	201.00	SORTIE	MIT 11470A73	\N	436	f	129087.00	MOHAMED	205707	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9022	1	2026-01-27	3428094.00	101.00	SORTIE	ISUZU 26128A8	\N	401	f	887698.00	TOUFIK	205708	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9023	1	2026-01-27	3428178.00	84.00	SORTIE	MIT 11469A73	\N	435	f	979340.00	ABDELKHALEK	205709	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9024	1	2026-01-27	3428280.00	102.00	SORTIE	MAN 28659D1	\N	410	f	96832.00	CHOUAIB	205710	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9025	1	2026-01-27	3428429.00	149.00	SORTIE	MIT 4703A73	\N	408	f	588525.00	MUSTAPHA	205711	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9027	1	2026-01-27	3428782.00	194.00	SORTIE	CHARGEUSE G 938	\N	413	f	8346.50	ABDERRAHIM	205713	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9029	1	2026-01-27	3428860.00	21.00	SORTIE	LINDE	\N	477	f	9522.00	CHAABI	205715	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9030	1	2026-01-27	3429047.00	187.00	SORTIE	VOLVO 22299A73	\N	480	f	642376.00	THAMI	205716	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9031	1	2026-01-27	3429074.00	27.00	SORTIE	LINDE	\N	472	f	13034.40	ABDELLAH	205717	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9033	1	2026-01-28	3429161.00	54.00	SORTIE	VOLVO 70352A2	\N	406	f	512192.00	CHOUAIB	205719	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9034	1	2026-01-28	3429291.00	130.00	SORTIE	MIT 11469A73	\N	435	f	979741.00	ABDELKHALEK	205720	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9035	1	2026-01-28	3429387.00	96.00	SORTIE	MIT 11470A73	\N	436	f	129361.00	MOHAMED	205721	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9037	1	2026-01-28	3429490.00	37.00	SORTIE	HYUNDAI 22368A73	\N	482	f	237033.00	BADER	205723	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9038	1	2026-01-28	3429700.00	210.00	SORTIE	VOLVO 17885A73	\N	438	f	752248.00	HOUSSAM	205724	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9039	1	2026-01-28	3429996.00	296.00	SORTIE	RENAULT 25636A13	\N	411	f	171478.00	YASSINE	205725	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9040	1	2026-01-28	3430132.00	136.00	SORTIE	VOLVO 22299A73	\N	480	f	642888.00	THAMI	205726	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9041	1	2026-01-28	3430221.00	89.00	SORTIE	MANITOU	\N	484	f	6342.60	SAID	205727	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9042	1	2026-01-28	3430254.00	33.00	SORTIE	FENWICK	\N	430	f	28356.60	ABDELKHALEK	205728	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9043	1	2026-01-28	3430320.00	66.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	205729	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9044	1	2026-01-28	3430346.00	26.00	SORTIE	LINDE	\N	472	f	13045.20	ABDELLAH	205730	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9045	1	2026-01-29	3430486.00	140.00	SORTIE	MAN 4790B8	\N	403	f	988324.00	KARDODI	205731	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9046	1	2026-01-29	3430677.00	191.00	SORTIE	MIT 11470A73	\N	436	f	129990.00	MOHAMED	205732	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9047	1	2026-01-29	3430800.00	123.00	SORTIE	MIT 4969A73	\N	409	f	959987.00	CHOUAIB	205733	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9048	1	2026-01-29	3430973.00	173.00	SORTIE	MAN 28659D1	\N	410	f	97399.00	CHOUAIB	205734	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9049	1	2026-01-29	3431037.00	64.00	SORTIE	HYUNDAI 18516A73	\N	471	f	344672.00	NOURDINE	205735	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9052	1	2026-01-29	3431698.00	39.00	SORTIE	LINDE	\N	428	f	4079.30	MILOUD	205738	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9053	1	2026-01-29	3431716.00	18.00	SORTIE	LINDE	\N	477	f	9528.40	CHAABI	205739	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9055	1	2026-01-29	3431784.00	27.00	SORTIE	LINDE	\N	472	f	13055.30	ABDELLAH	205741	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9056	1	2026-01-30	3431892.00	108.00	SORTIE	MIT 11469A73	\N	435	f	980051.00	ABDELKHALEK	205742	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9059	1	2026-01-30	3432298.00	60.00	SORTIE	MIT 11470A73	\N	436	f	130186.00	MOHAMED	205745	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9060	1	2026-01-30	3432466.00	168.00	SORTIE	CHARGEUSE G 938	\N	413	f	8360.40	ABDERRAHIM	205746	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9061	1	2026-01-30	3432492.00	26.00	SORTIE	HYUNDAI 22368A73	\N	482	f	237291.00	BADER	205747	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9063	1	2026-01-30	3433041.00	398.00	SORTIE	VOLVO 17885A73	\N	438	f	753503.00	HOUSSAM	205749	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9065	1	2026-01-30	3433104.00	41.00	SORTIE	HYUNDAI 18516A73	\N	471	f	344936.00	HAMID	205751	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9066	1	2026-01-30	3433131.00	27.00	SORTIE	LINDE	\N	472	f	13066.90	ABDELLAH	205752	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9067	1	2026-01-30	3433339.00	208.00	SORTIE	VOLVO 22299A73	\N	480	f	643722.00	THAMI	205753	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9068	1	2026-01-31	3433737.00	398.00	SORTIE	VOLVO 17886A73	\N	439	f	719991.00	MJID	205754	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9069	1	2026-01-31	3433887.00	150.00	SORTIE	MIT 11470A73	\N	436	f	130711.00	MOHAMED	205755	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9070	1	2026-01-31	3434086.00	198.00	SORTIE	RENAULT 25636A13	\N	411	f	172856.00	YASSINE	205756	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9071	1	2026-01-31	3434121.00	35.00	SORTIE	HYUNDAI 18516A73	\N	471	f	345163.00	NOURDINE	205757	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9074	1	2026-01-31	3434236.00	36.00	SORTIE	FENWICK	\N	430	f	28369.00	SAID	205760	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9075	1	2026-01-31	3434361.00	125.00	SORTIE	CHARGEUSE G 938	\N	413	f	8371.30	ABDERRAHIM	205761	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9076	1	2026-01-31	3434382.00	21.00	SORTIE	LINDE	\N	477	f	9536.40	CHAABI	205762	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9077	1	2026-01-31	3434403.00	21.00	SORTIE	LINDE	\N	472	f	13036.10	AZIZ	205763	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9079	1	2026-01-31	3434453.00	31.00	SORTIE	HYUNDAI 22368A73	\N	482	f	237633.00	BADER	205765	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9081	1	2026-02-02	3434556.00	60.00	SORTIE	MIT 4969A73	\N	409	f	960526.00	CHOUAIB	205767	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9082	1	2026-02-02	3434656.00	100.00	SORTIE	VOLVO 70352A2	\N	406	f	512435.00	CHOUAIB	205768	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9083	1	2026-02-02	3434742.00	86.00	SORTIE	MIT 11470A73	\N	436	f	131020.00	MOHAMED	205769	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9085	1	2026-02-02	3434831.00	30.00	SORTIE	KANGO 4812A73	\N	419	f	247111.00	TARMONIA	205771	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9087	1	2026-02-02	3434890.00	27.00	SORTIE	MANITOU	\N	426	f	1278.00	MILOUD	205773	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9088	1	2026-02-02	3434930.00	40.00	SORTIE	LINDE	\N	472	f	13092.10	AZIZ	205774	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9089	1	2026-02-03	3435107.00	177.00	SORTIE	ISUZU 26128A8	\N	401	f	888596.00	TOUFK	205781	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9090	1	2026-02-03	3435243.00	136.00	SORTIE	MIT 4969A73	\N	409	f	960643.00	CHOUAIB	205782	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9092	1	2026-02-04	3436177.00	140.00	SORTIE	MAN 4790B8	\N	403	f	988904.00	KARDODI	205784	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9093	1	2026-02-04	3436301.00	124.00	SORTIE	MIT 4703A73	\N	408	f	589059.00	MUSTAPHA	205785	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9095	1	2026-02-04	3436592.00	78.00	SORTIE	MIT 11470A73	\N	436	f	131926.00	MOHAMED	205787	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9102	1	2026-02-04	3438769.00	309.00	SORTIE	MAN 28659D1	\N	410	f	98307.00	CHOUAIB	205794	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9103	1	2026-02-04	3438812.00	43.00	SORTIE	LINDE	\N	472	f	13109.40	AZIZ	205795	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9105	1	2026-02-04	3439842.00	29.00	SORTIE	FENWICK	\N	430	f	25378.00	ABDELKHALEK	205797	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9108	1	2026-02-05	3440050.00	131.00	SORTIE	MIT 11470A73	\N	436	f	132358.00	MOHAMED	205800	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9110	1	2026-02-05	3440240.00	29.00	SORTIE	HYUNDAI 22368A73	\N	482	f	238270.00	BADER	205802	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9111	1	2026-02-05	3440327.00	87.00	SORTIE	RENAULT 25636A13	\N	411	f	173186.00	YASSINE	205803	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9112	1	2026-02-05	3440808.00	481.00	SORTIE	VOLVO 17885A73	\N	438	f	754874.00	HOUSSAM	205804	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9113	1	2026-02-05	3440845.00	37.00	SORTIE	LINDE	\N	477	f	9549.80	CHAABI	205805	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9114	1	2026-02-05	3440870.00	25.00	SORTIE	LINDE	\N	427	f	30240.00	MILOUD	205806	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9116	1	2026-02-05	3441053.00	170.00	SORTIE	CHARGEUSE G 938	\N	413	f	8399.70	ABDERRAHIM	205808	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9117	1	2026-02-05	3441235.00	182.00	SORTIE	VOLVO 22299A73	\N	480	f	644334.00	THAMI	205809	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9118	1	2026-02-06	3441380.00	145.00	SORTIE	MIT 4969A73	\N	409	f	961092.00	CHOUAIB	205810	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9119	1	2026-02-06	3441628.00	248.00	SORTIE	MAN 28659D1	\N	410	f	99081.00	CHOUAIB	205811	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9120	1	2026-02-06	3441752.00	124.00	SORTIE	VOLVO 22300A73	\N	481	f	741022.00	MUSTAPHA	205812	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9121	1	2026-02-06	3442037.00	285.00	SORTIE	VOLVO 17886A73	\N	439	f	720874.00	MJID	205813	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9122	1	2026-02-06	3442225.00	188.00	SORTIE	MIT 11470A73	\N	436	f	132964.00	MOHAMED	205814	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9124	1	2026-02-06	3442407.00	134.00	SORTIE	RENAULT 25636A13	\N	411	f	173650.00	YASSINE	205816	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9125	1	2026-02-06	3442451.00	44.00	SORTIE	LINDE	\N	472	f	13126.20	AZIZ	205817	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9127	1	2026-02-06	3442525.00	30.00	SORTIE	VOLVO 22300A73	\N	481	f	741100.00	MUSTAPHA	205819	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9128	1	2026-02-06	3442567.00	42.00	SORTIE	LINDE	\N	434	f	7868.20	MILOUD	205820	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9129	1	2026-02-06	3442654.00	87.00	SORTIE	MANITOU	\N	484	f	6384.00	SAID	205821	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9130	1	2026-02-06	3442681.00	27.00	SORTIE	HYUNDAI 22368A73	\N	482	f	238539.00	BADER	205822	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9131	1	2026-02-07	3442810.00	129.00	SORTIE	RENAULT 25636A13	\N	411	f	174150.00	YASSINE	205823	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9132	1	2026-02-07	3442866.00	56.00	SORTIE	HYUNDAI 18516A73	\N	471	f	345506.00	NOURDINE	205824	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9133	1	2026-02-07	3443012.00	146.00	SORTIE	MIT 11470A73	\N	436	f	133431.00	MOHAMED	205825	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9134	1	2026-02-07	3443200.00	188.00	SORTIE	VOLVO 22299A73	\N	480	f	645050.00	THAMI	205826	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9136	1	2026-02-07	3443270.00	20.00	SORTIE	KANGO 4812A73	\N	419	f	247246.00	TARMONIA	205828	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9137	1	2026-02-07	3443341.00	70.00	SORTIE	VOLVO 22299A73	\N	480	f	645303.00	THAMI	205829	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9138	1	2026-02-07	3443360.00	19.00	SORTIE	LINDE	\N	477	f	9557.00	CHAABI	205830	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9139	1	2026-02-07	3443385.00	25.00	SORTIE	LINDE	\N	472	f	13136.90	AZIZ	205831	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9140	1	2026-02-09	3443437.00	52.00	SORTIE	HYUNDAI 18516A73	\N	471	f	345824.00	NOURDINE	205832	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9141	1	2026-02-09	3443517.00	80.00	SORTIE	MIT 11470A73	\N	436	f	134027.00	MOHAMED	205833	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9142	1	2026-02-09	3443578.00	61.00	SORTIE	MAN 4790B8	\N	403	f	989447.00	KARDODI	205834	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9143	1	2026-02-09	3443678.00	100.00	SORTIE	VOLVO 22300A73	\N	481	f	741763.00	MUSTAPHA	205835	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9144	1	2026-02-09	3443816.00	138.00	SORTIE	RENAULT 25636A13	\N	411	f	174684.00	YASSINE	205836	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9145	1	2026-02-09	3443916.00	100.00	SORTIE	MIT 4969A73	\N	409	f	961380.00	MUSTAPHA	205837	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9147	1	2026-02-09	3444417.00	471.00	SORTIE	VOLVO 17885A73	\N	438	f	756105.00	HOUSSAM	205839	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9148	1	2026-02-09	3444442.00	25.00	SORTIE	LINDE	\N	427	f	3025.20	MILOUD	205840	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9149	1	2026-02-09	3444492.00	50.00	SORTIE	CHARGEUSE G 938	\N	413	f	\N	ABDERRAHIM	205841	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9150	1	2026-02-09	3444557.00	65.00	SORTIE	MANITOU	\N	426	f	\N	SAID	205842	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9151	1	2026-02-09	3444637.00	80.00	SORTIE	ISUZU 26128A8	\N	401	f	889122.00	TOUFIK	205843	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9152	1	2026-02-10	3444668.00	31.00	SORTIE	HYUNDAI 18516A73	\N	471	f	346014.00	NOURDINE	205844	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9153	1	2026-02-10	3444774.00	105.00	SORTIE	VOLVO 22299A73	\N	480	f	646108.00	THAMI	205845	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9154	1	2026-02-10	3444824.00	50.00	SORTIE	VOLVO 22300A73	\N	481	f	742385.00	MUSTAPHA	205846	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9156	1	2026-02-10	3444947.00	82.00	SORTIE	MIT 11470A73	\N	436	f	134265.00	MOHAMED	205852	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9157	1	2026-02-11	3444971.00	24.00	SORTIE	HYUNDAI 22368A73	\N	482	f	239020.00	BADER	205856	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9158	1	2026-02-12	3445264.00	293.00	SORTIE	VOLVO 17886A73	\N	439	f	721912.00	MJID	205866	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9159	1	2026-02-12	3445393.00	129.00	SORTIE	MIT 4969A73	\N	409	f	961779.00	CHOUAIB	205867	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9160	1	2026-02-12	3445510.00	117.00	SORTIE	VOLVO 70352A2	\N	406	f	512612.00	CHOUAIB	205868	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9161	1	2026-02-12	3445648.00	138.00	SORTIE	VOLVO 22300A73	\N	481	f	742966.00	MUSTAPHA	205869	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9162	1	2026-02-12	3445682.00	34.00	SORTIE	HYUNDAI 18516A73	\N	471	f	346441.00	NOURDINE	205870	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9164	1	2026-02-12	3446378.00	346.00	SORTIE	MAN 28659D1	\N	410	f	100361.00	CHOUAIB	205872	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9166	1	2026-02-12	3446590.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	239160.00	BADER	205874	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9169	1	2026-02-12	3447269.00	142.00	SORTIE	VOLVO 22299A73	\N	480	f	646830.00	THAMI	205877	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9171	1	2026-02-12	3447615.00	31.00	SORTIE	LINDE	\N	477	f	9568.80	CHAABI	205879	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9173	1	2026-02-13	3447776.00	128.00	SORTIE	VOLVO 22300A73	\N	481	f	743464.00	MUSTAPHA	205881	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9174	1	2026-02-13	3447943.00	167.00	SORTIE	MIT 11470A73	\N	436	f	135972.00	MOHAMED	205882	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9175	1	2026-02-13	3447983.00	40.00	SORTIE	HYUNDAI 18516A73	\N	471	f	346697.00	NOURDINE	205883	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9176	1	2026-02-13	3448133.00	150.00	SORTIE	MIT 4703A73	\N	408	f	589744.00	MUSTAPHA	205884	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9178	1	2026-02-13	3448185.00	36.00	SORTIE	LINDE	\N	434	f	7901.30	AZIZ	205886	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9180	1	2026-02-13	3448374.00	45.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	205888	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9182	1	2026-02-14	3448594.00	173.00	SORTIE	MIT 11470A73	\N	436	f	136538.00	MOHAMED	205890	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9183	1	2026-02-14	3448745.00	151.00	SORTIE	ISUZU 26128A8	\N	401	f	889715.00	TOUFIK	205891	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9184	1	2026-02-14	3448774.00	29.00	SORTIE	HYUNDAI 22368A73	\N	482	f	239582.00	BADER	205892	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9185	1	2026-02-14	3448807.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	346900.00	NOURDINE	205893	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9186	1	2026-02-14	3448948.00	141.00	SORTIE	VOLVO 22300A73	\N	481	f	743895.00	MUSTAPHA	205894	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9188	1	2026-02-14	3449193.00	190.00	SORTIE	VOLVO 22299A73	\N	480	f	647528.00	THAMI	205896	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9190	1	2026-02-14	3449379.00	132.00	SORTIE	MAN 28659D1	\N	410	f	100677.00	CHOUAIB	205898	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9191	1	2026-02-14	3449569.00	190.00	SORTIE	CHARGEUSE G 938	\N	413	f	8443.10	ABDERRAHIM	205899	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9192	1	2026-02-14	3449591.00	22.00	SORTIE	LINDE	\N	477	f	9577.20	CHAABI	205900	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9193	1	2026-02-14	3449627.00	36.00	SORTIE	FENWICK	\N	430	f	28405.00	ABDELKHALEK	205901	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9195	1	2026-02-14	3450153.00	500.00	SORTIE	VOLVO 17885A73	\N	438	f	757445.00	HOUSSAM	205903	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9196	1	2026-02-16	3450535.00	382.00	SORTIE	VOLVO 17886A73	\N	439	f	723057.00	MJID	205904	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9197	1	2026-02-16	3450719.00	184.00	SORTIE	MIT 4969A73	\N	409	f	962360.00	CHOUAIB	205905	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9198	1	2026-02-16	3450840.00	121.00	SORTIE	VOLVO 70352A2	\N	406	f	512855.00	CHOUAIB	205906	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9199	1	2026-02-16	3451012.00	172.00	SORTIE	VOLVO 22300A73	\N	481	f	744579.00	MUSTAPHA	205907	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9200	1	2026-02-16	3451034.00	22.00	SORTIE	HYUNDAI 22368A73	\N	482	f	239714.00	BADER	205908	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9201	1	2026-02-16	3451204.00	170.00	SORTIE	MIT 11470A73	\N	436	f	137101.00	MOHAMED	205909	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9204	1	2026-02-16	3451691.00	44.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347163.00	NOURDINE	205912	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9205	1	2026-02-16	3451726.00	35.00	SORTIE	VOLVO 22300A73	\N	481	f	744693.00	MUSTAPHA	205913	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9206	1	2026-02-16	3451896.00	170.00	SORTIE	VOLVO 22299A73	\N	480	f	648149.00	THAMI	205914	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9207	1	2026-02-16	3452090.00	194.00	SORTIE	RENAULT 25636A13	\N	411	f	175995.00	YASSINE	205915	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9208	1	2026-02-16	3452116.00	26.00	SORTIE	LINDE	\N	427	f	30271.00	MILOUD	205916	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9210	1	2026-02-17	3452353.00	207.00	SORTIE	MIT 11470A73	\N	436	f	137808.00	MOHAMED	205918	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9214	1	2026-02-17	3453058.00	42.00	SORTIE	VOLVO 22299A73	\N	480	f	648272.00	THAMI	205922	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9215	1	2026-02-17	3453104.00	46.00	SORTIE	LINDE	\N	434	f	7927.70	ABDELLAH	205923	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9216	1	2026-02-17	3453136.00	32.00	SORTIE	MIT 11470A73	\N	436	f	137887.00	MOHAMED	205924	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9218	1	2026-02-17	3453206.00	25.00	SORTIE	LINDE	\N	477	f	9586.70	CHAABI	205926	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9219	1	2026-02-17	3453370.00	164.00	SORTIE	CHARGEUSE G 938	\N	413	f	8456.90	ABDERRAHIM	205927	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9222	1	2026-02-18	3453754.00	196.00	SORTIE	RENAULT 25636A13	\N	411	f	176723.00	YASSINE	205930	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9223	1	2026-02-18	3453810.00	56.00	SORTIE	HYUNDAI 22772A73	\N	479	f	258670.00	NOURDINE	205931	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9225	1	2026-02-18	3454150.00	43.00	SORTIE	HYUNDAI 22368A73	\N	482	f	240193.00	BADER	205933	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9226	1	2026-02-18	3454314.00	164.00	SORTIE	MIT 4703A73	\N	408	f	590559.00	MUSTAPHA	205934	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9227	1	2026-02-18	3454612.00	298.00	SORTIE	MAN 28659D1	\N	410	f	101568.00	CHOUAIB	205935	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9228	1	2026-02-18	3454627.00	16.00	SORTIE	LINDE	\N	427	f	30278.00	MILOUD	205936	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9229	1	2026-02-18	3454707.00	80.00	SORTIE	RENAULT 25636A13	\N	411	f	177029.00	YASSINE	205937	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9230	1	2026-02-18	3454740.00	33.00	SORTIE	FENWICK	\N	430	f	28416.00	ABDELKHALEK	205938	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9231	1	2026-02-18	3454873.00	133.00	SORTIE	VOLVO 22299A73	\N	480	f	648743.00	THAMI	205939	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9232	1	2026-02-18	3454973.00	100.00	SORTIE	MAN 4790B8	\N	403	f	990159.00	KARDODI	205940	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9234	1	2026-02-19	3455156.00	127.00	SORTIE	MIT 4969A73	\N	409	f	962741.00	CHOUAIB	205942	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9235	1	2026-02-19	3455316.00	160.00	SORTIE	MIT 11470A73	\N	436	f	138461.00	MOHAMED	205943	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9237	1	2026-02-19	3455913.00	87.00	SORTIE	MANITOU	\N	484	f	6423.00	SAID	205945	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9240	1	2026-02-19	3456134.00	58.00	SORTIE	MANITOU	\N	426	f	1286.00	SAID	205948	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9242	1	2026-02-19	3456923.00	107.00	SORTIE	RENAULT 25636A13	\N	411	f	177476.00	YASSINE	205950	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9243	1	2026-02-19	3456984.00	61.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347421.00	NOURDINE	205951	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9244	1	2026-02-20	3457138.00	154.00	SORTIE	VOLVO 70352A2	\N	406	f	513206.00	CHOUAIB	205952	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9245	1	2026-02-20	3457333.00	195.00	SORTIE	VOLVO 22300A73	\N	481	f	745346.00	MUSTAPHA	205953	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9246	1	2026-02-20	3457390.00	57.00	SORTIE	MIT 11470A73	\N	436	f	138637.00	MOHAMED	205954	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9247	1	2026-02-20	3457422.00	32.00	SORTIE	HYUNDAI 22368A73	\N	482	f	240571.00	BADER	205955	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9249	1	2026-02-20	3457490.00	30.00	SORTIE	BERLINGO 981A73	\N	417	f	303108.00	MAGHNIA	205957	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9251	1	2026-02-20	3457636.00	97.00	SORTIE	MIT 4969A73	\N	409	f	963036.00	CHOUAIB	205959	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9252	1	2026-02-20	3457646.00	10.00	SORTIE	VOLVO 22300A73	\N	481	f	745376.00	MUSTAPHA	205960	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9254	1	2026-02-21	3458031.00	350.00	SORTIE	VOLVO 17886A73	\N	439	f	724012.00	MJID	205962	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9255	1	2026-02-21	3458196.00	165.00	SORTIE	MIT 11470A73	\N	436	f	139171.00	MOHAMED	205963	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9256	1	2026-02-21	3458255.00	59.00	SORTIE	HYUNDAI 22772A73	\N	479	f	259002.00	NOURDINE	205964	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9257	1	2026-02-21	3458496.00	241.00	SORTIE	VOLVO 22299A73	\N	480	f	649541.00	THAMI	205965	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9260	1	2026-02-21	3460823.00	29.00	SORTIE	FENWICK	\N	430	f	2842.80	ABDELKHALEK	205968	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9261	1	2026-02-21	3461030.00	207.00	SORTIE	CHARGEUSE G 938	\N	413	f	8474.20	ABDERRAHIM	205969	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9262	1	2026-02-21	3461052.00	22.00	SORTIE	HYUNDAI 22368A73	\N	482	f	240740.00	BADER	205970	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9263	1	2026-02-21	3461115.00	63.00	SORTIE	BERLINGO 10591A73	\N	433	f	399866.00	ABDESSLAM	205971	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9265	1	2026-02-21	3461287.00	19.00	SORTIE	LINDE	\N	427	f	3028.70	MILOUD	205973	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9266	1	2026-02-21	3461337.00	50.00	SORTIE	LINDE	\N	434	f	7957.50	ABDELLAH	205974	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9267	1	2026-02-21	3461375.00	38.00	SORTIE	LINDE	\N	477	f	9601.10	CHAABI	205975	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9268	1	2026-02-21	3461407.00	32.00	SORTIE	LINDE	\N	428	f	4081.00	JAWAD	205976	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9271	1	2026-02-23	3461645.00	153.00	SORTIE	MIT 4969A73	\N	409	f	963589.00	CHOUAIB	205979	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9272	1	2026-02-23	3461851.00	206.00	SORTIE	MIT 11470A73	\N	436	f	139888.00	MOHAMED	205980	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9273	1	2026-02-23	3462024.00	173.00	SORTIE	VOLVO 22300A73	\N	481	f	746068.00	MUSTAPHA	205981	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9274	1	2026-02-23	3462551.00	527.00	SORTIE	VOLVO 17885A73	\N	438	f	758908.00	HOUSSAM	205982	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9275	1	2026-02-23	3462670.00	119.00	SORTIE	MAN 4790B8	\N	403	f	990563.00	KARDODI	205983	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9276	1	2026-02-23	3462890.00	220.00	SORTIE	VOLVO 22299A73	\N	480	f	650338.00	THAMI	205984	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9277	1	2026-02-23	3462915.00	25.00	SORTIE	VOLVO 22300A73	\N	481	f	748158.00	MUSTAPHA	205985	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9278	1	2026-02-23	3462978.00	63.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347421.00	NOURDINE	205986	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9280	1	2026-02-23	3463082.00	62.00	SORTIE	MIT 11470A73	\N	436	f	140069.00	MOHAMED	205988	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9281	1	2026-02-24	3463109.00	27.00	SORTIE	HYUNDAI 22368A73	\N	482	f	241036.00	BADER	205989	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9283	1	2026-02-24	3463443.00	41.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347421.00	NOURDINE	205991	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9284	1	2026-02-24	3463490.00	47.00	SORTIE	HYUNDAI 22772A73	\N	479	f	252279.00	NOURDINE	205992	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9285	1	2026-02-24	3463621.00	131.00	SORTIE	RENAULT 25636A13	\N	411	f	177864.00	YASSINE	205993	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9286	1	2026-02-24	3463704.00	83.00	SORTIE	VOLVO 17886A73	\N	439	f	724222.00	MJID	205994	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9287	1	2026-02-24	3463784.00	80.00	SORTIE	VOLVO 22300A73	\N	481	f	746462.00	MUSTAPHA	205995	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9288	1	2026-02-24	3463831.00	47.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	205996	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9289	1	2026-02-24	3463858.00	27.00	SORTIE	LINDE	\N	428	f	40822.00	JAWAD	205997	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9290	1	2026-02-24	3463968.00	110.00	SORTIE	ISUZU 26128A8	\N	401	f	890278.00	TOUFIK	205998	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9291	1	2026-02-24	3464134.00	166.00	SORTIE	MIT 4969A73	\N	409	f	964202.00	CHOUAIB	205999	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9293	1	2026-02-25	3464471.00	193.00	SORTIE	MIT 11470A73	\N	436	f	140742.00	MOHAMED	206751	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9295	1	2026-02-25	3464647.00	139.00	SORTIE	VOLVO 70352A2	\N	406	f	513530.00	CHOUAIB	206753	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9297	1	2026-02-25	3465150.00	217.00	SORTIE	CHARGEUSE G 938	\N	413	f	8495.20	ABDERRAHIM	206755	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9298	1	2026-02-25	3465196.00	46.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347421.00	NOURDINE	206756	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9300	1	2026-02-25	3465351.00	110.00	SORTIE	MIT 4703A73	\N	408	f	591069.00	MUSTAPHA	206758	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9301	1	2026-02-25	3465373.00	22.00	SORTIE	LINDE	\N	427	f	30297.00	MILOUD	206759	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9302	1	2026-02-25	3465511.00	138.00	SORTIE	RENAULT 25636A13	\N	411	f	178399.00	YASSINE	206760	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9303	1	2026-02-25	3465730.00	219.00	SORTIE	MAN 28659D1	\N	410	f	102260.00	CHOUAIB	206761	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9304	1	2026-02-25	3465926.00	196.00	SORTIE	VOLVO 22299A73	\N	480	f	650980.00	THAMI	206762	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9305	1	2026-02-25	3465950.00	24.00	SORTIE	MIT 11470A73	\N	436	f	140812.00	MOHAMED	206763	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9307	1	2026-02-26	3466547.00	43.00	SORTIE	HYUNDAI 22772A73	\N	479	f	259539.00	NOURDINE	206765	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9309	1	2026-02-26	3467009.00	158.00	SORTIE	VOLVO 22300A73	\N	481	f	747047.00	MUSTAPHA	206767	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9310	1	2026-02-26	3467052.00	43.00	SORTIE	LINDE	\N	477	f	9617.30	CHAABI	206768	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9311	1	2026-02-26	3467094.00	42.00	SORTIE	FENWICK	\N	430	f	28442.00	ABDELKHALEK	206769	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9314	1	2026-02-26	3467320.00	31.00	SORTIE	HYUNDAI 241452	\N	482	f	241452.00	BADER	206772	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9315	1	2026-02-26	3467417.00	97.00	SORTIE	MAN 4790B8	\N	403	f	990908.00	KARDODI	206773	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9316	1	2026-02-26	3467514.00	97.00	SORTIE	VOLVO 22299A73	\N	480	f	651357.00	THAMI	206774	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9317	1	2026-02-27	3467691.00	177.00	SORTIE	MIT 11470A73	\N	436	f	141449.00	MOHAMED	206775	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9319	1	2026-02-27	3467814.00	91.00	SORTIE	MIT 4969A73	\N	409	f	964497.00	CHOUAIB	206777	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9320	1	2026-02-27	3467997.00	183.00	SORTIE	RENAULT 25636A13	\N	411	f	179053.00	YASSINE	206778	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9321	1	2026-02-27	3468148.00	152.00	SORTIE	CHARGEUSE G 938	\N	413	f	8509.60	ABDERRAHIM	206779	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9322	1	2026-02-27	3468195.00	46.00	SORTIE	LINDE	\N	434	f	7975.20	ABDELLAH	206780	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9323	1	2026-02-27	3468268.00	73.00	SORTIE	MANITOU	\N	484	f	6458.00	SAID	206781	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9324	1	2026-02-27	3468306.00	38.00	SORTIE	KANGO 4812A73	\N	419	f	248068.00	TARMONIA	206782	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9325	1	2026-02-27	3468374.00	68.00	SORTIE	ISUZU 26128A8	\N	401	f	890641.00	TOUFIK	206783	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9326	1	2026-02-27	3468405.00	31.00	SORTIE	LINDE	\N	428	f	4083.50	JAWAD	206784	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9327	1	2026-02-27	3468440.00	35.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	206785	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9328	1	2026-02-27	3468471.00	31.00	SORTIE	MIT 11470A73	\N	436	f	141532.00	MOHAMED	206786	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9329	1	2026-02-27	3468588.00	117.00	SORTIE	VOLVO 22299A73	\N	480	f	651802.00	THAMI	206787	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9330	1	2026-02-28	3468961.00	373.00	SORTIE	VOLVO 17886A73	\N	439	f	725533.00	MJID	206788	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9331	1	2026-02-28	3469042.00	81.00	SORTIE	MIT 4969A73	\N	409	f	964787.00	CHOUAIB	206789	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9332	1	2026-02-28	3469068.00	26.00	SORTIE	HYUNDAI 22368A73	\N	482	f	241704.00	BADER	206790	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9338	1	2026-02-28	3470302.00	47.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347421.00	HAMID	206796	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9339	1	2026-02-28	3470347.00	45.00	SORTIE	HYUNDAI 22772A73	\N	479	f	259824.00	NOURDINE	206797	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9341	1	2026-02-28	3470599.00	189.00	SORTIE	VOLVO 22300A73	\N	481	f	747731.00	MUSTAPHA	206799	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9343	1	2026-02-28	3470655.00	24.00	SORTIE	LINDE	\N	427	f	30307.00	MILOUD	206801	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9344	1	2026-02-28	3470786.00	131.00	SORTIE	RENAULT 25636A13	\N	411	f	179561.00	YASSINE	206802	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9345	1	2026-03-02	3470916.00	130.00	SORTIE	VOLVO 70352A2	\N	406	f	513828.00	CHOUAIB	206803	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9348	1	2026-03-02	3471009.00	25.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347421.00	NOURDINE	206806	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9349	1	2026-03-02	3471045.00	36.00	SORTIE	LINDE	\N	477	f	9631.00	CHAABI	206807	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9350	1	2026-03-02	3471066.00	21.00	SORTIE	LINDE	\N	428	f	4083.90	HASSAN	206808	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9351	1	2026-03-02	3471315.00	249.00	SORTIE	MAN 28659D1	\N	410	f	103148.00	CHOUAIB	206809	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9352	1	2026-03-02	3471525.00	210.00	SORTIE	MIT 11470A73	\N	436	f	142208.00	MOHAMED	206810	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9354	1	2026-03-03	3472356.00	171.00	SORTIE	RENAULT 25636A13	\N	411	f	180288.00	YASSINE	206812	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9355	1	2026-03-03	3472520.00	164.00	SORTIE	VOLVO 22300A73	\N	481	f	748357.00	MUSTAPHA	206813	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9357	1	2026-03-03	3472597.00	36.00	SORTIE	RENAULT 25636A13	\N	411	f	130373.00	YASSINE	206815	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9359	1	2026-03-03	3472693.00	38.00	SORTIE	FENWICK	\N	430	f	28459.00	ABDELKHALEK	206817	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9360	1	2026-03-03	3472898.00	205.00	SORTIE	CHARGEUSE G 938	\N	413	f	8527.80	ABDERRAHIM	206818	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9361	1	2026-03-03	3473311.00	413.00	SORTIE	VOLVO 17885A73	\N	438	f	760086.00	HOUSSAM	206819	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9362	1	2026-03-03	3473511.00	200.00	SORTIE	VOLVO 22299A73	\N	480	f	652463.00	THAMI	206820	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9363	1	2026-02-04	3473765.00	254.00	SORTIE	VOLVO 17886A73	\N	439	f	726455.00	MJID	206821	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9364	1	2026-02-04	3473968.00	203.00	SORTIE	MIT 11470A73	\N	436	f	142941.00	MOHAMED	206822	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9365	1	2026-02-04	3474113.00	145.00	SORTIE	MIT 4969A73	\N	409	f	965238.00	CHOUAIB	206823	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9371	1	2026-02-04	3474754.00	18.00	SORTIE	LINDE	\N	434	f	7984.00	MILOUD	206829	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9372	1	2026-02-04	3474865.00	111.00	SORTIE	MIT 4703A73	\N	408	f	591598.00	MUSTAPHA	206830	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9373	1	2026-02-04	3474891.00	25.00	SORTIE	LINDE	\N	428	f	40848.00	HASSAN	206831	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9374	1	2026-02-04	3474926.00	35.00	SORTIE	VOLVO 22300A73	\N	481	f	748434.00	CHOUAIB	206832	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9375	1	2026-02-04	3474977.00	51.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347421.00	NOURDINE	206833	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9376	1	2026-02-05	3475087.00	110.00	SORTIE	ISUZU 26128A8	\N	401	f	891154.00	TOUFIK	206834	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9377	1	2026-02-05	3475137.00	50.00	SORTIE	HYUNDAI 22368A73	\N	482	f	242168.00	BADER	206835	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9378	1	2026-02-05	3475273.00	136.00	SORTIE	RENAULT 25636A13	\N	411	f	180818.00	YASSINE	206836	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9379	1	2026-02-05	3475526.00	253.00	SORTIE	MAN 706A73	\N	407	f	142623.00	SOUFIANE	206837	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9380	1	2026-02-05	3475892.00	366.00	SORTIE	VOLVO 17885A73	\N	438	f	761101.00	HOUSSAM	206838	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9381	1	2026-02-05	3476009.00	117.00	SORTIE	MIT 11470A73	\N	436	f	143288.00	MOHAMED	206839	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9382	1	2026-03-06	3476322.00	313.00	SORTIE	VOLVO 17886A73	\N	439	f	727434.00	MJID	206840	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9383	1	2026-03-06	3476408.00	86.00	SORTIE	MANITOU	\N	484	f	6494.00	SAID	206841	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9385	1	2026-03-06	3476862.00	160.00	SORTIE	VOLVO 22300A73	\N	481	f	748985.00	MUSTAPHA	206843	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9386	1	2026-03-06	3476935.00	73.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	206844	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9387	1	2026-03-06	3477108.00	173.00	SORTIE	CHARGEUSE G 938	\N	413	f	8543.00	ABDERRAHIM	206845	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9391	1	2026-03-06	3477744.00	36.00	SORTIE	LINDE	\N	477	f	9645.20	CHAABI	206849	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9392	1	2026-03-07	3477808.00	64.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347630.00	NOURDINE	206850	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9393	1	2026-03-07	3477932.00	124.00	SORTIE	VOLVO 22299A73	\N	480	f	652824.00	THAMI	206851	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9394	1	2026-03-07	3478087.00	155.00	SORTIE	VOLVO 70352A2	\N	406	f	514180.00	CHOUAIB	206852	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9395	1	2026-03-07	3478245.00	158.00	SORTIE	MIT 11469A73	\N	435	f	980508.00	ABDELKHALEK	206853	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9396	1	2026-03-07	3478271.00	26.00	SORTIE	HYUNDAI 22368A73	\N	482	f	242459.00	BADER	206854	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9398	1	2026-03-07	3478465.00	160.00	SORTIE	MIT 11470A73	\N	436	f	143812.00	MOHAMED	206856	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9400	1	2026-03-07	3478934.00	187.00	SORTIE	RENAULT 25636A13	\N	411	f	181527.00	YASSINE	206858	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9402	1	2026-03-07	3479108.00	27.00	SORTIE	LINDE	\N	428	f	4086.00	ABDELMALEK	206860	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9403	1	2026-03-09	3479294.00	186.00	SORTIE	MIT 4969A73	\N	409	f	965792.00	CHOUAIB	206861	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9404	1	2026-03-09	3479338.00	44.00	SORTIE	HYUNDAI 18516A73	\N	471	f	347881.00	NOURDINE	206862	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9405	1	2026-03-09	3479404.00	66.00	SORTIE	ISUZU 26128A8	\N	401	f	891460.00	TOUFIK	206863	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9406	1	2026-03-09	3479592.00	187.00	SORTIE	VOLVO 22300A73	\N	481	f	749712.00	MUSTAPHA	206864	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9407	1	2026-03-09	3479654.00	62.00	SORTIE	VOLVO 22299A73	\N	480	f	653014.00	THAMI	206865	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9408	1	2026-03-09	3479788.00	134.00	SORTIE	RENAULT 25636A13	\N	411	f	182045.00	YASSINE	206866	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9409	1	2026-03-09	3479827.00	39.00	SORTIE	LINDE	\N	434	f	8005.00	MILOUD	206867	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9410	1	2026-03-09	3479964.00	137.00	SORTIE	VOLVO 17886A73	\N	439	f	727881.00	MJID	206868	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9412	1	2026-03-09	3480175.00	172.00	SORTIE	CHARGEUSE G 938	\N	413	f	8557.00	ABDERRAHIM	206870	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9414	1	2026-03-09	3480288.00	57.00	SORTIE	FENWICK	\N	430	f	28480.00	ABDELKHALEK	206872	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9415	1	2026-03-09	3480312.00	24.00	SORTIE	LINDE	\N	477	f	9654.90	CHAABI	206873	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9416	1	2026-03-09	3480442.00	130.00	SORTIE	MAN 4790B8	\N	403	f	991346.00	KARDODI	206874	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9417	1	2026-03-09	3480478.00	36.00	SORTIE	VOLVO 22300A73	\N	481	f	747817.00	MUSTAPHA	206875	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9419	1	2026-03-09	3480569.00	53.00	SORTIE	MIT 11470A73	\N	436	f	143929.00	MOHAMED	206877	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9420	1	2026-03-10	3480698.00	129.00	SORTIE	MIT 11469A73	\N	435	f	980885.00	ABDELKHALEK	206878	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9421	1	2026-03-10	3480767.00	69.00	SORTIE	HYUNDAI 22772A73	\N	479	f	260249.00	NOURDINE	206879	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9422	1	2026-03-10	3480790.00	23.00	SORTIE	HYUNDAI 22368A73	\N	482	f	242720.00	BADER	206880	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9426	1	2026-03-10	3481337.00	145.00	SORTIE	RENAULT 25636A13	\N	411	f	182611.00	YASSINE	206884	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9427	1	2026-03-10	3481362.00	25.00	SORTIE	LINDE	\N	428	f	4086.00	JAWAD	206885	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9429	1	2026-03-11	3481667.00	170.00	SORTIE	MIT 11470A73	\N	436	f	144473.00	MOHAMED	206887	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9431	1	2026-03-11	3482167.00	216.00	SORTIE	VOLVO 22299A73	\N	480	f	653765.00	THAMI	206889	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9432	1	2026-03-11	3482218.00	51.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	206890	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9434	1	2026-03-11	3482796.00	550.00	SORTIE	VOLVO 17885A73	\N	438	f	762741.00	HOUSSAM	206892	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9435	1	2026-03-11	3483007.00	211.00	SORTIE	VOLVO 22300A73	\N	481	f	750585.00	MUSTAPHA	206893	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9436	1	2026-03-11	3483032.00	25.00	SORTIE	HYUNDAI 22368A73	\N	482	f	243007.00	BADER	206894	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9437	1	2026-03-12	3483522.00	490.00	SORTIE	VOLVO 17886A73	\N	439	f	729398.00	MJID	206895	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9439	1	2026-03-12	3484024.00	189.00	SORTIE	MIT 11469A73	\N	435	f	981439.00	ABDELKHALEK	206897	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9440	1	2026-03-12	3484224.00	200.00	SORTIE	RENAULT 25636A13	\N	411	f	183353.00	YASSINE	206898	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9441	1	2026-03-12	3484248.00	23.00	SORTIE	LINDE	\N	428	f	4087.60	HASSAN	206899	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9442	1	2026-03-12	3484392.00	144.00	SORTIE	VOLVO 70352A2	\N	406	f	514498.00	CHOUAIB	206900	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9444	1	2026-03-12	3484621.00	182.00	SORTIE	CHARGEUSE G 938	\N	413	f	8572.80	ABDERRAHIM	206902	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9446	1	2026-03-12	3484811.00	37.00	SORTIE	LINDE	\N	477	f	9669.50	CHAABI	206904	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9447	1	2026-03-12	3484847.00	36.00	SORTIE	FENWICK	\N	430	f	28496.00	ABDELKHALEK	206905	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9448	1	2026-03-12	3484982.00	135.00	SORTIE	VOLVO 22300A73	\N	481	f	751150.00	MUSTAPHA	206906	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9450	1	2026-03-12	3485153.00	153.00	SORTIE	MIT 4969A73	\N	409	f	966193.00	CHOUAIB	206908	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9451	1	2026-03-13	3485263.00	110.00	SORTIE	MIT 11469A73	\N	435	f	981803.00	ABDELKHALEK	206909	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9452	1	2026-03-13	3485320.00	57.00	SORTIE	HYUNDAI 22772A73	\N	479	f	260661.00	NOURDINE	206910	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9454	1	2026-03-13	3485438.00	81.00	SORTIE	MANITOU	\N	484	f	6533.00	SAID	206912	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9456	1	2026-03-13	3485591.00	105.00	SORTIE	RENAULT 25636A13	\N	411	f	183760.00	YASSINE	206914	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9457	1	2026-03-13	3485621.00	30.00	SORTIE	KANGO 4812A73	\N	419	f	248525.00	TARMONIA	206915	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9458	1	2026-03-13	3485669.00	48.00	SORTIE	MIT 4969A73	\N	409	f	966354.00	CHOUAIB	206916	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9459	1	2026-03-13	3485705.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	348088.00	NOURDINE	206917	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9460	1	2026-03-14	3485819.00	114.00	SORTIE	ISUZU 26128A8	\N	401	f	892080.00	TOUFIK	206918	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9461	1	2026-03-14	3485982.00	163.00	SORTIE	MIT 11469A73	\N	435	f	982319.00	ABDELKHALEK	206919	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9462	1	2026-03-14	3486018.00	36.00	SORTIE	HYUNDAI 22368A73	\N	482	f	243373.00	BADER	206920	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9464	1	2026-03-14	3486566.00	229.00	SORTIE	VOLVO 22299A73	\N	480	f	654478.00	THAMI	206922	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9465	1	2026-03-14	3486713.00	147.00	SORTIE	MAN 4790B8	\N	403	f	991843.00	KARDODI	206923	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9470	1	2026-03-14	3487749.00	39.00	SORTIE	LINDE	\N	434	f	8029.60	MILOUD	206928	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9471	1	2026-03-14	3487783.00	34.00	SORTIE	MIT 11469A73	\N	435	f	982440.00	ABDELKHALEK	206929	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9472	1	2026-03-14	3487923.00	140.00	SORTIE	RENAULT 25636A13	\N	411	f	184263.00	YASSINE	206930	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9473	1	2026-03-14	3488368.00	445.00	SORTIE	VOLVO 17885A73	\N	438	f	764133.00	HOUSSAM	206931	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9474	1	2026-03-14	3488388.00	20.00	SORTIE	LINDE	\N	477	f	9677.00	CHAABI	206932	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9475	1	2026-03-14	3488410.00	22.00	SORTIE	LINDE	\N	428	f	4088.00	HASSAN	206933	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9476	1	2026-03-14	3488613.00	203.00	SORTIE	VOLVO 22300A73	\N	481	f	741933.00	MUSTAPHA	206934	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9477	1	2026-03-16	3489030.00	417.00	SORTIE	VOLVO 17886A73	\N	439	f	730775.00	MJID	206935	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9480	1	2026-03-16	3489245.00	131.00	SORTIE	VOLVO 22299A73	\N	480	f	654936.00	THAMI	206938	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9481	1	2026-03-16	3489283.00	39.00	SORTIE	LINDE	\N	427	f	30326.00	HASSAN	206939	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9484	1	2026-03-16	3490505.00	206.00	SORTIE	CHARGEUSE G 938	\N	413	f	8590.60	ABDERRAHIM	206942	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9485	1	2026-03-16	3490568.00	63.00	SORTIE	HYUNDAI 18516A73	\N	471	f	348497.00	NOURDINE	206943	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9486	1	2026-03-16	3490610.00	42.00	SORTIE	MANITOU	\N	426	f	\N	SAID	206944	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9487	1	2026-03-16	3490777.00	167.00	SORTIE	MIT 4969A73	\N	409	f	966924.00	CHOUAIB	206945	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9491	1	2026-03-16	3491195.00	190.00	SORTIE	MIT 4703A73	\N	408	f	592509.00	MUSTAPHA	206949	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9492	1	2026-03-16	3491223.00	28.00	SORTIE	HYUNDAI 22368A73	\N	482	f	243730.00	BADER	206950	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9494	1	2026-03-17	3491407.00	144.00	SORTIE	MIT 11469A73	\N	435	f	982902.00	ABDELKHALEK	206952	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9495	1	2026-03-17	3491568.00	161.00	SORTIE	VOLVO 22300A73	\N	481	f	752540.00	MUSTAPHA	206953	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9496	1	2026-03-17	3491582.00	14.00	SORTIE	LINDE	\N	428	f	4089.30	JAWAD	206954	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9497	1	2026-03-17	\N	55.00	SORTIE	HYUNDAI 22772A73	\N	479	f	260986.00	NOURDINE	206955	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9498	1	2026-03-18	3491804.00	167.00	SORTIE	VOLVO 22300A73	\N	481	f	753143.00	MUSTAPHA	206956	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9499	1	2026-03-18	3492162.00	358.00	SORTIE	VOLVO 17885A73	\N	438	f	765206.00	HOUSSAM	206957	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9500	1	2026-03-18	3492404.00	242.00	SORTIE	MAN 706A73	\N	407	f	143285.00	SOUFIANE	206958	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9501	1	2026-03-18	3492707.00	303.00	SORTIE	MAN 28659D1	\N	410	f	103934.00	CHOUAIB	206959	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9503	1	2026-03-18	3493052.00	28.00	SORTIE	MIT 4969A73	\N	409	f	966958.00	CHOUAIB	206961	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9505	1	2026-03-18	3493227.00	78.00	SORTIE	ISUZU 26128A8	\N	401	f	892485.00	TOUFIK	206963	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9507	1	2026-03-18	3493287.00	28.00	SORTIE	LINDE	\N	434	f	8043.70	MILOUD	206965	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9508	1	2026-03-18	3493449.00	162.00	SORTIE	VOLVO 22299A73	\N	480	f	655450.00	THAMI	206966	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9509	1	2026-03-19	3493609.00	160.00	SORTIE	MAN 4790B8	\N	403	f	992410.00	KARDODI	206967	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9510	1	2026-03-19	3493803.00	194.00	SORTIE	MIT 4969A73	\N	409	f	967628.00	CHOUAIB	206968	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9511	1	2026-03-19	3493826.00	23.00	SORTIE	HYUNDAI 18516A73	\N	471	f	348602.00	NOURDINE	206969	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9512	1	2026-03-19	3493993.00	167.00	SORTIE	MIT 11469A73	\N	435	f	983440.00	ABDELKHALEK	206970	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9513	1	2026-03-19	3494139.00	146.00	SORTIE	VOLVO 22300A73	\N	481	f	753653.00	MUSTAPHA	206971	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9516	1	2026-03-19	3494292.00	38.00	SORTIE	KANGO 4812A73	\N	419	f	248808.00	TARMONIA	206974	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9519	1	2026-03-19	3494401.00	53.00	SORTIE	HYUNDAI 22368A73	\N	482	f	244235.00	BADER	206977	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9520	1	2026-03-25	3494641.00	240.00	SORTIE	VOLVO 22299A73	\N	480	f	656307.00	THAMI	206978	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9521	1	2026-03-25	3494795.00	154.00	SORTIE	MIT 4969A73	\N	409	f	968163.00	CHOUAIB	206979	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9522	1	2026-03-25	3495198.00	403.00	SORTIE	VOLVO 17886A73	\N	439	f	732096.00	MJID	206980	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9523	1	2026-03-25	3495241.00	43.00	SORTIE	HYUNDAI 22368A73	\N	482	f	244962.00	BADER	206981	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9524	1	2026-03-25	3495290.00	49.00	SORTIE	MIT 11469A73	\N	435	f	836091.00	ABDELKHALEK	206982	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9525	1	2026-03-26	3495347.00	57.00	SORTIE	HYUNDAI 18516A73	\N	471	f	348933.00	NOURDINE	206983	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9526	1	2026-03-26	3495489.00	142.00	SORTIE	VOLVO 22300A73	\N	481	f	754191.00	MUSTAPHA	206984	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9527	1	2026-03-26	3495543.00	54.00	SORTIE	HYUNDAI 22772A73	\N	479	f	261346.00	NOURDINE	206985	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9528	1	2026-03-26	3495631.00	88.00	SORTIE	MANITOU	\N	484	f	6575.00	KARDODI	206986	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9530	1	2026-03-27	3495706.00	32.00	SORTIE	HYUNDAI 22368A73	\N	482	f	245215.00	BADER	206988	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9531	1	2026-03-27	3495753.00	47.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	206989	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9532	1	2026-03-27	3496019.00	266.00	SORTIE	VOLVO 17885A73	\N	438	f	766093.00	HOUSSAM	206990	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9533	1	2026-03-27	3496185.00	166.00	SORTIE	MIT 4969A73	\N	409	f	968770.00	CHOUAIB	206991	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9534	1	2026-03-27	3496245.00	60.00	SORTIE	FENWICK	\N	430	f	28521.00	ABDELKHALEK	206992	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9535	1	2026-03-27	3496284.00	39.00	SORTIE	LINDE	\N	477	f	9692.60	CHAABI	206993	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9536	1	2026-03-27	3496323.00	39.00	SORTIE	VOLVO 22300A73	\N	481	f	754293.00	MUSTAPHA	206994	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9537	1	2026-03-28	3496384.00	61.00	SORTIE	HYUNDAI 22772A73	\N	479	f	261749.00	NOURDINE	206995	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9538	1	2026-03-28	3496420.00	36.00	SORTIE	MIT 11469A73	\N	435	f	983708.00	ABDELKHALEK	206996	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9540	1	2026-03-28	3496666.00	183.00	SORTIE	VOLVO 17886A73	\N	439	f	732698.00	MJID	206998	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9543	1	2026-03-30	3496844.00	105.00	SORTIE	MIT 11469A73	\N	435	f	984074.00	ABDELKHALEK	206701	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9544	1	2026-03-30	3496991.00	147.00	SORTIE	VOLVO 22300A73	\N	481	f	754802.00	MUSTAPHA	206702	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9545	1	2026-03-30	3497031.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	245709.00	BADER	206703	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9547	1	2026-03-30	3497454.00	361.00	SORTIE	VOLVO 17885A73	\N	438	f	767141.00	HOUSSAM	206705	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9548	1	2026-03-30	3497508.00	54.00	SORTIE	HYUNDAI 18516A73	\N	471	f	349260.00	NOURDINE	206706	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9551	1	2026-03-30	3497612.00	17.00	SORTIE	LINDE	\N	428	f	4030.00	HASSAN	206709	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9552	1	2026-03-30	3497800.00	188.00	SORTIE	VOLVO 22299A73	\N	480	f	656924.00	THAMI	206710	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9553	1	2026-03-30	3498010.00	210.00	SORTIE	MAN 28659D1	\N	410	f	104463.00	CHOUAIB	206711	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9554	1	2026-03-31	3498087.00	77.00	SORTIE	VOLVO 70352A2	\N	406	f	514679.00	CHOUAIB	206712	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9555	1	2026-03-31	3498203.00	116.00	SORTIE	VOLVO 22300A73	\N	481	f	755219.00	MUSTAPHA	206713	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9556	1	2026-03-31	3498340.00	137.00	SORTIE	MIT 11469A73	\N	435	f	984550.00	ABDELKHALEK	206714	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9560	1	2026-03-31	3498892.00	38.00	SORTIE	HYUNDAI 18516A73	\N	471	f	349500.00	NOURDINE	206718	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9561	1	2026-03-31	3498943.00	51.00	SORTIE	HYUNDAI 22772A73	\N	479	f	262071.00	NOURDINE	206719	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9563	1	2026-04-01	3499764.00	332.00	SORTIE	VOLVO 17885A73	\N	438	f	768018.00	HOUSSAM	206721	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9564	1	2026-04-01	3499791.00	27.00	SORTIE	HYUNDAI 22368A73	\N	482	f	246065.00	BADER	206722	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9565	1	2026-04-01	3499878.00	87.00	SORTIE	ISUZU 26128A8	\N	401	f	892913.00	TOUFIK	206723	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9566	1	2026-04-01	3500009.00	131.00	SORTIE	MAN 4790B8	\N	403	f	992905.00	KARDODI	206724	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9567	1	2026-04-01	3500182.00	173.00	SORTIE	MIT 11469A73	\N	435	f	985131.00	ABDELKHALEK	206725	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9569	1	2026-04-01	3500748.00	270.00	SORTIE	MAN 28659D1	\N	410	f	105284.00	CHOUAIB	206727	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9571	1	2026-04-01	3501086.00	41.00	SORTIE	HYUNDAI 18516A73	\N	471	f	349753.00	NOURDINE	206729	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9572	1	2026-04-01	3501534.00	448.00	SORTIE	VOLVO 17886A73	\N	439	f	734154.00	MJID	206730	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9573	1	2026-04-01	3501563.00	29.00	SORTIE	LINDE	\N	434	f	8064.00	MILOUD	206731	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9574	1	2026-04-01	3501741.00	178.00	SORTIE	VOLVO 22300A73	\N	481	f	755868.00	MUSTAPHA	206732	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9576	1	2026-04-01	3501821.00	42.00	SORTIE	KANGO 4812A73	\N	419	f	249393.00	TARMONIA	206734	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9577	1	2026-04-01	3502023.00	202.00	SORTIE	VOLVO 22299A73	\N	480	f	657549.00	THAMI	206735	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9578	1	2026-04-02	3502183.00	160.00	SORTIE	MIT 4969A73	\N	409	f	969243.00	CHOUAIB	206736	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9579	1	2026-04-02	3502372.00	189.00	SORTIE	CHARGEUSE G 938	\N	413	f	8607.00	ABDERRAHIM	206737	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9580	1	2026-04-02	3502493.00	121.00	SORTIE	MIT 11469A73	\N	435	f	985559.00	ABDELKHALEK	206738	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9581	1	2026-04-02	3502570.00	77.00	SORTIE	MANITOU	\N	484	f	6609.00	SAID	206739	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9582	1	2026-04-02	3502591.00	21.00	SORTIE	LINDE	\N	427	f	30339.00	HASSAN	206740	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9583	1	2026-04-02	3502822.00	230.00	SORTIE	MAN 28659D1	\N	410	f	106084.00	CHOUAIB	206741	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9584	1	2026-04-02	3502858.00	36.00	SORTIE	HYUNDAI 18516A73	\N	471	f	349983.00	NOURDINE	206742	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9586	1	2026-04-03	3502969.00	68.00	SORTIE	MIT 4969A73	\N	409	f	969488.00	CHOUAIB	206744	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9587	1	2026-04-03	3503186.00	217.00	SORTIE	VOLVO 22299A73	\N	480	f	658474.00	THAMI	206745	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9588	1	2026-04-03	3503312.00	126.00	SORTIE	VOLVO 22300A73	\N	481	f	756279.00	MUSTAPHA	206746	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9589	1	2026-04-03	3503371.00	59.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	206747	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9590	1	2026-04-03	3503425.00	54.00	SORTIE	HYUNDAI 22772A73	\N	479	f	262392.00	NOURDINE	206748	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9591	1	2026-04-03	3503615.00	190.00	SORTIE	MIT 11469A73	\N	435	f	986218.00	ABDELKHALEK	206749	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9593	1	2026-04-03	3503842.00	166.00	SORTIE	RENAULT 25636A13	\N	411	f	184992.00	YASSINE	206651	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9594	1	2026-04-03	3503882.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	246483.00	BADER	206652	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9595	1	2026-04-03	3503905.00	23.00	SORTIE	LINDE	\N	428	f	4090.00	HASSAN	206653	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9596	1	2026-04-03	3503951.00	46.00	SORTIE	HYUNDAI 18516A73	\N	471	f	350314.00	NOURDINE	206654	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9597	1	2026-04-03	3504056.00	105.00	SORTIE	MAN 4790B8	\N	403	f	993283.00	KARDODI	206655	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9598	1	2026-04-03	3504106.00	50.00	SORTIE	VOLVO 22299A73	\N	480	f	658641.00	THAMI	206656	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9599	1	2026-04-04	3504525.00	419.00	SORTIE	VOLVO 17886A73	\N	439	f	735534.00	MJID	206657	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9600	1	2026-04-04	3505073.00	548.00	SORTIE	VOLVO 17885A73	\N	435	f	769585.00	HOUSSAM	206658	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9601	1	2026-04-04	3505254.00	181.00	SORTIE	MIT 11469A73	\N	435	f	986809.00	ABDELKHALEK	206659	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9603	1	2026-04-04	3505756.00	208.00	SORTIE	MAN 28659D1	\N	410	f	106727.00	CHOUAIB	206661	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9604	1	2026-04-04	3505895.00	139.00	SORTIE	MIT 4969A73	\N	409	f	970019.00	CHOUAIB	206662	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9606	1	2026-04-04	3506139.00	182.00	SORTIE	CHARGEUSE G 938	\N	413	f	8622.00	ABDERRAHIM	206664	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9607	1	2026-04-04	3506173.00	34.00	SORTIE	HYUNDAI 18516A73	\N	471	f	350522.00	NOURDINE	206665	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9610	1	2026-04-04	3506415.00	44.00	SORTIE	FENWICK	\N	430	f	28539.00	ABDELKHALEK	206668	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9611	1	2026-04-04	3506470.00	55.00	SORTIE	RENAULT 25636A13	\N	411	f	185187.00	YASSINE	206669	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9613	1	2026-04-04	3506513.00	38.00	SORTIE	LINDE	\N	477	f	9709.60	CHAABI	206671	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9615	1	2026-04-04	3506597.00	34.00	SORTIE	VOLVO 17886A73	\N	439	f	735618.00	MJID	206673	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9616	1	2026-04-06	3506733.00	135.00	SORTIE	MIT 4969A73	\N	409	f	970556.00	CHOUAIB	206674	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9617	1	2026-04-06	3506853.00	120.00	SORTIE	ISUZU 26128A8	\N	401	f	893534.00	TOUFIK	206675	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9618	1	2026-04-06	3507041.00	188.00	SORTIE	MIT 11469A73	\N	435	f	987480.00	ABDELKHALEK	206676	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9619	1	2026-04-06	3507065.00	24.00	SORTIE	HYUNDAI 22368A73	\N	482	f	246704.00	BADER	206677	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9620	1	2026-04-06	3507253.00	188.00	SORTIE	MIT 4703A73	\N	408	f	593485.00	MUSTAPHA	206678	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9622	1	2026-04-06	3507473.00	160.00	SORTIE	VOLVO 70352A2	\N	406	f	514994.00	CHOUAIB	206680	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9623	1	2026-04-06	3507692.00	219.00	SORTIE	VOLVO 22299A73	\N	480	f	659422.00	THAMI	206681	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9625	1	2026-04-06	3507988.00	254.00	SORTIE	VOLVO 17885A73	\N	438	f	770434.00	HOUSSAM	206683	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9626	1	2026-04-06	3508260.00	272.00	SORTIE	MAN 28659D1	\N	410	f	107640.00	CHOUAIB	206684	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9627	1	2026-04-06	3508299.00	39.00	SORTIE	HYUNDAI 18516A73	\N	471	f	350780.00	HAMID	206685	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9629	1	2026-04-06	3508801.00	209.00	SORTIE	VOLVO 17886A73	\N	439	f	736322.00	MJID	206687	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9630	1	2026-04-06	3508842.00	41.00	SORTIE	HYUNDAI 22772A73	\N	479	f	262671.00	HAMID	206688	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9631	1	2026-04-06	3508900.00	58.00	SORTIE	MIT 4969A73	\N	409	f	970777.00	CHOUAIB	206689	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9634	1	2026-04-06	3508979.00	22.00	SORTIE	LINDE	\N	428	f	4092.10	HASSAN	206692	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9636	1	2026-04-07	3509045.00	20.00	SORTIE	HYUNDAI 18516A73	\N	471	f	350894.00	HAMID	206694	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9637	1	2026-04-07	3509208.00	163.00	SORTIE	MIT 11469A73	\N	435	f	988069.00	ABDELKHALEK	206695	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9638	1	2026-04-07	3509361.00	153.00	SORTIE	RENAULT 25636A13	\N	411	f	185731.00	YASSINE	206696	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9639	1	2026-04-07	3509538.00	177.00	SORTIE	VOLVO 22299A73	\N	480	f	660071.00	THAMI	206697	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9640	1	2026-04-07	3509562.00	23.00	SORTIE	MIT 11469A73	\N	435	f	988146.00	ABDELKHALEK	206698	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9641	1	2026-04-07	3509620.00	58.00	SORTIE	MANITOU	\N	431	f	8674.00	SAID	206699	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9642	1	2026-04-07	3509673.00	53.00	SORTIE	MANITOU	\N	426	f	1278.90	SAID	206700	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9645	1	2026-04-07	3510388.00	130.00	SORTIE	MAN 4790B8	\N	403	f	993764.00	KARDODI	206603	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9646	1	2026-04-08	3510711.00	323.00	SORTIE	VOLVO 17885A73	\N	438	f	771396.00	HOUSSAM	206604	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9647	1	2026-04-08	3510896.00	185.00	SORTIE	MIT 4969A73	\N	409	f	971426.00	CHOUAIB	206605	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9648	1	2026-04-08	3510924.00	28.00	SORTIE	HYUNDAI 22368A73	\N	482	f	247078.00	BADER	206606	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9652	1	2026-04-08	3512620.00	53.00	SORTIE	HYUNDAI 22772A73	\N	479	f	263014.00	HICHAM	206610	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9653	1	2026-04-08	3512835.00	215.00	SORTIE	CHARGEUSE G 938	\N	413	f	8641.40	ABDERRAHIM	206611	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9654	1	2026-04-08	3512870.00	35.00	SORTIE	LINDE	\N	477	f	9723.70	ABDELKHALEK	206612	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9655	1	2026-04-08	3512910.00	40.00	SORTIE	FENWICK	\N	430	f	28553.00	SAID	206613	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9657	1	2026-04-08	3512954.00	10.00	SORTIE	LINDE	\N	428	f	4092.00	HASSAN	206615	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9658	1	2026-04-08	3512969.00	15.00	SORTIE	LINDE	\N	434	f	30346.00	MILOUD	206616	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9659	1	2026-04-08	3513261.00	292.00	SORTIE	VOLVO 17886A73	\N	439	f	737314.00	MJID	206617	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9660	1	2026-04-08	3513517.00	255.00	SORTIE	MAN 28659D1	\N	410	f	108397.00	CHOUAIB	206618	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9661	1	2026-04-09	3513603.00	86.00	SORTIE	RENAULT 25636A13	\N	411	f	186066.00	YASSINE	206619	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9662	1	2026-04-09	3513755.00	152.00	SORTIE	MIT 11469A73	\N	435	f	988669.00	ABDELKHALEK	206620	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9665	1	2026-04-09	3514085.00	121.00	SORTIE	MIT 4969A73	\N	409	f	971882.00	CHOUAIB	206623	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9666	1	2026-04-09	3514485.00	400.00	SORTIE	VOLVO 17885A73	\N	438	f	772549.00	HOUSSAM	206624	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9668	1	2026-04-09	3515195.00	43.00	SORTIE	MIT 4969A73	\N	409	f	972028.00	CHOUAIB	206626	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9670	1	2026-04-09	3515387.00	156.00	SORTIE	VOLVO 22299A73	\N	480	f	660631.00	THAMI	206628	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9671	1	2026-04-10	3515518.00	131.00	SORTIE	RENAULT 25636A13	\N	411	f	186662.00	YASSINE	206629	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9672	1	2026-04-10	3515686.00	168.00	SORTIE	MIT 11469A73	\N	435	f	989262.00	ABDELKHALEK	206630	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9673	1	2026-04-10	3515730.00	44.00	SORTIE	HYUNDAI 22772A73	\N	479	f	263320.00	HICHAM	206631	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9675	1	2026-04-10	3515993.00	214.00	SORTIE	MAN 28659D1	\N	410	f	109088.00	CHOUAIB	206633	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9676	1	2026-04-10	3516374.00	381.00	SORTIE	VOLVO 17886A73	\N	439	f	738586.00	MJID	206634	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9677	1	2026-04-10	3516401.00	27.00	SORTIE	LINDE	\N	428	f	4093.00	HASSAN	206635	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9678	1	2026-04-10	3516435.00	34.00	SORTIE	LINDE	\N	434	f	\N	MILOUD	206636	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9679	1	2026-04-10	3516465.00	30.00	SORTIE	KANGO 4812A73	\N	419	f	249816.00	TARMONIA	206637	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9680	1	2026-04-10	3516594.00	129.00	SORTIE	MIT 4969A73	\N	409	f	972489.00	CHOUAIB	206638	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9681	1	2026-04-10	3516686.00	92.00	SORTIE	MAN 4790B8	\N	403	f	974120.00	KARDODI	206639	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9682	1	2026-04-10	3516717.00	31.00	SORTIE	HYUNDAI 22368A73	\N	482	f	247312.00	BADER	206640	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9684	1	2026-04-11	3516928.00	152.00	SORTIE	VOLVO 70352A2	\N	406	f	515354.00	CHOUAIB	206642	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9685	1	2026-04-11	3517097.00	169.00	SORTIE	MIT 11469A73	\N	435	f	989891.00	ABDELKHALEK	206643	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9686	1	2026-04-11	3517237.00	140.00	SORTIE	ISUZU 26128A8	\N	401	f	894199.00	TOUFIK	206644	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9687	1	2026-04-11	3517402.00	165.00	SORTIE	RENAULT 25636A13	\N	411	f	187303.00	YASSINE	206645	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9689	1	2026-04-11	3517689.00	147.00	SORTIE	VOLVO 22299A73	\N	480	f	661184.00	THAMI	206647	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9691	1	2026-04-11	3518207.00	202.00	SORTIE	CHARGEUSE G 938	\N	413	f	8658.70	ABDERRAHIM	206649	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9695	1	2026-04-11	3518338.00	27.00	SORTIE	LINDE	\N	477	f	9736.00	CHAABI	206653	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9696	1	2026-04-11	3518373.00	35.00	SORTIE	FENWICK	\N	430	f	2856.00	SAID	206654	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9697	1	2026-04-13	3518508.00	135.00	SORTIE	VOLVO 22299A73	\N	480	f	661679.00	THAMI	206555	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9698	1	2026-04-13	3518633.00	125.00	SORTIE	MIT 11469A73	\N	435	f	990302.00	ABDELKHALEK	206556	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9699	1	2026-04-13	3518664.00	31.00	SORTIE	HYUNDAI 22368A73	\N	482	f	247677.00	BADER	206557	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9700	1	2026-04-13	3518783.00	119.00	SORTIE	MIT 4969A73	\N	409	f	972915.00	CHOUAIB	206558	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9701	1	2026-04-13	3518821.00	38.00	SORTIE	HYUNDAI 18516A73	\N	471	f	351088.00	NOURDINE	206559	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9702	1	2026-04-13	3518880.00	59.00	SORTIE	HYUNDAI 22772A73	\N	479	f	263712.00	NOURDINE	206560	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9703	1	2026-04-13	3519049.00	169.00	SORTIE	RENAULT 25636A13	\N	411	f	187921.00	YASSINE	206561	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9704	1	2026-04-13	3519335.00	285.00	SORTIE	MAN 28659D1	\N	410	f	109996.00	CHOUAIB	206562	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9705	1	2026-04-13	3519892.00	557.00	SORTIE	VOLVO 17885A73	\N	438	f	774296.00	HOUSSAM	206563	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9706	1	2026-04-13	3519973.00	81.00	SORTIE	MANITOU	\N	484	f	6644.00	SAID	206564	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9707	1	2026-04-14	3520153.00	180.00	SORTIE	MIT 11469A73	\N	435	f	990223.00	ABDELKHALEK	206565	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9714	1	2026-04-14	3522108.00	430.00	SORTIE	VOLVO 17886A73	\N	439	f	740095.00	MJID	206572	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9715	1	2026-04-14	3522287.00	179.00	SORTIE	MIT 4703A73	\N	408	f	594350.00	MUSTAPHA	206573	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9716	1	2026-04-14	3522403.00	116.00	SORTIE	VOLVO 22300A73	\N	481	f	756613.00	MUSTAPHA	206574	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9717	1	2026-04-14	3522425.00	22.00	SORTIE	LINDE	\N	427	f	3035.60	MILOUD	206575	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9719	1	2026-04-14	3522495.00	48.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	206577	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9720	1	2026-04-14	3522781.00	286.00	SORTIE	MAN 706A73	\N	407	f	143981.00	SOUFIANE	206578	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9721	1	2026-04-15	3523049.00	268.00	SORTIE	MAN 28659D1	\N	410	f	110859.00	CHOUAIB	206579	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9722	1	2026-04-15	3523143.00	93.00	SORTIE	VOLVO 70352A2	\N	406	f	515569.00	CHOUAIB	206580	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9724	1	2026-04-15	3523277.00	86.00	SORTIE	MIT 4969A73	\N	409	f	973220.00	CHOUAIB	206582	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9725	1	2026-04-15	3523307.00	30.00	SORTIE	HYUNDAI 22368A73	\N	482	f	247996.00	BADER	206583	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9726	1	2026-04-15	3523410.00	102.00	SORTIE	ISUZU 26128A8	\N	401	f	894764.00	TOUFIK	206584	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9727	1	2026-04-15	3523536.00	126.00	SORTIE	MIT 11469A73	\N	435	f	991341.00	ABDELKHALEK	206585	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9728	1	2026-04-15	3523634.00	98.00	SORTIE	MAN 4790B8	\N	403	f	994480.00	KARDODI	206586	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9731	1	2026-04-15	3524043.00	40.00	SORTIE	HYUNDAI 22772A73	\N	479	f	263944.00	NOURDINE	206589	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9732	1	2026-04-15	3524080.00	37.00	SORTIE	MANITOU	\N	484	f	5636.70	JAWAD	206590	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9733	1	2026-04-15	3524118.00	38.00	SORTIE	FENWICK	\N	430	f	25582.00	ABDELKHALEK	206591	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9735	1	2026-04-16	3524449.00	171.00	SORTIE	MIT 11469A73	\N	435	f	991928.00	ABDELKHALEK	206593	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9736	1	2026-04-16	3524689.00	240.00	SORTIE	VOLVO 22299A73	\N	480	f	662533.00	THAMI	206594	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9737	1	2026-04-16	3524992.00	303.00	SORTIE	VOLVO 17886A73	\N	439	f	741107.00	MJID	206595	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9738	1	2026-04-16	3525572.00	580.00	SORTIE	VOLVO 17885A73	\N	438	f	776137.00	HOUSSAM	206596	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9739	1	2026-04-16	3525676.00	104.00	SORTIE	MAN 28659D1	\N	410	f	111239.00	CHOUAIB	206597	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9741	1	2026-04-16	3526003.00	33.00	SORTIE	VOLVO 22299A73	\N	480	f	662617.00	THAMI	206599	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9742	1	2026-04-16	3526147.00	144.00	SORTIE	MIT 4969A73	\N	409	f	973704.00	CHOUAIB	206600	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9743	1	2026-04-16	3526346.00	199.00	SORTIE	CHARGEUSE G 938	\N	413	f	\N	ABDERRAHIM	206501	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9746	1	2026-04-16	3527018.00	42.00	SORTIE	LINDE	\N	477	f	9754.30	CHAABI	206504	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9747	1	2026-04-16	3527061.00	43.00	SORTIE	LINDE	\N	434	f	8126.50	MILOUD	206505	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9748	1	2026-04-16	3527071.00	10.00	SORTIE	FENWICK	\N	430	f	2858.00	SAID	206506	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9749	1	2026-04-16	3527215.00	144.00	SORTIE	RENAULT 25636A13	\N	411	f	188355.00	YASSINE	206507	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9750	1	2026-04-17	3527242.00	27.00	SORTIE	HYUNDAI 22368A73	\N	482	f	248235.00	BADER	206508	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9751	1	2026-04-17	3527363.00	120.00	SORTIE	MIT 11469A73	\N	435	f	992367.00	ABDELKHALEK	206509	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9754	1	2026-04-17	3527467.00	17.00	SORTIE	LINDE	\N	427	f	3036.10	MILOUD	206512	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9756	1	2026-04-17	3527540.00	40.00	SORTIE	LINDE	\N	428	f	4095.50	ABDELLAH	206515	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9757	1	2026-04-17	3527713.00	173.00	SORTIE	MIT 4969A73	\N	409	f	974351.00	CHOUAIB	206516	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9758	1	2026-04-18	3527878.00	165.00	SORTIE	RENAULT 25636A13	\N	411	f	188952.00	YASSINE	206517	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9760	1	2026-04-18	3528035.00	42.00	SORTIE	HYUNDAI 22772A73	\N	479	f	264182.00	NOURDINE	206519	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9762	1	2026-04-18	3528192.00	109.00	SORTIE	MIT 11469A73	\N	435	f	992785.00	ABDELKHALEK	206521	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9763	1	2026-04-18	3528262.00	70.00	SORTIE	MIT 11469A73	\N	435	f	993027.00	ABDELKHALEK	206522	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9764	1	2026-04-20	3528362.00	100.00	SORTIE	ISUZU 26128A8	\N	407	f	895275.00	TOUFIK	206523	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9765	1	2026-04-20	3528550.00	188.00	SORTIE	RENAULT 25636A13	\N	411	f	189630.00	YASSINE	206524	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9766	1	2026-04-20	3528690.00	140.00	SORTIE	MIT 4969A73	\N	409	f	974885.00	CHOUAIB	206525	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9767	1	2026-04-20	3528723.00	33.00	SORTIE	HYUNDAI 22368A73	\N	482	f	248664.00	BADER	206526	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9768	1	2026-04-20	3528813.00	90.00	SORTIE	MANITOU	\N	484	f	6684.00	SAID	206527	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9769	1	2026-04-20	3529033.00	220.00	SORTIE	VOLVO 22299A73	\N	480	f	663472.00	THAMI	206528	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9771	1	2026-04-20	3529413.00	280.00	SORTIE	MAN 28659D1	\N	410	f	112127.00	CHOUAIB	206530	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9772	1	2026-04-20	3529465.00	52.00	SORTIE	HYUNDAI 18516A73	\N	471	f	351414.00	NOURDINE	206531	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9774	1	2026-04-20	3529521.00	15.00	SORTIE	MIT 4969A73	\N	409	f	974941.00	CHOUAIB	206533	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9775	1	2026-04-20	3529556.00	35.00	SORTIE	FENWICK	\N	430	f	28599.00	ABDELKHALEK	206534	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9777	1	2026-04-20	3529638.00	50.00	SORTIE	MANITOU	\N	426	f	1278.00	SAID	206536	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9778	1	2026-04-21	3529808.00	170.00	SORTIE	MIT 11469A73	\N	435	f	993652.00	ABDELKHALEK	206537	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9781	1	2026-04-21	3530374.00	450.00	SORTIE	VOLVO 17885A73	\N	438	f	777854.00	HOUSSAM	206540	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9782	1	2026-04-21	3530574.00	200.00	SORTIE	VOLVO 22300A73	\N	481	f	757396.00	MUSTAPHA	206541	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9783	1	2026-04-21	3530662.00	88.00	SORTIE	VOLVO 22299A73	\N	480	f	663743.00	THAMI	206542	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9784	1	2026-04-21	3530975.00	313.00	SORTIE	VOLVO 17886A73	\N	439	f	743120.00	MJID	206543	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9785	1	2026-04-21	3531076.00	101.00	SORTIE	CHARGEUSE G 938	\N	413	f	\N	ABDERRAHIM	206544	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9786	1	2026-04-21	3531110.00	34.00	SORTIE	LINDE	\N	434	f	8146.60	MILOUD	206545	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9787	1	2026-04-21	3531299.00	189.00	SORTIE	RENAULT 25636A13	\N	411	f	190528.00	YASSINE	206546	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9788	1	2026-04-21	3531337.00	38.00	SORTIE	LINDE	\N	477	f	9770.40	CHAABI	206547	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9789	1	2026-04-21	3531361.00	24.00	SORTIE	LINDE	\N	427	f	3036.00	JAWAD	206548	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9790	1	2026-04-21	3531511.00	150.00	SORTIE	MAN 4790B8	\N	403	f	995100.00	KARDODI	206549	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9791	1	2026-04-21	3531577.00	66.00	SORTIE	VOLVO 22300A73	\N	481	f	757610.00	MUSTAPHA	206550	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9792	1	2026-04-22	3531614.00	37.00	SORTIE	HYUNDAI 22368A73	\N	482	f	249018.00	BADER	206001	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9793	1	2026-04-22	3531681.00	67.00	SORTIE	MIT 11469A73	\N	435	f	993863.00	ABDELKHALEK	206002	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9794	1	2026-04-22	3531737.00	56.00	SORTIE	HYUNDAI 22772A73	\N	479	f	264584.00	HICHAM	206003	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9795	1	2026-04-22	3531947.00	210.00	SORTIE	VOLVO 22299A73	\N	480	f	664525.00	THAMI	206004	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9796	1	2026-04-22	3532091.00	144.00	SORTIE	MIT 4969A73	\N	409	f	975457.00	CHOUAIB	206005	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9798	1	2026-04-22	3532160.00	33.00	SORTIE	HYUNDAI 18516A73	\N	471	f	351622.00	ABDERRAHIM	206007	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9799	1	2026-04-23	3532430.00	270.00	SORTIE	MAN 706A73	\N	407	f	144664.00	SOUFIANE	206008	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9801	1	2026-04-23	3532754.00	18.00	SORTIE	HYUNDAI 18516A73	\N	471	f	351730.00	ABDERRAHIM	206010	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9802	1	2026-04-23	3532858.00	104.00	SORTIE	RENAULT 25636A13	\N	411	f	190895.00	YASSINE	206011	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9804	1	2026-04-23	3533346.00	158.00	SORTIE	MIT 11469A73	\N	435	f	994431.00	ABDELKHALEK	206013	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9808	1	2026-04-23	3534243.00	165.00	SORTIE	VOLVO 22300A73	\N	481	f	758188.00	MUSTAPHA	206017	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9809	1	2026-04-23	3534285.00	42.00	SORTIE	MIT 4969A73	\N	409	f	975600.00	CHOUAIB	206018	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9810	1	2026-04-23	3534320.00	35.00	SORTIE	FENWICK	\N	430	f	28612.00	SAID	206019	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9812	1	2026-04-23	3534383.00	25.00	SORTIE	LINDE	\N	477	f	9780.60	CHAABI	206021	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9814	1	2026-04-23	3534978.00	36.00	SORTIE	VOLVO 22300A73	\N	481	f	758332.00	MUSTAPHA	206023	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9815	1	2026-04-24	3535162.00	184.00	SORTIE	VOLVO 22299A73	\N	480	f	664229.00	THAMI	206024	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9816	1	2026-04-24	3535237.00	75.00	SORTIE	ISUZU 26128A8	\N	401	f	895664.00	TOUFIK	206025	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9817	1	2026-04-24	3535254.00	17.00	SORTIE	HYUNDAI 22368A73	\N	482	f	249323.00	BADER	206026	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9819	1	2026-04-24	3535518.00	230.00	SORTIE	MAN 28659D1	\N	410	f	112817.00	CHOUAIB	206028	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9820	1	2026-04-24	3535721.00	203.00	SORTIE	CHARGEUSE G 938	\N	413	f	8704.20	ABDERRAHIM	206029	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9823	1	2026-04-24	3535910.00	37.00	SORTIE	KANGO 4812A73	\N	419	f	\N	TARMONIA	206032	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9824	1	2026-04-24	3536103.00	193.00	SORTIE	MIT 4703A73	\N	408	f	595420.00	MUSTAPHA	206033	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9826	1	2026-04-24	3536189.00	52.00	SORTIE	LINDE	\N	428	f	4097.20	JAWAD	206035	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9827	1	2026-04-24	3536464.00	275.00	SORTIE	VOLVO 17886A73	\N	439	f	744116.00	MJID	206036	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9828	1	2026-04-24	3536635.00	171.00	SORTIE	MIT 11469A73	\N	435	f	995009.00	ABDELKHALEK	206037	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9829	1	2026-04-24	3536789.00	154.00	SORTIE	RENAULT 25636A13	\N	411	f	191476.00	YASSINE	206038	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9830	1	2026-04-24	3536835.00	46.00	SORTIE	HYUNDAI 22772A73	\N	479	f	264914.00	HICHAM	206039	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9831	1	2026-04-24	3536850.00	15.00	SORTIE	HYUNDAI 18516A73	\N	471	f	351822.00	ABDERRAHIM	206040	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9832	1	2026-04-24	3537357.00	507.00	SORTIE	VOLVO 17885A73	\N	438	f	779162.00	HOUSSAM	206041	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9833	1	2026-04-25	3537501.00	144.00	SORTIE	MIT 4969A73	\N	409	f	976079.00	CHOUAIB	206042	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9835	1	2026-04-25	3537749.00	170.00	SORTIE	VOLVO 22300A73	\N	481	f	759034.00	MUSTAPHA	206044	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9837	1	2026-04-25	3539774.00	24.00	SORTIE	HYUNDAI 18516A73	\N	471	f	351966.00	HICHAM	206046	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9838	1	2026-04-25	3539794.00	20.00	SORTIE	HYUNDAI 22368A73	\N	482	f	249589.00	BADER	206047	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9839	1	2026-04-25	3539865.00	71.00	SORTIE	VOLVO 22300A73	\N	481	f	759303.00	MUSTAPHA	206048	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9840	1	2026-04-25	3539892.00	27.00	SORTIE	FENWICK	\N	430	f	28619.00	SAID	206049	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9841	1	2026-04-25	3539929.00	37.00	SORTIE	LINDE	\N	434	f	8167.60	MILOUD	206050	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9842	1	2026-04-25	3540039.00	110.00	SORTIE	VOLVO 22299A73	\N	480	f	665544.00	THAMI	206051	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9844	1	2026-04-25	3540252.00	186.00	SORTIE	MAN 28659D1	\N	410	f	113417.00	CHOUAIB	206053	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9845	1	2026-04-25	3540271.00	19.00	SORTIE	LINDE	\N	477	f	9789.00	CHAABI	206054	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9846	1	2026-04-25	3540531.00	260.00	SORTIE	VOLVO 17886A73	\N	439	f	745015.00	MJID	206055	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9847	1	2026-04-25	3540561.00	30.00	SORTIE	MIT 4969A73	\N	409	f	976152.00	CHOUAIB	206056	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9848	1	2026-04-27	3540679.00	118.00	SORTIE	MIT 11469A73	\N	435	f	995383.00	ABDELKHALEK	206057	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9849	1	2026-04-27	3540735.00	56.00	SORTIE	HYUNDAI 22772A73	\N	479	f	265305.00	NOURDINE	206058	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9850	1	2026-04-27	3540758.00	23.00	SORTIE	HYUNDAI 18516A73	\N	471	f	352127.00	ABDERRAHIM	206059	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9851	1	2026-04-27	3540908.00	150.00	SORTIE	MAN 4790B8	\N	403	f	995707.00	KARDODI	206060	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9852	1	2026-04-27	3541086.00	178.00	SORTIE	RENAULT 25636A13	\N	411	f	192247.00	YASSINE	206061	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9854	1	2026-04-27	3541412.00	179.00	SORTIE	VOLVO 70352A2	\N	406	f	515985.00	CHOUAIB	206063	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9856	1	2026-04-27	3541513.00	45.00	SORTIE	MIT 11469A73	\N	435	f	995531.00	ABDELKHALEK	206065	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9857	1	2026-04-27	3541785.00	272.00	SORTIE	VOLVO 17885A73	\N	438	f	779862.00	HOUSSAM	206066	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9858	1	2026-04-27	3541822.00	37.00	SORTIE	RENAULT 25636A13	\N	411	f	192412.00	YASSINE	206067	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9861	1	2026-04-28	3542070.00	177.00	SORTIE	MIT 4969A73	\N	409	f	976773.00	CHOUAIB	206070	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9862	1	2026-04-28	3542098.00	28.00	SORTIE	HYUNDAI 22368A73	\N	482	f	249904.00	BADER	206071	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9863	1	2026-04-28	3542261.00	163.00	SORTIE	VOLVO 22299A73	\N	480	f	666090.00	THAMI	206072	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9866	1	2026-04-28	3543044.00	218.00	SORTIE	VOLVO 17886A73	\N	439	f	745874.00	MJID	206075	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9867	1	2026-04-28	3543074.00	30.00	SORTIE	HYUNDAI 18516A73	\N	471	f	352312.00	NOURDINE	206076	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9868	1	2026-04-28	3543279.00	205.00	SORTIE	MAN 28659D1	\N	410	f	114078.00	CHOUAIB	206077	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9869	1	2026-04-28	3543445.00	166.00	SORTIE	VOLVO 22300A73	\N	481	f	759871.00	MUSTAPHA	206078	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9870	1	2026-04-28	3543653.00	208.00	SORTIE	CHARGEUSE G 938	\N	413	f	8723.40	ABDERRAHIM	206079	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9871	1	2026-04-28	3543690.00	37.00	SORTIE	FENWICK	\N	430	f	28633.00	SAID	206080	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9872	1	2026-04-28	3543710.00	20.00	SORTIE	LINDE	\N	477	f	9796.80	CHAABI	206081	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9873	1	2026-04-28	3543747.00	37.00	SORTIE	LINDE	\N	427	f	30381.00	MILOUD	206082	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9874	1	2026-04-28	3543759.00	12.00	SORTIE	MIT 4969A73	\N	409	f	976798.00	CHOUAIB	206083	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9875	1	2026-04-28	3543771.00	12.00	SORTIE	LINDE	\N	428	f	4097.90	JAWAD	206084	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9876	1	2026-04-28	3544061.00	290.00	SORTIE	VOLVO 17885A73	\N	438	f	780804.00	MJID	206085	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9877	1	2026-04-29	3544127.00	66.00	SORTIE	VOLVO 22299A73	\N	480	f	666339.00	THAMI	206086	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9878	1	2026-04-29	3544255.00	128.00	SORTIE	MIT 11469A73	\N	435	f	995958.00	ABDELKHALEK	206087	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9879	1	2026-04-29	3544277.00	22.00	SORTIE	HYUNDAI 18516A73	\N	471	f	352467.00	ABDERRAHIM	206088	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9881	1	2026-04-29	3544508.00	176.00	SORTIE	RENAULT 25636A13	\N	411	f	193044.00	YASSINE	206090	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9884	1	2026-04-29	3544977.00	43.00	SORTIE	MIT 11469A73	\N	435	f	996095.00	ABDELKHALEK	206093	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9885	1	2026-04-29	3545130.00	153.00	SORTIE	MAN 28659D1	\N	410	f	114626.00	CHOUAIB	206094	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9886	1	2026-04-29	3545200.00	70.00	SORTIE	RENAULT 25636A13	\N	411	f	193351.00	YASSINE	206095	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9887	1	2026-04-29	3545240.00	40.00	SORTIE	LINDE	\N	434	f	8185.00	MILOUD	206096	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9888	1	2026-04-29	3545445.00	205.00	SORTIE	MAN 706A73	\N	407	f	145225.00	CHOUAIB	206097	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9890	1	2026-04-30	3545638.00	153.00	SORTIE	MIT 4969A73	\N	409	f	977351.00	CHOUAIB	206099	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9891	1	2026-04-30	3545678.00	40.00	SORTIE	HYUNDAI 22368A73	\N	482	f	250262.00	BADER	206100	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9892	1	2026-04-30	3545763.00	85.00	SORTIE	MANITOU	\N	484	f	6753.00	SAID	206101	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
9894	1	2026-04-30	3546025.00	162.00	SORTIE	VOLVO 22300A73	\N	481	f	760496.00	MUSTAPHA	206103	IMPORT	11	2026-06-12 00:33:33.45069+00	2026-06-12 00:33:33.45069+00
\.


--
-- Data for Name: suivi_vidanges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suivi_vidanges (id, vehicule_id, composant_id, intervalle_nbh, compteur_nbh_actuel, date_dernier_entretien, prochain_entretien_estime, statut, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tracteur_semi_assignment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tracteur_semi_assignment (id, tracteur_id, semi_id, date_debut, date_fin, actif, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: types_intervention; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.types_intervention (id, libelle) FROM stdin;
1	Amélioration
2	Changement
3	Confection
4	Contrôle
5	Démontage
6	Dépannage
7	Diagnostic
8	Montage
9	Préparation
10	Purge
11	Rectification
12	Réglage
13	Essai
14	Rénovation
15	Réparation
16	Vidange
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, prenom, nom, fonction, matricule_emp, site, telephone, dashboard_config, preferences_notifications, created_at, updated_at, refresh_token, refresh_token_expires_at, password_reset_otp, password_reset_otp_expires_at, password_reset_otp_used_at, password_reset_token, password_reset_token_expires_at, actif, role) FROM stdin;
12	magasin.dev@intersig.ma	$2a$12$UnaXkqAW5xuH7Z7hJilXM.UD8GPyTETI5C3HV4TEJve/TklhgpTEq	Magasin	Dev	\N	\N	\N	\N	{}	{}	2026-06-11 20:25:49.874474+00	2026-06-16 07:53:56.722195+00	\N	\N	\N	\N	\N	\N	\N	t	MAGASIN
11	admin.dev@intersig.ma	$2a$12$GMYkOuFpyTxvJodEMQLVzeMSvA0HqlXLXBMA6UArBeJzyAW7mfkhG	Admin	Dev	\N	\N	\N	+212600000001	{}	{}	2026-06-11 20:25:49.494509+00	2026-06-16 07:54:25.007489+00	5e18d7de-a837-486e-a7b3-515092c38e92	2026-06-16 15:54:25.489424+00	\N	\N	\N	\N	\N	t	ADMIN
\.


--
-- Data for Name: vehicules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicules (id, code, type, marque, modele, matricule, n_chassis, annee, carburant, statut, date_mise_service, photo_url, actif, created_at, updated_at, capacite_tonnes, config_axle, visite_tech_tracteur_expiration, visite_tech_semi_expiration, carnet_circulation_expiration, metrologie_expiration, extincteur_expiration, batterie_modele, batterie_date_achat, batterie_date_controle, conso_gasoil_litres_mois, compteur_km, compteur_heures, chauffeur_prenom, chauffeur_nom, config_axle_semi, voyages_mois, km_parcourus, metrologie_date_controle) FROM stdin;
\.


--
-- Name: ai_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_conversations_id_seq', 117, true);


--
-- Name: ai_embeddings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_embeddings_id_seq', 8490, true);


--
-- Name: ai_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_messages_id_seq', 243, true);


--
-- Name: arrivage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.arrivage_id_seq', 92, true);


--
-- Name: bareme_jaugeage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bareme_jaugeage_id_seq', 3, true);


--
-- Name: citerne_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.citerne_id_seq', 1, true);


--
-- Name: composants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.composants_id_seq', 3068, true);


--
-- Name: demandes_achat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.demandes_achat_id_seq', 18, true);


--
-- Name: imports_historique_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.imports_historique_id_seq', 9, true);


--
-- Name: interventions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.interventions_id_seq', 1090, true);


--
-- Name: jaugeage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jaugeage_id_seq', 1, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 66377, true);


--
-- Name: pneu_inspections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pneu_inspections_id_seq', 22, true);


--
-- Name: pneus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pneus_id_seq', 918, true);


--
-- Name: releves_compteur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.releves_compteur_id_seq', 42, true);


--
-- Name: sortie_carburant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sortie_carburant_id_seq', 9894, true);


--
-- Name: suivi_vidanges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suivi_vidanges_id_seq', 75, true);


--
-- Name: tracteur_semi_assignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tracteur_semi_assignment_id_seq', 3, true);


--
-- Name: types_intervention_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.types_intervention_id_seq', 16, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 12, true);


--
-- Name: vehicules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicules_id_seq', 410, true);


--
-- Name: ai_conversations ai_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_pkey PRIMARY KEY (id);


--
-- Name: ai_embeddings ai_embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_embeddings
    ADD CONSTRAINT ai_embeddings_pkey PRIMARY KEY (id);


--
-- Name: ai_messages ai_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_pkey PRIMARY KEY (id);


--
-- Name: arrivage arrivage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.arrivage
    ADD CONSTRAINT arrivage_pkey PRIMARY KEY (id);


--
-- Name: bareme_jaugeage bareme_jaugeage_citerne_id_hauteur_cm_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bareme_jaugeage
    ADD CONSTRAINT bareme_jaugeage_citerne_id_hauteur_cm_key UNIQUE (citerne_id, hauteur_cm);


--
-- Name: bareme_jaugeage bareme_jaugeage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bareme_jaugeage
    ADD CONSTRAINT bareme_jaugeage_pkey PRIMARY KEY (id);


--
-- Name: citerne citerne_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.citerne
    ADD CONSTRAINT citerne_pkey PRIMARY KEY (id);


--
-- Name: composants composants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composants
    ADD CONSTRAINT composants_pkey PRIMARY KEY (id);


--
-- Name: demandes_achat demandes_achat_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demandes_achat
    ADD CONSTRAINT demandes_achat_code_key UNIQUE (code);


--
-- Name: demandes_achat demandes_achat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demandes_achat
    ADD CONSTRAINT demandes_achat_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_fleet_core flyway_schema_history_fleet_core_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history_fleet_core
    ADD CONSTRAINT flyway_schema_history_fleet_core_pk PRIMARY KEY (installed_rank);


--
-- Name: flyway_schema_history_magasin flyway_schema_history_magasin_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history_magasin
    ADD CONSTRAINT flyway_schema_history_magasin_pk PRIMARY KEY (installed_rank);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: imports_historique imports_historique_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imports_historique
    ADD CONSTRAINT imports_historique_pkey PRIMARY KEY (id);


--
-- Name: interventions interventions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interventions
    ADD CONSTRAINT interventions_pkey PRIMARY KEY (id);


--
-- Name: jaugeage jaugeage_citerne_id_date_jaugeage_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jaugeage
    ADD CONSTRAINT jaugeage_citerne_id_date_jaugeage_key UNIQUE (citerne_id, date_jaugeage);


--
-- Name: jaugeage jaugeage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jaugeage
    ADD CONSTRAINT jaugeage_pkey PRIMARY KEY (id);


--
-- Name: kpi_matview_refresh kpi_matview_refresh_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_matview_refresh
    ADD CONSTRAINT kpi_matview_refresh_pkey PRIMARY KEY (matview_name);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: pneu_inspections pneu_inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pneu_inspections
    ADD CONSTRAINT pneu_inspections_pkey PRIMARY KEY (id);


--
-- Name: pneus pneus_n_serie_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pneus
    ADD CONSTRAINT pneus_n_serie_key UNIQUE (n_serie);


--
-- Name: pneus pneus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pneus
    ADD CONSTRAINT pneus_pkey PRIMARY KEY (id);


--
-- Name: releves_compteur releves_compteur_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.releves_compteur
    ADD CONSTRAINT releves_compteur_pkey PRIMARY KEY (id);


--
-- Name: sortie_carburant sortie_carburant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sortie_carburant
    ADD CONSTRAINT sortie_carburant_pkey PRIMARY KEY (id);


--
-- Name: suivi_vidanges suivi_vidanges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suivi_vidanges
    ADD CONSTRAINT suivi_vidanges_pkey PRIMARY KEY (id);


--
-- Name: tracteur_semi_assignment tracteur_semi_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracteur_semi_assignment
    ADD CONSTRAINT tracteur_semi_assignment_pkey PRIMARY KEY (id);


--
-- Name: types_intervention types_intervention_libelle_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types_intervention
    ADD CONSTRAINT types_intervention_libelle_key UNIQUE (libelle);


--
-- Name: types_intervention types_intervention_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types_intervention
    ADD CONSTRAINT types_intervention_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vehicules vehicules_code_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicules
    ADD CONSTRAINT vehicules_code_type_key UNIQUE (code, type);


--
-- Name: vehicules vehicules_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicules
    ADD CONSTRAINT vehicules_matricule_key UNIQUE (matricule);


--
-- Name: vehicules vehicules_n_chassis_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicules
    ADD CONSTRAINT vehicules_n_chassis_key UNIQUE (n_chassis);


--
-- Name: vehicules vehicules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicules
    ADD CONSTRAINT vehicules_pkey PRIMARY KEY (id);


--
-- Name: composants_vehicule_reference_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX composants_vehicule_reference_uq ON public.composants USING btree (vehicule_id, reference) WHERE ((vehicule_id IS NOT NULL) AND (reference IS NOT NULL));


--
-- Name: flyway_schema_history_fleet_core_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_fleet_core_s_idx ON public.flyway_schema_history_fleet_core USING btree (success);


--
-- Name: flyway_schema_history_magasin_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_magasin_s_idx ON public.flyway_schema_history_magasin USING btree (success);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_ai_conv_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_conv_user ON public.ai_conversations USING btree (user_id, updated_at DESC);


--
-- Name: idx_ai_emb_vector; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_emb_vector ON public.ai_embeddings USING ivfflat (embedding public.vector_cosine_ops);


--
-- Name: idx_ai_embeddings_ivfflat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_embeddings_ivfflat ON public.ai_embeddings USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_ai_msg_conv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_msg_conv ON public.ai_messages USING btree (conversation_id, created_at);


--
-- Name: idx_arrivage_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_arrivage_date ON public.arrivage USING btree (date_arrivage);


--
-- Name: idx_composants_vehicule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_composants_vehicule_id ON public.composants USING btree (vehicule_id);


--
-- Name: idx_composants_vehicule_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_composants_vehicule_type ON public.composants USING btree (vehicule_type);


--
-- Name: idx_demandes_achat_statut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_demandes_achat_statut ON public.demandes_achat USING btree (statut, date_demande DESC);


--
-- Name: idx_interventions_vehicule_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_interventions_vehicule_date ON public.interventions USING btree (vehicule_id, date_debut DESC);


--
-- Name: idx_notifications_dedup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_dedup ON public.notifications USING btree (user_id, categorie, target_id, created_at DESC);


--
-- Name: idx_notifs_user_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifs_user_unread ON public.notifications USING btree (user_id, lu, created_at DESC);


--
-- Name: idx_pneus_position_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_pneus_position_active ON public.pneus USING btree (vehicule_id, "position") WHERE (actif = true);


--
-- Name: idx_pneus_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pneus_status ON public.pneus USING btree (status) WHERE ((status)::text <> 'ok'::text);


--
-- Name: idx_pneus_vehicule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pneus_vehicule ON public.pneus USING btree (vehicule_id);


--
-- Name: idx_releves_vehicule_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_releves_vehicule_date ON public.releves_compteur USING btree (vehicule_id, date_releve DESC);


--
-- Name: idx_sortie_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sortie_code ON public.sortie_carburant USING btree (vehicule_code);


--
-- Name: idx_sortie_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sortie_date ON public.sortie_carburant USING btree (date_sortie);


--
-- Name: idx_sortie_vehicule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sortie_vehicule ON public.sortie_carburant USING btree (vehicule_id, date_sortie);


--
-- Name: idx_tsa_semi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tsa_semi ON public.tracteur_semi_assignment USING btree (semi_id);


--
-- Name: idx_tsa_tracteur; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tsa_tracteur ON public.tracteur_semi_assignment USING btree (tracteur_id);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_vehicules_actif_type_statut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicules_actif_type_statut ON public.vehicules USING btree (actif, type, statut);


--
-- Name: idx_vehicules_code_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicules_code_trgm ON public.vehicules USING gin (lower((code)::text) public.gin_trgm_ops);


--
-- Name: idx_vehicules_marque_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicules_marque_trgm ON public.vehicules USING gin (lower((marque)::text) public.gin_trgm_ops);


--
-- Name: idx_vehicules_matricule_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicules_matricule_trgm ON public.vehicules USING gin (lower((matricule)::text) public.gin_trgm_ops);


--
-- Name: idx_vehicules_modele_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicules_modele_trgm ON public.vehicules USING gin (lower((modele)::text) public.gin_trgm_ops);


--
-- Name: idx_vehicules_nchassis_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicules_nchassis_trgm ON public.vehicules USING gin (lower((n_chassis)::text) public.gin_trgm_ops);


--
-- Name: mv_kpis_couts_mois_mois; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_kpis_couts_mois_mois ON public.mv_kpis_couts_mois USING btree (mois);


--
-- Name: mv_kpis_dispo_jour; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_kpis_dispo_jour ON public.mv_kpis_dispo USING btree (jour);


--
-- Name: mv_kpis_km_mois_mois; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_kpis_km_mois_mois ON public.mv_kpis_km_mois USING btree (mois);


--
-- Name: uidx_tsa_semi_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uidx_tsa_semi_active ON public.tracteur_semi_assignment USING btree (semi_id) WHERE ((date_fin IS NULL) AND (actif = true));


--
-- Name: uidx_tsa_tracteur_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uidx_tsa_tracteur_active ON public.tracteur_semi_assignment USING btree (tracteur_id) WHERE ((date_fin IS NULL) AND (actif = true));


--
-- Name: ai_embeddings trg_ai_embeddings_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ai_embeddings_updated_at BEFORE UPDATE ON public.ai_embeddings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: composants trg_composants_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_composants_updated_at BEFORE UPDATE ON public.composants FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: demandes_achat trg_demandes_achat_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_demandes_achat_updated_at BEFORE UPDATE ON public.demandes_achat FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: imports_historique trg_imports_historique_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_imports_historique_updated_at BEFORE UPDATE ON public.imports_historique FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: interventions trg_interventions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_interventions_updated_at BEFORE UPDATE ON public.interventions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: notifications trg_notifications_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_notifications_updated_at BEFORE UPDATE ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: pneu_inspections trg_pneu_inspections_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_pneu_inspections_updated_at BEFORE UPDATE ON public.pneu_inspections FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: pneus trg_pneu_status; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_pneu_status BEFORE UPDATE ON public.pneus FOR EACH ROW EXECUTE FUNCTION public.update_pneu_status();


--
-- Name: pneus trg_pneus_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_pneus_updated_at BEFORE UPDATE ON public.pneus FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: releves_compteur trg_releve_pneus; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_releve_pneus AFTER INSERT ON public.releves_compteur FOR EACH ROW EXECUTE FUNCTION public.process_releve();


--
-- Name: releves_compteur trg_releves_compteur_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_releves_compteur_updated_at BEFORE UPDATE ON public.releves_compteur FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: suivi_vidanges trg_suivi_vidanges_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_suivi_vidanges_updated_at BEFORE UPDATE ON public.suivi_vidanges FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: users trg_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: vehicules trg_vehicules_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_vehicules_updated_at BEFORE UPDATE ON public.vehicules FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: tracteur_semi_assignment tsa_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tsa_updated_at BEFORE UPDATE ON public.tracteur_semi_assignment FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: ai_conversations ai_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_messages ai_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ai_conversations(id) ON DELETE CASCADE;


--
-- Name: arrivage arrivage_citerne_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.arrivage
    ADD CONSTRAINT arrivage_citerne_id_fkey FOREIGN KEY (citerne_id) REFERENCES public.citerne(id);


--
-- Name: bareme_jaugeage bareme_jaugeage_citerne_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bareme_jaugeage
    ADD CONSTRAINT bareme_jaugeage_citerne_id_fkey FOREIGN KEY (citerne_id) REFERENCES public.citerne(id) ON DELETE CASCADE;


--
-- Name: composants composants_cree_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composants
    ADD CONSTRAINT composants_cree_par_fkey FOREIGN KEY (cree_par) REFERENCES public.users(id);


--
-- Name: composants composants_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composants
    ADD CONSTRAINT composants_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.composants(id);


--
-- Name: composants composants_vehicule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composants
    ADD CONSTRAINT composants_vehicule_id_fkey FOREIGN KEY (vehicule_id) REFERENCES public.vehicules(id);


--
-- Name: demandes_achat demandes_achat_approbateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demandes_achat
    ADD CONSTRAINT demandes_achat_approbateur_id_fkey FOREIGN KEY (approbateur_id) REFERENCES public.users(id);


--
-- Name: demandes_achat demandes_achat_composant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demandes_achat
    ADD CONSTRAINT demandes_achat_composant_id_fkey FOREIGN KEY (composant_id) REFERENCES public.composants(id);


--
-- Name: demandes_achat demandes_achat_demandeur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demandes_achat
    ADD CONSTRAINT demandes_achat_demandeur_id_fkey FOREIGN KEY (demandeur_id) REFERENCES public.users(id);


--
-- Name: imports_historique imports_historique_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imports_historique
    ADD CONSTRAINT imports_historique_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: interventions interventions_composant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interventions
    ADD CONSTRAINT interventions_composant_id_fkey FOREIGN KEY (composant_id) REFERENCES public.composants(id);


--
-- Name: interventions interventions_demande_achat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interventions
    ADD CONSTRAINT interventions_demande_achat_id_fkey FOREIGN KEY (demande_achat_id) REFERENCES public.demandes_achat(id);


--
-- Name: interventions interventions_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interventions
    ADD CONSTRAINT interventions_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.types_intervention(id);


--
-- Name: interventions interventions_vehicule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interventions
    ADD CONSTRAINT interventions_vehicule_id_fkey FOREIGN KEY (vehicule_id) REFERENCES public.vehicules(id);


--
-- Name: jaugeage jaugeage_citerne_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jaugeage
    ADD CONSTRAINT jaugeage_citerne_id_fkey FOREIGN KEY (citerne_id) REFERENCES public.citerne(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_vehicule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_vehicule_id_fkey FOREIGN KEY (vehicule_id) REFERENCES public.vehicules(id);


--
-- Name: pneu_inspections pneu_inspections_pneu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pneu_inspections
    ADD CONSTRAINT pneu_inspections_pneu_id_fkey FOREIGN KEY (pneu_id) REFERENCES public.pneus(id);


--
-- Name: pneu_inspections pneu_inspections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pneu_inspections
    ADD CONSTRAINT pneu_inspections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pneus pneus_composant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pneus
    ADD CONSTRAINT pneus_composant_id_fkey FOREIGN KEY (composant_id) REFERENCES public.composants(id);


--
-- Name: pneus pneus_vehicule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pneus
    ADD CONSTRAINT pneus_vehicule_id_fkey FOREIGN KEY (vehicule_id) REFERENCES public.vehicules(id);


--
-- Name: releves_compteur releves_compteur_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.releves_compteur
    ADD CONSTRAINT releves_compteur_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: releves_compteur releves_compteur_import_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.releves_compteur
    ADD CONSTRAINT releves_compteur_import_id_fkey FOREIGN KEY (import_id) REFERENCES public.imports_historique(id);


--
-- Name: releves_compteur releves_compteur_vehicule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.releves_compteur
    ADD CONSTRAINT releves_compteur_vehicule_id_fkey FOREIGN KEY (vehicule_id) REFERENCES public.vehicules(id);


--
-- Name: sortie_carburant sortie_carburant_citerne_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sortie_carburant
    ADD CONSTRAINT sortie_carburant_citerne_id_fkey FOREIGN KEY (citerne_id) REFERENCES public.citerne(id);


--
-- Name: sortie_carburant sortie_carburant_vehicule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sortie_carburant
    ADD CONSTRAINT sortie_carburant_vehicule_id_fkey FOREIGN KEY (vehicule_id) REFERENCES public.vehicules(id) ON DELETE SET NULL;


--
-- Name: suivi_vidanges suivi_vidanges_composant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suivi_vidanges
    ADD CONSTRAINT suivi_vidanges_composant_id_fkey FOREIGN KEY (composant_id) REFERENCES public.composants(id);


--
-- Name: suivi_vidanges suivi_vidanges_vehicule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suivi_vidanges
    ADD CONSTRAINT suivi_vidanges_vehicule_id_fkey FOREIGN KEY (vehicule_id) REFERENCES public.vehicules(id);


--
-- Name: tracteur_semi_assignment tracteur_semi_assignment_semi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracteur_semi_assignment
    ADD CONSTRAINT tracteur_semi_assignment_semi_id_fkey FOREIGN KEY (semi_id) REFERENCES public.vehicules(id);


--
-- Name: tracteur_semi_assignment tracteur_semi_assignment_tracteur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracteur_semi_assignment
    ADD CONSTRAINT tracteur_semi_assignment_tracteur_id_fkey FOREIGN KEY (tracteur_id) REFERENCES public.vehicules(id);


--
-- Name: mv_kpis_couts_mois; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_kpis_couts_mois;


--
-- Name: mv_kpis_dispo; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_kpis_dispo;


--
-- Name: mv_kpis_km_mois; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_kpis_km_mois;


--
-- PostgreSQL database dump complete
--

\unrestrict FsGuBOHkuJnfxNOSelghfkBcLywPABCuoUCxyHPShBqwjrwW4A82hcgpSMKMhEZ

